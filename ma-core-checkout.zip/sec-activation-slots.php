<?php
/**
 * SEC Activation Slots
 *
 * 10 rolling slots per 24 hours. Each slot is claimed on successful checkout
 * and auto-released after 24 hours. When all slots are taken, visitors join
 * a waitlist and are emailed the moment any slot becomes available.
 *
 * USAGE IN YOUR MAIN PLUGIN FILE:
 *   require_once plugin_dir_path(__FILE__) . 'sec-activation-slots.php';
 *   add_action('plugins_loaded', ['SEC_Activation_Slots', 'init']);
 *
 * ON SUCCESSFUL STRIPE CHECKOUT:
 *   SEC_Activation_Slots::claim_slot($customer_email);
 */

if (!defined('ABSPATH')) exit;

class SEC_Activation_Slots {

    const TOTAL_SLOTS     = 10;
    const SLOT_DURATION   = 86400; // 24 hours in seconds
    const OPTION_SLOTS    = 'sec_activation_slots';
    const OPTION_WAITLIST = 'sec_activation_waitlist';

    /* ── Bootstrap ──────────────────────────────────────────────── */

    public static function init() {
        add_filter('cron_schedules', [__CLASS__, 'add_cron_interval']);
        add_action('rest_api_init',  [__CLASS__, 'register_rest_routes']);
        add_action('sec_check_expired_slots', [__CLASS__, 'release_expired_slots']);
        add_action('sec_auto_reserve_slots', [__CLASS__, 'auto_reserve_daily_slots']);

        // AJAX handlers for admin
        add_action('wp_ajax_sec_reserve_slots_manual', [__CLASS__, 'ajax_reserve_slots']);

        if (!wp_next_scheduled('sec_check_expired_slots')) {
            wp_schedule_event(time(), 'sec_every_minute', 'sec_check_expired_slots');
        }

        // Setup automatic slot reservation if enabled
        self::setup_auto_reservation();
    }

    public static function add_cron_interval($schedules) {
        $schedules['sec_every_minute'] = [
            'interval' => 60,
            'display'  => 'Every Minute (SEC Slots)',
        ];
        return $schedules;
    }

    /* ── REST Routes ────────────────────────────────────────────── */

    public static function register_rest_routes() {
        register_rest_route('sec/v1', '/slots', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'rest_get_slots'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('sec/v1', '/slots/free', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'rest_free_slots'],
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
            'args' => [
                'count' => ['required' => true, 'sanitize_callback' => 'absint'],
                'nonce' => ['required' => true],
            ],
        ]);

        register_rest_route('sec/v1', '/waitlist', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'rest_join_waitlist'],
            'permission_callback' => '__return_true',
            'args' => [
                'email' => ['required' => true, 'sanitize_callback' => 'sanitize_email'],
                'name'  => ['required' => false, 'sanitize_callback' => 'sanitize_text_field'],
                'nonce' => ['required' => true],
            ],
        ]);

        register_rest_route('sec/v1', '/waitlist/list', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'rest_get_waitlist'],
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ]);
    }

    /* ── REST: GET /slots ───────────────────────────────────────── */

    public static function rest_get_slots() {
        self::release_expired_slots();

        $slots     = self::get_slots();
        $now       = time();
        $active    = array_filter($slots, fn($s) => $s['active']);
        $available = self::TOTAL_SLOTS - count($active);

        $public_slots = array_map(function($s) use ($now) {
            $expires_in = null;
            if ($s['active']) {
                $expires_in = max(0, ($s['claimed_at'] + self::SLOT_DURATION) - $now);
            }
            return [
                'active'      => $s['active'],
                'expires_in'  => $expires_in, // seconds until this slot reopens
            ];
        }, $slots);

        return rest_ensure_response([
            'available' => max(0, $available),
            'total'     => self::TOTAL_SLOTS,
            'slots'     => array_values($public_slots),
        ]);
    }

    /* ── REST: POST /slots/free ─────────────────────────────────── */

    public static function rest_free_slots(WP_REST_Request $request) {
        if (!wp_verify_nonce($request->get_param('nonce'), 'sec_admin_nonce')) {
            return new WP_Error('invalid_nonce', 'Security check failed.', ['status' => 403]);
        }

        $count = $request->get_param('count');
        if ($count <= 0) {
            return new WP_Error('invalid_count', 'Count must be greater than 0.', ['status' => 400]);
        }

        $freed = self::free_slots_manual($count);

        return rest_ensure_response([
            'success' => true,
            'freed'   => $freed,
            'message' => "Successfully freed {$freed} slot(s). Waitlist members have been notified.",
        ]);
    }

    /* ── REST: GET /waitlist/list ───────────────────────────────── */

    public static function rest_get_waitlist() {
        $list = self::get_waitlist();
        return rest_ensure_response([
            'success' => true,
            'count'   => count($list),
            'waitlist' => $list,
        ]);
    }

    /* ── AJAX: Reserve Slots ────────────────────────────────────── */

    public static function ajax_reserve_slots() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_admin_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to reserve slots.'));
        }

        $count = intval($_POST['count'] ?? 0);
        if ($count <= 0) {
            wp_send_json_error(array('message' => 'Invalid count.'));
        }

        $success = self::take_slots_manual($count);

        if ($success) {
            wp_send_json_success(array(
                'message' => "Successfully reserved {$count} slot(s) for 24 hours."
            ));
        } else {
            wp_send_json_error(array(
                'message' => 'No available slots to reserve.'
            ));
        }
    }

    /* ── REST: POST /waitlist ───────────────────────────────────── */

    public static function rest_join_waitlist(WP_REST_Request $request) {
        if (!wp_verify_nonce($request->get_param('nonce'), 'sec_waitlist_nonce')) {
            return new WP_Error('invalid_nonce', 'Security check failed.', ['status' => 403]);
        }

        $email = $request->get_param('email');
        $name  = $request->get_param('name') ?: '';

        if (!$email || !is_email($email)) {
            return new WP_Error('invalid_email', 'A valid email is required.', ['status' => 400]);
        }

        // Re-check: slot may have freed up while they were reading
        self::release_expired_slots();
        if (self::get_available_count() > 0) {
            return rest_ensure_response([
                'success' => false,
                'reload'  => true,
                'message' => 'Great news — a slot just opened up! Refreshing now…',
            ]);
        }

        $added = self::add_to_waitlist($email, $name);

        if (!$added) {
            return rest_ensure_response([
                'success' => true,
                'already' => true,
                'message' => "You're already on the waitlist. We'll notify you the moment a slot opens.",
            ]);
        }

        self::send_waitlist_confirmation_email($email, $name);

        return rest_ensure_response([
            'success' => true,
            'message' => "You're on the list! We'll email you as soon as a slot opens.",
        ]);
    }

    /* ── Slot Data ──────────────────────────────────────────────── */

    public static function get_slots(): array {
        $slots = get_option(self::OPTION_SLOTS, []);
        while (count($slots) < self::TOTAL_SLOTS) {
            $slots[] = ['active' => false, 'claimed_at' => 0, 'email' => ''];
        }
        return array_slice($slots, 0, self::TOTAL_SLOTS);
    }

    public static function save_slots(array $slots): void {
        update_option(self::OPTION_SLOTS, $slots, false);
    }

    public static function get_available_count(): int {
        $slots  = self::get_slots();
        $active = array_filter($slots, fn($s) => $s['active']);
        return max(0, self::TOTAL_SLOTS - count($active));
    }

    /* ── Claim a Slot (call after successful Stripe checkout) ───── */

    public static function claim_slot(string $email = ''): bool {
        self::release_expired_slots();
        $slots = self::get_slots();

        foreach ($slots as &$slot) {
            if (!$slot['active']) {
                $slot['active']     = true;
                $slot['claimed_at'] = time();
                $slot['email']      = sanitize_email($email);
                self::save_slots($slots);
                return true;
            }
        }
        unset($slot);
        return false;
    }

    /* ── Release Expired Slots (runs every minute via cron) ─────── */

    public static function release_expired_slots(): void {
        $slots   = self::get_slots();
        $changed = false;
        $freed   = 0;

        foreach ($slots as &$slot) {
            if ($slot['active'] && (time() - $slot['claimed_at']) >= self::SLOT_DURATION) {
                $slot['active']     = false;
                $slot['claimed_at'] = 0;
                $slot['email']      = '';
                $changed = true;
                $freed++;
            }
        }
        unset($slot);

        if ($changed) {
            self::save_slots($slots);
            if ($freed > 0) {
                // Notify exactly N people from waitlist, where N = number of freed slots
                self::notify_waitlist($freed);
            }
        }
    }

    /* ── Waitlist ───────────────────────────────────────────────── */

    public static function get_waitlist(): array {
        return get_option(self::OPTION_WAITLIST, []);
    }

    public static function add_to_waitlist(string $email, string $name = ''): bool {
        $list = self::get_waitlist();
        foreach ($list as $entry) {
            if (strtolower($entry['email']) === strtolower($email)) {
                return false;
            }
        }
        $list[] = [
            'email'    => $email,
            'name'     => sanitize_text_field($name),
            'added_at' => time(),
        ];
        update_option(self::OPTION_WAITLIST, $list, false);
        return true;
    }

    /**
     * Notify waitlist members (first-come, first-served)
     * Only notifies as many people as there are available slots
     *
     * @param int $slots_freed Number of slots that just became available (optional)
     */
    public static function notify_waitlist(int $slots_freed = null): void {
        $list = self::get_waitlist();
        if (empty($list)) return;

        $available = $slots_freed ?? self::get_available_count();
        if ($available <= 0) return;

        // Only notify the first N people (where N = available slots)
        $to_notify = array_slice($list, 0, $available);
        $remaining = array_slice($list, $available);

        // Send notifications to the first people on the list
        foreach ($to_notify as $entry) {
            self::send_waitlist_notification_email($entry['email'], $entry['name'] ?? '');
            error_log('SEC Slots: Notified waitlist member: ' . $entry['email']);
        }

        // Update waitlist to remove notified people (keep the rest)
        update_option(self::OPTION_WAITLIST, $remaining, false);
    }

    /* ── Emails ─────────────────────────────────────────────────── */

    private static function get_mailer(): \PHPMailer\PHPMailer\PHPMailer {
        if (!class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
            require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
            require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
            require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
        }
        $m = new \PHPMailer\PHPMailer\PHPMailer(true);
        $m->isSMTP();
        $m->Host       = SMTP_HOST;
        $m->SMTPAuth   = SMTP_AUTH;
        $m->Username   = SMTP_USERNAME;
        $m->Password   = SMTP_PASSWORD;
        $m->SMTPSecure = SMTP_SECURE;
        $m->Port       = SMTP_PORT;
        $m->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
        $m->setFrom(SMTP_USERNAME, 'Marketing Aid');
        $m->isHTML(true);
        return $m;
    }

    private static function email_wrapper(string $inner_html, string $banner = ''): string {
        return <<<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f9f9f9;font-family:Arial,sans-serif;color:#333;">
<table width="100%" bgcolor="#f9f9f9" cellpadding="0" cellspacing="0"><tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" bgcolor="#ffffff"
       style="border:1px solid #ddd;border-radius:8px;overflow:hidden;margin:32px 0;">
  <tr>
    <td align="center" style="background:#000;padding:20px;">
      <a href="https://marketingaid.org/" target="_blank">
        <img src="https://marketingaid.org/LogoLarge.png" height="50"
             alt="Marketing Aid Logo" style="display:block;margin:0 auto;">
      </a>
    </td>
  </tr>
  {$banner}
  <tr><td style="padding:36px 36px 28px;font-size:16px;line-height:1.6;">{$inner_html}</td></tr>
  <tr>
    <td align="center" style="background:#f1f1f1;padding:16px;font-size:12px;color:#999;">
      &copy; 2026 Marketing Aid. All rights reserved.
    </td>
  </tr>
</table>
</td></tr></table>
</body></html>
HTML;
    }

    public static function send_waitlist_confirmation_email(string $email, string $name): void {
        $email    = sanitize_email($email);
        if (!is_email($email)) return;
        $greeting = $name ? 'Hi ' . esc_html($name) . ',' : 'Hi there,';

        $body = self::email_wrapper(<<<BODY
<p>{$greeting}</p>
<p>You've been added to the <strong>Platform Activation waitlist</strong>.</p>
<p>We only open <strong>10 activation slots per day</strong>, so spots go quickly.
   The moment one becomes available you'll receive an email with a direct link —
   so you can claim your spot before anyone else.</p>
<p style="font-size:13px;color:#888;margin-top:24px;">
  Didn't sign up? You can safely ignore this email.
</p>
<p style="margin-top:26px;">— <strong>The Marketing Aid Team</strong></p>
BODY);

        try {
            $m = self::get_mailer();
            $m->addAddress($email);
            $m->Subject = "You're on the waitlist — Marketing Aid Platform";
            $m->Body    = $body;
            $m->send();
        } catch (\Exception $e) {
            error_log('📧 Waitlist Confirmation Error: ' . $e->getMessage());
        }
    }

    public static function send_waitlist_notification_email(string $email, string $name): void {
        $email    = sanitize_email($email);
        if (!is_email($email)) return;
        $greeting     = $name ? 'Hi ' . esc_html($name) . ',' : 'Hi there,';
        $checkout_url = esc_url(home_url('/#activate')); // ← update to your checkout URL
        $available    = self::get_available_count();

        $banner = <<<BANNER
<tr>
  <td align="center"
      style="background:linear-gradient(135deg,#139204,#36b827);
             padding:16px 28px;color:#fff;font-size:15px;font-weight:600;">
    🟢 A slot just opened — {$available} available right now
  </td>
</tr>
BANNER;

        $body = self::email_wrapper(<<<BODY
<p>{$greeting}</p>
<p>Good news — a <strong>Platform Activation slot</strong> just opened and you're
   being notified first because you joined our waitlist.</p>
<p>Slots are first-come, first-served and each carries a <strong>24-hour timer</strong>,
   so act quickly.</p>
<div style="text-align:center;margin:32px 0;">
  <a href="{$checkout_url}"
     style="display:inline-block;background:linear-gradient(135deg,#139204,#36b827);
            color:#fff;text-decoration:none;font-size:17px;font-weight:700;
            padding:16px 44px;border-radius:10px;">
    Activate My Platform — $29/mo
  </a>
</div>
<p style="font-size:13px;color:#888;text-align:center;">
  You're receiving this because you joined our waitlist. If you've already activated,
  you can safely ignore this email.
</p>
<p style="margin-top:26px;">— <strong>The Marketing Aid Team</strong></p>
BODY, $banner);

        try {
            $m = self::get_mailer();
            $m->addAddress($email);
            $m->Subject = '🟢 A Platform Activation slot just opened — claim it now';
            $m->Body    = $body;
            $m->send();
        } catch (\Exception $e) {
            error_log('📧 Waitlist Notification Error: ' . $e->getMessage());
        }
    }

    /* ── Admin Helpers ──────────────────────────────────────────── */

    public static function admin_summary(): array {
        self::release_expired_slots();
        $slots    = self::get_slots();
        $waitlist = self::get_waitlist();
        $active   = array_filter($slots, fn($s) => $s['active']);
        return [
            'total'          => self::TOTAL_SLOTS,
            'active'         => count($active),
            'available'      => self::TOTAL_SLOTS - count($active),
            'waitlist_count' => count($waitlist),
            'slots'          => $slots,
        ];
    }

    public static function reset_all_slots(): void {
        delete_option(self::OPTION_SLOTS);
    }

    /** Run on plugin activation */
    public static function activate(): void {
        self::init();
        // Force first slot check
        self::release_expired_slots();
    }

    /** Run on plugin deactivation */
    public static function deactivate(): void {
        wp_clear_scheduled_hook('sec_check_expired_slots');
        wp_clear_scheduled_hook('sec_auto_reserve_slots');
    }

    /* ── Manual & Automatic Slot Reservation ─────────────────────── */

    /**
     * Get total number of slots
     */
    public static function get_total_slots(): int {
        return self::TOTAL_SLOTS;
    }

    /**
     * Get number of available slots (alias for get_available_count)
     */
    public static function get_available_slots(): int {
        return self::get_available_count();
    }

    /**
     * Manually reserve slots for 24 hours
     */
    public static function take_slots_manual(int $count): bool {
        self::release_expired_slots();
        $slots = self::get_slots();
        $reserved = 0;

        foreach ($slots as &$slot) {
            if ($reserved >= $count) break;
            if (!$slot['active']) {
                $slot['active']     = true;
                $slot['claimed_at'] = time();
                $slot['email']      = 'manual_reservation';
                $reserved++;
            }
        }
        unset($slot);

        if ($reserved > 0) {
            self::save_slots($slots);
            return true;
        }
        return false;
    }

    /**
     * Manually free/release a specified number of slots
     * Notifies waitlist if people are waiting
     */
    public static function free_slots_manual(int $count): int {
        if ($count <= 0) return 0;

        $slots = self::get_slots();
        $freed = 0;

        foreach ($slots as &$slot) {
            if ($freed >= $count) break;
            if ($slot['active']) {
                $slot['active']     = false;
                $slot['claimed_at'] = 0;
                $slot['email']      = '';
                $freed++;
            }
        }
        unset($slot);

        if ($freed > 0) {
            self::save_slots($slots);
            // Notify waitlist members
            self::notify_waitlist($freed);
        }

        return $freed;
    }

    /**
     * Automatically reserve daily slots (called by cron)
     */
    public static function auto_reserve_daily_slots(): void {
        $enabled = get_option('sec_auto_slot_enabled', 0);
        if (!$enabled) return;

        $daily_slots = intval(get_option('sec_auto_daily_slots', 2));
        if ($daily_slots <= 0) return;

        self::take_slots_manual($daily_slots);
        error_log('SEC: Automatically reserved ' . $daily_slots . ' slots.');
    }

    /**
     * Setup automatic daily slot reservation cron
     */
    public static function setup_auto_reservation(): void {
        if (!wp_next_scheduled('sec_auto_reserve_slots')) {
            // Schedule for midnight every day
            $midnight = strtotime('tomorrow midnight');
            wp_schedule_event($midnight, 'daily', 'sec_auto_reserve_slots');
        }
    }
}

// Register activation/deactivation hooks from the main plugin file:
// register_activation_hook(__FILE__,   ['SEC_Activation_Slots', 'activate']);
// register_deactivation_hook(__FILE__, ['SEC_Activation_Slots', 'deactivate']);
