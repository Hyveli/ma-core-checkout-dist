<?php
/**
 * SEC Activation Slots
 *
 * 10 rolling slots per 24 hours. Each slot is claimed on successful checkout
 * and auto-released after 24 hours. When all slots are taken, visitors join
 * a waitlist and are emailed the moment any slot becomes available.
 *
 * USAGE IN YOUR MAIN PLUGIN FILE:
 *   require_once plugin_dir_path(__FILE__) . 'sec-activation-slots.php';
 *   add_action('plugins_loaded', ['SEC_Activation_Slots', 'init']);
 *
 * ON SUCCESSFUL STRIPE CHECKOUT:
 *   SEC_Activation_Slots::claim_slot($customer_email);
 */

if (!defined('ABSPATH')) exit;

class SEC_Activation_Slots {

    const TOTAL_SLOTS     = 10;
    const SLOT_DURATION   = 86400; // 24 hours in seconds
    const OPTION_SLOTS    = 'sec_activation_slots';
    const OPTION_WAITLIST = 'sec_activation_waitlist';

    /* ── Bootstrap ──────────────────────────────────────────────── */

    public static function init() {
        add_filter('cron_schedules', [__CLASS__, 'add_cron_interval']);
        add_action('rest_api_init',  [__CLASS__, 'register_rest_routes']);
        add_action('sec_check_expired_slots', [__CLASS__, 'release_expired_slots']);
        add_action('sec_auto_reserve_slots', [__CLASS__, 'auto_reserve_daily_slots']);

        // AJAX handlers for admin
        add_action('wp_ajax_sec_reserve_slots_manual', [__CLASS__, 'ajax_reserve_slots']);

        if (!wp_next_scheduled('sec_check_expired_slots')) {
            wp_schedule_event(time(), 'sec_every_minute', 'sec_check_expired_slots');
        }

        // Setup automatic slot reservation if enabled
        self::setup_auto_reservation();
    }

    public static function add_cron_interval($schedules) {
        $schedules['sec_every_minute'] = [
            'interval' => 60,
            'display'  => 'Every Minute (SEC Slots)',
        ];
        return $schedules;
    }

    /* ── REST Routes ────────────────────────────────────────────── */

    public static function register_rest_routes() {
        register_rest_route('sec/v1', '/slots', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'rest_get_slots'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('sec/v1', '/slots/free', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'rest_free_slots'],
            'permission_callback' => function() {
                // This is what WP REST checks BEFORE calling the callback.
                // wp_rest_request_before_callbacks sends the X-WP-Nonce header
                // which WP validates automatically for cookie-authenticated requests.
                // We just need to confirm the user has the right capability.
                return current_user_can('manage_options');
            },
            'args' => [
                'count' => ['required' => true, 'sanitize_callback' => 'absint'],
            ],
        ]);

        register_rest_route('sec/v1', '/waitlist', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'rest_join_waitlist'],
            'permission_callback' => '__return_true',
            'args' => [
                'email' => ['required' => true, 'sanitize_callback' => 'sanitize_email'],
                'name'  => ['required' => false, 'sanitize_callback' => 'sanitize_text_field'],
            ],
        ]);

        register_rest_route('sec/v1', '/waitlist/list', [
            'methods'             => 'GET',
            'callback'            => [__CLASS__, 'rest_get_waitlist'],
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ]);
    }

    /* ── REST: GET /slots ───────────────────────────────────────── */

    public static function rest_get_slots() {
        self::release_expired_slots();

        $slots     = self::get_slots();
        $now       = time();
        $active    = array_filter($slots, fn($s) => $s['active']);
        $available = self::TOTAL_SLOTS - count($active);

        $public_slots = array_map(function($s) use ($now) {
            $expires_in = null;
            if ($s['active']) {
                $expires_in = max(0, ($s['claimed_at'] + self::SLOT_DURATION) - $now);
            }
            return [
                'active'      => $s['active'],
                'expires_in'  => $expires_in,
            ];
        }, $slots);

        return rest_ensure_response([
            'available' => max(0, $available),
            'total'     => self::TOTAL_SLOTS,
            'slots'     => array_values($public_slots),
        ]);
    }

    /* ── REST: POST /slots/free ─────────────────────────────────── */

    public static function rest_free_slots(WP_REST_Request $request) {
        // permission_callback already verified manage_options + WP nonce header.
        // No manual nonce check needed here — WP REST handles it via X-WP-Nonce.
        $count = $request->get_param('count');
        if ($count <= 0) {
            return new WP_Error('invalid_count', 'Count must be greater than 0.', ['status' => 400]);
        }

        $freed = self::free_slots_manual($count);

        return rest_ensure_response([
            'success' => true,
            'freed'   => $freed,
            'message' => "Successfully freed {$freed} slot(s). Waitlist members have been notified.",
        ]);
    }

    /* ── REST: GET /waitlist/list ───────────────────────────────── */

    public static function rest_get_waitlist() {
        $list = self::get_waitlist();
        return rest_ensure_response([
            'success'  => true,
            'count'    => count($list),
            'waitlist' => $list,
        ]);
    }

    /* ── AJAX: Reserve Slots ────────────────────────────────────── */

    public static function ajax_reserve_slots() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_admin_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to reserve slots.'));
        }

        $count = intval($_POST['count'] ?? 0);
        if ($count <= 0) {
            wp_send_json_error(array('message' => 'Invalid count.'));
        }

        $success = self::take_slots_manual($count);

        if ($success) {
            wp_send_json_success(array(
                'message' => "Successfully reserved {$count} slot(s) for 24 hours."
            ));
        } else {
            wp_send_json_error(array(
                'message' => 'No available slots to reserve.'
            ));
        }
    }

    /* ── REST: POST /waitlist ───────────────────────────────────── */

    public static function rest_join_waitlist(WP_REST_Request $request) {
        $email = $request->get_param('email');
        $name  = $request->get_param('name') ?: '';

        if (!$email || !is_email($email)) {
            return new WP_Error('invalid_email', 'A valid email is required.', ['status' => 400]);
        }

        self::release_expired_slots();
        if (self::get_available_count() > 0) {
            return rest_ensure_response([
                'success' => false,
                'reload'  => true,
                'message' => 'Great news — a slot just opened up! Refreshing now…',
            ]);
        }

        $added = self::add_to_waitlist($email, $name);

        if (!$added) {
            return rest_ensure_response([
                'success' => true,
                'already' => true,
                'message' => "You're already on the waitlist. We'll notify you the moment a slot opens.",
            ]);
        }

        self::send_waitlist_confirmation_email($email, $name);

        return rest_ensure_response([
            'success' => true,
            'message' => "You're on the list! We'll email you as soon as a slot opens.",
        ]);
    }

    /* ── Slot Data ──────────────────────────────────────────────── */

    public static function get_slots(): array {
        $slots = get_option(self::OPTION_SLOTS, []);
        while (count($slots) < self::TOTAL_SLOTS) {
            $slots[] = ['active' => false, 'claimed_at' => 0, 'email' => ''];
        }
        return array_slice($slots, 0, self::TOTAL_SLOTS);
    }

    public static function save_slots(array $slots): void {
        update_option(self::OPTION_SLOTS, $slots, false);
    }

    public static function get_available_count(): int {
        $slots  = self::get_slots();
        $active = array_filter($slots, fn($s) => $s['active']);
        return max(0, self::TOTAL_SLOTS - count($active));
    }

    /* ── Claim a Slot (call after successful Stripe checkout) ───── */

    public static function claim_slot(string $email = ''): bool {
        self::release_expired_slots();
        $slots = self::get_slots();

        foreach ($slots as &$slot) {
            if (!$slot['active']) {
                $slot['active']     = true;
                $slot['claimed_at'] = time();
                $slot['email']      = sanitize_email($email);
                self::save_slots($slots);
                return true;
            }
        }
        unset($slot);
        return false;
    }

    /* ── Release Expired Slots (runs every minute via cron) ─────── */

    public static function release_expired_slots(): void {
        $slots   = self::get_slots();
        $changed = false;
        $freed   = 0;

        foreach ($slots as &$slot) {
            if ($slot['active'] && (time() - $slot['claimed_at']) >= self::SLOT_DURATION) {
                $slot['active']     = false;
                $slot['claimed_at'] = 0;
                $slot['email']      = '';
                $changed = true;
                $freed++;
            }
        }
        unset($slot);

        if ($changed) {
            self::save_slots($slots);
            if ($freed > 0) {
                self::notify_waitlist($freed);
            }
        }
    }

    /* ── Waitlist ───────────────────────────────────────────────── */

    public static function get_waitlist(): array {
        return get_option(self::OPTION_WAITLIST, []);
    }

    public static function add_to_waitlist(string $email, string $name = ''): bool {
        $list = self::get_waitlist();
        foreach ($list as $entry) {
            if (strtolower($entry['email']) === strtolower($email)) {
                return false;
            }
        }
        $list[] = [
            'email'    => $email,
            'name'     => sanitize_text_field($name),
            'added_at' => time(),
        ];
        update_option(self::OPTION_WAITLIST, $list, false);
        return true;
    }

    public static function notify_waitlist(int $slots_freed = null): void {
        $list = self::get_waitlist();
        if (empty($list)) return;

        $available = $slots_freed ?? self::get_available_count();
        if ($available <= 0) return;

        $to_notify = array_slice($list, 0, $available);
        $remaining = array_slice($list, $available);

        foreach ($to_notify as $entry) {
            self::send_waitlist_notification_email($entry['email'], $entry['name'] ?? '');
            error_log('SEC Slots: Notified waitlist member: ' . $entry['email']);
        }

        update_option(self::OPTION_WAITLIST, $remaining, false);
    }

    /* ── Emails ─────────────────────────────────────────────────── */

    private static function get_mailer(): \PHPMailer\PHPMailer\PHPMailer {
        if (!class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
            require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
            require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
            require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
        }
        $m = new \PHPMailer\PHPMailer\PHPMailer(true);
        $m->isSMTP();
        $m->Host       = SMTP_HOST;
        $m->SMTPAuth   = SMTP_AUTH;
        $m->Username   = SMTP_USERNAME;
        $m->Password   = SMTP_PASSWORD;
        $m->SMTPSecure = SMTP_SECURE;
        $m->Port       = SMTP_PORT;
        $m->SMTPOptions = ['ssl' => ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true]];
        $m->setFrom(SMTP_USERNAME, 'Marketing Aid');
        $m->isHTML(true);
        $m->CharSet = 'UTF-8';
        $m->Encoding = 'base64';
        return $m;
    }

    private static function email_wrapper(string $inner_html, string $banner = ''): string {
        $logo_url = self::get_brand_logo_url();
        $gradient_start = sanitize_hex_color(get_option('sec_email_header_gradient_start', '#B8C7E6')) ?: '#B8C7E6';
        $gradient_end = sanitize_hex_color(get_option('sec_email_header_gradient_end', '#94B5F0')) ?: '#94B5F0';
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));

        $logo_html = !empty($logo_url)
            ? '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($from_name) . '" width="220" style="display:block; width:220px; max-width:220px; height:auto; max-height:68px; margin:0 auto;">'
            : '<div style="font-family:\'Roboto\',\'DM Sans\',Arial,sans-serif;font-size:42px;font-weight:700;letter-spacing:0.04em;color:#121A2D;line-height:1;text-transform:uppercase;">Marketing<span style="color:#2F6BEB;">Aid</span></div>';

        return <<<HTML
<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:'DM Sans','Roboto',Arial,sans-serif;color:#2f3c55;">
<table width="100%" bgcolor="#f3f4f6" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:32px 12px;">
<table width="600" cellpadding="0" cellspacing="0" bgcolor="#ffffff"
       style="border:1px solid #e7ebf3;border-radius:12px;overflow:hidden;max-width:600px;">
  <tr>
    <td align="center" style="background:linear-gradient(135deg,{$gradient_start},{$gradient_end});padding:30px 20px;">
      <a href="https://marketingaid.org/" target="_blank">
        {$logo_html}
      </a>
    </td>
  </tr>
  {$banner}
  <tr><td style="padding:32px 30px 24px;font-size:16px;line-height:1.62;color:#334155;">{$inner_html}</td></tr>
  <tr>
    <td align="center" style="background:#f8fafc;padding:16px;font-size:12px;color:#7b8498;">
      &copy; 2026 Marketing Aid. All rights reserved.
    </td>
  </tr>
</table>
</td></tr></table>
</body></html>
HTML;
    }

    private static function get_brand_logo_url(): string {
        $logo_url = get_option('sec_logo_url', '');
        if (empty($logo_url)) {
            $logo_url = get_option('sec_logo_image', get_option('sec_email_logo_url', ''));
        }

        $logo_url = esc_url_raw((string) $logo_url);
        if ($logo_url === '') {
            return '';
        }

        if (preg_match('/\\.svg(\\?.*)?$/i', $logo_url)) {
            $png_fallback = esc_url_raw((string) get_option('sec_logo_png_fallback_url', ''));
            if ($png_fallback !== '') {
                return $png_fallback;
            }
        }

        return $logo_url;
    }

    public static function send_waitlist_confirmation_email(string $email, string $name): void {
        $email    = sanitize_email($email);
        if (!is_email($email)) return;
        $greeting = $name ? 'Hi ' . esc_html($name) . ',' : 'Hi there,';

        $body = self::email_wrapper(<<<BODY
<p>{$greeting}</p>
<p>You've been added to the <strong>Platform Activation waitlist</strong>.</p>
<p>We have <strong>10 activation slots open at a time</strong>, and right now none are available.
   As soon as one opens, you'll get a notification with a direct link.</p>
<p>Slots are first-come, first-served, so claiming quickly gives you the best chance.</p>
<p style="font-size:13px;color:#888;margin-top:24px;">
  Didn't sign up? You can safely ignore this email.
</p>
<p style="margin-top:26px;">- <strong>The Marketing Aid Team</strong></p>
BODY);

        try {
            $m = self::get_mailer();
            $m->addAddress($email);
            $m->Subject = "You're on the waitlist - Marketing Aid Platform";
            $m->Body    = $body;
            $m->send();
        } catch (\Exception $e) {
            error_log('📧 Waitlist Confirmation Error: ' . $e->getMessage());
        }
    }

    public static function send_waitlist_notification_email(string $email, string $name): void {
        $email    = sanitize_email($email);
        if (!is_email($email)) return;
        $greeting     = $name ? 'Hi ' . esc_html($name) . ',' : 'Hi there,';
        $checkout_url = esc_url(home_url('/#activate'));
        $available    = self::get_available_count();

        $banner = <<<BANNER
<tr>
  <td align="center"
      style="background:linear-gradient(135deg,#139204,#36b827);
             padding:16px 28px;color:#fff;font-size:15px;font-weight:600;">
    A slot just opened - {$available} available right now
  </td>
</tr>
BANNER;

        $body = self::email_wrapper(<<<BODY
<p>{$greeting}</p>
<p>Good news - a <strong>Platform Activation slot</strong> just opened and you're
   being notified first because you joined our waitlist.</p>
<p>Slots are first-come, first-served, so claim yours as soon as you are ready.</p>
<div style="text-align:center;margin:32px 0;">
  <a href="{$checkout_url}"
     style="display:inline-block;background:linear-gradient(135deg,#139204,#36b827);
            color:#fff;text-decoration:none;font-size:17px;font-weight:700;
            padding:16px 44px;border-radius:10px;">
    Activate My Platform - $29/mo
  </a>
</div>
<p style="font-size:13px;color:#888;text-align:center;">
  You're receiving this because you joined our waitlist. If you've already activated,
  you can safely ignore this email.
</p>
<p style="margin-top:26px;">- <strong>The Marketing Aid Team</strong></p>
BODY, $banner);

        try {
            $m = self::get_mailer();
            $m->addAddress($email);
            $m->Subject = 'A Platform Activation slot just opened - claim it now';
            $m->Body    = $body;
            $m->send();
        } catch (\Exception $e) {
            error_log('📧 Waitlist Notification Error: ' . $e->getMessage());
        }
    }

    /* ── Admin Helpers ──────────────────────────────────────────── */

    public static function admin_summary(): array {
        self::release_expired_slots();
        $slots    = self::get_slots();
        $waitlist = self::get_waitlist();
        $active   = array_filter($slots, fn($s) => $s['active']);
        return [
            'total'          => self::TOTAL_SLOTS,
            'active'         => count($active),
            'available'      => self::TOTAL_SLOTS - count($active),
            'waitlist_count' => count($waitlist),
            'slots'          => $slots,
        ];
    }

    public static function reset_all_slots(): void {
        delete_option(self::OPTION_SLOTS);
    }

    public static function activate(): void {
        self::init();
        self::release_expired_slots();
    }

    public static function deactivate(): void {
        wp_clear_scheduled_hook('sec_check_expired_slots');
        wp_clear_scheduled_hook('sec_auto_reserve_slots');
    }

    /* ── Manual & Automatic Slot Reservation ─────────────────────── */

    public static function get_total_slots(): int {
        return self::TOTAL_SLOTS;
    }

    public static function get_available_slots(): int {
        return self::get_available_count();
    }

    public static function take_slots_manual(int $count): bool {
        self::release_expired_slots();
        $slots    = self::get_slots();
        $reserved = 0;

        foreach ($slots as &$slot) {
            if ($reserved >= $count) break;
            if (!$slot['active']) {
                $slot['active']     = true;
                $slot['claimed_at'] = time();
                $slot['email']      = 'manual_reservation';
                $reserved++;
            }
        }
        unset($slot);

        if ($reserved > 0) {
            self::save_slots($slots);
            return true;
        }
        return false;
    }

    public static function free_slots_manual(int $count): int {
        if ($count <= 0) return 0;

        $slots = self::get_slots();
        $freed = 0;

        foreach ($slots as &$slot) {
            if ($freed >= $count) break;
            if ($slot['active']) {
                $slot['active']     = false;
                $slot['claimed_at'] = 0;
                $slot['email']      = '';
                $freed++;
            }
        }
        unset($slot);

        if ($freed > 0) {
            self::save_slots($slots);
            self::notify_waitlist($freed);
        }

        return $freed;
    }

    public static function auto_reserve_daily_slots(): void {
        $enabled = get_option('sec_auto_slot_enabled', 0);
        if (!$enabled) return;

        $daily_slots = intval(get_option('sec_auto_daily_slots', 2));
        if ($daily_slots <= 0) return;

        self::take_slots_manual($daily_slots);
        error_log('SEC: Automatically reserved ' . $daily_slots . ' slots.');
    }

    public static function setup_auto_reservation(): void {
        if (!wp_next_scheduled('sec_auto_reserve_slots')) {
            $midnight = strtotime('tomorrow midnight');
            wp_schedule_event($midnight, 'daily', 'sec_auto_reserve_slots');
        }
    }
}

// register_activation_hook(__FILE__,   ['SEC_Activation_Slots', 'activate']);
// register_deactivation_hook(__FILE__, ['SEC_Activation_Slots', 'deactivate']);
