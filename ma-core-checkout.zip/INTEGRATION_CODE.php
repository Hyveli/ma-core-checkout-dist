<?php
/**
 * INTEGRATION CODE - Add this to your stripe-embedded-checkout.php
 *
 * This file contains all the code snippets you need to integrate the survey modal
 * into your existing Stripe Embedded Checkout plugin.
 */

// ============================================================================
// STEP 1: Add these includes after line 14 (after activation slots include)
// ============================================================================

// Load survey system classes
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-db.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-email.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-modal.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-admin.php';


// ============================================================================
// STEP 2: Update the activate() method to create survey table
// Add this inside the activate() method (around line 63)
// ============================================================================

// Create survey table
SEC_Survey_DB::create_table();


// ============================================================================
// STEP 3: Update the handle_checkout_success() method
// Find the handle_checkout_success() method (around line 1259)
// Replace lines 1336-1347 with this code:
// ============================================================================

// Send confirmation email
$this->send_confirmation_email($session, $token_data);

// Store payment session data for survey modal
SEC_Survey_Modal::store_payment_session($session, $token_data);

// Redirect back to the page with the shortcode (or home) with thank-you trigger
$redirect_url = home_url('/?payment_complete=1');

// If we know the referring page, redirect there
if (isset($_SESSION['sec_form_referrer']) && !empty($_SESSION['sec_form_referrer'])) {
    $ref = $_SESSION['sec_form_referrer'];
    $redirect_url = $ref . (strpos($ref, '?') !== false ? '&' : '?') . 'payment_complete=1';
    unset($_SESSION['sec_form_referrer']);
}

wp_redirect($redirect_url);
exit;


// ============================================================================
// STEP 4: Update the handle_custom_invoice_success() method
// Find the handle_custom_invoice_success() method (around line 2579)
// Replace line 2646-2648 with this code:
// ============================================================================

// Store payment session for survey
$session_data = array(
    'customer' => $invoice['stripe_customer_id'],
    'customer_details' => (object)array('email' => $invoice['customer_email']),
    'amount_total' => $invoice['amount_total'] * 100, // Convert to cents
    'id' => $session_id
);
$token_data = array(
    'full_name' => $invoice['customer_name']
);
SEC_Survey_Modal::store_payment_session((object)$session_data, $token_data);

// Redirect to success page with survey modal
wp_redirect(home_url('/?payment_complete=1'));
exit;


// ============================================================================
// STEP 5: OPTIONAL - Add Plugin Update Checker (for GitHub updates)
// Add this at the very bottom of stripe-embedded-checkout.php, AFTER the class
// ============================================================================

/**
 * Plugin Update Checker
 *
 * To use this, you need to:
 * 1. Install the PUC library via Composer:
 *    composer require yahnis-elsts/plugin-update-checker
 *
 * 2. OR manually download from:
 *    https://github.com/YahnisElsts/plugin-update-checker/releases
 *    Extract to: vendor/plugin-update-checker/
 *
 * 3. Update your GitHub repo URL below
 */

// Check if PUC exists before loading
$puc_path = plugin_dir_path(__FILE__) . 'vendor/plugin-update-checker/plugin-update-checker.php';

if (file_exists($puc_path)) {
    require $puc_path;

    use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

    $myUpdateChecker = PucFactory::buildUpdateChecker(
        'https://github.com/YOUR-USERNAME/ma-core-checkout/', // ← CHANGE THIS to your GitHub repo
        __FILE__,
        'ma-core-checkout'
    );

    // Set the branch to check (usually 'main' or 'master')
    $myUpdateChecker->setBranch('main');

    // If using a private repo, uncomment and add your token:
    // $myUpdateChecker->setAuthentication('YOUR_GITHUB_TOKEN');
}


// ============================================================================
// STEP 6: Replace "Membership" terminology with "Setup Fee"
// Use Find & Replace in your code editor:
// ============================================================================

/**
 * Find and Replace the following:
 *
 * 1. Search:  "Annual Membership"
 *    Replace: "Website Setup Fee"
 *
 * 2. Search:  "Membership"
 *    Replace: "Setup Fee"
 *
 * 3. Search:  "membership"
 *    Replace: "setup fee"
 *
 * 4. Search:  'sec_membership_name'
 *    Replace: 'sec_setup_fee_name'
 *
 * 5. In admin pages, replace labels like:
 *    "Membership Name" → "Service Name"
 *    "Membership Settings" → "Payment Settings"
 */


// ============================================================================
// STEP 7: Update Database Option Names (optional but recommended)
// Run this once to rename options in wp_options table:
// ============================================================================

/**
 * Add this to your activate() method or run once via WP CLI:
 */

// Rename membership options to setup fee options
global $wpdb;

$old_options = array(
    'sec_membership_name' => 'sec_setup_fee_name',
    'sec_membership_price' => 'sec_setup_fee_price',
    // Add any other membership-related options here
);

foreach ($old_options as $old => $new) {
    $value = get_option($old);
    if ($value !== false) {
        update_option($new, $value);
        // Optionally delete old option after migration:
        // delete_option($old);
    }
}


// ============================================================================
// That's it! Your survey modal is now integrated.
// ============================================================================

/**
 * TESTING CHECKLIST:
 *
 * 1. Activate the plugin (creates survey table)
 * 2. Complete a test Stripe payment
 * 3. After payment success, survey modal should appear
 * 4. Fill out the survey and submit
 * 5. Check admin dashboard: "Survey Submissions" menu
 * 6. Verify email was sent to notification email
 * 7. Test file uploads (should accept up to 35MB)
 * 8. Test all 11 steps of the survey
 *
 * UPDATING VIA GITHUB:
 *
 * 1. Update version number in plugin header (Version: 2.1.0)
 * 2. Commit changes: git commit -am "Version 2.1.0"
 * 3. Create tag: git tag v2.1.0
 * 4. Push to GitHub:
 *    git push origin main
 *    git push origin v2.1.0
 * 5. WordPress will detect the update within 12 hours
 *
 * SURVEY SETTINGS:
 *
 * - Go to: Dashboard → Stripe Checkout → Survey Settings
 * - Set the notification email address
 * - All survey submissions will be emailed to this address
 *
 * SURVEY SUBMISSIONS:
 *
 * - View all submissions: Dashboard → Stripe Checkout → Survey Submissions
 * - Filter by status (New, Reviewed)
 * - View full details with images
 * - Mark as reviewed or delete
 */
