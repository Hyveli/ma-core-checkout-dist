<?php
/**
 * Email Settings Diagnostic
 *
 * Upload this file to your WordPress root and visit:
 * https://yoursite.com/test-email-settings.php
 *
 * This will show you what email addresses are currently configured.
 */

// Load WordPress
require_once('wp-load.php');

// Security check
if (!current_user_can('manage_options')) {
    die('Access denied. You must be an administrator.');
}

echo '<h1>Email Settings Diagnostic</h1>';
echo '<style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; padding: 20px; }
    table { border-collapse: collapse; width: 100%; max-width: 800px; margin: 20px 0; }
    th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
    th { background: #0073aa; color: white; }
    tr:nth-child(even) { background: #f9f9f9; }
    .empty { color: #999; font-style: italic; }
    .set { color: #46b450; font-weight: bold; }
    .warning { background: #fff3cd; border: 1px solid #ffc107; padding: 10px; margin: 10px 0; }
</style>';

$settings = [
    'Default From Name' => get_option('sec_email_from_name', ''),
    'Default From Email' => get_option('sec_email_from_email', ''),
    'Billing Support Email' => get_option('sec_billing_support_email', ''),
    'Invoice From Email' => get_option('sec_invoice_from_email', ''),
    'Survey From Email' => get_option('sec_survey_from_email', ''),
    'Reminder From Email' => get_option('sec_reminder_from_email', ''),
    'Completion From Email' => get_option('sec_completion_from_email', ''),
];

echo '<table>';
echo '<tr><th>Setting</th><th>Value</th><th>Status</th></tr>';

foreach ($settings as $label => $value) {
    $status = !empty($value)
        ? '<span class="set">✓ Configured</span>'
        : '<span class="empty">Not set (using fallback)</span>';

    $display = !empty($value) ? esc_html($value) : '<span class="empty">(empty)</span>';

    echo '<tr>';
    echo '<td><strong>' . esc_html($label) . '</strong></td>';
    echo '<td>' . $display . '</td>';
    echo '<td>' . $status . '</td>';
    echo '</tr>';
}

echo '</table>';

// Check for empty aliases
$empty_aliases = array_filter([
    'Invoice' => empty(get_option('sec_invoice_from_email', '')),
    'Survey' => empty(get_option('sec_survey_from_email', '')),
    'Reminder' => empty(get_option('sec_reminder_from_email', '')),
    'Completion' => empty(get_option('sec_completion_from_email', '')),
]);

if (!empty($empty_aliases)) {
    echo '<div class="warning">';
    echo '<strong>⚠️ Warning:</strong> The following email types have no specific From address configured:<br>';
    echo '<ul>';
    foreach (array_keys($empty_aliases) as $type) {
        echo '<li>' . esc_html($type) . ' emails will use the default From email: <strong>' . esc_html(get_option('sec_email_from_email', get_option('admin_email'))) . '</strong></li>';
    }
    echo '</ul>';
    echo '<p><strong>Action Required:</strong> Go to <a href="' . admin_url('admin.php?page=sec-branding-settings') . '">Branding Settings</a> and configure email-specific From addresses.</p>';
    echo '</div>';
}

echo '<hr>';
echo '<h2>Email Flow Chart</h2>';
echo '<table>';
echo '<tr><th>Email Type</th><th>Will Send From</th><th>Fallback Chain</th></tr>';

$flows = [
    'Payment Receipt' => [
        'primary' => get_option('sec_invoice_from_email', ''),
        'fallback' => get_option('sec_email_from_email', get_option('admin_email'))
    ],
    'Invoice' => [
        'primary' => get_option('sec_invoice_from_email', ''),
        'fallback' => get_option('sec_email_from_email', get_option('admin_email'))
    ],
    'Survey Invitation' => [
        'primary' => get_option('sec_survey_from_email', ''),
        'fallback' => get_option('sec_email_from_email', get_option('admin_email'))
    ],
    'Survey Reminder' => [
        'primary' => get_option('sec_reminder_from_email', ''),
        'fallback' => get_option('sec_email_from_email', get_option('admin_email'))
    ],
    'Survey Completion' => [
        'primary' => get_option('sec_completion_from_email', ''),
        'fallback' => get_option('sec_email_from_email', get_option('admin_email'))
    ],
];

foreach ($flows as $type => $addresses) {
    $will_use = !empty($addresses['primary']) ? $addresses['primary'] : $addresses['fallback'];
    $chain = !empty($addresses['primary'])
        ? 'Using configured address'
        : 'Fallback → Default From Email → admin_email';

    echo '<tr>';
    echo '<td><strong>' . esc_html($type) . '</strong></td>';
    echo '<td><strong>' . esc_html($will_use) . '</strong></td>';
    echo '<td>' . esc_html($chain) . '</td>';
    echo '</tr>';
}

echo '</table>';

echo '<hr>';
echo '<p><a href="' . admin_url('admin.php?page=sec-branding-settings') . '">→ Go to Branding Settings</a></p>';
echo '<p><small>Delete this file after testing for security.</small></p>';
