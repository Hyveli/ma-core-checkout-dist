<?php
/**
 * Survey Admin Dashboard
 *
 * Handles admin pages for viewing and managing survey submissions
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_Admin {

    /**
     * Convert 24-hour time to 12-hour format (or return as-is if already 12-hour)
     */
    private static function format_time_12hour($time24) {
        // Check if already in 12-hour format (contains AM/PM)
        if (preg_match('/\s*(AM|PM|am|pm)\s*$/i', $time24)) {
            return trim($time24);
        }

        // Convert from 24-hour format
        list($hours, $minutes) = explode(':', $time24);
        $h = intval($hours);
        $period = $h >= 12 ? 'PM' : 'AM';
        $h12 = $h == 0 ? 12 : ($h > 12 ? $h - 12 : $h);
        return $h12 . ':' . $minutes . ' ' . $period;
    }

    private static function get_social_platform_name($social) {
        $platform = '';
        if (is_array($social)) {
            $platform = trim((string) ($social['platform'] ?? ($social['label'] ?? '')));
        }
        return $platform !== '' ? $platform : 'Social Link';
    }

    private static function get_social_link_url($value) {
        $url = trim((string) $value);
        if ($url === '') {
            return '';
        }
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        return $url;
    }

    /**
     * Initialize admin pages
     */
    public static function init() {
        add_action('admin_menu', array('SEC_Survey_Admin', 'add_admin_menu'), 20);
        add_action('admin_post_sec_delete_survey', array('SEC_Survey_Admin', 'handle_delete_survey'));
        add_action('admin_post_sec_update_survey_status', array('SEC_Survey_Admin', 'handle_update_status'));
        add_action('admin_post_sec_clear_all_test_data', array('SEC_Survey_Admin', 'handle_clear_all_test_data'));
    }

    /**
     * Add admin menu
     */
    public static function add_admin_menu() {
        add_submenu_page(
            'stripe-embedded-checkout', // Parent slug (main plugin page)
            'Survey Submissions',
            'Survey Submissions',
            'manage_options',
            'sec-survey-submissions',
            array('SEC_Survey_Admin', 'render_submissions_page')
        );

        add_submenu_page(
            'stripe-embedded-checkout',
            'Survey Settings',
            'Survey Settings',
            'manage_options',
            'sec-survey-settings',
            array('SEC_Survey_Admin', 'render_settings_page')
        );

        add_submenu_page(
            'stripe-embedded-checkout',
            'Clear Test Data',
            'Clear Test Data',
            'manage_options',
            'sec-clear-test-data',
            array('SEC_Survey_Admin', 'render_clear_data_page')
        );
    }

    /**
     * Render survey submissions list page
     */
    public static function render_submissions_page() {
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to access this page.');
        }

        // Handle view single submission
        if (isset($_GET['action']) && $_GET['action'] === 'view' && isset($_GET['id'])) {
            self::render_single_submission(intval($_GET['id']));
            return;
        }

        // Get submissions
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = 20;

        $args = array(
            'status' => $status_filter,
            'limit' => $per_page,
            'offset' => ($paged - 1) * $per_page
        );

        $submissions = SEC_Survey_DB::get_submissions($args);
        $total = SEC_Survey_DB::get_submission_count($status_filter);
        $total_pages = ceil($total / $per_page);

        // Count by status
        $count_new = SEC_Survey_DB::get_submission_count('new');
        $count_reviewed = SEC_Survey_DB::get_submission_count('reviewed');
        $count_all = SEC_Survey_DB::get_submission_count();

        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Survey Submissions</h1>

            <?php if ($count_new > 0): ?>
            <div class="notice notice-info" style="margin: 20px 0;">
                <p><strong><?php echo $count_new; ?> new submission(s)</strong> waiting for review.</p>
            </div>
            <?php endif; ?>

            <ul class="subsubsub">
                <li><a href="?page=sec-survey-submissions" <?php echo empty($status_filter) ? 'class="current"' : ''; ?>>All (<?php echo $count_all; ?>)</a> |</li>
                <li><a href="?page=sec-survey-submissions&status=new" <?php echo $status_filter === 'new' ? 'class="current"' : ''; ?>>New (<?php echo $count_new; ?>)</a> |</li>
                <li><a href="?page=sec-survey-submissions&status=reviewed" <?php echo $status_filter === 'reviewed' ? 'class="current"' : ''; ?>>Reviewed (<?php echo $count_reviewed; ?>)</a></li>
            </ul>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width: 40px;">#</th>
                        <th>Business Name</th>
                        <th>Customer</th>
                        <th>Industry</th>
                        <th>Payment</th>
                        <th>Submitted</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($submissions)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">
                            <p style="color: #999;">No survey submissions found.</p>
                        </td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($submissions as $submission): ?>
                        <tr>
                            <td><?php echo $submission->id; ?></td>
                            <td><strong><?php echo esc_html($submission->business_name ?: '—'); ?></strong></td>
                            <td>
                                <?php echo esc_html($submission->customer_name); ?><br>
                                <small style="color: #666;"><?php echo esc_html($submission->customer_email); ?></small>
                            </td>
                            <td><?php echo esc_html($submission->industry === 'Other' ? $submission->custom_industry : $submission->industry); ?></td>
                            <td><strong>$<?php echo number_format($submission->payment_amount, 2); ?></strong></td>
                            <td><?php echo date('M j, Y g:i A', strtotime($submission->submitted_at)); ?></td>
                            <td>
                                <?php
                                $badge_color = $submission->status === 'new' ? '#0073aa' : '#46b450';
                                $badge_text = ucfirst($submission->status);
                                ?>
                                <span style="display: inline-block; padding: 4px 10px; border-radius: 12px; background: <?php echo $badge_color; ?>; color: white; font-size: 11px; font-weight: 600;">
                                    <?php echo $badge_text; ?>
                                </span>
                            </td>
                            <td>
                                <a href="?page=sec-survey-submissions&action=view&id=<?php echo $submission->id; ?>" class="button button-small">View</a>

                                <?php if ($submission->status === 'new'): ?>
                                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                                    <input type="hidden" name="action" value="sec_update_survey_status">
                                    <input type="hidden" name="submission_id" value="<?php echo $submission->id; ?>">
                                    <input type="hidden" name="status" value="reviewed">
                                    <?php wp_nonce_field('sec_survey_status_' . $submission->id); ?>
                                    <button type="submit" class="button button-small">Mark Reviewed</button>
                                </form>
                                <?php endif; ?>

                                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this submission?');">
                                    <input type="hidden" name="action" value="sec_delete_survey">
                                    <input type="hidden" name="submission_id" value="<?php echo $submission->id; ?>">
                                    <?php wp_nonce_field('sec_delete_survey_' . $submission->id); ?>
                                    <button type="submit" class="button button-small button-link-delete" style="color: #b32d2e;">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php if ($total_pages > 1): ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    $base_url = add_query_arg(array('page' => 'sec-survey-submissions', 'status' => $status_filter), admin_url('admin.php'));

                    echo paginate_links(array(
                        'base' => add_query_arg('paged', '%#%', $base_url),
                        'format' => '',
                        'current' => $paged,
                        'total' => $total_pages,
                        'prev_text' => '&laquo;',
                        'next_text' => '&raquo;'
                    ));
                    ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render single submission detail view
     */
    private static function render_single_submission($id) {
        $submission = SEC_Survey_DB::get_submission($id);

        if (!$submission) {
            echo '<div class="wrap"><h1>Submission Not Found</h1><p>The requested submission could not be found.</p></div>';
            return;
        }

        // Decode JSON fields
        $hours = json_decode($submission->hours, true) ?: array();
        $booking = json_decode($submission->booking, true) ?: array();
        $socials = json_decode($submission->socials, true) ?: array();
        $brand = json_decode($submission->brand, true) ?: array();
        $file_paths = json_decode($submission->file_paths, true) ?: array();

        $upload_dir = wp_upload_dir();
        $survey_url = $upload_dir['baseurl'] . '/survey-images/';

        ?>
        <div class="wrap">
            <h1>Survey Submission #<?php echo $submission->id; ?></h1>

            <p>
                <a href="?page=sec-survey-submissions" class="button">&larr; Back to All Submissions</a>

                <?php if ($submission->status === 'new'): ?>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display: inline;">
                    <input type="hidden" name="action" value="sec_update_survey_status">
                    <input type="hidden" name="submission_id" value="<?php echo $submission->id; ?>">
                    <input type="hidden" name="status" value="reviewed">
                    <?php wp_nonce_field('sec_survey_status_' . $submission->id); ?>
                    <button type="submit" class="button button-primary">Mark as Reviewed</button>
                </form>
                <?php endif; ?>
            </p>

            <div style="background: white; border: 1px solid #ccc; border-radius: 8px; padding: 30px; margin-top: 20px;">

                <!-- Payment Information -->
                <div style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; margin-bottom: 30px;">
                    <h2 style="margin-top: 0;">Payment Information</h2>
                    <table class="form-table">
                        <tr>
                            <th>Customer Name:</th>
                            <td><strong><?php echo esc_html($submission->customer_name); ?></strong></td>
                        </tr>
                        <tr>
                            <th>Email:</th>
                            <td><?php echo esc_html($submission->customer_email); ?></td>
                        </tr>
                        <tr>
                            <th>Payment Amount:</th>
                            <td><strong style="color: #46b450; font-size: 18px;">$<?php echo number_format($submission->payment_amount, 2); ?></strong></td>
                        </tr>
                        <tr>
                            <th>Stripe Customer ID:</th>
                            <td><code><?php echo esc_html($submission->stripe_customer_id); ?></code></td>
                        </tr>
                        <tr>
                            <th>Stripe Session ID:</th>
                            <td><code><?php echo esc_html($submission->stripe_session_id); ?></code></td>
                        </tr>
                        <tr>
                            <th>Submitted:</th>
                            <td><?php echo date('F j, Y g:i A', strtotime($submission->submitted_at)); ?></td>
                        </tr>
                        <tr>
                            <th>Status:</th>
                            <td>
                                <?php
                                $badge_color = $submission->status === 'new' ? '#0073aa' : '#46b450';
                                ?>
                                <span style="display: inline-block; padding: 6px 12px; border-radius: 12px; background: <?php echo $badge_color; ?>; color: white; font-weight: 600;">
                                    <?php echo ucfirst($submission->status); ?>
                                </span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Business Information -->
                <?php if ($submission->business_name): ?>
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Business Information</h2>
                    <table class="form-table">
                        <tr>
                            <th>Business Name:</th>
                            <td><strong><?php echo esc_html($submission->business_name); ?></strong></td>
                        </tr>
                        <tr>
                            <th>Industry:</th>
                            <td><?php echo esc_html($submission->industry === 'Other' ? $submission->custom_industry : $submission->industry); ?></td>
                        </tr>
                        <?php if ($submission->tagline): ?>
                        <tr>
                            <th>Tagline:</th>
                            <td><em><?php echo esc_html($submission->tagline); ?></em></td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
                <?php endif; ?>

                <!-- Services -->
                <?php if ($submission->services): ?>
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Services Offered</h2>
                    <div style="background: #f8fafc; padding: 15px; border-radius: 5px; white-space: pre-line; line-height: 1.6;">
                        <?php echo nl2br(esc_html($submission->services)); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Business Hours -->
                <?php if (!empty($hours)): ?>
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Business Hours</h2>
                    <table class="widefat">
                        <tbody>
                            <?php foreach ($hours as $day => $time): ?>
                            <tr>
                                <td style="width: 100px; font-weight: bold;"><?php echo esc_html($day); ?></td>
                                <td>
                                    <?php if ($time['closed']): ?>
                                        <em style="color: #999;">Closed</em>
                                    <?php else: ?>
                                        <?php
                                        $open_12h = self::format_time_12hour($time['open']);
                                        $close_12h = self::format_time_12hour($time['close']);
                                        echo esc_html($open_12h) . ' - ' . esc_html($close_12h);
                                        ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>

                <!-- Booking Methods -->
                <?php if (!empty($booking)): ?>
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Booking Methods</h2>
                    <?php
                    $booking_labels = array(
                        'virtual' => '📹 Virtually (video or phone call)',
                        'our_location' => '🏢 At my location (client comes to me)',
                        'client_location' => '🚗 At the client\'s location (I go to them)'
                    );
                    ?>
                    <ul>
                        <?php foreach ($booking as $method): ?>
                        <li><?php echo esc_html($booking_labels[$method] ?? $method); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Contact Information -->
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Contact Information</h2>
                    <table class="form-table">
                        <?php if ($submission->contact_phone): ?>
                        <tr>
                            <th>Phone:</th>
                            <td><?php echo esc_html($submission->contact_phone); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if ($submission->contact_email): ?>
                        <tr>
                            <th>Email:</th>
                            <td><?php echo esc_html($submission->contact_email); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if ($submission->contact_address): ?>
                        <tr>
                            <th>Address:</th>
                            <td><?php echo esc_html($submission->contact_address); ?></td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>

                <!-- Social Media -->
                <?php if (!empty($socials)): ?>
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Social Media</h2>
                    <table class="form-table">
                        <?php foreach ($socials as $social): ?>
                            <?php if (!empty($social['value'])): ?>
                            <?php
                                $platform_name = self::get_social_platform_name($social);
                                $social_url = self::get_social_link_url($social['value']);
                            ?>
                            <tr>
                                <th><?php echo esc_html($platform_name); ?>:</th>
                                <td>
                                    <a href="<?php echo esc_url($social_url); ?>" target="_blank" rel="noopener noreferrer">
                                        <?php echo esc_html($social_url); ?>
                                    </a>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>

                <!-- Brand Information -->
                <?php if (!empty($brand)): ?>
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Brand Assets</h2>
                    <?php
                    $brand_labels = array(
                        'logo' => '🎨 Has logo',
                        'colors' => '🎨 Has brand colors',
                        'slogan' => '💬 Has slogan',
                        'none' => 'None yet — build it for me'
                    );
                    ?>
                    <ul>
                        <?php foreach ($brand as $item): ?>
                        <li><?php echo esc_html($brand_labels[$item] ?? $item); ?></li>
                        <?php endforeach; ?>
                    </ul>

                    <?php if ($submission->brand_colors): ?>
                    <p><strong>Brand Colors:</strong> <?php echo esc_html($submission->brand_colors); ?></p>
                    <?php endif; ?>

                    <?php if ($submission->brand_slogan): ?>
                    <p><strong>Slogan:</strong> <em><?php echo esc_html($submission->brand_slogan); ?></em></p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Files -->
                <?php if ($submission->logo_path || !empty($file_paths)): ?>
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Uploaded Files</h2>

                    <?php if ($submission->logo_path): ?>
                    <div style="margin-bottom: 20px;">
                        <h3>Logo:</h3>
                        <?php
                        // Check if it's already a full URL or a relative path
                        if (strpos($submission->logo_path, 'http') === 0) {
                            $logo_url = $submission->logo_path;
                        } else {
                            $logo_url = $survey_url . basename($submission->logo_path);
                        }

                        // Try to get image size to check if it's an image
                        $is_image = false;
                        $image_headers = @get_headers($logo_url);
                        if ($image_headers && strpos($image_headers[0], '200') !== false) {
                            $content_type = '';
                            foreach ($image_headers as $header) {
                                if (stripos($header, 'content-type:') === 0) {
                                    $content_type = trim(substr($header, 13));
                                    break;
                                }
                            }
                            $is_image = strpos($content_type, 'image/') === 0;
                        }
                        ?>
                        <?php if ($is_image): ?>
                        <img src="<?php echo esc_url($logo_url); ?>" alt="Logo" style="max-width: 200px; height: auto; border: 1px solid #ddd; padding: 10px; background: white;">
                        <?php endif; ?>
                        <p>
                            <a href="<?php echo esc_url($logo_url); ?>" target="_blank" class="button" download>Download Logo</a>
                            <button type="button" class="button button-link-delete sec-delete-file" data-submission-id="<?php echo esc_attr($submission_id); ?>" data-file-type="logo" data-file-url="<?php echo esc_attr($logo_url); ?>" style="margin-left: 10px; color: #dc2626;">Delete Logo</button>
                        </p>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($file_paths)): ?>
                    <div>
                        <h3>Other Files (<?php echo count($file_paths); ?>):</h3>
                        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px;">
                            <?php foreach ($file_paths as $file_path): ?>
                            <?php
                            // Check if it's already a full URL or a relative path
                            if (strpos($file_path, 'http') === 0) {
                                $file_url = $file_path;
                            } else {
                                $file_url = $survey_url . basename($file_path);
                            }

                            // Check if it's an image by trying to get headers
                            $is_image = false;
                            $file_headers = @get_headers($file_url);
                            if ($file_headers && strpos($file_headers[0], '200') !== false) {
                                $content_type = '';
                                foreach ($file_headers as $header) {
                                    if (stripos($header, 'content-type:') === 0) {
                                        $content_type = trim(substr($header, 13));
                                        break;
                                    }
                                }
                                $is_image = strpos($content_type, 'image/') === 0;
                            }

                            $filename = basename($file_url);
                            ?>
                            <div style="border: 1px solid #ddd; border-radius: 5px; overflow: hidden; background: white;">
                                <?php if ($is_image): ?>
                                <a href="<?php echo esc_url($file_url); ?>" target="_blank">
                                    <img src="<?php echo esc_url($file_url); ?>" alt="File" style="width: 100%; height: 150px; object-fit: cover; display: block;">
                                </a>
                                <?php else: ?>
                                <div style="height: 150px; display: flex; align-items: center; justify-content: center; font-size: 48px;">
                                    📄
                                </div>
                                <?php endif; ?>
                                <div style="padding: 10px; text-align: center;">
                                    <small style="display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><?php echo esc_html($filename); ?></small>
                                    <a href="<?php echo esc_url($file_url); ?>" target="_blank" class="button button-small" style="margin-top: 5px;" download>Download</a>
                                    <button type="button" class="button button-small button-link-delete sec-delete-file" data-submission-id="<?php echo esc_attr($submission_id); ?>" data-file-type="file" data-file-url="<?php echo esc_attr($file_url); ?>" style="margin-top: 5px; color: #dc2626; display: block; width: 100%;">Delete</button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <!-- Additional Notes -->
                <?php if ($submission->extra): ?>
                <div style="margin-bottom: 30px;">
                    <h2 style="border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Additional Notes</h2>
                    <div style="background: #f8fafc; padding: 15px; border-radius: 5px; white-space: pre-line; line-height: 1.6;">
                        <?php echo nl2br(esc_html($submission->extra)); ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('.sec-delete-file').on('click', function() {
                if (!confirm('Are you sure you want to delete this file? This action cannot be undone.')) {
                    return;
                }

                const btn = $(this);
                const submissionId = btn.data('submission-id');
                const fileType = btn.data('file-type');
                const fileUrl = btn.data('file-url');

                btn.prop('disabled', true).text('Deleting...');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'sec_delete_survey_file',
                        nonce: '<?php echo wp_create_nonce('sec_delete_file_nonce'); ?>',
                        submission_id: submissionId,
                        file_type: fileType,
                        file_url: fileUrl
                    },
                    success: function(response) {
                        if (response.success) {
                            btn.closest(fileType === 'logo' ? 'div' : 'div[style*="border"]').fadeOut(400, function() {
                                $(this).remove();
                            });
                            alert('File deleted successfully!');
                        } else {
                            alert('Error: ' + (response.data.message || 'Failed to delete file.'));
                            btn.prop('disabled', false).text(fileType === 'logo' ? 'Delete Logo' : 'Delete');
                        }
                    },
                    error: function() {
                        alert('Error: Failed to delete file.');
                        btn.prop('disabled', false).text(fileType === 'logo' ? 'Delete Logo' : 'Delete');
                    }
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Render settings page
     */
    public static function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to access this page.');
        }

        // Handle form submission
        if (isset($_POST['sec_survey_settings_nonce']) && wp_verify_nonce($_POST['sec_survey_settings_nonce'], 'sec_survey_settings')) {
            update_option('sec_survey_notification_email', sanitize_email($_POST['notification_email']));
            echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
        }

        $notification_email = get_option('sec_survey_notification_email', get_option('admin_email'));

        ?>
        <div class="wrap">
            <h1>Survey Settings</h1>

            <form method="post" action="">
                <?php wp_nonce_field('sec_survey_settings', 'sec_survey_settings_nonce'); ?>

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="notification_email">Notification Email</label>
                        </th>
                        <td>
                            <input type="email" name="notification_email" id="notification_email" value="<?php echo esc_attr($notification_email); ?>" class="regular-text" required>
                            <p class="description">Survey submissions will be sent to this email address.</p>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <input type="submit" class="button button-primary" value="Save Settings">
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * Render clear test data page.
     */
    public static function render_clear_data_page() {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to access this page.');
        }

        global $wpdb;
        $survey_table = $wpdb->prefix . 'sec_survey_submissions';
        $customers_table = $wpdb->prefix . 'sec_customers';

        $survey_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $survey_table");
        $customer_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $customers_table");

        $slot_summary = class_exists('SEC_Activation_Slots') ? SEC_Activation_Slots::admin_summary() : array(
            'active' => 0,
            'waitlist_count' => 0,
        );

        if (isset($_GET['clear_result']) && $_GET['clear_result'] === 'success') {
            $message = sprintf(
                'Clear complete. Customers deleted: %d. Survey submissions deleted: %d. Survey files deleted: %d. Activation slots cleared: %d. Waitlist entries deleted: %d.',
                intval($_GET['customers_deleted'] ?? 0),
                intval($_GET['surveys_deleted'] ?? 0),
                intval($_GET['files_deleted'] ?? 0),
                intval($_GET['slots_cleared'] ?? 0),
                intval($_GET['waitlist_deleted'] ?? 0)
            );
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
        } elseif (isset($_GET['waitlist_result']) && $_GET['waitlist_result'] === 'success') {
            $message = sprintf('Waitlist cleared. Entries deleted: %d.', intval($_GET['waitlist_deleted'] ?? 0));
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
        }

        ?>
        <div class="wrap">
            <h1>Clear Test Data</h1>

            <p>Use this page to reset test-only plugin data between checkout and survey test runs.</p>

            <table class="widefat striped" style="max-width: 800px; margin: 16px 0 24px;">
                <thead>
                    <tr>
                        <th>Data Type</th>
                        <th>Current Count</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Customers table rows</td>
                        <td><?php echo esc_html($customer_count); ?></td>
                    </tr>
                    <tr>
                        <td>Survey submissions</td>
                        <td><?php echo esc_html($survey_count); ?></td>
                    </tr>
                    <tr>
                        <td>Active activation slots</td>
                        <td><?php echo esc_html($slot_summary['active']); ?></td>
                    </tr>
                    <tr>
                        <td>Waitlist entries</td>
                        <td><?php echo esc_html($slot_summary['waitlist_count']); ?></td>
                    </tr>
                </tbody>
            </table>

            <div style="padding: 14px; border-left: 4px solid #2271b1; background: #f0f6fc; max-width: 800px; margin-bottom: 18px;">
                <strong>Clear All Test Data does:</strong>
                <ul style="margin: 8px 0 0 18px; list-style: disc;">
                    <li>Deletes all rows in <code>sec_customers</code>.</li>
                    <li>Deletes all rows in <code>sec_survey_submissions</code>.</li>
                    <li>Deletes survey upload files from known survey upload folders.</li>
                    <li>Auto-clears active activation slots that match emails found in customers and survey submissions.</li>
                    <li>Deletes all waitlist entries.</li>
                </ul>
            </div>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('Clear ALL test data now? This cannot be undone.');" style="margin-bottom: 16px;">
                <input type="hidden" name="action" value="sec_clear_all_test_data">
                <input type="hidden" name="clear_target" value="all">
                <?php wp_nonce_field('sec_clear_all_test_data_action'); ?>
                <button type="submit" class="button button-primary">Clear All Test Data</button>
            </form>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('Clear all waitlist entries?');">
                <input type="hidden" name="action" value="sec_clear_all_test_data">
                <input type="hidden" name="clear_target" value="waitlist">
                <?php wp_nonce_field('sec_clear_all_test_data_action'); ?>
                <button type="submit" class="button button-secondary">Clear Waitlist Only</button>
            </form>
        </div>
        <?php
    }

    /**
     * Clear activation slots that were claimed by known customer/survey emails.
     *
     * @param array $emails
     * @return int
     */
    private static function clear_slots_for_emails($emails) {
        if (!class_exists('SEC_Activation_Slots')) {
            return 0;
        }

        $emails = array_filter(array_map('strtolower', array_map('trim', (array) $emails)));
        if (empty($emails)) {
            return 0;
        }

        $slots = SEC_Activation_Slots::get_slots();
        $cleared = 0;
        $changed = false;

        foreach ($slots as &$slot) {
            $slot_email = strtolower(trim((string) ($slot['email'] ?? '')));
            if (!empty($slot['active']) && $slot_email !== '' && in_array($slot_email, $emails, true)) {
                $slot['active'] = false;
                $slot['claimed_at'] = 0;
                $slot['email'] = '';
                $changed = true;
                $cleared++;
            }
        }
        unset($slot);

        if ($changed) {
            SEC_Activation_Slots::save_slots($slots);
        }

        return $cleared;
    }

    /**
     * Handle clear data actions.
     */
    public static function handle_clear_all_test_data() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'sec_clear_all_test_data_action')) {
            wp_die('Security check failed');
        }

        $target = sanitize_text_field($_POST['clear_target'] ?? 'all');
        $waitlist_before = class_exists('SEC_Activation_Slots') ? count(SEC_Activation_Slots::get_waitlist()) : 0;

        if ($target === 'waitlist') {
            delete_option('sec_activation_waitlist');
            wp_redirect(add_query_arg(array(
                'page' => 'sec-clear-test-data',
                'waitlist_result' => 'success',
                'waitlist_deleted' => $waitlist_before,
            ), admin_url('admin.php')));
            exit;
        }

        global $wpdb;
        $survey_table = $wpdb->prefix . 'sec_survey_submissions';
        $customers_table = $wpdb->prefix . 'sec_customers';

        $survey_emails = $wpdb->get_col("SELECT customer_email FROM $survey_table WHERE customer_email <> ''");
        $customer_emails = $wpdb->get_col("SELECT email FROM $customers_table WHERE email <> ''");
        $slots_cleared = self::clear_slots_for_emails(array_merge((array) $survey_emails, (array) $customer_emails));

        delete_option('sec_activation_waitlist');

        $survey_result = SEC_Survey_DB::clear_all_submissions_and_files();
        $customers_deleted = (int) $wpdb->query("DELETE FROM $customers_table");

        wp_redirect(add_query_arg(array(
            'page' => 'sec-clear-test-data',
            'clear_result' => 'success',
            'customers_deleted' => $customers_deleted,
            'surveys_deleted' => intval($survey_result['deleted_rows'] ?? 0),
            'files_deleted' => intval($survey_result['deleted_files'] ?? 0),
            'slots_cleared' => $slots_cleared,
            'waitlist_deleted' => $waitlist_before,
        ), admin_url('admin.php')));
        exit;
    }

    /**
     * Handle survey deletion
     */
    public static function handle_delete_survey() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $submission_id = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;

        if (!wp_verify_nonce($_POST['_wpnonce'], 'sec_delete_survey_' . $submission_id)) {
            wp_die('Security check failed');
        }

        $result = SEC_Survey_DB::delete_submission($submission_id);

        wp_redirect(add_query_arg(
            array('page' => 'sec-survey-submissions', 'deleted' => $result ? '1' : '0'),
            admin_url('admin.php')
        ));
        exit;
    }

    /**
     * Handle status update
     */
    public static function handle_update_status() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $submission_id = isset($_POST['submission_id']) ? intval($_POST['submission_id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

        if (!wp_verify_nonce($_POST['_wpnonce'], 'sec_survey_status_' . $submission_id)) {
            wp_die('Security check failed');
        }

        SEC_Survey_DB::update_status($submission_id, $status);

        wp_redirect(add_query_arg(
            array('page' => 'sec-survey-submissions', 'updated' => '1'),
            admin_url('admin.php')
        ));
        exit;
    }
}

// Initialize
SEC_Survey_Admin::init();
