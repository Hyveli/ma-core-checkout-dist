<?php
/**
 * Time Simulator for Testing
 *
 * Allows you to fast-forward time for testing:
 * - Email reminder sequences
 * - Slot refills
 * - Date-based logic
 */

if (!defined('ABSPATH')) exit;

class SEC_Time_Simulator {

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_admin_page'), 99);
        add_action('admin_post_sec_simulate_time', array(__CLASS__, 'handle_simulate_time'));
        add_action('admin_post_sec_reset_time', array(__CLASS__, 'handle_reset_time'));
        add_action('wp_ajax_sec_trigger_reminder_check', array(__CLASS__, 'ajax_trigger_reminder_check'));
    }

    public static function add_admin_page() {
        add_submenu_page(
            'stripe-embedded-checkout',
            'Time Simulator',
            '🕐 Time Simulator',
            'manage_options',
            'sec-time-simulator',
            array(__CLASS__, 'render_page')
        );
    }

    public static function render_page() {
        $simulated_offset = get_option('sec_time_offset', 0);
        $current_real = current_time('mysql');
        $current_simulated = self::get_current_time();

        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';
        $incomplete = $wpdb->get_results("
            SELECT id, customer_name, customer_email, payment_date, last_activity,
                   reminder_1_sent, reminder_2_sent, reminder_3_sent, reminder_4_sent,
                   survey_step
            FROM {$table}
            WHERE survey_completed = 0
              AND survey_token IS NOT NULL
              AND survey_token != ''
            ORDER BY payment_date DESC
            LIMIT 10
        ");
        ?>
        <div class="wrap">
            <h1>🕐 Time Simulator</h1>
            <p>Fast-forward time to test email reminders and slot refills without waiting.</p>

            <?php
            // Show migration result if present
            if (class_exists('SEC_Survey_Migration')) {
                SEC_Survey_Migration::show_migration_result();

                // Show migration notice if needed
                if (SEC_Survey_Migration::needs_migration()) {
                    ?>
                    <div class="notice notice-warning inline" style="margin:20px 0;padding:15px;">
                        <p>
                            <strong>⚠ Data Migration Needed:</strong>
                            Some incomplete surveys have missing payment dates, which will cause reminder timing issues.
                            <a href="<?php echo admin_url('admin.php?page=sec-time-simulator&action=normalize_dates'); ?>" class="button button-primary" style="margin-left:10px;">
                                Fix Payment Dates Now
                            </a>
                        </p>
                    </div>
                    <?php
                }
            }
            ?>

            <div style="background:#fff;padding:20px;border-radius:8px;margin-bottom:20px;border:1px solid #ddd;">
                <h2 style="margin-top:0;">Current Time</h2>
                <table class="widefat" style="max-width:600px;">
                    <tr>
                        <td style="width:150px;font-weight:600;">Real Time:</td>
                        <td><code><?php echo $current_real; ?></code></td>
                    </tr>
                    <tr>
                        <td style="font-weight:600;">Simulated Time:</td>
                        <td>
                            <code style="color:#2536EB;font-weight:600;"><?php echo $current_simulated; ?></code>
                            <?php if ($simulated_offset > 0): ?>
                                <span style="color:#22c55e;margin-left:10px;">
                                    (+<?php echo human_time_diff(time(), time() + $simulated_offset); ?> ahead)
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>

                <h3>Fast-Forward Time</h3>
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="margin-bottom:20px;">
                    <?php wp_nonce_field('sec_simulate_time'); ?>
                    <input type="hidden" name="action" value="sec_simulate_time">

                    <div style="display:flex;gap:10px;flex-wrap:wrap;">
                        <button type="submit" name="offset" value="3600" class="button">+1 Hour</button>
                        <button type="submit" name="offset" value="86400" class="button">+1 Day</button>
                        <button type="submit" name="offset" value="259200" class="button">+3 Days</button>
                        <button type="submit" name="offset" value="604800" class="button">+7 Days</button>
                        <button type="submit" name="offset" value="1209600" class="button">+14 Days</button>
                    </div>
                </form>

                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" style="display:inline;">
                    <?php wp_nonce_field('sec_reset_time'); ?>
                    <input type="hidden" name="action" value="sec_reset_time">
                    <button type="submit" class="button button-secondary">Reset to Real Time</button>
                </form>

                <button type="button" id="sec-trigger-check" class="button button-primary" style="margin-left:10px;">
                    Trigger Reminder Check Now
                </button>
                <span id="sec-check-result" style="margin-left:10px;"></span>
            </div>

            <div style="background:#fff;padding:20px;border-radius:8px;border:1px solid #ddd;">
                <h2 style="margin-top:0;">Incomplete Surveys (Reminder Candidates)</h2>
                <?php if (empty($incomplete)): ?>
                    <p>No incomplete surveys found.</p>
                <?php else: ?>
                    <table class="widefat">
                        <thead>
                            <tr>
                                <th>Customer</th>
                                <th>Payment Date</th>
                                <th>Last Activity</th>
                                <th>Step</th>
                                <th>Reminders Sent</th>
                                <th>Time Since Payment</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($incomplete as $sub):
                                // Handle NULL or invalid payment dates - use WordPress timezone
                                $payment_time = false;
                                if (!empty($sub->payment_date) && $sub->payment_date !== '0000-00-00 00:00:00') {
                                    // Parse payment_date in WordPress timezone
                                    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
                                    $payment_dt = date_create_immutable_from_format('Y-m-d H:i:s', $sub->payment_date, $tz);
                                    if ($payment_dt) {
                                        $payment_time = $payment_dt->getTimestamp();
                                    }
                                }

                                $reminders = array();
                                if ($sub->reminder_1_sent) $reminders[] = '1';
                                if ($sub->reminder_2_sent) $reminders[] = '2';
                                if ($sub->reminder_3_sent) $reminders[] = '3';
                                if ($sub->reminder_4_sent) $reminders[] = '4';
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($sub->customer_name); ?></strong><br>
                                    <small><?php echo esc_html($sub->customer_email); ?></small>
                                </td>
                                <td><?php echo esc_html($sub->payment_date ?: 'N/A'); ?></td>
                                <td><?php echo esc_html($sub->last_activity ?: 'N/A'); ?></td>
                                <td>Step <?php echo $sub->survey_step; ?> / 11</td>
                                <td>
                                    <?php echo $reminders ? implode(', ', $reminders) : 'None'; ?>
                                </td>
                                <td>
                                    <?php
                                    if ($payment_time !== false) {
                                        echo human_time_diff($payment_time, time() + $simulated_offset) . ' ago';
                                    } else {
                                        echo '<em style="color:#dc2626;">No payment date</em>';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#sec-trigger-check').on('click', function() {
                var $btn = $(this);
                var $result = $('#sec-check-result');

                $btn.prop('disabled', true).text('Checking...');
                $result.html('<span style="color:#f59e0b;">⏳ Running reminder check...</span>');

                $.post(ajaxurl, {
                    action: 'sec_trigger_reminder_check',
                    nonce: '<?php echo wp_create_nonce('sec_trigger_check'); ?>'
                }, function(response) {
                    if (response.success) {
                        $result.html('<span style="color:#22c55e;">✓ ' + response.data + '</span>');
                        setTimeout(function() { location.reload(); }, 2000);
                    } else {
                        $result.html('<span style="color:#ef4444;">✗ ' + response.data + '</span>');
                    }
                    $btn.prop('disabled', false).text('Trigger Reminder Check Now');
                });
            });
        });
        </script>
        <?php
    }

    public static function handle_simulate_time() {
        check_admin_referer('sec_simulate_time');

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $offset = isset($_POST['offset']) ? intval($_POST['offset']) : 0;
        $current_offset = get_option('sec_time_offset', 0);
        $new_offset = $current_offset + $offset;

        update_option('sec_time_offset', $new_offset);

        wp_redirect(add_query_arg('page', 'sec-time-simulator', admin_url('admin.php')));
        exit;
    }

    public static function handle_reset_time() {
        check_admin_referer('sec_reset_time');

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        delete_option('sec_time_offset');

        wp_redirect(add_query_arg('page', 'sec-time-simulator', admin_url('admin.php')));
        exit;
    }

    public static function ajax_trigger_reminder_check() {
        check_ajax_referer('sec_trigger_check', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        // Manually trigger the reminder check
        do_action('sec_check_survey_reminders');

        wp_send_json_success('Reminder check completed. Page will reload to show updated status.');
    }

    /**
     * Get current simulated time as MySQL datetime
     */
    public static function get_current_time() {
        $offset = get_option('sec_time_offset', 0);
        return date('Y-m-d H:i:s', time() + $offset);
    }

    /**
     * Get current simulated timestamp
     */
    public static function get_current_timestamp() {
        $offset = get_option('sec_time_offset', 0);
        return time() + $offset;
    }
}

SEC_Time_Simulator::init();
