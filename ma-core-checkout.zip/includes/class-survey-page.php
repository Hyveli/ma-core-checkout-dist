<?php
/**
 * Standalone Survey Page Handler
 *
 * Replaces the modal popup with a full dedicated page experience.
 * On payment success, Stripe redirects to: /survey/?survey_token=xxx
 *
 * HOW IT WORKS:
 * 1. Stripe success_url is changed to point to the survey page URL with {CHECKOUT_SESSION_ID}
 * 2. This class intercepts that URL, validates the token, and serves the full-page survey
 * 3. The survey JS submits via the same AJAX actions as before (sec_submit_survey etc.)
 *
 * INSTALLATION:
 * - Add this file to your plugin's includes/ directory
 * - Call SEC_Survey_Page::init() from your main plugin file
 * - Update your Stripe success_url to: home_url('/survey/?survey_token={CHECKOUT_SESSION_ID}')
 *   (or whichever slug you configure in SEC_SURVEY_PAGE_SLUG below)
 *
 * WHITELIST FIX (rate limiting):
 * - See the end of this file for instructions to clear your IP's rate-limit transient
 * - Or call SEC_Survey_Page::clear_rate_limit_for_current_ip() from WP CLI / admin
 */

if (!defined('ABSPATH')) exit;

// ─── Configuration ────────────────────────────────────────────────────────────
define('SEC_SURVEY_PAGE_SLUG', 'survey'); // The WP page slug or virtual path

class SEC_Survey_Page {

    /**
     * Initialize hooks
     */
    public static function init() {
        // Create the WP page on activation if it doesn't exist
        add_action('admin_init', array(__CLASS__, 'maybe_create_page'));

        // Intercept the slug and serve the survey page template
        add_action('template_redirect', array(__CLASS__, 'maybe_serve_survey_page'));

        // Assets for the survey page
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_survey_assets'));

        // Admin: rate-limit reset tool
        add_action('admin_post_sec_clear_rate_limit', array(__CLASS__, 'handle_clear_rate_limit'));
        add_action('wp_ajax_sec_clear_rate_limit_ip', array(__CLASS__, 'ajax_clear_rate_limit'));
    }

    /**
     * Create the /survey/ WordPress page if it doesn't already exist.
     * The page uses a blank template — all HTML is output by this class.
     */
    public static function maybe_create_page() {
        $slug = SEC_SURVEY_PAGE_SLUG;

        if (get_page_by_path($slug)) {
            return; // Already exists
        }

        wp_insert_post(array(
            'post_title'   => 'Website Launch Survey',
            'post_name'    => $slug,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '',
            'meta_input'   => array('_sec_survey_page' => '1'),
        ));
    }

    public static function maybe_serve_survey_page() {
    if ( ! is_page( SEC_SURVEY_PAGE_SLUG ) ) return;

    $survey_token = isset( $_GET['survey_token'] ) ? sanitize_text_field( $_GET['survey_token'] ) : '';
    $session_data = array();
    $resume_token = '';
    $resume_step  = 0;
    $resume_answers = null;
    $is_resume    = false;

    if ( $survey_token ) {
        // Embedded Stripe return_url passes Checkout Session ID here first.
        if (strpos($survey_token, 'cs_') === 0) {
            $normalized_token = self::bootstrap_from_checkout_session($survey_token);
            if (!empty($normalized_token) && $normalized_token !== $survey_token) {
                wp_safe_redirect(add_query_arg(
                    array('survey_token' => rawurlencode($normalized_token)),
                    trailingslashit(home_url(SEC_SURVEY_PAGE_SLUG))
                ));
                exit;
            }
            if (!empty($normalized_token)) {
                $survey_token = $normalized_token;
            }
        }

        $submission = SEC_Survey_DB::get_submission_by_token( $survey_token );

        if ( $submission && $submission->survey_completed ) {
            self::serve_already_submitted();
            exit;
        }

        if ( $submission ) {
            $resume_token   = $survey_token;
            $resume_step    = (int) $submission->survey_step;
            $resume_answers = $submission->survey_progress ? json_decode( $submission->survey_progress, true ) : null;
            $is_resume      = $resume_step > 0;
            $session_data   = array(
                'customer_id'    => $submission->stripe_customer_id,
                'customer_name'  => $submission->customer_name,
                'customer_email' => $submission->customer_email,
                'payment_amount' => (float) $submission->payment_amount,
                'session_id'     => $submission->stripe_session_id,
            );
        }
    }

    self::serve_page( $session_data, $resume_token, $resume_step, $resume_answers, $is_resume );
    exit;
}

    /**
     * Convert a Stripe Checkout Session ID into a persisted survey token.
     * Also sends post-payment customer emails once when this path is first hit.
     */
    private static function bootstrap_from_checkout_session($checkout_session_id) {
        $checkout_session_id = sanitize_text_field($checkout_session_id);
        if (empty($checkout_session_id)) {
            return '';
        }

        $existing = SEC_Survey_DB::get_submission_by_stripe_session_id($checkout_session_id);
        if ($existing && !empty($existing->survey_token)) {
            return $existing->survey_token;
        }

        if (!defined('STRIPE_SECRET_KEY') || empty(STRIPE_SECRET_KEY)) {
            return '';
        }

        try {
            if (!class_exists('Stripe\\Stripe')) {
                require_once plugin_dir_path(dirname(__FILE__)) . 'vendor/autoload.php';
            }

            \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
            $session = \Stripe\Checkout\Session::retrieve($checkout_session_id);
            if (!$session || ($session->payment_status ?? '') !== 'paid') {
                return '';
            }

            $token_data = array(
                'full_name'     => $session->customer_details->name ?? '',
                'business_name' => $session->metadata->business_name ?? '',
                'email'         => $session->customer_details->email ?? '',
            );

            $survey_token = SEC_Survey_Modal::store_payment_session($session, $token_data);
            if (empty($survey_token)) {
                return '';
            }

            self::maybe_send_post_payment_emails($session, $survey_token, $token_data);
            return $survey_token;
        } catch (Exception $e) {
            error_log('SEC Survey Page bootstrap error: ' . $e->getMessage());
            return '';
        }
    }

    /**
     * Send customer-facing payment/survey emails once per Stripe session.
     */
    private static function maybe_send_post_payment_emails($session, $survey_token, $token_data) {
        if (!class_exists('SEC_Survey_Email') || empty($session) || empty($survey_token)) {
            return;
        }

        $session_id = sanitize_text_field($session->id ?? '');
        if (empty($session_id)) {
            return;
        }

        $mail_lock_key = 'sec_post_payment_mails_' . md5($session_id);
        if (get_transient($mail_lock_key)) {
            return;
        }

        $customer_email = sanitize_email($token_data['email'] ?? ($session->customer_details->email ?? ''));
        $customer_name  = sanitize_text_field($token_data['full_name'] ?? ($session->customer_details->name ?? ''));
        $business_name  = sanitize_text_field($token_data['business_name'] ?? '');

        if (!empty($customer_email)) {
            SEC_Survey_Email::send_payment_receipt(array(
                'customer_email' => $customer_email,
                'customer_name'  => $customer_name,
                'amount'         => intval($session->amount_total ?? 0),
                'business_name'  => $business_name,
            ));

            SEC_Survey_Email::send_survey_invitation($customer_email, $customer_name, $survey_token, $business_name);
        }

        set_transient($mail_lock_key, 1, 7 * DAY_IN_SECONDS);
    }

    /**
     * Output the complete standalone survey page.
     */
    private static function serve_page($session_data, $resume_token, $resume_step, $resume_answers, $is_resume) {
        $nonce = wp_create_nonce('sec_survey_nonce');

        // Serialize the JS config
        $js_config = wp_json_encode(array(
            'ajax_url'       => admin_url('admin-ajax.php'),
            'nonce'          => $nonce,
            'session'        => $session_data,
            'auto_open'      => true,
            'resume_token'   => $resume_token,
            'resume_step'    => $resume_step,
            'resume_answers' => $resume_answers,
            'is_resume'      => $is_resume,
        ));

        // Plugin asset URLs
        $plugin_url = plugin_dir_url(dirname(__FILE__));

        // Collect blog name and favicon
        $site_name  = get_bloginfo('name');
        $favicon    = get_site_icon_url(32);

        header('Content-Type: text/html; charset=UTF-8');
        header('Cache-Control: no-store');

        echo '<!DOCTYPE html>';
        echo '<html lang="en" data-theme="light">';
        echo '<head>';
        echo '<meta charset="UTF-8">';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
        echo '<title>Website Launch Survey — ' . esc_attr($site_name) . '</title>';
        if ($favicon) echo '<link rel="icon" href="' . esc_url($favicon) . '">';

        // Fonts
        echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
        echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
        echo '<link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;0,9..40,800&display=swap" rel="stylesheet">';

        // Survey page base styles + JSX design components
        echo '<link rel="stylesheet" href="' . esc_url($plugin_url . 'assets/css/survey-page.css?v=2.0.0') . '">';
        echo '<link rel="stylesheet" href="' . esc_url($plugin_url . 'assets/css/survey-modal.css?v=2.0.0') . '">';
        echo '<link rel="stylesheet" href="' . esc_url($plugin_url . 'assets/css/survey-time-picker.css?v=2.0.0') . '">';

        echo '</head>';
        echo '<body>';

        // Inject JS config BEFORE the survey script
        echo '<script>';
        echo 'window.secSurveyData = ' . $js_config . ';';
        echo '</script>';

        // Include the standalone HTML body (nav, main, and inline script)
        $template = plugin_dir_path(__FILE__) . '../templates/survey-page-body.php';
        if ( ! file_exists($template) ) {
            die('Survey template not found at: ' . $template);
        }
        include $template;

        echo '</body>';
        echo '</html>';
    }

    /**
     * Serve a simple "already submitted" page.
     */
    private static function serve_already_submitted() {
        header('Content-Type: text/html; charset=UTF-8');
        ?>
        <!DOCTYPE html>
        <html lang="en" data-theme="light">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Survey Already Submitted</title>
            <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
            <style>
                :root[data-theme="light"] { --brand-blue:#2536EB; --bg-secondary:#f8f9fa; --text-primary:#1f2937; --text-secondary:#6b7280; --border-color:#e5e7eb; --bg-primary:#fff; --success-color:#22c55e; }
                body { font-family: 'DM Sans',sans-serif; background:var(--bg-secondary); color:var(--text-primary); display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0; }
                .card { background:var(--bg-primary); border-radius:20px; border:1px solid var(--border-color); padding:3rem 2rem; max-width:480px; width:90%; text-align:center; box-shadow:0 10px 25px rgba(0,0,0,0.1); }
                .icon { width:72px;height:72px;background:linear-gradient(135deg,var(--success-color),#10b981);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1.5rem;font-size:2rem;color:white; }
                h1 { font-size:1.75rem;font-weight:800;margin-bottom:0.75rem; }
                p  { color:var(--text-secondary);line-height:1.7; }
                a  { color:var(--brand-blue);font-weight:600;text-decoration:none; }
            </style>
        </head>
        <body>
            <div class="card">
                <div class="icon">✓</div>
                <h1>Survey Already Submitted</h1>
                <p>We've already received your website information. Our team is working on your preview and will be in touch within 48 hours.</p>
                <p style="margin-top:1.5rem;"><a href="<?php echo esc_url(home_url('/')); ?>">← Return to homepage</a></p>
            </div>
        </body>
        </html>
        <?php
    }

    /**
     * Enqueue assets — only when on the survey page (fallback for non-intercepted renders).
     * In most cases serve_page() handles assets directly.
     */
    public static function enqueue_survey_assets() {
        if (!is_page(SEC_SURVEY_PAGE_SLUG)) return;

        wp_enqueue_style(
            'sec-survey-page',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/survey-page.css',
            array(),
            '2.0.0'  // Updated for new design
        );
    }

    // =========================================================================
    // RATE LIMIT MANAGEMENT
    // =========================================================================

    /**
     * Get the transient key for a given IP address.
     * This is the SAME key used in stripe-embedded-checkout.php.
     */
    public static function rate_limit_key($ip = '') {
        if (empty($ip)) {
            foreach (array('HTTP_CF_CONNECTING_IP','HTTP_X_REAL_IP','HTTP_X_FORWARDED_FOR','REMOTE_ADDR') as $hdr) {
                if (!empty($_SERVER[$hdr])) {
                    $ip = trim(explode(',', $_SERVER[$hdr])[0]);
                    break;
                }
            }
        }
        return 'sec_rate_' . md5(sanitize_text_field($ip));
    }

    /**
     * Clear the rate limit for the current request's IP.
     * Call this from wp-cli or a temporary admin page:
     *
     *   SEC_Survey_Page::clear_rate_limit_for_current_ip();
     *
     * Or from WP-CLI:
     *   wp eval "SEC_Survey_Page::clear_rate_limit_for_ip('YOUR_IP_HERE');"
     */
    public static function clear_rate_limit_for_current_ip() {
        $key = self::rate_limit_key();
        delete_transient($key);
        return $key;
    }

    /**
     * Clear rate limit for a specific IP address.
     *
     * @param string $ip e.g. '192.168.1.1'
     */
    public static function clear_rate_limit_for_ip($ip) {
        $key = self::rate_limit_key($ip);
        delete_transient($key);
        return $key;
    }

    /**
     * Admin POST handler — clears rate limit for the currently-logged-in admin's IP.
     * Accessible via: wp-admin/admin-post.php?action=sec_clear_rate_limit&_wpnonce=XXX
     */
    public static function handle_clear_rate_limit() {
        if (!current_user_can('manage_options')) wp_die('Unauthorized');
        check_admin_referer('sec_clear_rate_limit');
        $key = self::clear_rate_limit_for_current_ip();
        wp_redirect(add_query_arg(array('sec_rate_cleared' => '1', 'key' => $key), wp_get_referer()));
        exit;
    }

    /**
     * AJAX handler — allows admins to clear a rate limit from the WP admin UI.
     */
    public static function ajax_clear_rate_limit() {
        if (!current_user_can('manage_options')) wp_send_json_error('Unauthorized');
        check_ajax_referer('sec_admin_nonce', 'nonce');

        $ip = isset($_POST['ip']) ? sanitize_text_field($_POST['ip']) : '';
        if ($ip) {
            self::clear_rate_limit_for_ip($ip);
            wp_send_json_success("Rate limit cleared for IP: $ip");
        } else {
            $key = self::clear_rate_limit_for_current_ip();
            wp_send_json_success("Rate limit cleared. Transient key: $key");
        }
    }
}

// Initialize
SEC_Survey_Page::init();
