<?php
/**
 * Survey Abandonment Reminder System
 *
 * Sends timed reminder emails to customers who haven't completed their survey.
 * Runs via WP Cron every 15 minutes.
 *
 * Reminder Schedule:
 * - 1 hour after payment (helpful/casual)
 * - 24 hours after payment (more direct)
 * - 72 hours after payment (urgency)
 * - 7 days after payment ("onboarding spot at risk")
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_Reminders {

    public static function init() {
        // Schedule cron job
        add_action('wp', array(__CLASS__, 'schedule_cron'));
        add_action('sec_check_survey_reminders', array(__CLASS__, 'check_and_send_reminders'));
    }

    /**
     * Schedule the cron job to run every 15 minutes
     */
    public static function schedule_cron() {
        if (!wp_next_scheduled('sec_check_survey_reminders')) {
            wp_schedule_event(time(), 'every_15_minutes', 'sec_check_survey_reminders');
        }
    }

    /**
     * Add custom cron interval for 15 minutes
     */
    public static function add_cron_interval($schedules) {
        $schedules['every_15_minutes'] = array(
            'interval' => 900, // 15 minutes in seconds
            'display'  => __('Every 15 Minutes')
        );
        return $schedules;
    }

    /**
     * Main cron function - checks for incomplete surveys and sends reminders
     */
    public static function check_and_send_reminders() {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';

        // Use simulated time if available, otherwise real time
        $current_time = class_exists('SEC_Time_Simulator')
            ? SEC_Time_Simulator::get_current_time()
            : current_time('mysql');

        // Get all incomplete surveys (tokenized but not completed)
        $incomplete_surveys = $wpdb->get_results("
            SELECT * FROM {$table}
            WHERE survey_completed = 0
              AND survey_token IS NOT NULL
              AND survey_token != ''
        ");

        foreach ($incomplete_surveys as $submission) {
            self::process_reminder($submission, $current_time);
        }
    }

    /**
     * Process reminder for a single submission
     */
    private static function process_reminder($submission, $current_time) {
        // Skip if no valid payment date
        if (empty($submission->payment_date) || $submission->payment_date === '0000-00-00 00:00:00') {
            return;
        }

        // Parse stored payment_date in the site's configured timezone.
        $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
        $payment_dt = date_create_immutable_from_format('Y-m-d H:i:s', $submission->payment_date, $tz);
        if (!$payment_dt) {
            return; // Invalid date format
        }

        // Use WordPress current datetime for timezone consistency.
        $current_dt = function_exists('current_datetime') ? current_datetime() : new DateTimeImmutable('now', $tz);
        $time_since_payment = $current_dt->getTimestamp() - $payment_dt->getTimestamp();

        if ($time_since_payment < 0) {
            // If clocks/timezones are off, never send early.
            return;
        }

        // Check all reminders independently (not elseif!)
        // This allows catching up if time simulation jumps forward

        // Reminder 1: 1 hour after payment (if not sent)
        if (!$submission->reminder_1_sent && $time_since_payment >= 3600) {
            self::send_reminder_email($submission, 1);
            self::mark_reminder_sent($submission->id, 1);
        }

        // Reminder 2: 24 hours after payment (if not sent)
        if (!$submission->reminder_2_sent && $time_since_payment >= 86400) {
            self::send_reminder_email($submission, 2);
            self::mark_reminder_sent($submission->id, 2);
        }

        // Reminder 3: 72 hours after payment (if not sent)
        if (!$submission->reminder_3_sent && $time_since_payment >= 259200) {
            self::send_reminder_email($submission, 3);
            self::mark_reminder_sent($submission->id, 3);
        }

        // Reminder 4: 7 days after payment (if not sent)
        if (!$submission->reminder_4_sent && $time_since_payment >= 604800) {
            self::send_reminder_email($submission, 4);
            self::mark_reminder_sent($submission->id, 4);
        }
    }

    /**
     * Mark a reminder as sent in the database
     */
    private static function mark_reminder_sent($submission_id, $reminder_number) {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';
        $field = 'reminder_' . $reminder_number . '_sent';

        // Use simulated time if available, otherwise real time
        $sent_at = class_exists('SEC_Time_Simulator')
            ? SEC_Time_Simulator::get_current_time()
            : current_time('mysql');

        $wpdb->update(
            $table,
            array(
                $field => 1,
                'reminder_' . $reminder_number . '_sent_at' => $sent_at
            ),
            array('id' => $submission_id),
            array('%d', '%s'),
            array('%d')
        );
    }

    /**
     * Send reminder email
     */
    private static function send_reminder_email($submission, $reminder_number) {
        $first_name = self::get_first_name($submission->customer_name);
        $resume_url = home_url('/survey/?survey_token=' . $submission->survey_token);
        $current_step = (int) $submission->survey_step;
        $total_steps = 11; // Total survey steps
        $progress_percent = round(($current_step / $total_steps) * 100);

        $subject = self::get_subject_line($reminder_number, $first_name);
        $body = self::get_email_body($reminder_number, $first_name, $current_step, $total_steps, $progress_percent, $resume_url);

        // Get sender info from branding settings - use reminder-specific From address
        $from_email = get_option('sec_reminder_from_email', '');
        if (empty($from_email)) {
            $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        }
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));

        // Allow filtering
        $from_email = apply_filters('sec_reminder_email_from', $from_email, $submission->customer_email);
        $from_name = apply_filters('sec_reminder_email_from_name', $from_name . ' Alerts', $submission->customer_email);

        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );

        // Add logo if available
        $logo_url = get_option('sec_logo_url', '');

        wp_mail($submission->customer_email, $subject, $body, $headers);

        // Log the reminder
        error_log("Survey reminder {$reminder_number} sent to {$submission->customer_email}");
    }

    /**
     * Get first name from full name
     */
    private static function get_first_name($full_name) {
        $parts = explode(' ', trim($full_name));
        return !empty($parts[0]) ? $parts[0] : 'there';
    }

    /**
     * Get email subject line based on reminder number
     */
    private static function get_subject_line($reminder_number, $first_name) {
        $subjects = array(
            1 => "{$first_name}, your website setup is waiting",
            2 => "Quick reminder: Complete your website setup",
            3 => "{$first_name}, we're ready to build your site",
            4 => "Final notice: Your onboarding spot is at risk"
        );
        return $subjects[$reminder_number];
    }

    /**
     * Get email body HTML
     */
    private static function get_email_body($reminder_number, $first_name, $current_step, $total_steps, $progress_percent, $resume_url) {
        $logo_url = get_option('sec_logo_url', '');
        $brand_color = '#2536EB';

        // Different messaging for each reminder
        $messages = array(
            1 => array(
                'heading' => "Hi {$first_name},",
                'body' => "Thanks for starting your website setup! I noticed you left off at <strong>Step {$current_step} of {$total_steps}</strong>.<br><br>No worries – your progress is saved and you can pick up right where you left off. It'll only take a few more minutes to finish.",
                'cta' => 'Continue Your Setup'
            ),
            2 => array(
                'heading' => "Hi {$first_name},",
                'body' => "You're <strong>{$progress_percent}% done</strong> with your website setup, but we can't start building until the survey is complete.<br><br>You left off at <strong>Step {$current_step} of {$total_steps}</strong>. Let's finish this so we can get your site live!",
                'cta' => 'Finish Setup Now'
            ),
            3 => array(
                'heading' => "{$first_name}, we're ready when you are",
                'body' => "Our team is standing by to build your custom website, but we need your input first.<br><br>You're <strong>{$progress_percent}% complete</strong> (Step {$current_step} of {$total_steps}). The sooner you finish, the sooner we can deliver your site.",
                'cta' => 'Complete Setup'
            ),
            4 => array(
                'heading' => "Final notice: {$first_name}",
                'body' => "It's been 7 days since your payment, and your website setup is still incomplete.<br><br><strong>Your onboarding spot is at risk.</strong> If we don't hear from you soon, we may need to release your slot to another customer.<br><br>You're only <strong>" . ($total_steps - $current_step) . " steps away</strong> from getting your website built.",
                'cta' => 'Secure Your Spot'
            )
        );

        $msg = $messages[$reminder_number];

        $html = '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>' . esc_html($msg['heading']) . '</title>
    <!--[if mso]>
    <style type="text/css">
        table {border-collapse:collapse;border-spacing:0;margin:0;}
        td {padding:0;}
    </style>
    <![endif]-->
</head>
<body style="margin:0;padding:0;font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',Roboto,\'Helvetica Neue\',Arial,sans-serif;background-color:#f8f9fa;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#f8f9fa;padding:40px 20px;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;background-color:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,0.1);">
                    ';

        // Logo header
        if ($logo_url) {
            $html .= '
                    <tr>
                        <td align="center" style="padding:30px 40px 20px;">
                            <img src="' . esc_url($logo_url) . '" alt="Logo" style="max-width:180px;height:auto;">
                        </td>
                    </tr>';
        }

        $html .= '
                    <!-- Heading -->
                    <tr>
                        <td style="padding:20px 40px 0;">
                            <h1 style="margin:0;font-size:24px;font-weight:700;color:#1f2937;line-height:1.3;">' . $msg['heading'] . '</h1>
                        </td>
                    </tr>

                    <!-- Progress Bar -->
                    <tr>
                        <td style="padding:20px 40px;">
                            <div style="background:#e5e7eb;border-radius:999px;height:8px;overflow:hidden;margin-bottom:8px;">
                                <div style="background:' . $brand_color . ';height:8px;width:' . $progress_percent . '%;border-radius:999px;"></div>
                            </div>
                            <p style="margin:0;font-size:13px;color:#6b7280;text-align:center;"><strong>Step ' . $current_step . ' of ' . $total_steps . '</strong> • ' . $progress_percent . '% Complete</p>
                        </td>
                    </tr>

                    <!-- Body Text -->
                    <tr>
                        <td style="padding:0 40px 30px;">
                            <p style="margin:0;font-size:16px;line-height:1.6;color:#4b5563;">' . $msg['body'] . '</p>
                        </td>
                    </tr>

                    <!-- CTA Button -->
                    <tr>
                        <td align="center" style="padding:0 40px 40px;">
                            <a href="' . esc_url($resume_url) . '" style="display:inline-block;background:' . $brand_color . ';color:#ffffff;text-decoration:none;padding:16px 32px;border-radius:8px;font-size:16px;font-weight:600;box-shadow:0 4px 12px rgba(37,54,235,0.3);">' . $msg['cta'] . ' →</a>
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="padding:30px 40px;background:#f8f9fa;border-top:1px solid #e5e7eb;">
                            <p style="margin:0;font-size:13px;color:#9ca3af;text-align:center;margin-bottom:12px;">Need help? Just reply to this email.<br>Your progress is automatically saved.</p>';

        // Add unsubscribe footer if enabled
        $unsubscribe_enabled = get_option('sec_enable_unsubscribe', false);
        if ($unsubscribe_enabled && class_exists('SEC_Unsubscribe')) {
            $unsubscribe_url = SEC_Unsubscribe::get_unsubscribe_url($submission->customer_email);
            $company_name = get_option('sec_email_from_name', get_bloginfo('name'));
            $html .= '<p style="margin:0;font-size:12px;color:#9ca3af;text-align:center;line-height:1.6;">
                © ' . date('Y') . ' ' . esc_html($company_name) . '. All rights reserved.<br>
                <a href="' . esc_url($unsubscribe_url) . '" style="color:#9ca3af;text-decoration:underline;">Unsubscribe</a>
            </p>';
        } else {
            $company_name = get_option('sec_email_from_name', get_bloginfo('name'));
            $html .= '<p style="margin:0;font-size:12px;color:#9ca3af;text-align:center;line-height:1.6;">
                © ' . date('Y') . ' ' . esc_html($company_name) . '. All rights reserved.
            </p>';
        }

        $html .= '
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';

        return $html;
    }
}

// Add custom cron interval
add_filter('cron_schedules', array('SEC_Survey_Reminders', 'add_cron_interval'));

// Initialize
SEC_Survey_Reminders::init();
