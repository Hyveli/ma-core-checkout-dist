<?php
/**
 * Survey Modal Handler
 *
 * Handles survey modal display, AJAX submission, and integration with Stripe payments
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_Modal {
    private static function is_allowed_survey_upload($filename, $mime_type = '') {
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'webp', 'svg', 'pdf', 'doc', 'docx');
        $ext = strtolower(pathinfo((string) $filename, PATHINFO_EXTENSION));
        $mime = strtolower((string) $mime_type);

        if (in_array($ext, $allowed_extensions, true)) {
            return true;
        }
        if (strpos($mime, 'image/') === 0) {
            return true;
        }
        return in_array($mime, array(
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        ), true);
    }

    /**
     * Initialize the survey modal
     */
    public static function init() {
        // Register AJAX handlers
        add_action('wp_ajax_sec_submit_survey', array(__CLASS__, 'ajax_submit_survey'));
        add_action('wp_ajax_nopriv_sec_submit_survey', array(__CLASS__, 'ajax_submit_survey'));

        add_action('wp_ajax_sec_upload_survey_file', array(__CLASS__, 'ajax_upload_survey_file'));
        add_action('wp_ajax_nopriv_sec_upload_survey_file', array(__CLASS__, 'ajax_upload_survey_file'));

        add_action('wp_ajax_sec_delete_survey_file', array(__CLASS__, 'ajax_delete_survey_file'));

        // Auto-save survey progress
        add_action('wp_ajax_sec_save_survey_progress', array(__CLASS__, 'ajax_save_survey_progress'));
        add_action('wp_ajax_nopriv_sec_save_survey_progress', array(__CLASS__, 'ajax_save_survey_progress'));

        // Validate a resume token and return saved progress
        add_action('wp_ajax_sec_get_survey_progress', array(__CLASS__, 'ajax_get_survey_progress'));
        add_action('wp_ajax_nopriv_sec_get_survey_progress', array(__CLASS__, 'ajax_get_survey_progress'));

        // Enqueue assets when payment_complete parameter is present OR a valid survey token is in the URL
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));

        // Output survey modal HTML
        add_action('wp_footer', array(__CLASS__, 'output_survey_modal'));
    }

    /**
     * Enqueue survey modal assets
     */
    public static function enqueue_assets() {
        // Trigger on ?payment_complete OR ?survey_token=xxx
        $has_payment_complete = isset($_GET['payment_complete']);
        $survey_token         = isset($_GET['survey_token']) ? sanitize_text_field($_GET['survey_token']) : '';
        $has_token            = !empty($survey_token);

        if (!$has_payment_complete && !$has_token) {
            return;
        }

        // Enqueue CSS
        wp_enqueue_style(
            'sec-survey-modal',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/survey-modal.css',
            array(),
            '2.0.0'  // Updated for new JSX-style design
        );

        wp_enqueue_style(
            'sec-survey-time-picker',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/survey-time-picker.css',
            array('sec-survey-modal'),
            '2.0.0'  // Updated for new JSX-style design
        );

        // Enqueue JavaScript
        wp_enqueue_script(
            'sec-survey-modal',
            plugin_dir_url(dirname(__FILE__)) . 'assets/js/survey-modal.js',
            array(),
            '2.0.0',  // Updated for new JSX-style design
            true
        );

        // Resolve session data: from PHP session OR from DB token
        $session_data = self::get_session_data();
        $resume_token = '';
        $resume_step  = 0;
        $resume_answers = null;

        if ($has_token) {
            $submission = SEC_Survey_DB::get_submission_by_token($survey_token);
            if ($submission && !$submission->survey_completed) {
                $resume_token   = $survey_token;
                $resume_step    = (int) $submission->survey_step;
                $resume_answers = $submission->survey_progress ? json_decode($submission->survey_progress, true) : null;
                // Populate session data from DB row
                $session_data = array(
                    'customer_id'    => $submission->stripe_customer_id,
                    'customer_name'  => $submission->customer_name,
                    'customer_email' => $submission->customer_email,
                    'payment_amount' => $submission->payment_amount,
                    'session_id'     => $submission->stripe_session_id,
                );
            }
        }

        wp_localize_script('sec-survey-modal', 'secSurveyData', array(
            'ajax_url'       => admin_url('admin-ajax.php'),
            'nonce'          => wp_create_nonce('sec_survey_nonce'),
            'session'        => $session_data,
            'auto_open'      => true,
            'resume_token'   => $resume_token,
            'resume_step'    => $resume_step,
            'resume_answers' => $resume_answers,
            'is_resume'      => !empty($resume_token),
        ));
    }

    /**
     * Get session data from the most recent payment
     */
    private static function get_session_data() {
        // Start session if not already started
        if (!session_id()) {
            session_start();
        }

        // Try to get session data from PHP session
        if (isset($_SESSION['sec_last_payment'])) {
            return $_SESSION['sec_last_payment'];
        }

        // Default data structure
        return array(
            'customer_id' => '',
            'customer_name' => '',
            'customer_email' => '',
            'payment_amount' => 0,
            'session_id' => ''
        );
    }

    /**
     * Output survey modal HTML structure
     */
    public static function output_survey_modal() {
        // Only output on pages with payment_complete parameter
        if (!isset($_GET['payment_complete'])) {
            return;
        }

        ?>
        <!-- Survey Modal Container (populated by JavaScript) -->
        <div id="sec-survey-modal-overlay" style="display: none;">
            <div id="sec-survey-modal"></div>
        </div>
        <?php
    }

    /**
     * AJAX: Save survey progress (auto-save per step)
     */
    public static function ajax_save_survey_progress() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_survey_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        $token   = sanitize_text_field($_POST['token'] ?? '');
        $step    = intval($_POST['step'] ?? 0);
        $answers = isset($_POST['answers']) ? json_decode(stripslashes($_POST['answers']), true) : array();
        if (is_array($answers) && isset($answers['socials']) && is_array($answers['socials'])) {
            $answers['socials'] = self::normalize_socials($answers['socials'], false);
        }

        if (empty($token)) {
            wp_send_json_error(array('message' => 'No token provided.'));
        }

        // Verify the token belongs to a real (non-completed) submission
        $submission = SEC_Survey_DB::get_submission_by_token($token);
        if (!$submission || $submission->survey_completed) {
            wp_send_json_error(array('message' => 'Invalid or already-completed survey token.'));
        }

        $saved = SEC_Survey_DB::save_survey_progress($token, $step, $answers);

        if ($saved) {
            wp_send_json_success(array('message' => 'Progress saved.', 'step' => $step));
        } else {
            wp_send_json_error(array('message' => 'Failed to save progress.'));
        }
    }

    /**
     * AJAX: Get saved survey progress by token
     */
    public static function ajax_get_survey_progress() {
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_survey_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        $token = sanitize_text_field($_POST['token'] ?? '');
        if (empty($token)) {
            wp_send_json_error(array('message' => 'No token.'));
        }

        $submission = SEC_Survey_DB::get_submission_by_token($token);
        if (!$submission) {
            wp_send_json_error(array('message' => 'Token not found.'));
        }

        if ($submission->survey_completed) {
            wp_send_json_error(array('message' => 'Survey already completed.', 'completed' => true));
        }

        $answers = $submission->survey_progress ? json_decode($submission->survey_progress, true) : array();

        wp_send_json_success(array(
            'step'    => (int) $submission->survey_step,
            'answers' => $answers,
            'session' => array(
                'customer_id'    => $submission->stripe_customer_id,
                'customer_name'  => $submission->customer_name,
                'customer_email' => $submission->customer_email,
                'payment_amount' => $submission->payment_amount,
                'session_id'     => $submission->stripe_session_id,
            ),
        ));
    }

    /**
     * Handle survey file upload via AJAX
     */
    public static function ajax_upload_survey_file() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_survey_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        // Check if file was uploaded
        if (empty($_FILES['file'])) {
            wp_send_json_error(array('message' => 'No file uploaded.'));
        }

        $file = $_FILES['file'];

        // Validate file size (35MB max)
        $max_size = 35 * 1024 * 1024; // 35MB in bytes
        if ($file['size'] > $max_size) {
            wp_send_json_error(array('message' => 'File size exceeds 35MB limit.'));
        }

        // Validate file type (extension + MIME fallback for better compatibility)
        $file_type = function_exists('mime_content_type') ? mime_content_type($file['tmp_name']) : '';
        if (!self::is_allowed_survey_upload($file['name'], $file_type)) {
            wp_send_json_error(array('message' => 'Invalid file type. Allowed: JPG, PNG, WEBP, SVG, PDF, DOC, DOCX.'));
        }

        $locations = SEC_Survey_DB::get_survey_upload_locations();
        $survey_dir = $locations['current']['dir'];

        // Create directory if it doesn't exist
        if (!file_exists($survey_dir)) {
            wp_mkdir_p($survey_dir);
        }

        // Generate unique filename
        $file_ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $file_name = wp_unique_filename($survey_dir, uniqid() . '_' . sanitize_file_name($file['name']));
        $file_path = $survey_dir . $file_name;

        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            $file_url = trailingslashit($locations['current']['url']) . $file_name;
            wp_send_json_success(array(
                'file_path' => $file_url,
                'file_name' => $file['name'],
                'file_size' => $file['size'],
                'file_type' => $file_type
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to upload file.'));
        }
    }

    /**
     * Handle survey file deletion via AJAX
     */
    public static function ajax_delete_survey_file() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_delete_file_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        // Check user permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to delete files.'));
        }

        $submission_id = intval($_POST['submission_id'] ?? 0);
        $file_type = sanitize_text_field($_POST['file_type'] ?? '');
        $file_url = esc_url_raw($_POST['file_url'] ?? '');

        if (!$submission_id || !$file_type || !$file_url) {
            wp_send_json_error(array('message' => 'Missing required parameters.'));
        }

        // Get submission from database
        $submission = SEC_Survey_DB::get_submission($submission_id);
        if (!$submission) {
            wp_send_json_error(array('message' => 'Submission not found.'));
        }

        // Extract filename from URL
        $file_path = SEC_Survey_DB::resolve_stored_file_path($file_url);

        // Delete the physical file
        $file_deleted = false;
        if (!empty($file_path) && file_exists($file_path)) {
            $file_deleted = unlink($file_path);
        }

        // Update database to remove file reference
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';
        $updated = false;

        if ($file_type === 'logo') {
            // Remove logo
            $updated = $wpdb->update(
                $table_name,
                array('logo_path' => ''),
                array('id' => $submission_id),
                array('%s'),
                array('%d')
            );
        } else {
            // Remove from file_paths array
            $file_paths = maybe_unserialize($submission->file_paths);
            if (is_array($file_paths)) {
                $file_paths = array_filter($file_paths, function($path) use ($file_url) {
                    return $path !== $file_url;
                });
                $updated = $wpdb->update(
                    $table_name,
                    array('file_paths' => maybe_serialize(array_values($file_paths))),
                    array('id' => $submission_id),
                    array('%s'),
                    array('%d')
                );
            }
        }

        if ($updated !== false || $file_deleted) {
            wp_send_json_success(array(
                'message' => 'File deleted successfully.',
                'file_deleted' => $file_deleted,
                'db_updated' => $updated !== false
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to delete file.'));
        }
    }

    /**
     * Handle survey submission via AJAX
     */
    public static function ajax_submit_survey() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_survey_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        // Log submission attempt
        error_log('SEC Survey: Starting submission...');
        error_log('SEC Survey: POST data: ' . print_r(array_keys($_POST), true));
        error_log('SEC Survey: FILES data: ' . print_r(array_keys($_FILES), true));

        // Handle file uploads first
        $logo_path = sanitize_text_field($_POST['logo_path'] ?? '');
        $file_paths = array();

        // Keep any already-uploaded file paths sent from draft state.
        $existing_file_paths = isset($_POST['existing_file_paths']) ? json_decode(stripslashes($_POST['existing_file_paths']), true) : array();
        if (is_array($existing_file_paths)) {
            foreach ($existing_file_paths as $existing_path) {
                $clean_path = esc_url_raw($existing_path);
                if (!empty($clean_path)) {
                    $file_paths[] = $clean_path;
                }
            }
        }

        // Upload logo file if present
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $logo_upload = self::handle_file_upload($_FILES['logo']);
            if ($logo_upload['success']) {
                $logo_path = $logo_upload['file_path'];
            }
        }

        // Upload multiple files if present
        if (isset($_FILES['files']) && is_array($_FILES['files']['name'])) {
            foreach ($_FILES['files']['name'] as $key => $filename) {
                if ($_FILES['files']['error'][$key] === UPLOAD_ERR_OK) {
                    $file = array(
                        'name' => $_FILES['files']['name'][$key],
                        'type' => $_FILES['files']['type'][$key],
                        'tmp_name' => $_FILES['files']['tmp_name'][$key],
                        'error' => $_FILES['files']['error'][$key],
                        'size' => $_FILES['files']['size'][$key]
                    );
                    $file_upload = self::handle_file_upload($file);
                    if ($file_upload['success']) {
                        $file_paths[] = $file_upload['file_path'];
                    }
                }
            }
        }

        if (!empty($file_paths)) {
            $file_paths = array_values(array_unique($file_paths));
        }

        $hours_raw = isset($_POST['hours']) ? json_decode(stripslashes($_POST['hours']), true) : array();
        $booking_raw = isset($_POST['booking']) ? json_decode(stripslashes($_POST['booking']), true) : array();
        $socials_raw = isset($_POST['socials']) ? json_decode(stripslashes($_POST['socials']), true) : array();
        $brand_raw = isset($_POST['brand']) ? json_decode(stripslashes($_POST['brand']), true) : array();

        $socials_normalized = self::normalize_socials($socials_raw, true);
        if (is_wp_error($socials_normalized)) {
            wp_send_json_error(array(
                'message' => $socials_normalized->get_error_message(),
            ));
        }

        // Prepare submission data
        $submission_data = array(
            // Required payment info
            'stripe_customer_id' => sanitize_text_field($_POST['customer_id'] ?? ''),
            'stripe_session_id' => sanitize_text_field($_POST['session_id'] ?? ''),
            'customer_name' => sanitize_text_field($_POST['customer_name'] ?? ''),
            'customer_email' => sanitize_email($_POST['customer_email'] ?? ''),
            'payment_amount' => floatval($_POST['payment_amount'] ?? 0),

            // Survey fields
            'business_name' => sanitize_text_field($_POST['business_name'] ?? ''),
            'industry' => sanitize_text_field($_POST['industry'] ?? ''),
            'custom_industry' => sanitize_text_field($_POST['custom_industry'] ?? ''),
            'tagline' => wp_kses_post($_POST['tagline'] ?? ''),
            'services' => wp_kses_post($_POST['services'] ?? ''),

            // JSON fields - decode and sanitize recursively
            'hours' => self::sanitize_array_recursive($hours_raw),
            'booking' => self::sanitize_array_recursive($booking_raw),
            'socials' => $socials_normalized,
            'brand' => self::sanitize_array_recursive($brand_raw),

            // Contact info
            'contact_phone' => sanitize_text_field($_POST['contact_phone'] ?? ''),
            'contact_email' => sanitize_email($_POST['contact_email'] ?? ''),
            'contact_address' => sanitize_text_field($_POST['contact_address'] ?? ''),

            // Brand info
            'brand_colors' => sanitize_text_field($_POST['brand_colors'] ?? ''),
            'brand_slogan' => sanitize_text_field($_POST['brand_slogan'] ?? ''),

            // File paths
            'logo_path' => $logo_path,
            'file_paths' => $file_paths,

            // Extra notes
            'extra' => wp_kses_post($_POST['extra'] ?? '')
        );

        // Log submission data
        error_log('SEC Survey: Submission data prepared');
        error_log('SEC Survey: Customer: ' . $submission_data['customer_name'] . ' (' . $submission_data['customer_email'] . ')');

        // Save/update submission in database
        $token = sanitize_text_field($_POST['survey_token'] ?? '');
        if (!empty($token)) {
            $submission_id = SEC_Survey_DB::finalize_submission_by_token($token, $submission_data);
        } else {
            $submission_id = SEC_Survey_DB::insert_submission($submission_data);
        }

        if ($submission_id) {
            error_log('SEC Survey: Submission saved with ID: ' . $submission_id);

            // Send admin notification email
            $email_sent = SEC_Survey_Email::send_admin_notification($submission_id);
            SEC_Survey_Email::send_completion_confirmation(SEC_Survey_DB::get_submission($submission_id));

            // Log for debugging
            if ($email_sent) {
                error_log('SEC Survey: Email notification sent for submission #' . $submission_id);
            } else {
                error_log('SEC Survey: Failed to send email notification for submission #' . $submission_id);
            }

            wp_send_json_success(array(
                'message' => 'Survey submitted successfully!',
                'submission_id' => $submission_id
            ));
        } else {
            wp_send_json_error(array(
                'message' => 'Failed to save survey. Please try again or contact support.'
            ));
        }
    }

    /**
     * Recursively sanitize arrays for safe storage
     */
    private static function sanitize_array_recursive($data) {
        if (!is_array($data)) {
            return sanitize_text_field($data);
        }

        $sanitized = array();
        foreach ($data as $key => $value) {
            $sanitized_key = sanitize_key($key);
            if (is_array($value)) {
                $sanitized[$sanitized_key] = self::sanitize_array_recursive($value);
            } else {
                $sanitized[$sanitized_key] = sanitize_text_field($value);
            }
        }
        return $sanitized;
    }

    private static function normalize_socials($socials, $strict = true) {
        if (!is_array($socials)) {
            return array();
        }

        $normalized = array();
        foreach ($socials as $index => $social) {
            if (!is_array($social)) {
                continue;
            }

            $platform = self::canonical_social_platform_label(
                $social['platform'] ?? ($social['label'] ?? '')
            );
            $icon = isset($social['icon']) ? wp_kses_post((string) $social['icon']) : '';
            $placeholder = isset($social['placeholder']) ? sanitize_text_field($social['placeholder']) : '';
            $raw_value = isset($social['value']) ? (string) $social['value'] : '';
            $value = trim($raw_value);

            if ($value === '') {
                $normalized[] = array(
                    'platform' => $platform,
                    'label' => $platform,
                    'icon' => $icon,
                    'placeholder' => $placeholder,
                    'value' => '',
                );
                continue;
            }

            $url = self::normalize_social_url($platform, $value);
            if (is_wp_error($url)) {
                if ($strict) {
                    return new WP_Error(
                        'invalid_social_url',
                        sprintf(
                            'Invalid %s URL: %s',
                            !empty($platform) ? $platform : 'social',
                            $url->get_error_message()
                        )
                    );
                }
                $url = '';
            }

            $normalized[] = array(
                'platform' => $platform,
                'label' => $platform,
                'icon' => $icon,
                'placeholder' => $placeholder,
                'value' => $url,
            );
        }

        return $normalized;
    }

    private static function canonical_social_platform_label($platform) {
        $label = trim((string) $platform);
        if ($label === '') {
            return '';
        }

        $normalized = strtolower($label);
        if (in_array($normalized, array('x', 'twitter', 'x / twitter', 'x/twitter'), true)) {
            return 'X / Twitter';
        }
        if ($normalized === 'youtube') {
            return 'YouTube';
        }
        if ($normalized === 'linkedin') {
            return 'LinkedIn';
        }
        if ($normalized === 'tiktok') {
            return 'TikTok';
        }
        if ($normalized === 'facebook') {
            return 'Facebook';
        }
        if ($normalized === 'instagram') {
            return 'Instagram';
        }
        if ($normalized === 'pinterest') {
            return 'Pinterest';
        }
        if ($normalized === 'other') {
            return 'Other';
        }

        return sanitize_text_field($label);
    }

    private static function normalize_social_url($platform, $value) {
        $rules = array(
            'Facebook' => array(
                'hosts' => array('facebook.com'),
                'handle_prefix' => 'https://facebook.com/',
            ),
            'Instagram' => array(
                'hosts' => array('instagram.com'),
                'handle_prefix' => 'https://instagram.com/',
            ),
            'LinkedIn' => array(
                'hosts' => array('linkedin.com'),
                'handle_prefix' => '',
            ),
            'TikTok' => array(
                'hosts' => array('tiktok.com'),
                'handle_prefix' => 'https://tiktok.com/@',
            ),
            'X / Twitter' => array(
                'hosts' => array('x.com', 'twitter.com'),
                'handle_prefix' => 'https://x.com/',
            ),
            'YouTube' => array(
                'hosts' => array('youtube.com', 'youtu.be'),
                'handle_prefix' => 'https://youtube.com/@',
            ),
            'Pinterest' => array(
                'hosts' => array('pinterest.com'),
                'handle_prefix' => 'https://pinterest.com/',
            ),
            'Other' => array(
                'hosts' => array(),
                'handle_prefix' => '',
            ),
        );

        $platform = self::canonical_social_platform_label($platform);
        $rule = $rules[$platform] ?? $rules['Other'];
        $candidate = trim((string) $value);

        if ($candidate === '') {
            return '';
        }

        if (!empty($rule['handle_prefix']) && strpos($candidate, '@') === 0) {
            $handle = ltrim($candidate, '@');
            $handle = preg_replace('/[^A-Za-z0-9._-]/', '', $handle);
            if ($handle === '') {
                return new WP_Error('invalid_social_handle', 'Please enter a valid handle.');
            }
            $candidate = $rule['handle_prefix'] . $handle;
        }

        if (!preg_match('#^https?://#i', $candidate)) {
            $candidate = 'https://' . $candidate;
        }

        $parts = wp_parse_url($candidate);
        if (!is_array($parts) || empty($parts['host'])) {
            return new WP_Error('invalid_social_url', 'Please enter a valid URL.');
        }

        $scheme = strtolower($parts['scheme'] ?? 'https');
        if ($scheme !== 'http' && $scheme !== 'https') {
            return new WP_Error('invalid_social_url', 'Only http/https URLs are allowed.');
        }

        $host = strtolower($parts['host']);
        if (strpos($host, 'www.') === 0) {
            $host = substr($host, 4);
        }

        if (!empty($rule['hosts'])) {
            $matches = false;
            foreach ($rule['hosts'] as $allowed_host) {
                $allowed_host = strtolower($allowed_host);
                if ($host === $allowed_host || substr($host, -1 * (strlen($allowed_host) + 1)) === '.' . $allowed_host) {
                    $matches = true;
                    break;
                }
            }

            if (!$matches) {
                return new WP_Error(
                    'invalid_social_platform',
                    sprintf('%s links must use %s.', $platform, implode(' or ', $rule['hosts']))
                );
            }
        } elseif (!self::is_valid_public_domain($host)) {
            return new WP_Error(
                'invalid_social_url',
                'Please enter a valid URL with a real domain (e.g. example.com).'
            );
        }

        $path = isset($parts['path']) ? $parts['path'] : '';
        if ($platform === 'LinkedIn' && ($path === '' || $path === null)) {
            $path = '/';
        }

        $normalized_parts = array(
            'scheme' => 'https',
            'host' => $host,
            'path' => $path,
            'query' => isset($parts['query']) ? $parts['query'] : '',
            'fragment' => isset($parts['fragment']) ? $parts['fragment'] : '',
        );

        return self::unparse_url($normalized_parts);
    }

    private static function is_valid_public_domain($host) {
        $host = strtolower(trim((string) $host));
        if ($host === '' || strlen($host) > 253) {
            return false;
        }

        if (preg_match('/^\d{1,3}(?:\.\d{1,3}){3}$/', $host)) {
            return false;
        }

        if (strpos($host, ':') !== false) {
            return false;
        }

        $labels = explode('.', $host);
        if (count($labels) < 2) {
            return false;
        }

        $tld = end($labels);
        if (!preg_match('/^[a-z]{2,63}$/i', $tld)) {
            return false;
        }

        foreach ($labels as $label) {
            if (!preg_match('/^[a-z0-9-]{1,63}$/i', $label)) {
                return false;
            }
            if ($label[0] === '-' || substr($label, -1) === '-') {
                return false;
            }
        }

        return true;
    }

    private static function unparse_url($parts) {
        $scheme = isset($parts['scheme']) ? $parts['scheme'] . '://' : '';
        $host = $parts['host'] ?? '';
        $port = isset($parts['port']) ? ':' . $parts['port'] : '';
        $user = $parts['user'] ?? '';
        $pass = isset($parts['pass']) ? ':' . $parts['pass'] : '';
        $pass = ($user || $pass) ? "$pass@" : '';
        $path = $parts['path'] ?? '';
        $query = isset($parts['query']) && $parts['query'] !== '' ? '?' . $parts['query'] : '';
        $fragment = isset($parts['fragment']) && $parts['fragment'] !== '' ? '#' . $parts['fragment'] : '';

        return $scheme . $user . $pass . $host . $port . $path . $query . $fragment;
    }

    /**
     * Store payment session data for survey AND create a tokenized DB row.
     * Call this after successful Stripe payment.
     *
     * @param object     $session    Stripe session object
     * @param array|null $token_data Optional extra customer data ['full_name', etc.]
     * @return string  The survey_token (used for the email link)
     */
    public static function store_payment_session($session, $token_data = null) {
        if (!session_id()) {
            session_start();
        }

        $payment_data = array(
            'customer_id'    => $session->customer ?? '',
            'customer_name'  => $token_data['full_name'] ?? '',
            'customer_email' => $session->customer_details->email ?? '',
            'payment_amount' => ($session->amount_total / 100),
            'session_id'     => $session->id ?? ''
        );

        $_SESSION['sec_last_payment'] = $payment_data;

        // Also store as transient as backup (expires in 1 hour)
        set_transient(
            'sec_payment_session_' . $session->id,
            $payment_data,
            HOUR_IN_SECONDS
        );

        // Create a tokenized DB row so progress can be saved and resumed
        $survey_token = SEC_Survey_DB::create_or_update_survey_progress(
            $session->id ?? '',
            array(
                'customer_id'    => $session->customer ?? '',
                'name'           => $token_data['full_name'] ?? '',
                'email'          => $session->customer_details->email ?? '',
                'payment_amount' => ($session->amount_total / 100),
            )
        );

        // Add the survey token to the transient so the confirmation page can read it
        if ($survey_token) {
            $payment_data['survey_token'] = $survey_token;
            set_transient(
                'sec_payment_session_' . $session->id,
                $payment_data,
                HOUR_IN_SECONDS
            );
        }

        return $survey_token ?: '';
    }

    /**
     * Handle file upload to custom plugin folder
     */
    private static function handle_file_upload($file) {
        // Validate file size (35MB max)
        $max_size = 35 * 1024 * 1024;
        if ($file['size'] > $max_size) {
            error_log('SEC Survey: File too large: ' . $file['size']);
            return array('success' => false, 'error' => 'File size exceeds 35MB limit.');
        }

        $file_info = wp_check_filetype(sanitize_file_name($file['name']));
        $file_type = strtolower((string)($file_info['type'] ?? ''));
        $fallback_mime = function_exists('mime_content_type') ? mime_content_type($file['tmp_name']) : '';
        $detected_mime = $file_type ?: strtolower((string)$fallback_mime);

        if (!self::is_allowed_survey_upload($file['name'], $detected_mime)) {
            error_log('SEC Survey: Invalid file type: ' . ($detected_mime ?: 'unknown'));
            return array('success' => false, 'error' => 'Invalid file type. Allowed: JPG, PNG, WEBP, SVG, PDF, DOC, DOCX.');
        }

        $locations = SEC_Survey_DB::get_survey_upload_locations();
        $upload_dir = trailingslashit($locations['current']['dir']);

        // Create directory if it doesn't exist
        if (!file_exists($upload_dir)) {
            wp_mkdir_p($upload_dir);
            // Add .htaccess to protect directory and prevent PHP execution
            $htaccess_content = "Options -Indexes\n";
            $htaccess_content .= "php_flag engine off\n";
            $htaccess_content .= "<FilesMatch \"\\.(jpg|jpeg|png|webp|pdf)$\">\n";
            $htaccess_content .= "    Order Allow,Deny\n";
            $htaccess_content .= "    Allow from all\n";
            $htaccess_content .= "</FilesMatch>";
            file_put_contents($upload_dir . '.htaccess', $htaccess_content);
        }

        // Generate unique filename with validated extension
        $allowed_ext_map = array(
            'jpg' => 'jpg',
            'jpeg' => 'jpg',
            'png' => 'png',
            'webp' => 'webp',
            'svg' => 'svg',
            'pdf' => 'pdf',
            'doc' => 'doc',
            'docx' => 'docx',
        );
        $source_ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        $file_ext = isset($allowed_ext_map[$source_ext]) ? $allowed_ext_map[$source_ext] : 'bin';
        $file_name = uniqid() . '_' . time() . '.' . $file_ext;
        $file_path = $upload_dir . $file_name;

        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            // Return full upload URL
            $file_url = trailingslashit($locations['current']['url']) . $file_name;

            return array(
                'success' => true,
                'file_path' => $file_url,
                'file_name' => $file['name']
            );
        }

        return array('success' => false, 'error' => 'Failed to move uploaded file.');
    }
}

// Initialize
SEC_Survey_Modal::init();
