<?php
/**
 * Survey Modal Handler
 *
 * Handles survey modal display, AJAX submission, and integration with Stripe payments
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_Modal {

    /**
     * Initialize the survey modal
     */
    public static function init() {
        // Register AJAX handlers
        add_action('wp_ajax_sec_submit_survey', array(__CLASS__, 'ajax_submit_survey'));
        add_action('wp_ajax_nopriv_sec_submit_survey', array(__CLASS__, 'ajax_submit_survey'));

        add_action('wp_ajax_sec_upload_survey_file', array(__CLASS__, 'ajax_upload_survey_file'));
        add_action('wp_ajax_nopriv_sec_upload_survey_file', array(__CLASS__, 'ajax_upload_survey_file'));

        add_action('wp_ajax_sec_delete_survey_file', array(__CLASS__, 'ajax_delete_survey_file'));

        // Enqueue assets when payment_complete parameter is present
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));

        // Output survey modal HTML
        add_action('wp_footer', array(__CLASS__, 'output_survey_modal'));
    }

    /**
     * Enqueue survey modal assets
     */
    public static function enqueue_assets() {
        // Only enqueue on pages with payment_complete parameter
        if (!isset($_GET['payment_complete'])) {
            return;
        }

        // Enqueue CSS
        wp_enqueue_style(
            'sec-survey-modal',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/survey-modal.css',
            array(),
            '1.0.1'
        );

        // Enqueue time picker CSS
        wp_enqueue_style(
            'sec-survey-time-picker',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/survey-time-picker.css',
            array('sec-survey-modal'),
            '1.0.0'
        );

        // Enqueue JavaScript
        wp_enqueue_script(
            'sec-survey-modal',
            plugin_dir_url(dirname(__FILE__)) . 'assets/js/survey-modal.js',
            array(),
            '1.0.0',
            true
        );

        // Get session data for the survey
        $session_data = self::get_session_data();

        // Localize script with AJAX URL and session data
        wp_localize_script('sec-survey-modal', 'secSurveyData', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sec_survey_nonce'),
            'session' => $session_data,
            'auto_open' => true // Auto-open modal on page load
        ));
    }

    /**
     * Get session data from the most recent payment
     */
    private static function get_session_data() {
        // Start session if not already started
        if (!session_id()) {
            session_start();
        }

        // Try to get session data from PHP session
        if (isset($_SESSION['sec_last_payment'])) {
            return $_SESSION['sec_last_payment'];
        }

        // Default data structure
        return array(
            'customer_id' => '',
            'customer_name' => '',
            'customer_email' => '',
            'payment_amount' => 0,
            'session_id' => ''
        );
    }

    /**
     * Output survey modal HTML structure
     */
    public static function output_survey_modal() {
        // Only output on pages with payment_complete parameter
        if (!isset($_GET['payment_complete'])) {
            return;
        }

        ?>
        <!-- Survey Modal Container (populated by JavaScript) -->
        <div id="sec-survey-modal-overlay" style="display: none;">
            <div id="sec-survey-modal"></div>
        </div>
        <?php
    }

    /**
     * Handle survey file upload via AJAX
     */
    public static function ajax_upload_survey_file() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_survey_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        // Check if file was uploaded
        if (empty($_FILES['file'])) {
            wp_send_json_error(array('message' => 'No file uploaded.'));
        }

        $file = $_FILES['file'];

        // Validate file size (35MB max)
        $max_size = 35 * 1024 * 1024; // 35MB in bytes
        if ($file['size'] > $max_size) {
            wp_send_json_error(array('message' => 'File size exceeds 35MB limit.'));
        }

        // Validate file type
        $allowed_types = array(
            'image/jpeg',
            'image/png',
            'image/jpg',
            'image/webp',
            'image/svg+xml',
            'application/pdf'
        );

        $file_type = mime_content_type($file['tmp_name']);

        if (!in_array($file_type, $allowed_types)) {
            wp_send_json_error(array('message' => 'Invalid file type. Only images (JPG, PNG, WEBP, SVG) and PDFs are allowed.'));
        }

        // Upload directory
        $upload_dir = wp_upload_dir();
        $survey_dir = $upload_dir['basedir'] . '/survey-images/';

        // Create directory if it doesn't exist
        if (!file_exists($survey_dir)) {
            wp_mkdir_p($survey_dir);
        }

        // Generate unique filename
        $file_ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $file_name = wp_unique_filename($survey_dir, uniqid() . '_' . sanitize_file_name($file['name']));
        $file_path = $survey_dir . $file_name;

        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            wp_send_json_success(array(
                'file_path' => $file_name, // Return relative path
                'file_name' => $file['name'],
                'file_size' => $file['size'],
                'file_type' => $file_type
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to upload file.'));
        }
    }

    /**
     * Handle survey file deletion via AJAX
     */
    public static function ajax_delete_survey_file() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_delete_file_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        // Check user permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to delete files.'));
        }

        $submission_id = intval($_POST['submission_id'] ?? 0);
        $file_type = sanitize_text_field($_POST['file_type'] ?? '');
        $file_url = esc_url_raw($_POST['file_url'] ?? '');

        if (!$submission_id || !$file_type || !$file_url) {
            wp_send_json_error(array('message' => 'Missing required parameters.'));
        }

        // Get submission from database
        $submission = SEC_Survey_DB::get_submission($submission_id);
        if (!$submission) {
            wp_send_json_error(array('message' => 'Submission not found.'));
        }

        // Extract filename from URL
        $filename = basename(parse_url($file_url, PHP_URL_PATH));
        $plugin_dir = dirname(dirname(__FILE__));
        $file_path = $plugin_dir . '/survey-uploads/' . $filename;

        // Delete the physical file
        $file_deleted = false;
        if (file_exists($file_path)) {
            $file_deleted = unlink($file_path);
        }

        // Update database to remove file reference
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';
        $updated = false;

        if ($file_type === 'logo') {
            // Remove logo
            $updated = $wpdb->update(
                $table_name,
                array('logo_path' => ''),
                array('id' => $submission_id),
                array('%s'),
                array('%d')
            );
        } else {
            // Remove from file_paths array
            $file_paths = maybe_unserialize($submission->file_paths);
            if (is_array($file_paths)) {
                $file_paths = array_filter($file_paths, function($path) use ($file_url) {
                    return $path !== $file_url;
                });
                $updated = $wpdb->update(
                    $table_name,
                    array('file_paths' => maybe_serialize(array_values($file_paths))),
                    array('id' => $submission_id),
                    array('%s'),
                    array('%d')
                );
            }
        }

        if ($updated !== false || $file_deleted) {
            wp_send_json_success(array(
                'message' => 'File deleted successfully.',
                'file_deleted' => $file_deleted,
                'db_updated' => $updated !== false
            ));
        } else {
            wp_send_json_error(array('message' => 'Failed to delete file.'));
        }
    }

    /**
     * Handle survey submission via AJAX
     */
    public static function ajax_submit_survey() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'sec_survey_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        // Log submission attempt
        error_log('SEC Survey: Starting submission...');
        error_log('SEC Survey: POST data: ' . print_r(array_keys($_POST), true));
        error_log('SEC Survey: FILES data: ' . print_r(array_keys($_FILES), true));

        // Handle file uploads first
        $logo_path = '';
        $file_paths = array();

        // Upload logo file if present
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $logo_upload = self::handle_file_upload($_FILES['logo']);
            if ($logo_upload['success']) {
                $logo_path = $logo_upload['file_path'];
            }
        }

        // Upload multiple files if present
        if (isset($_FILES['files']) && is_array($_FILES['files']['name'])) {
            foreach ($_FILES['files']['name'] as $key => $filename) {
                if ($_FILES['files']['error'][$key] === UPLOAD_ERR_OK) {
                    $file = array(
                        'name' => $_FILES['files']['name'][$key],
                        'type' => $_FILES['files']['type'][$key],
                        'tmp_name' => $_FILES['files']['tmp_name'][$key],
                        'error' => $_FILES['files']['error'][$key],
                        'size' => $_FILES['files']['size'][$key]
                    );
                    $file_upload = self::handle_file_upload($file);
                    if ($file_upload['success']) {
                        $file_paths[] = $file_upload['file_path'];
                    }
                }
            }
        }

        // Prepare submission data
        $submission_data = array(
            // Required payment info
            'stripe_customer_id' => sanitize_text_field($_POST['customer_id'] ?? ''),
            'stripe_session_id' => sanitize_text_field($_POST['session_id'] ?? ''),
            'customer_name' => sanitize_text_field($_POST['customer_name'] ?? ''),
            'customer_email' => sanitize_email($_POST['customer_email'] ?? ''),
            'payment_amount' => floatval($_POST['payment_amount'] ?? 0),

            // Survey fields
            'business_name' => sanitize_text_field($_POST['business_name'] ?? ''),
            'industry' => sanitize_text_field($_POST['industry'] ?? ''),
            'custom_industry' => sanitize_text_field($_POST['custom_industry'] ?? ''),
            'tagline' => wp_kses_post($_POST['tagline'] ?? ''),
            'services' => wp_kses_post($_POST['services'] ?? ''),

            // JSON fields - decode and sanitize recursively
            'hours' => self::sanitize_array_recursive(isset($_POST['hours']) ? json_decode(stripslashes($_POST['hours']), true) : array()),
            'booking' => self::sanitize_array_recursive(isset($_POST['booking']) ? json_decode(stripslashes($_POST['booking']), true) : array()),
            'socials' => self::sanitize_array_recursive(isset($_POST['socials']) ? json_decode(stripslashes($_POST['socials']), true) : array()),
            'brand' => self::sanitize_array_recursive(isset($_POST['brand']) ? json_decode(stripslashes($_POST['brand']), true) : array()),

            // Contact info
            'contact_phone' => sanitize_text_field($_POST['contact_phone'] ?? ''),
            'contact_email' => sanitize_email($_POST['contact_email'] ?? ''),
            'contact_address' => sanitize_text_field($_POST['contact_address'] ?? ''),

            // Brand info
            'brand_colors' => sanitize_text_field($_POST['brand_colors'] ?? ''),
            'brand_slogan' => sanitize_text_field($_POST['brand_slogan'] ?? ''),

            // File paths
            'logo_path' => $logo_path,
            'file_paths' => $file_paths,

            // Extra notes
            'extra' => wp_kses_post($_POST['extra'] ?? '')
        );

        // Log submission data
        error_log('SEC Survey: Submission data prepared');
        error_log('SEC Survey: Customer: ' . $submission_data['customer_name'] . ' (' . $submission_data['customer_email'] . ')');

        // Insert submission into database
        $submission_id = SEC_Survey_DB::insert_submission($submission_data);

        if ($submission_id) {
            error_log('SEC Survey: Submission saved with ID: ' . $submission_id);

            // Send admin notification email
            $email_sent = SEC_Survey_Email::send_admin_notification($submission_id);

            // Log for debugging
            if ($email_sent) {
                error_log('SEC Survey: Email notification sent for submission #' . $submission_id);
            } else {
                error_log('SEC Survey: Failed to send email notification for submission #' . $submission_id);
            }

            wp_send_json_success(array(
                'message' => 'Survey submitted successfully!',
                'submission_id' => $submission_id
            ));
        } else {
            wp_send_json_error(array(
                'message' => 'Failed to save survey. Please try again or contact support.'
            ));
        }
    }

    /**
     * Recursively sanitize arrays for safe storage
     */
    private static function sanitize_array_recursive($data) {
        if (!is_array($data)) {
            return sanitize_text_field($data);
        }

        $sanitized = array();
        foreach ($data as $key => $value) {
            $sanitized_key = sanitize_key($key);
            if (is_array($value)) {
                $sanitized[$sanitized_key] = self::sanitize_array_recursive($value);
            } else {
                $sanitized[$sanitized_key] = sanitize_text_field($value);
            }
        }
        return $sanitized;
    }

    /**
     * Store payment session data for survey
     * Call this after successful Stripe payment
     */
    public static function store_payment_session($session, $token_data = null) {
        if (!session_id()) {
            session_start();
        }

        $payment_data = array(
            'customer_id' => $session->customer ?? '',
            'customer_name' => $token_data['full_name'] ?? '',
            'customer_email' => $session->customer_details->email ?? '',
            'payment_amount' => ($session->amount_total / 100), // Convert from cents
            'session_id' => $session->id ?? ''
        );

        $_SESSION['sec_last_payment'] = $payment_data;

        // Also store as transient as backup (expires in 1 hour)
        set_transient(
            'sec_payment_session_' . $session->id,
            $payment_data,
            HOUR_IN_SECONDS
        );
    }

    /**
     * Handle file upload to custom plugin folder
     */
    private static function handle_file_upload($file) {
        // Validate file size (35MB max)
        $max_size = 35 * 1024 * 1024;
        if ($file['size'] > $max_size) {
            error_log('SEC Survey: File too large: ' . $file['size']);
            return array('success' => false, 'error' => 'File size exceeds 35MB limit.');
        }

        // Validate file type using WordPress function
        $allowed_types = array(
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/jpg' => 'jpg',
            'image/webp' => 'webp',
            'application/pdf' => 'pdf'
        );

        // Use WordPress wp_check_filetype for extension validation
        $file_info = wp_check_filetype(sanitize_file_name($file['name']));
        $file_type = $file_info['type'];

        // Security: Reject if file type is not in allowed list or is false
        if (!isset($allowed_types[$file_type])) {
            error_log('SEC Survey: Invalid file type: ' . ($file_type ?: 'unknown'));
            return array('success' => false, 'error' => 'Invalid file type. Only JPG, PNG, WEBP, and PDF files are allowed.');
        }

        // Additional MIME type validation using WordPress
        $real_mime = wp_check_filetype($file['tmp_name']);
        if ($real_mime['type'] && $real_mime['type'] !== $file_type) {
            error_log('SEC Survey: MIME type mismatch: expected ' . $file_type . ', got ' . $real_mime['type']);
            return array('success' => false, 'error' => 'File type validation failed.');
        }

        // Create custom upload directory in plugin folder
        $plugin_dir = dirname(dirname(__FILE__));
        $upload_dir = $plugin_dir . '/survey-uploads/';

        // Create directory if it doesn't exist
        if (!file_exists($upload_dir)) {
            wp_mkdir_p($upload_dir);
            // Add .htaccess to protect directory and prevent PHP execution
            $htaccess_content = "Options -Indexes\n";
            $htaccess_content .= "php_flag engine off\n";
            $htaccess_content .= "<FilesMatch \"\\.(jpg|jpeg|png|webp|pdf)$\">\n";
            $htaccess_content .= "    Order Allow,Deny\n";
            $htaccess_content .= "    Allow from all\n";
            $htaccess_content .= "</FilesMatch>";
            file_put_contents($upload_dir . '.htaccess', $htaccess_content);
        }

        // Generate unique filename with validated extension
        $file_ext = $allowed_types[$file_type];
        $file_name = uniqid() . '_' . time() . '.' . $file_ext;
        $file_path = $upload_dir . $file_name;

        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            // Return full URL instead of relative path
            $plugin_url = plugin_dir_url(dirname(__FILE__));
            $file_url = $plugin_url . 'survey-uploads/' . $file_name;

            return array(
                'success' => true,
                'file_path' => $file_url,
                'file_name' => $file['name']
            );
        }

        return array('success' => false, 'error' => 'Failed to move uploaded file.');
    }
}

// Initialize
SEC_Survey_Modal::init();
