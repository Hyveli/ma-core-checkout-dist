<?php
/**
 * Survey Email Notifications
 *
 * Handles email notifications for survey submissions
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_Email {

    /**
     * Send survey submission notification to admin
     *
     * @param int $submission_id Survey submission ID
     * @return bool True on success, false on failure
     */
    public static function send_admin_notification($submission_id) {
        $submission = SEC_Survey_DB::get_submission($submission_id);

        if (!$submission) {
            return false;
        }

        // Get admin email from settings or use default
        $admin_email = get_option('sec_survey_notification_email', get_option('admin_email'));

        // Prepare email content
        $subject = sprintf(
            'New Website Setup Survey Submission - %s',
            $submission->business_name ?: $submission->customer_name
        );

        $email_body = self::format_submission_email($submission);

        // Email headers
        $headers = array('Content-Type: text/html; charset=UTF-8');

        // Send email (no attachments - files are included as download links)
        $sent = wp_mail($admin_email, $subject, $email_body, $headers);

        return $sent;
    }

    /**
     * Format submission data for email
     *
     * @param object $submission Submission data
     * @return string HTML formatted email body
     */
    private static function format_submission_email($submission) {
        $html = self::get_email_header();

        $html .= '<div style="padding: 30px; font-family: Arial, sans-serif; color: #333;">';

        // Header section
        $html .= '<h1 style="color: #3b82f6; margin-bottom: 10px;">New Website Setup Survey</h1>';
        $html .= '<p style="color: #666; font-size: 14px; margin-bottom: 30px;">Received ' . date('F j, Y g:i A', strtotime($submission->submitted_at)) . '</p>';

        // Payment Information
        $html .= '<div style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; margin-bottom: 30px;">';
        $html .= '<h2 style="margin: 0 0 15px 0; font-size: 18px; color: #1e40af;">Payment Information</h2>';
        $html .= self::format_field_row('Customer Name', $submission->customer_name);
        $html .= self::format_field_row('Email', $submission->customer_email);
        $html .= self::format_field_row('Payment Amount', '$' . number_format($submission->payment_amount, 2));
        $html .= self::format_field_row('Stripe Customer ID', $submission->stripe_customer_id);
        $html .= self::format_field_row('Stripe Session ID', $submission->stripe_session_id);
        $html .= '</div>';

        // Business Information
        if ($submission->business_name) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Business Information</h2>';
            $html .= self::format_field_row('Business Name', $submission->business_name);

            $industry = $submission->industry === 'Other' ? $submission->custom_industry : $submission->industry;
            $html .= self::format_field_row('Industry', $industry);

            if ($submission->tagline) {
                $html .= self::format_field_row('Tagline', $submission->tagline);
            }
            $html .= '</div>';
        }

        // Services
        if ($submission->services) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Services Offered</h2>';
            $html .= '<div style="background: #f8fafc; padding: 15px; border-radius: 5px; white-space: pre-line; line-height: 1.6;">' . nl2br(esc_html($submission->services)) . '</div>';
            $html .= '</div>';
        }

        // Business Hours
        if ($submission->hours) {
            $hours = json_decode($submission->hours, true);
            if (is_array($hours) && !empty($hours)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Business Hours</h2>';
                $html .= '<table style="width: 100%; border-collapse: collapse;">';

                foreach ($hours as $day => $time) {
                    $html .= '<tr>';
                    $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold; width: 100px;">' . esc_html($day) . '</td>';

                    if ($time['closed']) {
                        $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb; color: #999; font-style: italic;">Closed</td>';
                    } else {
                        $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">' . esc_html($time['open']) . ' - ' . esc_html($time['close']) . '</td>';
                    }

                    $html .= '</tr>';
                }

                $html .= '</table>';
                $html .= '</div>';
            }
        }

        // Booking Methods
        if ($submission->booking) {
            $booking = json_decode($submission->booking, true);
            if (is_array($booking) && !empty($booking)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Booking Methods</h2>';

                $booking_labels = array(
                    'virtual' => '📹 Virtually (video or phone call)',
                    'our_location' => '🏢 At my location (client comes to me)',
                    'client_location' => '🚗 At the client\'s location (I go to them)'
                );

                $html .= '<ul style="list-style: none; padding: 0;">';
                foreach ($booking as $method) {
                    $label = $booking_labels[$method] ?? $method;
                    $html .= '<li style="padding: 8px 0; border-bottom: 1px solid #e5e7eb;">✓ ' . esc_html($label) . '</li>';
                }
                $html .= '</ul>';
                $html .= '</div>';
            }
        }

        // Contact Information
        $html .= '<div style="margin-bottom: 30px;">';
        $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Contact Information</h2>';
        if ($submission->contact_phone) {
            $html .= self::format_field_row('Phone', $submission->contact_phone);
        }
        if ($submission->contact_email) {
            $html .= self::format_field_row('Email', $submission->contact_email);
        }
        if ($submission->contact_address) {
            $html .= self::format_field_row('Address', $submission->contact_address);
        }
        $html .= '</div>';

        // Social Media
        if ($submission->socials) {
            $socials = json_decode($submission->socials, true);
            if (is_array($socials) && !empty($socials)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Social Media</h2>';

                foreach ($socials as $social) {
                    if (!empty($social['value'])) {
                        $html .= '<p style="margin: 8px 0;">';
                        $html .= '<strong>' . esc_html($social['icon'] ?? '') . ' ' . esc_html($social['platform']) . ':</strong> ';
                        $html .= '<a href="' . esc_url('https://' . $social['value']) . '" style="color: #3b82f6; text-decoration: none;">' . esc_html($social['value']) . '</a>';
                        $html .= '</p>';
                    }
                }

                $html .= '</div>';
            }
        }

        // Brand Information
        if ($submission->brand) {
            $brand = json_decode($submission->brand, true);
            if (is_array($brand) && !empty($brand)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Brand Assets</h2>';

                $brand_labels = array(
                    'logo' => '🎨 Has logo',
                    'colors' => '🎨 Has brand colors',
                    'slogan' => '💬 Has slogan',
                    'none' => 'None yet — build it for me'
                );

                foreach ($brand as $item) {
                    $label = $brand_labels[$item] ?? $item;
                    $html .= '<p style="margin: 8px 0;">✓ ' . esc_html($label) . '</p>';
                }

                if ($submission->brand_colors) {
                    $html .= self::format_field_row('Brand Colors', $submission->brand_colors);
                }
                if ($submission->brand_slogan) {
                    $html .= self::format_field_row('Slogan', $submission->brand_slogan);
                }

                $html .= '</div>';
            }
        }

        // Files - Include download links
        $has_files = false;
        $file_html = '';

        if ($submission->logo_path) {
            $has_files = true;
            $logo_url = $submission->logo_path;
            // Check if it's already a full URL or relative path
            if (strpos($logo_url, 'http') !== 0) {
                $logo_url = plugins_url('ma-core-checkout/' . $logo_url);
            }

            $file_html .= '<div style="margin-bottom: 15px; background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;">';
            $file_html .= '<div style="display: flex; align-items: center; gap: 10px;">';
            $file_html .= '<span style="font-size: 24px;">🎨</span>';
            $file_html .= '<div style="flex: 1;">';
            $file_html .= '<strong style="color: #1e40af; display: block; margin-bottom: 5px;">Logo</strong>';
            $file_html .= '<a href="' . esc_url($logo_url) . '" style="display: inline-block; background: #3b82f6; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; font-size: 14px; font-weight: bold;">Download Logo →</a>';
            $file_html .= '</div>';
            $file_html .= '</div>';
            $file_html .= '</div>';
        }

        if ($submission->file_paths) {
            $files = json_decode($submission->file_paths, true);
            if (is_array($files) && !empty($files)) {
                $has_files = true;

                foreach ($files as $index => $file_path) {
                    $file_url = $file_path;
                    // Check if it's already a full URL or relative path
                    if (strpos($file_url, 'http') !== 0) {
                        $file_url = plugins_url('ma-core-checkout/' . $file_path);
                    }

                    $filename = basename($file_url);
                    $is_image = preg_match('/\.(jpg|jpeg|png|gif|webp|svg)$/i', $filename);

                    $file_html .= '<div style="margin-bottom: 15px; background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;">';
                    $file_html .= '<div style="display: flex; align-items: center; gap: 10px;">';
                    $file_html .= '<span style="font-size: 24px;">' . ($is_image ? '🖼️' : '📄') . '</span>';
                    $file_html .= '<div style="flex: 1;">';
                    $file_html .= '<strong style="color: #1e40af; display: block; margin-bottom: 5px;">File ' . ($index + 1) . '</strong>';
                    $file_html .= '<span style="color: #666; font-size: 13px; display: block; margin-bottom: 8px;">' . esc_html($filename) . '</span>';
                    $file_html .= '<a href="' . esc_url($file_url) . '" style="display: inline-block; background: #3b82f6; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; font-size: 14px; font-weight: bold;">Download File →</a>';
                    $file_html .= '</div>';
                    $file_html .= '</div>';
                    $file_html .= '</div>';
                }
            }
        }

        if ($has_files) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">📎 Uploaded Files</h2>';
            $html .= $file_html;
            $html .= '<p style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 12px; margin-top: 15px; font-size: 13px; color: #666;">';
            $html .= '<strong>💡 Tip:</strong> Click the download buttons above to view and save the uploaded files.';
            $html .= '</p>';
            $html .= '</div>';
        }

        // Additional Notes
        if ($submission->extra) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Additional Notes</h2>';
            $html .= '<div style="background: #f8fafc; padding: 15px; border-radius: 5px; white-space: pre-line; line-height: 1.6;">' . nl2br(esc_html($submission->extra)) . '</div>';
            $html .= '</div>';
        }

        // View in Dashboard link
        $view_url = admin_url('admin.php?page=sec-survey-submissions&action=view&id=' . $submission->id);
        $html .= '<div style="text-align: center; margin-top: 40px; padding-top: 30px; border-top: 2px solid #e5e7eb;">';
        $html .= '<a href="' . esc_url($view_url) . '" style="display: inline-block; background: linear-gradient(135deg, #3b82f6, #0ea5e9); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 16px;">View Full Details in Dashboard →</a>';
        $html .= '</div>';

        $html .= '</div>';
        $html .= self::get_email_footer();

        return $html;
    }

    /**
     * Format a field row for email
     */
    private static function format_field_row($label, $value) {
        if (empty($value)) return '';

        return '<p style="margin: 8px 0;"><strong style="color: #1e40af;">' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
    }

    /**
     * Prepare file attachments for email
     */
    private static function prepare_attachments($submission) {
        $attachments = array();
        $upload_dir = wp_upload_dir();
        $survey_dir = $upload_dir['basedir'] . '/survey-images/';

        // Add logo file
        if (!empty($submission->logo_path)) {
            $logo_file = $survey_dir . basename($submission->logo_path);
            if (file_exists($logo_file)) {
                $attachments[] = $logo_file;
            }
        }

        // Add other files
        if (!empty($submission->file_paths)) {
            $file_paths = json_decode($submission->file_paths, true);
            if (is_array($file_paths)) {
                foreach ($file_paths as $file_path) {
                    $file = $survey_dir . basename($file_path);
                    if (file_exists($file)) {
                        $attachments[] = $file;
                    }
                }
            }
        }

        return $attachments;
    }

    /**
     * Get email header HTML
     */
    private static function get_email_header() {
        $logo_url = get_option('sec_email_logo_url', 'https://marketingaid.org/LogoLarge.png');

        return '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Survey Submission</title>
        </head>
        <body style="margin: 0; padding: 0; background-color: #f3f4f6;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f3f4f6;">
                <tr>
                    <td align="center" style="padding: 40px 20px;">
                        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); overflow: hidden;">
                            <tr>
                                <td align="center" style="background: linear-gradient(135deg, #3b82f6, #0ea5e9); padding: 30px;">
                                    <img src="' . esc_url($logo_url) . '" alt="Marketing Aid" style="height: 50px; display: block;">
                                </td>
                            </tr>
                            <tr>
                                <td>';
    }

    /**
     * Get email footer HTML
     */
    private static function get_email_footer() {
        return '                </td>
                            </tr>
                            <tr>
                                <td align="center" style="background-color: #f8fafc; padding: 20px; color: #6b7280; font-size: 12px;">
                                    &copy; ' . date('Y') . ' Marketing Aid. All rights reserved.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>';
    }
}
