<?php
/**
 * Survey Email Notifications
 *
 * Handles email notifications for survey submissions
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_Email {

    /**
     * Send payment receipt email to customer
     *
     * @param array $payment_data Payment information
     * @return bool True on success, false on failure
     */
    public static function send_payment_receipt($payment_data) {
        $customer_email = $payment_data['customer_email'] ?? '';
        $customer_name = $payment_data['customer_name'] ?? '';
        $amount = $payment_data['amount'] ?? 0;
        $business_name = $payment_data['business_name'] ?? '';

        if (empty($customer_email)) {
            return false;
        }

        // Get customized email settings
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        $subject = get_option('sec_receipt_email_subject', 'Payment Receipt - {{business_name}}');
        $body = get_option('sec_receipt_email_body', self::get_default_receipt_body());

        // Replace placeholders
        $replacements = [
            '{{customer_name}}' => $customer_name,
            '{{customer_email}}' => $customer_email,
            '{{amount}}' => '$' . number_format($amount / 100, 2),
            '{{date}}' => date('F j, Y'),
            '{{business_name}}' => $business_name ?: 'your business'
        ];

        foreach ($replacements as $placeholder => $value) {
            $subject = str_replace($placeholder, $value, $subject);
            $body = str_replace($placeholder, $value, $body);
        }

        // Email headers
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        ];

        // Wrap body in email template
        $html = self::get_email_header();
        $html .= '<div style="padding: 30px; font-family: Arial, sans-serif; color: #333;">';
        $html .= '<div style="white-space: pre-line; line-height: 1.6;">' . nl2br(esc_html($body)) . '</div>';
        $html .= '</div>';
        $html .= self::get_email_footer();

        return wp_mail($customer_email, $subject, $html, $headers);
    }

    /**
     * Get default receipt email body
     */
    private static function get_default_receipt_body() {
        return 'Hi {{customer_name}},

Thank you for your payment! Your website setup is confirmed.

Payment Details:
• Amount: {{amount}}
• Date: {{date}}
• Business: {{business_name}}

Next Steps:
1. Complete the website launch survey (link sent separately)
2. We\'ll build your website within 48 hours
3. You\'ll receive a preview link to review before going live

Questions? Just reply to this email.

Best regards,
The ' . get_bloginfo('name') . ' Team';
    }

    /**
     * Convert 24-hour time to 12-hour format
     */
    private static function format_time_12hour($time24) {
        list($hours, $minutes) = explode(':', $time24);
        $h = intval($hours);
        $period = $h >= 12 ? 'PM' : 'AM';
        $h12 = $h == 0 ? 12 : ($h > 12 ? $h - 12 : $h);
        return $h12 . ':' . $minutes . ' ' . $period;
    }

    /**
     * Send survey submission notification to admin
     *
     * @param int $submission_id Survey submission ID
     * @return bool True on success, false on failure
     */
    public static function send_admin_notification($submission_id) {
        $submission = SEC_Survey_DB::get_submission($submission_id);

        if (!$submission) {
            return false;
        }

        // Get admin email from settings or use default
        $admin_email = get_option('sec_survey_notification_email', get_option('admin_email'));

        // Prepare email content
        $subject = sprintf(
            'New Website Setup Survey Submission - %s',
            $submission->business_name ?: $submission->customer_name
        );

        $email_body = self::format_submission_email($submission);

        // Email headers
        $headers = array('Content-Type: text/html; charset=UTF-8');

        // Send email (no attachments - files are included as download links)
        $sent = wp_mail($admin_email, $subject, $email_body, $headers);

        return $sent;
    }

    /**
     * Format submission data for email
     *
     * @param object $submission Submission data
     * @return string HTML formatted email body
     */
    private static function format_submission_email($submission) {
        $html = self::get_email_header();

        $html .= '<div style="padding: 30px; font-family: Arial, sans-serif; color: #333;">';

        // Header section
        $html .= '<h1 style="color: #3b82f6; margin-bottom: 10px;">New Website Setup Survey</h1>';
        $html .= '<p style="color: #666; font-size: 14px; margin-bottom: 30px;">Received ' . date('F j, Y g:i A', strtotime($submission->submitted_at)) . '</p>';

        // Payment Information
        $html .= '<div style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; margin-bottom: 30px;">';
        $html .= '<h2 style="margin: 0 0 15px 0; font-size: 18px; color: #1e40af;">Payment Information</h2>';
        $html .= self::format_field_row('Customer Name', $submission->customer_name);
        $html .= self::format_field_row('Email', $submission->customer_email);
        $html .= self::format_field_row('Payment Amount', '$' . number_format($submission->payment_amount, 2));
        $html .= self::format_field_row('Stripe Customer ID', $submission->stripe_customer_id);
        $html .= self::format_field_row('Stripe Session ID', $submission->stripe_session_id);
        $html .= '</div>';

        // Business Information
        if ($submission->business_name) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Business Information</h2>';
            $html .= self::format_field_row('Business Name', $submission->business_name);

            $industry = $submission->industry === 'Other' ? $submission->custom_industry : $submission->industry;
            $html .= self::format_field_row('Industry', $industry);

            if ($submission->tagline) {
                $html .= self::format_field_row('Tagline', $submission->tagline);
            }
            $html .= '</div>';
        }

        // Services
        if ($submission->services) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Services Offered</h2>';
            $html .= '<div style="background: #f8fafc; padding: 15px; border-radius: 5px; white-space: pre-line; line-height: 1.6;">' . nl2br(esc_html($submission->services)) . '</div>';
            $html .= '</div>';
        }

        // Business Hours
        if ($submission->hours) {
            $hours = json_decode($submission->hours, true);
            if (is_array($hours) && !empty($hours)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Business Hours</h2>';
                $html .= '<table style="width: 100%; border-collapse: collapse;">';

                foreach ($hours as $day => $time) {
                    $html .= '<tr>';
                    $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold; width: 100px;">' . esc_html($day) . '</td>';

                    if ($time['closed']) {
                        $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb; color: #999; font-style: italic;">Closed</td>';
                    } else {
                        $open_12h = self::format_time_12hour($time['open']);
                        $close_12h = self::format_time_12hour($time['close']);
                        $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">' . esc_html($open_12h) . ' - ' . esc_html($close_12h) . '</td>';
                    }

                    $html .= '</tr>';
                }

                $html .= '</table>';
                $html .= '</div>';
            }
        }

        // Booking Methods
        if ($submission->booking) {
            $booking = json_decode($submission->booking, true);
            if (is_array($booking) && !empty($booking)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Booking Methods</h2>';

                $booking_labels = array(
                    'virtual' => '📹 Virtually (video or phone call)',
                    'our_location' => '🏢 At my location (client comes to me)',
                    'client_location' => '🚗 At the client\'s location (I go to them)'
                );

                $html .= '<ul style="list-style: none; padding: 0;">';
                foreach ($booking as $method) {
                    $label = $booking_labels[$method] ?? $method;
                    $html .= '<li style="padding: 8px 0; border-bottom: 1px solid #e5e7eb;">✓ ' . esc_html($label) . '</li>';
                }
                $html .= '</ul>';
                $html .= '</div>';
            }
        }

        // Contact Information
        $html .= '<div style="margin-bottom: 30px;">';
        $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Contact Information</h2>';
        if ($submission->contact_phone) {
            $html .= self::format_field_row('Phone', $submission->contact_phone);
        }
        if ($submission->contact_email) {
            $html .= self::format_field_row('Email', $submission->contact_email);
        }
        if ($submission->contact_address) {
            $html .= self::format_field_row('Address', $submission->contact_address);
        }
        $html .= '</div>';

        // Social Media
        if ($submission->socials) {
            $socials = json_decode($submission->socials, true);
            if (is_array($socials) && !empty($socials)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Social Media</h2>';

                foreach ($socials as $social) {
                    if (!empty($social['value'])) {
                        $html .= '<p style="margin: 8px 0;">';
                        $html .= '<strong>' . esc_html($social['icon'] ?? '') . ' ' . esc_html($social['platform']) . ':</strong> ';
                        $html .= '<a href="' . esc_url('https://' . $social['value']) . '" style="color: #3b82f6; text-decoration: none;">' . esc_html($social['value']) . '</a>';
                        $html .= '</p>';
                    }
                }

                $html .= '</div>';
            }
        }

        // Brand Information
        if ($submission->brand) {
            $brand = json_decode($submission->brand, true);
            if (is_array($brand) && !empty($brand)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Brand Assets</h2>';

                $brand_labels = array(
                    'logo' => '🎨 Has logo',
                    'colors' => '🎨 Has brand colors',
                    'slogan' => '💬 Has slogan',
                    'none' => 'None yet — build it for me'
                );

                foreach ($brand as $item) {
                    $label = $brand_labels[$item] ?? $item;
                    $html .= '<p style="margin: 8px 0;">✓ ' . esc_html($label) . '</p>';
                }

                if ($submission->brand_colors) {
                    $html .= self::format_field_row('Brand Colors', $submission->brand_colors);
                }
                if ($submission->brand_slogan) {
                    $html .= self::format_field_row('Slogan', $submission->brand_slogan);
                }

                $html .= '</div>';
            }
        }

        // Files - Include download links
        $has_files = false;
        $file_html = '';

        if ($submission->logo_path) {
            $has_files = true;
            // Logo path is already a full URL from upload
            $logo_url = $submission->logo_path;

            $file_html .= '<div style="margin-bottom: 15px; background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;">';
            $file_html .= '<div style="display: flex; align-items: center; gap: 10px;">';
            $file_html .= '<span style="font-size: 24px;">🎨</span>';
            $file_html .= '<div style="flex: 1;">';
            $file_html .= '<strong style="color: #1e40af; display: block; margin-bottom: 5px;">Logo</strong>';
            $file_html .= '<a href="' . esc_url($logo_url) . '" style="display: inline-block; background: #3b82f6; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; font-size: 14px; font-weight: bold;">Download Logo →</a>';
            $file_html .= '</div>';
            $file_html .= '</div>';
            $file_html .= '</div>';
        }

        if ($submission->file_paths) {
            $files = json_decode($submission->file_paths, true);
            if (is_array($files) && !empty($files)) {
                $has_files = true;

                foreach ($files as $index => $file_path) {
                    // File path is already a full URL from upload
                    $file_url = $file_path;
                    $filename = basename($file_url);
                    $is_image = preg_match('/\.(jpg|jpeg|png|gif|webp|svg)$/i', $filename);

                    $file_html .= '<div style="margin-bottom: 15px; background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;">';
                    $file_html .= '<div style="display: flex; align-items: center; gap: 10px;">';
                    $file_html .= '<span style="font-size: 24px;">' . ($is_image ? '🖼️' : '📄') . '</span>';
                    $file_html .= '<div style="flex: 1;">';
                    $file_html .= '<strong style="color: #1e40af; display: block; margin-bottom: 5px;">File ' . ($index + 1) . '</strong>';
                    $file_html .= '<span style="color: #666; font-size: 13px; display: block; margin-bottom: 8px;">' . esc_html($filename) . '</span>';
                    $file_html .= '<a href="' . esc_url($file_url) . '" style="display: inline-block; background: #3b82f6; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; font-size: 14px; font-weight: bold;">Download File →</a>';
                    $file_html .= '</div>';
                    $file_html .= '</div>';
                    $file_html .= '</div>';
                }
            }
        }

        if ($has_files) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">📎 Uploaded Files</h2>';
            $html .= $file_html;
            $html .= '<p style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 12px; margin-top: 15px; font-size: 13px; color: #666;">';
            $html .= '<strong>💡 Tip:</strong> Click the download buttons above to view and save the uploaded files.';
            $html .= '</p>';
            $html .= '</div>';
        }

        // Additional Notes
        if ($submission->extra) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Additional Notes</h2>';
            $html .= '<div style="background: #f8fafc; padding: 15px; border-radius: 5px; white-space: pre-line; line-height: 1.6;">' . nl2br(esc_html($submission->extra)) . '</div>';
            $html .= '</div>';
        }

        // View in Dashboard link
        $view_url = admin_url('admin.php?page=sec-survey-submissions&action=view&id=' . $submission->id);
        $html .= '<div style="text-align: center; margin-top: 40px; padding-top: 30px; border-top: 2px solid #e5e7eb;">';
        $html .= '<a href="' . esc_url($view_url) . '" style="display: inline-block; background: linear-gradient(135deg, #3b82f6, #0ea5e9); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 16px;">View Full Details in Dashboard →</a>';
        $html .= '</div>';

        $html .= '</div>';
        $html .= self::get_email_footer();

        return $html;
    }

    /**
     * Format a field row for email
     */
    private static function format_field_row($label, $value) {
        if (empty($value)) return '';

        return '<p style="margin: 8px 0;"><strong style="color: #1e40af;">' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
    }

    /**
     * Prepare file attachments for email
     */
    private static function prepare_attachments($submission) {
        $attachments = array();
        $upload_dir = wp_upload_dir();
        $survey_dir = $upload_dir['basedir'] . '/survey-images/';

        // Add logo file
        if (!empty($submission->logo_path)) {
            $logo_file = $survey_dir . basename($submission->logo_path);
            if (file_exists($logo_file)) {
                $attachments[] = $logo_file;
            }
        }

        // Add other files
        if (!empty($submission->file_paths)) {
            $file_paths = json_decode($submission->file_paths, true);
            if (is_array($file_paths)) {
                foreach ($file_paths as $file_path) {
                    $file = $survey_dir . basename($file_path);
                    if (file_exists($file)) {
                        $attachments[] = $file;
                    }
                }
            }
        }

        return $attachments;
    }

    /**
     * Get email header HTML
     */
    private static function get_email_header() {
        $logo_url = get_option('sec_email_logo_url', 'https://marketingaid.org/LogoLarge.png');

        return '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Survey Submission</title>
        </head>
        <body style="margin: 0; padding: 0; background-color: #f3f4f6;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f3f4f6;">
                <tr>
                    <td align="center" style="padding: 40px 20px;">
                        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); overflow: hidden;">
                            <tr>
                                <td align="center" style="background: linear-gradient(135deg, #3b82f6, #0ea5e9); padding: 30px;">
                                    <img src="' . esc_url($logo_url) . '" alt="Marketing Aid" style="height: 50px; display: block;">
                                </td>
                            </tr>
                            <tr>
                                <td>';
    }

    /**
     * Get email footer HTML
     */
    private static function get_email_footer() {
        return '                </td>
                            </tr>
                            <tr>
                                <td align="center" style="background-color: #f8fafc; padding: 20px; color: #6b7280; font-size: 12px;">
                                    &copy; ' . date('Y') . ' Marketing Aid. All rights reserved.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>';
    }

    /**
     * Send a "complete your survey" reminder email to the customer.
     * Includes a tokenized link that resumes the survey at the saved step.
     *
     * @param string $customer_email
     * @param string $customer_name
     * @param string $survey_token   The unique survey token from the DB
     * @param string $site_url       Base URL of the site (defaults to home_url)
     * @param int    $resume_step    Which step they were on (0-based)
     * @return bool
     */
    public static function send_survey_reminder($customer_email, $customer_name, $survey_token, $site_url = '', $resume_step = 0) {
        if (empty($customer_email) || empty($survey_token)) {
            return false;
        }

        if (empty($site_url)) {
            $site_url = home_url();
        }

        // Build the tokenized resume URL. Adjust the page slug to match your survey page.
        $survey_page_url = add_query_arg(
            array('survey_token' => rawurlencode($survey_token)),
            trailingslashit($site_url) . 'activate/'   // ← change 'activate/' to your survey page slug if different
        );

        $first_name  = explode(' ', trim($customer_name))[0] ?: 'there';
        $step_number = $resume_step + 1; // Human-readable step

        $subject = 'Complete your website survey — we\'re waiting on you!';

        $body  = self::get_email_header();
        $body .= '
        <div style="padding: 40px 30px; font-family: \'DM Sans\', Arial, sans-serif; color: #1f2937;">

            <h1 style="font-size: 26px; font-weight: 700; margin: 0 0 12px 0; color: #1f2937;">
                Hey ' . esc_html($first_name) . ', don\'t forget to finish your survey! 📋
            </h1>

            <p style="font-size: 16px; color: #4b5563; margin: 0 0 24px 0; line-height: 1.7;">
                Thank you for your payment — your website build is queued and ready to go.<br>
                We just need a few more details from you to get started.
            </p>

            <!-- Progress pill -->
            <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 16px 20px; margin-bottom: 28px; display: inline-block;">
                <p style="margin: 0; font-size: 14px; font-weight: 600; color: #1d4ed8;">
                    📍 You left off at Step ' . intval($step_number) . ' of 11
                </p>
                <p style="margin: 4px 0 0 0; font-size: 13px; color: #3b82f6;">
                    Your progress has been saved — pick up right where you left off.
                </p>
            </div>

            <!-- CTA Button -->
            <div style="text-align: center; margin: 32px 0;">
                <a href="' . esc_url($survey_page_url) . '"
                   style="display: inline-block; background: #2536EB; color: #ffffff; text-decoration: none;
                          padding: 16px 40px; border-radius: 10px; font-size: 17px; font-weight: 700;
                          letter-spacing: 0.3px; box-shadow: 0 4px 14px rgba(37,54,235,0.35);">
                    Continue My Survey →
                </a>
            </div>

            <p style="font-size: 14px; color: #6b7280; margin: 0 0 8px 0; line-height: 1.7;">
                <strong>Why does this matter?</strong> Without your survey, we cannot build your website.
                The link above is unique to you and will restore all of the answers you\'ve already provided.
            </p>

            <p style="font-size: 13px; color: #9ca3af; margin: 24px 0 0 0;">
                If the button above doesn\'t work, copy and paste this link into your browser:<br>
                <a href="' . esc_url($survey_page_url) . '" style="color: #2536EB; word-break: break-all;">' . esc_html($survey_page_url) . '</a>
            </p>
        </div>';
        $body .= self::get_email_footer();

        $headers = array('Content-Type: text/html; charset=UTF-8');

        return wp_mail($customer_email, $subject, $body, $headers);
    }

    /**
     * Schedule a survey reminder email to be sent after a delay.
     * Hook into Stripe payment success and call this with the customer data.
     *
     * @param string $customer_email
     * @param string $customer_name
     * @param string $survey_token
     * @param int    $delay_seconds  How many seconds to wait before sending (default: 3600 = 1hr)
     */
    public static function schedule_survey_reminder($customer_email, $customer_name, $survey_token, $delay_seconds = 3600) {
        $event_args = array(
            'email' => $customer_email,
            'name'  => $customer_name,
            'token' => $survey_token,
        );

        // Store parameters for the cron callback
        $key = 'sec_survey_reminder_' . md5($survey_token);
        set_transient($key, $event_args, $delay_seconds + 300);

        wp_schedule_single_event(
            time() + $delay_seconds,
            'sec_send_survey_reminder',
            array($survey_token)
        );
    }

    /**
     * Cron callback: fires scheduled reminder.
     * Register the action hook in your main plugin file:
     *   add_action('sec_send_survey_reminder', ['SEC_Survey_Email', 'cron_send_survey_reminder']);
     *
     * @param string $survey_token
     */
    public static function cron_send_survey_reminder($survey_token) {
        $key  = 'sec_survey_reminder_' . md5($survey_token);
        $args = get_transient($key);

        if (!$args) {
            return; // Transient expired or already handled
        }

        // Check if survey is already completed — skip if so
        $submission = SEC_Survey_DB::get_submission_by_token($survey_token);
        if (!$submission || $submission->survey_completed) {
            delete_transient($key);
            return;
        }

        self::send_survey_reminder(
            $args['email'],
            $args['name'],
            $survey_token,
            '',
            (int) $submission->survey_step
        );

        delete_transient($key);
    }
}

