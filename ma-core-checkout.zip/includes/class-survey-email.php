<?php
/**
 * Survey Email Notifications
 *
 * Handles email notifications for survey submissions
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_Email {
    private static function get_social_platform_name($social) {
        $platform = '';
        if (is_array($social)) {
            $platform = trim((string) ($social['platform'] ?? ($social['label'] ?? '')));
        }
        return $platform !== '' ? $platform : 'Social Link';
    }

    private static function get_social_link_url($value) {
        $url = trim((string) $value);
        if ($url === '') {
            return '';
        }
        if (!preg_match('#^https?://#i', $url)) {
            $url = 'https://' . $url;
        }
        return $url;
    }

    /**
     * Send payment receipt email to customer
     *
     * @param array $payment_data Payment information
     * @return bool True on success, false on failure
     */
    public static function send_payment_receipt($payment_data) {
        $customer_email = $payment_data['customer_email'] ?? '';
        $customer_name = $payment_data['customer_name'] ?? '';
        $amount = (int) ($payment_data['amount'] ?? 0);
        $business_name = $payment_data['business_name'] ?? '';
        $session_id = $payment_data['session_id'] ?? '';
        $original_amount_cents = isset($payment_data['original_amount'])
            ? (int) round(((float) $payment_data['original_amount']) * 100)
            : (int) round(((float) get_option('sec_setup_fee_amount', 499.00)) * 100);
        $processing_fee_cents = isset($payment_data['processing_fee'])
            ? (int) round(((float) $payment_data['processing_fee']) * 100)
            : (int) round(((float) get_option('sec_processing_fee', 2.50)) * 100);
        $calculated_subtotal_cents = max(0, $original_amount_cents + $processing_fee_cents);
        $discount_cents = max(0, $calculated_subtotal_cents - $amount);

        if (empty($customer_email)) {
            return false;
        }

        // Get customized email settings
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        $subject = get_option('sec_receipt_email_subject', 'Payment Receipt - {{business_name}}');
        $body = get_option('sec_receipt_email_body', self::get_default_receipt_body());

        // Replace placeholders
        $replacements = [
            '{{customer_name}}' => $customer_name,
            '{{customer_email}}' => $customer_email,
            '{{amount}}' => '$' . number_format($amount / 100, 2),
            '{{original_amount}}' => '$' . number_format($original_amount_cents / 100, 2),
            '{{processing_fee}}' => '$' . number_format($processing_fee_cents / 100, 2),
            '{{total_amount}}' => '$' . number_format($amount / 100, 2),
            '{{discount_amount}}' => '$' . number_format($discount_cents / 100, 2),
            '{{date}}' => date('F j, Y'),
            '{{business_name}}' => $business_name ?: 'your business'
        ];

        foreach ($replacements as $placeholder => $value) {
            $subject = str_replace($placeholder, $value, $subject);
            $body = str_replace($placeholder, $value, $body);
        }

        // Email headers
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        ];

        $attachments = self::build_payment_pdf_attachments(array(
            'customer_name' => $customer_name,
            'customer_email' => $customer_email,
            'business_name' => $business_name,
            'amount' => $amount,
            'session_id' => $session_id,
            'date' => date('F j, Y g:i A'),
        ));

        // Wrap body in email template
        $html = self::get_email_header();
        $html .= '<div style="padding: 30px; font-family: Arial, sans-serif; color: #333;">';
        $html .= self::render_plaintext_body_html($body);
        $html .= '</div>';
        $html .= self::get_email_footer();

        $sent = wp_mail($customer_email, $subject, $html, $headers, $attachments);
        self::cleanup_temp_files($attachments);
        return $sent;
    }

    /**
     * Get default receipt email body
     */
    private static function get_default_receipt_body() {
        return 'Hi {{customer_name}},

Thank you for your payment! Your website setup is confirmed.

Payment Details:
• Original Price: {{original_amount}}
• Processing Fee: {{processing_fee}}
• Discount: {{discount_amount}}
• Total Paid: {{total_amount}}
• Date: {{date}}
• Business: {{business_name}}

Next Steps:
1. Complete the website launch survey (link sent separately)
2. We\'ll build your website within 48 hours
3. You\'ll receive a preview link to review before going live

Questions? Just reply to this email.

Best regards,
The ' . get_bloginfo('name') . ' Team';
    }



    /**
     * Get default survey invitation email body
     */
    private static function get_default_survey_template() {
        return 'Hi {{customer_name}},

Thank you for your payment! To build your website, we need a few details about your business.

Please complete the survey here:
{{survey_link}}

This should only take 5-10 minutes. Your progress is saved automatically, so you can complete it later if needed.

Once submitted, we\'ll have your website ready within 48 hours!

Best regards,
The ' . get_bloginfo('name') . ' Team';
    }

    /**
     * Get default survey completion email body
     */
    private static function get_default_completion_template() {
        return 'Hi {{customer_name}},

Perfect! We received your website launch details for {{business_name}}.

What happens next:
• Our team will build your custom website
• Expect a preview/demo link within 48 hours
• You\'ll be able to review and request changes

Submitted on: {{submitted_at}}

Best regards,
The ' . get_bloginfo('name') . ' Team';
    }

    /**
     * Convert 24-hour time to 12-hour format (or return as-is if already 12-hour)
     */
    private static function format_time_12hour($time24) {
        // Check if already in 12-hour format (contains AM/PM)
        if (preg_match('/\s*(AM|PM|am|pm)\s*$/i', $time24)) {
            return trim($time24);
        }

        // Convert from 24-hour format
        list($hours, $minutes) = explode(':', $time24);
        $h = intval($hours);
        $period = $h >= 12 ? 'PM' : 'AM';
        $h12 = $h == 0 ? 12 : ($h > 12 ? $h - 12 : $h);
        return $h12 . ':' . $minutes . ' ' . $period;
    }



    /**
     * Send immediate survey invitation email with tokenized link.
     */
    public static function send_survey_invitation($customer_email, $customer_name, $survey_token, $business_name = '', $site_url = '') {
        if (empty($customer_email) || empty($survey_token)) {
            return false;
        }

        if (empty($site_url)) {
            $site_url = home_url();
        }

        $survey_link = add_query_arg(
            array('survey_token' => rawurlencode($survey_token)),
            trailingslashit($site_url) . 'survey/'
        );

        $subject = get_option('sec_survey_email_subject', 'Complete Your Website Launch Survey');
        $body = get_option('sec_survey_email_body', self::get_default_survey_template());

        $replacements = array(
            '{{customer_name}}' => $customer_name ?: 'there',
            '{{survey_link}}' => $survey_link,
            '{{business_name}}' => $business_name ?: 'your business',
        );

        foreach ($replacements as $placeholder => $value) {
            $subject = str_replace($placeholder, $value, $subject);
            $body = str_replace($placeholder, $value, $body);
        }

        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );

        $html = self::get_email_header();
        $html .= '<div style="padding: 30px; font-family: Arial, sans-serif; color: #333;">';
        // Parse body with CTA button support
        $html .= self::render_plaintext_body_html($body, $survey_link, 'Complete Survey →');
        $html .= '</div>';
        $html .= self::get_email_footer();

        return wp_mail($customer_email, $subject, $html, $headers);
    }

    /**
     * Send survey completion confirmation to customer.
     */
    public static function send_completion_confirmation($submission) {
        if (empty($submission) || empty($submission->customer_email)) {
            return false;
        }

        $subject = get_option('sec_completion_email_subject', 'Website Launch Confirmed - Ready in 48 Hours');
        $body = get_option('sec_completion_email_body', self::get_default_completion_template());

        $replacements = array(
            '{{customer_name}}' => $submission->customer_name ?: 'there',
            '{{business_name}}' => $submission->business_name ?: 'your business',
            '{{submitted_at}}' => !empty($submission->submitted_at) ? date('F j, Y g:i A', strtotime($submission->submitted_at)) : date('F j, Y g:i A'),
        );

        foreach ($replacements as $placeholder => $value) {
            $subject = str_replace($placeholder, $value, $subject);
            $body = str_replace($placeholder, $value, $body);
        }

        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );

        $html = self::get_email_header();
        $html .= '<div style="padding: 30px; font-family: Arial, sans-serif; color: #333;">';
        $html .= self::render_plaintext_body_html($body);
        $html .= '</div>';
        $html .= self::get_email_footer();

        return wp_mail($submission->customer_email, $subject, $html, $headers);
    }

    /**
     * Send survey submission notification to admin
     *
     * @param int $submission_id Survey submission ID
     * @return bool True on success, false on failure
     */
    public static function send_admin_notification($submission_id) {
        $submission = SEC_Survey_DB::get_submission($submission_id);

        if (!$submission) {
            return false;
        }

        // Get admin email from settings or use default
        $admin_email = get_option('sec_survey_notification_email', get_option('admin_email'));

        // Prepare email content
        $subject = sprintf(
            'New Website Setup Survey Submission - %s',
            $submission->business_name ?: $submission->customer_name
        );

        $email_body = self::format_submission_email($submission);

        // Email headers
        $headers = array('Content-Type: text/html; charset=UTF-8');

        // Send email (no attachments - files are included as download links)
        $sent = wp_mail($admin_email, $subject, $email_body, $headers);

        return $sent;
    }

    /**
     * Format submission data for email
     *
     * @param object $submission Submission data
     * @return string HTML formatted email body
     */
    private static function format_submission_email($submission) {
        $html = self::get_email_header();

        $html .= '<div style="padding: 30px; font-family: Arial, sans-serif; color: #333;">';

        // Header section
        $html .= '<h1 style="color: #3b82f6; margin-bottom: 10px;">New Website Setup Survey</h1>';
        $html .= '<p style="color: #666; font-size: 14px; margin-bottom: 30px;">Received ' . date('F j, Y g:i A', strtotime($submission->submitted_at)) . '</p>';

        // Payment Information
        $html .= '<div style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; margin-bottom: 30px;">';
        $html .= '<h2 style="margin: 0 0 15px 0; font-size: 18px; color: #1e40af;">Payment Information</h2>';
        $html .= self::format_field_row('Customer Name', $submission->customer_name);
        $html .= self::format_field_row('Email', $submission->customer_email);
        $html .= self::format_field_row('Payment Amount', '$' . number_format($submission->payment_amount, 2));
        $html .= self::format_field_row('Stripe Customer ID', $submission->stripe_customer_id);
        $html .= self::format_field_row('Stripe Session ID', $submission->stripe_session_id);
        $html .= '</div>';

        // Business Information
        if ($submission->business_name) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Business Information</h2>';
            $html .= self::format_field_row('Business Name', $submission->business_name);

            $industry = $submission->industry === 'Other' ? $submission->custom_industry : $submission->industry;
            $html .= self::format_field_row('Industry', $industry);

            if ($submission->tagline) {
                $html .= self::format_field_row('Tagline', $submission->tagline);
            }
            $html .= '</div>';
        }

        // Services
        if ($submission->services) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Services Offered</h2>';
            $html .= '<div style="background: #f8fafc; padding: 15px; border-radius: 5px; white-space: pre-line; line-height: 1.6;">' . nl2br(esc_html($submission->services)) . '</div>';
            $html .= '</div>';
        }

        // Business Hours
        if ($submission->hours) {
            $hours = json_decode($submission->hours, true);
            if (is_array($hours) && !empty($hours)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Business Hours</h2>';
                $html .= '<table style="width: 100%; border-collapse: collapse;">';

                foreach ($hours as $day => $time) {
                    $html .= '<tr>';
                    $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb; font-weight: bold; width: 100px;">' . esc_html($day) . '</td>';

                    if ($time['closed']) {
                        $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb; color: #999; font-style: italic;">Closed</td>';
                    } else {
                        $open_12h = self::format_time_12hour($time['open']);
                        $close_12h = self::format_time_12hour($time['close']);
                        $html .= '<td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">' . esc_html($open_12h) . ' - ' . esc_html($close_12h) . '</td>';
                    }

                    $html .= '</tr>';
                }

                $html .= '</table>';
                $html .= '</div>';
            }
        }

        // Booking Methods
        if ($submission->booking) {
            $booking = json_decode($submission->booking, true);
            if (is_array($booking) && !empty($booking)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Booking Methods</h2>';

                $booking_labels = array(
                    'virtual' => '📹 Virtually (video or phone call)',
                    'our_location' => '🏢 At my location (client comes to me)',
                    'client_location' => '🚗 At the client\'s location (I go to them)'
                );

                $html .= '<ul style="list-style: none; padding: 0;">';
                foreach ($booking as $method) {
                    $label = $booking_labels[$method] ?? $method;
                    $html .= '<li style="padding: 8px 0; border-bottom: 1px solid #e5e7eb;">✓ ' . esc_html($label) . '</li>';
                }
                $html .= '</ul>';
                $html .= '</div>';
            }
        }

        // Contact Information
        $html .= '<div style="margin-bottom: 30px;">';
        $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Contact Information</h2>';
        if ($submission->contact_phone) {
            $html .= self::format_field_row('Phone', $submission->contact_phone);
        }
        if ($submission->contact_email) {
            $html .= self::format_field_row('Email', $submission->contact_email);
        }
        if ($submission->contact_address) {
            $html .= self::format_field_row('Address', $submission->contact_address);
        }
        $html .= '</div>';

        // Social Media
        if ($submission->socials) {
            $socials = json_decode($submission->socials, true);
            if (is_array($socials) && !empty($socials)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Social Media</h2>';

                foreach ($socials as $social) {
                    if (!empty($social['value'])) {
                        $platform_name = self::get_social_platform_name($social);
                        $social_url = self::get_social_link_url($social['value']);
                        $html .= '<p style="margin: 8px 0;">';
                        $html .= '<strong>' . esc_html($platform_name) . ':</strong> ';
                        $html .= '<a href="' . esc_url($social_url) . '" style="color: #3b82f6; text-decoration: none;">' . esc_html($social_url) . '</a>';
                        $html .= '</p>';
                    }
                }

                $html .= '</div>';
            }
        }

        // Brand Information
        if ($submission->brand) {
            $brand = json_decode($submission->brand, true);
            if (is_array($brand) && !empty($brand)) {
                $html .= '<div style="margin-bottom: 30px;">';
                $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Brand Assets</h2>';

                $brand_labels = array(
                    'logo' => '🎨 Has logo',
                    'colors' => '🎨 Has brand colors',
                    'slogan' => '💬 Has slogan',
                    'none' => 'None yet — build it for me'
                );

                foreach ($brand as $item) {
                    $label = $brand_labels[$item] ?? $item;
                    $html .= '<p style="margin: 8px 0;">✓ ' . esc_html($label) . '</p>';
                }

                if ($submission->brand_colors) {
                    $html .= self::format_field_row('Brand Colors', $submission->brand_colors);
                }
                if ($submission->brand_slogan) {
                    $html .= self::format_field_row('Slogan', $submission->brand_slogan);
                }

                $html .= '</div>';
            }
        }

        // Files - Include download links
        $has_files = false;
        $file_html = '';

        if ($submission->logo_path) {
            $has_files = true;
            // Logo path is already a full URL from upload
            $logo_url = $submission->logo_path;

            $file_html .= '<div style="margin-bottom: 15px; background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;">';
            $file_html .= '<div style="display: flex; align-items: center; gap: 10px;">';
            $file_html .= '<span style="font-size: 24px;">🎨</span>';
            $file_html .= '<div style="flex: 1;">';
            $file_html .= '<strong style="color: #1e40af; display: block; margin-bottom: 5px;">Logo</strong>';
            $file_html .= '<a href="' . esc_url($logo_url) . '" style="display: inline-block; background: #3b82f6; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; font-size: 14px; font-weight: bold;">Download Logo →</a>';
            $file_html .= '</div>';
            $file_html .= '</div>';
            $file_html .= '</div>';
        }

        if ($submission->file_paths) {
            $files = json_decode($submission->file_paths, true);
            if (is_array($files) && !empty($files)) {
                $has_files = true;

                foreach ($files as $index => $file_path) {
                    // File path is already a full URL from upload
                    $file_url = $file_path;
                    $filename = basename($file_url);
                    $is_image = preg_match('/\.(jpg|jpeg|png|gif|webp|svg)$/i', $filename);

                    $file_html .= '<div style="margin-bottom: 15px; background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;">';
                    $file_html .= '<div style="display: flex; align-items: center; gap: 10px;">';
                    $file_html .= '<span style="font-size: 24px;">' . ($is_image ? '🖼️' : '📄') . '</span>';
                    $file_html .= '<div style="flex: 1;">';
                    $file_html .= '<strong style="color: #1e40af; display: block; margin-bottom: 5px;">File ' . ($index + 1) . '</strong>';
                    $file_html .= '<span style="color: #666; font-size: 13px; display: block; margin-bottom: 8px;">' . esc_html($filename) . '</span>';
                    $file_html .= '<a href="' . esc_url($file_url) . '" style="display: inline-block; background: #3b82f6; color: white; padding: 8px 16px; text-decoration: none; border-radius: 5px; font-size: 14px; font-weight: bold;">Download File →</a>';
                    $file_html .= '</div>';
                    $file_html .= '</div>';
                    $file_html .= '</div>';
                }
            }
        }

        if ($has_files) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">📎 Uploaded Files</h2>';
            $html .= $file_html;
            $html .= '<p style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 12px; margin-top: 15px; font-size: 13px; color: #666;">';
            $html .= '<strong>💡 Tip:</strong> Click the download buttons above to view and save the uploaded files.';
            $html .= '</p>';
            $html .= '</div>';
        }

        // Additional Notes
        if ($submission->extra) {
            $html .= '<div style="margin-bottom: 30px;">';
            $html .= '<h2 style="color: #1e40af; font-size: 18px; margin-bottom: 15px; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">Additional Notes</h2>';
            $html .= '<div style="background: #f8fafc; padding: 15px; border-radius: 5px; white-space: pre-line; line-height: 1.6;">' . nl2br(esc_html($submission->extra)) . '</div>';
            $html .= '</div>';
        }

        // View in Dashboard link
        $view_url = admin_url('admin.php?page=sec-survey-submissions&action=view&id=' . $submission->id);
        $html .= '<div style="text-align: center; margin-top: 40px; padding-top: 30px; border-top: 2px solid #e5e7eb;">';
        $html .= '<a href="' . esc_url($view_url) . '" style="display: inline-block; background: linear-gradient(135deg, #3b82f6, #0ea5e9); color: white; padding: 15px 40px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 16px;">View Full Details in Dashboard →</a>';
        $html .= '</div>';

        $html .= '</div>';
        $html .= self::get_email_footer();

        return $html;
    }

    /**
     * Format a field row for email
     */
    private static function format_field_row($label, $value) {
        if (empty($value)) return '';

        return '<p style="margin: 8px 0;"><strong style="color: #1e40af;">' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
    }

    /**
     * Prepare file attachments for email
     */
    private static function prepare_attachments($submission) {
        $attachments = array();

        // Add logo file
        if (!empty($submission->logo_path)) {
            $logo_file = SEC_Survey_DB::resolve_stored_file_path($submission->logo_path);
            if (!empty($logo_file) && file_exists($logo_file)) {
                $attachments[] = $logo_file;
            }
        }

        // Add other files
        if (!empty($submission->file_paths)) {
            $file_paths = json_decode($submission->file_paths, true);
            if (is_array($file_paths)) {
                foreach ($file_paths as $file_path) {
                    $file = SEC_Survey_DB::resolve_stored_file_path($file_path);
                    if (!empty($file) && file_exists($file)) {
                        $attachments[] = $file;
                    }
                }
            }
        }

        return $attachments;
    }

    /**
     * Get email header HTML
     */
    private static function get_email_header() {
        $logo_url = self::get_email_logo_url();
        $gradient_start = sanitize_hex_color(get_option('sec_email_header_gradient_start', '#3b82f6')) ?: '#3b82f6';
        $gradient_end = sanitize_hex_color(get_option('sec_email_header_gradient_end', '#0ea5e9')) ?: '#0ea5e9';
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));

        return '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Survey Submission</title>
        </head>
        <body style="margin: 0; padding: 0; background-color: #f3f4f6;">
            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f3f4f6;">
                <tr>
                    <td align="center" style="padding: 40px 20px;">
                        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); overflow: hidden;">
                            <tr>
                                <td align="center" style="background: linear-gradient(135deg, ' . esc_attr($gradient_start) . ', ' . esc_attr($gradient_end) . '); padding: 30px;">
                                    ' . (!empty($logo_url)
                                        ? '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($from_name) . '" width="220" style="display:block; width:220px; max-width:220px; height:auto; max-height:68px; margin:0 auto;">'
                                        : '<div style="font-family:Arial,sans-serif; font-size:28px; line-height:1; color:#ffffff; font-weight:700;">' . esc_html($from_name) . '</div>') . '
                                </td>
                            </tr>
                            <tr>
                                <td>';
    }

    /**
     * Get email footer HTML
     */
    private static function get_email_footer() {
        return '                </td>
                            </tr>
                            <tr>
                                <td align="center" style="background-color: #f8fafc; padding: 20px; color: #6b7280; font-size: 12px;">
                                    &copy; ' . date('Y') . ' Marketing Aid. All rights reserved.
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </body>
        </html>';
    }

    /**
     * Parse and replace {{cta_button:Text}} placeholder with styled button.
     *
     * @param string $body Email body content
     * @param string $url URL for the button
     * @param string $default_text Default button text if not specified
     * @return string Processed body with CTA button
     */
    private static function parse_cta_button($body, $url, $default_text = 'Continue →') {
        // Pattern: {{cta_button}} or {{cta_button:Custom Text}}
        $pattern = '/\{\{cta_button(?::([^}]+))?\}\}/i';

        if (preg_match($pattern, $body, $matches)) {
            // Extract button text (use custom text if provided, otherwise default)
            $button_text = isset($matches[1]) && !empty(trim($matches[1]))
                ? trim($matches[1])
                : $default_text;

            // Generate email-client-friendly button using table structure
            $button_html = '
<!--[if mso]>
<v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="' . esc_url($url) . '" style="height:50px;v-text-anchor:middle;width:250px;" arcsize="16%" stroke="f" fillcolor="#2536EB">
<w:anchorlock/>
<center style="color:#ffffff;font-family:Arial,sans-serif;font-size:17px;font-weight:bold;">' . esc_html($button_text) . '</center>
</v:roundrect>
<![endif]-->
<!--[if !mso]><!-->
<table border="0" cellpadding="0" cellspacing="0" style="margin:24px auto;border-collapse:separate!important;border-radius:8px;background:#2536EB;mso-table-lspace:0pt;mso-table-rspace:0pt;">
<tr>
<td align="center" valign="middle" style="font-family:Arial,sans-serif;font-size:17px;padding:16px 40px;background:#2536EB;border-radius:8px;">
<a href="' . esc_url($url) . '" target="_blank" style="display:inline-block;color:#ffffff;background-color:#2536EB;border:solid 2px #2536EB;border-radius:8px;text-decoration:none;font-size:17px;font-weight:700;margin:0;padding:0;line-height:1.2;">' . esc_html($button_text) . '</a>
</td>
</tr>
</table>
<!--<![endif]-->';

            // Replace placeholder with button
            $body = preg_replace($pattern, $button_html, $body);
        }

        return $body;
    }

    /**
     * Convert plain text (with line breaks) into cleaner paragraph HTML.
     * Now supports {{cta_button:Text}} placeholders.
     */
    private static function render_plaintext_body_html($body, $cta_url = '', $cta_default_text = 'Continue →') {
        $body = trim((string) $body);
        if ($body === '') {
            return '';
        }

        // Parse CTA button first if URL provided
        if (!empty($cta_url)) {
            $body = self::parse_cta_button($body, $cta_url, $cta_default_text);
        }

        $chunks = preg_split("/\R{2,}/", $body);
        $html = '';
        foreach ($chunks as $chunk) {
            $chunk = trim($chunk);
            if ($chunk === '') {
                continue;
            }

            // Check if this chunk contains the CTA button HTML (already processed)
            if (strpos($chunk, 'mso-table-lspace') !== false || strpos($chunk, 'background:#2536EB') !== false || strpos($chunk, '<table') !== false) {
                // This is the button HTML, output as-is
                $html .= $chunk;
            } else {
                // Regular text paragraph - escape and auto-linkify URLs
                $escaped_chunk = esc_html($chunk);
                // Auto-linkify URLs (https:// or http://)
                $escaped_chunk = preg_replace(
                    '#(https?://[^\s<]+)#i',
                    '<a href="$1" style="color:#2536EB; word-break:break-all; text-decoration:underline;">$1</a>',
                    $escaped_chunk
                );
                $html .= '<p style="margin:0 0 14px 0; line-height:1.55; color:#334155;">' . nl2br($escaped_chunk) . '</p>';
            }
        }

        return $html;
    }

    /**
     * Build local PDF attachments for payment receipt + invoice copy.
     */
    private static function build_payment_pdf_attachments($data) {
        $attachments = array();
        if (!class_exists('SEC_Reusable_PDF_Template')) {
            return $attachments;
        }

        $amount_total = (float) ($data['amount'] ?? 0) / 100;
        $business_name = sanitize_text_field($data['business_name'] ?? get_bloginfo('name'));
        $customer_name = sanitize_text_field($data['customer_name'] ?? '');
        $customer_email = sanitize_email($data['customer_email'] ?? '');
        $session_id = sanitize_text_field($data['session_id'] ?? '');
        $date = sanitize_text_field($data['date'] ?? date('F j, Y g:i A'));
        $logo_url = get_option('sec_logo_url', '');
        if (empty($logo_url)) {
            $logo_url = get_option('sec_logo_image', get_option('sec_email_logo_url', ''));
        }
        $png_fallback = esc_url_raw((string) get_option('sec_logo_png_fallback_url', ''));
        if (!empty($png_fallback) && preg_match('/\\.svg(\\?.*)?$/i', (string) $logo_url)) {
            $logo_url = $png_fallback;
        }
        $support_email = sanitize_email(get_option('sec_billing_support_email', 'billing@marketingaid.org')) ?: 'billing@marketingaid.org';
        $service_name = sanitize_text_field(get_option('sec_setup_fee_name', 'Website Setup Fee'));
        $setup_fee = (float) get_option('sec_setup_fee_amount', 499.00);
        $processing_fee = (float) get_option('sec_processing_fee', 2.50);
        $calculated_subtotal = max(0, $setup_fee + $processing_fee);
        $calculated_discount = max(0, $calculated_subtotal - $amount_total);
        $accent_color = sanitize_hex_color(get_option('sec_pdf_header_color_start', '#0EA5E9')) ?: '#0EA5E9';
        $secondary_color = sanitize_hex_color(get_option('sec_pdf_header_color_end', '#0A2540')) ?: '#0A2540';
        $line_items = array(
            array('name' => $service_name . ' (Original Price)', 'quantity' => 1, 'price' => $setup_fee),
            array('name' => 'Processing Fee', 'quantity' => 1, 'price' => $processing_fee),
        );

        $common_data = array(
            'brand_name' => $business_name !== '' ? $business_name : get_bloginfo('name'),
            'business_name' => $business_name !== '' ? $business_name : get_bloginfo('name'),
            'customer_name' => $customer_name,
            'customer_email' => $customer_email,
            'support_email' => $support_email,
            'amount_total' => $amount_total,
            'amount_subtotal' => $calculated_subtotal,
            'amount_discount' => $calculated_discount,
            'payment_method' => 'Card',
            'session_id' => $session_id,
            'receipt_number' => $session_id !== '' ? substr($session_id, -12) : '',
            'date' => $date,
            'service_name' => $service_name,
            'line_items' => $line_items,
            'accent_color' => $accent_color,
            'secondary_color' => $secondary_color,
            'logo_url' => $logo_url,
            'footer_note' => 'Questions? Contact ' . $support_email,
        );

        $receipt_file = SEC_Reusable_PDF_Template::create_payment_receipt_pdf_file(
            array_merge($common_data, array('status' => 'Paid')),
            'payment-receipt-' . md5($session_id . $customer_email)
        );
        if (!empty($receipt_file)) {
            $attachments[] = $receipt_file;
        }

        $invoice_file = SEC_Reusable_PDF_Template::create_invoice_pdf_file(
            array(
                'business_name' => $business_name !== '' ? $business_name : get_bloginfo('name'),
                'support_email' => $support_email,
                'customer_name' => $customer_name,
                'customer_email' => $customer_email,
                'invoice_number' => $session_id !== '' ? 'INV-' . strtoupper(substr($session_id, -8)) : 'INV-' . date('Ymd'),
                'status' => 'paid',
                'created_at' => current_time('mysql'),
                'expires_at' => '',
                'amount_subtotal' => $calculated_subtotal,
                'amount_tax' => 0,
                'amount_discount' => $calculated_discount,
                'amount_total' => $amount_total,
                'items' => $line_items,
                'primary_color' => $accent_color,
                'secondary_color' => $secondary_color,
                'logo_url' => $logo_url,
                'footer_note' => 'For support contact ' . $support_email,
            ),
            'invoice-copy-' . md5($session_id . $customer_email)
        );
        if (!empty($invoice_file)) {
            $attachments[] = $invoice_file;
        }

        return $attachments;
    }

    private static function cleanup_temp_files($paths) {
        if (class_exists('SEC_Reusable_PDF_Template')) {
            SEC_Reusable_PDF_Template::cleanup_temp_files($paths);
        }
    }

    private static function get_email_logo_url() {
        $logo_url = get_option('sec_logo_url', '');
        if (empty($logo_url)) {
            $logo_url = get_option('sec_logo_image', get_option('sec_email_logo_url', ''));
        }

        $logo_url = esc_url_raw((string) $logo_url);
        if ($logo_url === '') {
            return '';
        }

        if (!preg_match('/\.svg(\?.*)?$/i', $logo_url)) {
            return $logo_url;
        }

        $png_fallback = esc_url_raw((string) get_option('sec_logo_png_fallback_url', ''));
        if ($png_fallback !== '') {
            return $png_fallback;
        }

        // Email clients are unreliable with SVG. Convert and cache a PNG if Imagick is available.
        $png_url = self::convert_svg_logo_to_cached_png_url($logo_url);
        if ($png_url !== '') {
            return $png_url;
        }

        // Last fallback: no logo (use text wordmark).
        return '';
    }

    private static function convert_svg_logo_to_cached_png_url($svg_url) {
        if (!class_exists('Imagick') || !function_exists('wp_remote_get')) {
            return '';
        }

        $cache_key = 'sec_logo_png_cache_' . md5($svg_url);
        $cached_url = get_transient($cache_key);
        if (!empty($cached_url)) {
            return esc_url_raw((string) $cached_url);
        }

        $response = wp_remote_get($svg_url, array('timeout' => 8));
        if (is_wp_error($response)) {
            return '';
        }

        $svg = (string) wp_remote_retrieve_body($response);
        if ($svg === '') {
            return '';
        }

        try {
            $img = new \Imagick();
            $img->setBackgroundColor(new \ImagickPixel('transparent'));
            $img->readImageBlob($svg);
            $img->setImageFormat('png');
            $png_blob = $img->getImageBlob();
            $img->clear();
            $img->destroy();
        } catch (\Exception $e) {
            return '';
        }

        if (empty($png_blob)) {
            return '';
        }

        $upload_dir = wp_upload_dir();
        if (empty($upload_dir['basedir']) || empty($upload_dir['baseurl'])) {
            return '';
        }

        $dir = trailingslashit($upload_dir['basedir']) . 'sec-email-logo-cache/';
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }

        $filename = 'logo-' . md5($svg_url) . '.png';
        $path = $dir . $filename;
        $url = trailingslashit($upload_dir['baseurl']) . 'sec-email-logo-cache/' . $filename;

        if (file_put_contents($path, $png_blob) === false) {
            return '';
        }

        set_transient($cache_key, $url, DAY_IN_SECONDS);
        return esc_url_raw($url);
    }

    /**
     * Send a "complete your survey" reminder email to the customer.
     * Includes a tokenized link that resumes the survey at the saved step.
     *
     * @param string $customer_email
     * @param string $customer_name
     * @param string $survey_token   The unique survey token from the DB
     * @param string $site_url       Base URL of the site (defaults to home_url)
     * @param int    $resume_step    Which step they were on (0-based)
     * @return bool
     */
    public static function send_survey_reminder($customer_email, $customer_name, $survey_token, $site_url = '', $resume_step = 0) {
        if (empty($customer_email) || empty($survey_token)) {
            return false;
        }

        if (empty($site_url)) {
            $site_url = home_url();
        }

        // Build the tokenized resume URL
        $survey_page_url = add_query_arg(
            array('survey_token' => rawurlencode($survey_token)),
            trailingslashit($site_url) . 'survey/'
        );

        $total_steps = 11;
        $current_step = $resume_step + 1; // Human-readable step (1-based)
        $progress_percent = round(($resume_step / $total_steps) * 100);

        // Get subject and body from branding settings
        $subject = get_option('sec_reminder_email_subject', 'Complete your website setup - we\'re waiting on you!');
        $body = get_option('sec_reminder_email_body', self::get_default_reminder_template());

        // Replace placeholders
        $replacements = array(
            '{{customer_name}}' => $customer_name ?: 'there',
            '{{current_step}}' => $current_step,
            '{{total_steps}}' => $total_steps,
            '{{progress_percent}}' => $progress_percent,
            '{{survey_link}}' => $survey_page_url,
        );

        foreach ($replacements as $placeholder => $value) {
            $subject = str_replace($placeholder, $value, $subject);
            $body = str_replace($placeholder, $value, $body);
        }

        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );

        $html = self::get_email_header();
        $html .= '<div style="padding: 30px; font-family: Arial, sans-serif; color: #333;">';
        // Parse body with CTA button support
        $html .= self::render_plaintext_body_html($body, $survey_page_url, 'Continue My Survey →');
        $html .= '</div>';
        $html .= self::get_email_footer();

        return wp_mail($customer_email, $subject, $html, $headers);
    }

    /**
     * Schedule a survey reminder email to be sent after a delay.
     * Hook into Stripe payment success and call this with the customer data.
     *
     * @param string $customer_email
     * @param string $customer_name
     * @param string $survey_token
     * @param int    $delay_seconds  How many seconds to wait before sending (default: 3600 = 1hr)
     */
    public static function schedule_survey_reminder($customer_email, $customer_name, $survey_token, $delay_seconds = 3600) {
        $event_args = array(
            'email' => $customer_email,
            'name'  => $customer_name,
            'token' => $survey_token,
        );

        // Store parameters for the cron callback
        $key = 'sec_survey_reminder_' . md5($survey_token);
        set_transient($key, $event_args, $delay_seconds + 300);

        wp_schedule_single_event(
            time() + $delay_seconds,
            'sec_send_survey_reminder',
            array($survey_token)
        );
    }

    /**
     * Cron callback: fires scheduled reminder.
     * Register the action hook in your main plugin file:
     *   add_action('sec_send_survey_reminder', ['SEC_Survey_Email', 'cron_send_survey_reminder']);
     *
     * @param string $survey_token
     */
    public static function cron_send_survey_reminder($survey_token) {
        $key  = 'sec_survey_reminder_' . md5($survey_token);
        $args = get_transient($key);

        if (!$args) {
            return; // Transient expired or already handled
        }

        // Check if survey is already completed — skip if so
        $submission = SEC_Survey_DB::get_submission_by_token($survey_token);
        if (!$submission || $submission->survey_completed) {
            delete_transient($key);
            return;
        }

        self::send_survey_reminder(
            $args['email'],
            $args['name'],
            $survey_token,
            '',
            (int) $submission->survey_step
        );

        delete_transient($key);
    }
}
