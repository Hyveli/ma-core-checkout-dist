<?php
/**
 * Survey Data Migration
 *
 * Handles one-time data fixes and migrations for the survey system.
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_Migration {

    /**
     * Normalize payment_date for existing records
     *
     * For records with NULL payment_date, sets it based on:
     * 1. submitted_at (most reliable fallback - set when record was created)
     * 2. survey_last_saved (if they started the survey)
     * 3. last_activity (last interaction)
     * 4. Current time (last resort)
     */
    public static function normalize_payment_dates() {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';

        // Find records with NULL payment_date
        $null_count = $wpdb->get_var("
            SELECT COUNT(*)
            FROM {$table}
            WHERE payment_date IS NULL
               OR payment_date = '0000-00-00 00:00:00'
        ");

        if ($null_count == 0) {
            return array(
                'success' => true,
                'updated' => 0,
                'message' => 'No records need payment_date normalization.'
            );
        }

        // Normalize using submitted_at as fallback (record creation time)
        $updated = $wpdb->query("
            UPDATE {$table}
            SET payment_date = COALESCE(
                NULLIF(payment_date, '0000-00-00 00:00:00'),
                survey_last_saved,
                last_activity,
                submitted_at,
                NOW()
            ),
            payment_status = CASE
                WHEN payment_status IS NULL OR payment_status = '' THEN 'paid'
                ELSE payment_status
            END
            WHERE payment_date IS NULL
               OR payment_date = '0000-00-00 00:00:00'
        ");

        return array(
            'success' => true,
            'updated' => $updated,
            'message' => "Normalized payment_date for {$updated} record(s)."
        );
    }

    /**
     * Check if migration is needed
     */
    public static function needs_migration() {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';

        $count = $wpdb->get_var("
            SELECT COUNT(*)
            FROM {$table}
            WHERE payment_date IS NULL
               OR payment_date = '0000-00-00 00:00:00'
        ");

        return $count > 0;
    }

    /**
     * Admin notice for migration
     */
    public static function show_migration_notice() {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (!self::needs_migration()) {
            return;
        }

        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <strong>Survey Reminder System:</strong>
                Some survey submissions have missing payment dates.
                <a href="<?php echo admin_url('admin.php?page=sec-time-simulator&action=normalize_dates'); ?>" class="button button-primary" style="margin-left:10px;">
                    Normalize Payment Dates
                </a>
            </p>
        </div>
        <?php
    }

    /**
     * Handle migration action
     */
    public static function handle_migration_action() {
        if (!isset($_GET['action']) || $_GET['action'] !== 'normalize_dates') {
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $result = self::normalize_payment_dates();

        $redirect_url = add_query_arg(
            array(
                'page' => 'sec-time-simulator',
                'migration' => $result['success'] ? 'success' : 'error',
                'updated' => $result['updated']
            ),
            admin_url('admin.php')
        );

        wp_redirect($redirect_url);
        exit;
    }

    /**
     * Show migration result message
     */
    public static function show_migration_result() {
        if (!isset($_GET['migration'])) {
            return;
        }

        $type = $_GET['migration'] === 'success' ? 'success' : 'error';
        $updated = isset($_GET['updated']) ? intval($_GET['updated']) : 0;

        ?>
        <div class="notice notice-<?php echo $type; ?> is-dismissible">
            <p>
                <?php if ($type === 'success'): ?>
                    <strong>✓ Migration Complete:</strong> Normalized payment_date for <?php echo $updated; ?> record(s).
                <?php else: ?>
                    <strong>✗ Migration Failed:</strong> An error occurred during migration.
                <?php endif; ?>
            </p>
        </div>
        <?php
    }

    /**
     * Initialize migration hooks
     */
    public static function init() {
        add_action('admin_notices', array(__CLASS__, 'show_migration_notice'));
        add_action('admin_init', array(__CLASS__, 'handle_migration_action'));
    }
}

SEC_Survey_Migration::init();
