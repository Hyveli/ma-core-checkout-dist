<?php
/**
 * Reusable branded PDF template for transactional documents.
 *
 * This file is intentionally generic so it can be copied into another plugin
 * and reused by changing the document model values (brand, title, items, totals).
 */

if (!defined('ABSPATH')) {
    exit;
}

class SEC_Reusable_PDF_Template {
    private const PAGE_WIDTH = 612.0;
    private const PAGE_HEIGHT = 792.0;

    /**
     * Build and write a branded payment receipt PDF.
     */
    public static function create_payment_receipt_pdf_file(array $data, $name_hint = '') {
        $document = self::build_receipt_document($data);
        return self::write_document_pdf_file($document, $name_hint ?: 'payment-receipt-' . md5(($data['session_id'] ?? '') . ($data['customer_email'] ?? '')));
    }

    /**
     * Build and write a branded invoice PDF.
     */
    public static function create_invoice_pdf_file(array $data, $name_hint = '') {
        $document = self::build_invoice_document($data);
        return self::write_document_pdf_file($document, $name_hint ?: 'invoice-' . md5(($data['invoice_number'] ?? '') . ($data['customer_email'] ?? '')));
    }

    /**
     * Shared cleanup helper for generated temp files.
     */
    public static function cleanup_temp_files($paths) {
        if (!is_array($paths)) {
            return;
        }

        foreach ($paths as $path) {
            if (!empty($path) && is_string($path) && file_exists($path)) {
                @unlink($path);
            }
        }
    }

    /**
     * Generic write helper for document models.
     */
    public static function write_document_pdf_file(array $document, $name_hint) {
        $upload_dir = wp_upload_dir();
        $dir = trailingslashit($upload_dir['basedir']) . 'sec-pdf-documents/';
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }

        $filename = sanitize_file_name((string) $name_hint) . '.pdf';
        $path = $dir . $filename;
        $pdf = self::render_document_pdf($document);

        if ($pdf === '') {
            return '';
        }

        $written = file_put_contents($path, $pdf);
        if ($written === false) {
            return '';
        }

        return $path;
    }

    /**
     * Reusable document model for receipts.
     */
    private static function build_receipt_document(array $data) {
        $brand_name = self::clean_text($data['brand_name'] ?? get_bloginfo('name'));
        $accent_hex = self::normalize_hex($data['accent_color'] ?? '#635BFF', '#635BFF');
        $secondary_hex = self::normalize_hex($data['secondary_color'] ?? '#0A2540', '#0A2540');

        $service_name = self::clean_text($data['service_name'] ?? 'Website Setup Service');
        $amount_total = (float) ($data['amount_total'] ?? $data['amount'] ?? 0);
        $amount_subtotal = isset($data['amount_subtotal']) ? (float) $data['amount_subtotal'] : $amount_total;

        $totals = array(
            array('label' => 'Subtotal', 'amount' => self::money($amount_subtotal), 'kind' => 'muted'),
        );

        if (!empty($data['amount_discount']) && (float) $data['amount_discount'] > 0) {
            $totals[] = array('label' => 'Discount', 'amount' => '- ' . self::money((float) $data['amount_discount']), 'kind' => 'muted');
        }

        $totals[] = array('label' => 'Total Paid', 'amount' => self::money($amount_total), 'kind' => 'strong');

        $meta_rows = array(
            array('label' => 'Receipt #', 'value' => self::clean_text($data['receipt_number'] ?? substr((string) ($data['session_id'] ?? ''), -12))),
            array('label' => 'Date', 'value' => self::clean_text($data['date'] ?? date('F j, Y g:i A'))),
            array('label' => 'Status', 'value' => self::clean_text($data['status'] ?? 'Paid')),
            array('label' => 'Payment Method', 'value' => self::clean_text($data['payment_method'] ?? 'Card')),
        );

        if (!empty($data['session_id'])) {
            $meta_rows[] = array('label' => 'Session ID', 'value' => self::clean_text((string) $data['session_id']));
        }

        return array(
            'title' => 'PAYMENT RECEIPT',
            'subtitle' => self::clean_text($data['document_subtitle'] ?? 'Transaction confirmation'),
            'accent_hex' => $accent_hex,
            'secondary_hex' => $secondary_hex,
            'logo_label' => self::clean_text($data['logo_label'] ?? self::initials($brand_name)),
            'company_block_title' => 'From',
            'company_lines' => self::compact_lines(array(
                $brand_name,
                self::clean_text($data['business_address'] ?? ''),
                self::clean_text($data['business_phone'] ?? ''),
                self::clean_text($data['support_email'] ?? get_option('admin_email')),
            )),
            'customer_block_title' => 'Billed To',
            'customer_lines' => self::compact_lines(array(
                self::clean_text($data['customer_name'] ?? ''),
                self::clean_text($data['customer_email'] ?? ''),
                self::clean_text($data['customer_address'] ?? ''),
            )),
            'metadata_rows' => $meta_rows,
            'table_headers' => array('Description', 'Qty', 'Unit', 'Amount'),
            'table_rows' => array(
                array('description' => $service_name, 'qty' => '1', 'unit' => self::money($amount_total), 'amount' => self::money($amount_total)),
            ),
            'totals' => $totals,
            'footer_note' => self::clean_text($data['footer_note'] ?? ('Questions? Contact ' . self::clean_text($data['support_email'] ?? get_option('admin_email')))),
            'logo_url' => self::clean_text($data['logo_url'] ?? ''),
        );
    }

    /**
     * Reusable document model for invoices.
     */
    private static function build_invoice_document(array $data) {
        $brand_name = self::clean_text($data['business_name'] ?? get_bloginfo('name'));
        $accent_hex = self::normalize_hex($data['primary_color'] ?? '#635BFF', '#635BFF');
        $secondary_hex = self::normalize_hex($data['secondary_color'] ?? '#0A2540', '#0A2540');

        $items = is_array($data['items'] ?? null) ? $data['items'] : array();
        $table_rows = array();

        foreach ($items as $item) {
            $name = self::clean_text($item['name'] ?? 'Item');
            $qty = (int) ($item['quantity'] ?? 1);
            $price = (float) ($item['price'] ?? 0);
            $line_total = $qty * $price;

            $table_rows[] = array(
                'description' => $name,
                'qty' => (string) max(1, $qty),
                'unit' => self::money($price),
                'amount' => self::money($line_total),
            );
        }

        if (empty($table_rows)) {
            $fallback_total = (float) ($data['amount_total'] ?? 0);
            $table_rows[] = array(
                'description' => 'Service Charge',
                'qty' => '1',
                'unit' => self::money($fallback_total),
                'amount' => self::money($fallback_total),
            );
        }

        $subtotal = isset($data['amount_subtotal']) ? (float) $data['amount_subtotal'] : (float) ($data['amount_total'] ?? 0);
        $tax = (float) ($data['amount_tax'] ?? 0);
        $total = (float) ($data['amount_total'] ?? 0);

        $totals = array(
            array('label' => 'Subtotal', 'amount' => self::money($subtotal), 'kind' => 'muted'),
        );

        if ($tax > 0) {
            $totals[] = array('label' => 'Tax', 'amount' => self::money($tax), 'kind' => 'muted');
        }

        $totals[] = array('label' => 'Total Due', 'amount' => self::money($total), 'kind' => 'strong');

        $created_at = !empty($data['created_at']) ? date('F j, Y', strtotime((string) $data['created_at'])) : date('F j, Y');
        $due_date = !empty($data['expires_at']) ? date('F j, Y', strtotime((string) $data['expires_at'])) : '';

        $meta_rows = array(
            array('label' => 'Invoice #', 'value' => self::clean_text($data['invoice_number'] ?? '')),
            array('label' => 'Issued', 'value' => self::clean_text($created_at)),
            array('label' => 'Status', 'value' => ucfirst(self::clean_text($data['status'] ?? 'Pending'))),
        );

        if ($due_date !== '') {
            $meta_rows[] = array('label' => 'Due', 'value' => self::clean_text($due_date));
        }

        return array(
            'title' => 'INVOICE',
            'subtitle' => self::clean_text($data['document_subtitle'] ?? 'Payment request'),
            'accent_hex' => $accent_hex,
            'secondary_hex' => $secondary_hex,
            'logo_label' => self::clean_text($data['logo_label'] ?? self::initials($brand_name)),
            'company_block_title' => 'From',
            'company_lines' => self::compact_lines(array(
                $brand_name,
                self::clean_text($data['business_address'] ?? ''),
                self::clean_text($data['business_phone'] ?? ''),
                self::clean_text($data['support_email'] ?? get_option('admin_email')),
            )),
            'customer_block_title' => 'Bill To',
            'customer_lines' => self::compact_lines(array(
                self::clean_text($data['customer_name'] ?? ''),
                self::clean_text($data['customer_email'] ?? ''),
                self::clean_text($data['customer_address'] ?? ''),
                self::clean_text($data['customer_phone'] ?? ''),
            )),
            'metadata_rows' => $meta_rows,
            'table_headers' => array('Description', 'Qty', 'Unit', 'Amount'),
            'table_rows' => $table_rows,
            'totals' => $totals,
            'footer_note' => self::clean_text($data['footer_note'] ?? ('For support contact ' . self::clean_text($data['support_email'] ?? get_option('admin_email')))),
            'logo_url' => self::clean_text($data['logo_url'] ?? ''),
        );
    }

    /**
     * Core renderer for a branded document model.
     */
    private static function render_document_pdf(array $document) {
        $ops = array();

        $accent = self::hex_to_rgb($document['accent_hex'] ?? '#635BFF');
        $secondary = self::hex_to_rgb($document['secondary_hex'] ?? '#0A2540');

        // Header background.
        self::draw_filled_rect($ops, 0, 0, self::PAGE_WIDTH, 104, $secondary);

        // Logo badge area.
        self::draw_filled_rect($ops, 40, 28, 64, 40, array(1, 1, 1));
        self::draw_text($ops, strtoupper((string) ($document['logo_label'] ?? 'LOGO')), 52, 53, 11, $accent, true);

        // Brand/logo metadata line for easy swap checks.
        if (!empty($document['logo_url'])) {
            self::draw_text($ops, 'Logo: ' . self::trim_text((string) $document['logo_url'], 72), 120, 58, 8, array(1, 1, 1), false);
        }

        self::draw_text($ops, (string) ($document['title'] ?? 'DOCUMENT'), 432, 46, 15, array(1, 1, 1), true);
        self::draw_text($ops, (string) ($document['subtitle'] ?? ''), 432, 66, 9, array(0.90, 0.92, 0.98), false);

        // Main canvas card.
        self::draw_filled_rect($ops, 24, 116, self::PAGE_WIDTH - 48, self::PAGE_HEIGHT - 152, array(1, 1, 1));

        // Company + customer blocks.
        $left_x = 40;
        $right_x = 326;
        $top = 134;

        self::draw_section_label($ops, (string) ($document['company_block_title'] ?? 'From'), $left_x, $top, $accent);
        $y_after_company = self::draw_multiline_block($ops, $document['company_lines'] ?? array(), $left_x, $top + 18, 10, array(0.15, 0.2, 0.28), 14, 36);

        self::draw_section_label($ops, (string) ($document['customer_block_title'] ?? 'Bill To'), $right_x, $top, $accent);
        $y_after_customer = self::draw_multiline_block($ops, $document['customer_lines'] ?? array(), $right_x, $top + 18, 10, array(0.15, 0.2, 0.28), 14, 36);

        $meta_top = max($y_after_company, $y_after_customer) + 8;

        // Metadata panel.
        self::draw_filled_rect($ops, 40, $meta_top, self::PAGE_WIDTH - 80, 78, array(0.97, 0.98, 1.0));
        $meta_x = 56;
        $meta_y = $meta_top + 18;
        $meta_rows = is_array($document['metadata_rows'] ?? null) ? $document['metadata_rows'] : array();
        $meta_col_width = 128;

        $meta_index = 0;
        foreach ($meta_rows as $meta) {
            $col = $meta_index % 4;
            $row = (int) floor($meta_index / 4);
            $x = $meta_x + ($col * $meta_col_width);
            $y = $meta_y + ($row * 34);
            self::draw_text($ops, strtoupper(self::clean_text($meta['label'] ?? '')), $x, $y, 7, array(0.45, 0.52, 0.62), true);
            self::draw_text($ops, self::trim_text(self::clean_text($meta['value'] ?? ''), 24), $x, $y + 11, 9, array(0.1, 0.16, 0.24), false);
            $meta_index++;
        }

        // Line items table.
        $table_top = $meta_top + 98;
        self::draw_filled_rect($ops, 40, $table_top, self::PAGE_WIDTH - 80, 30, array(0.96, 0.97, 0.99));

        $headers = is_array($document['table_headers'] ?? null) ? $document['table_headers'] : array('Description', 'Qty', 'Unit', 'Amount');
        self::draw_text($ops, strtoupper(self::clean_text($headers[0] ?? 'Description')), 52, $table_top + 19, 8, array(0.31, 0.38, 0.49), true);
        self::draw_text($ops, strtoupper(self::clean_text($headers[1] ?? 'Qty')), 360, $table_top + 19, 8, array(0.31, 0.38, 0.49), true);
        self::draw_text($ops, strtoupper(self::clean_text($headers[2] ?? 'Unit')), 422, $table_top + 19, 8, array(0.31, 0.38, 0.49), true);
        self::draw_text($ops, strtoupper(self::clean_text($headers[3] ?? 'Amount')), 494, $table_top + 19, 8, array(0.31, 0.38, 0.49), true);

        $rows = is_array($document['table_rows'] ?? null) ? $document['table_rows'] : array();
        $row_top = $table_top + 34;
        $row_height = 24;
        $max_rows = 9;

        for ($i = 0; $i < min(count($rows), $max_rows); $i++) {
            $row = $rows[$i];
            if ($i % 2 === 1) {
                self::draw_filled_rect($ops, 40, $row_top + ($i * $row_height), self::PAGE_WIDTH - 80, $row_height, array(0.99, 0.995, 1.0));
            }

            $y = $row_top + ($i * $row_height) + 15;
            self::draw_text($ops, self::trim_text(self::clean_text($row['description'] ?? ''), 54), 52, $y, 9, array(0.13, 0.17, 0.24), false);
            self::draw_text($ops, self::trim_text(self::clean_text($row['qty'] ?? ''), 8), 360, $y, 9, array(0.13, 0.17, 0.24), false);
            self::draw_text($ops, self::trim_text(self::clean_text($row['unit'] ?? ''), 12), 422, $y, 9, array(0.13, 0.17, 0.24), false);
            self::draw_text($ops, self::trim_text(self::clean_text($row['amount'] ?? ''), 14), 494, $y, 9, array(0.13, 0.17, 0.24), true);
        }

        // Totals block.
        $totals_top = $row_top + (max(1, min(count($rows), $max_rows)) * $row_height) + 18;
        self::draw_filled_rect($ops, 344, $totals_top, 228, 84, array(0.985, 0.99, 1.0));

        $totals = is_array($document['totals'] ?? null) ? $document['totals'] : array();
        $ty = $totals_top + 19;
        foreach ($totals as $total) {
            $kind = self::clean_text($total['kind'] ?? 'normal');
            $label_color = $kind === 'muted' ? array(0.39, 0.45, 0.55) : array(0.1, 0.16, 0.24);
            $value_color = $kind === 'strong' ? $accent : array(0.1, 0.16, 0.24);
            $value_bold = ($kind === 'strong');
            $size = $kind === 'strong' ? 11 : 9;

            self::draw_text($ops, self::trim_text(self::clean_text($total['label'] ?? ''), 24), 356, $ty, $size, $label_color, false);
            self::draw_text($ops, self::trim_text(self::clean_text($total['amount'] ?? ''), 16), 560, $ty, $size, $value_color, $value_bold);
            $ty += ($kind === 'strong' ? 18 : 14);
        }

        // Footer with visual divider.
        $footer_y = min(self::PAGE_HEIGHT - 28, $totals_top + 110);
        self::draw_line($ops, 40, $footer_y, self::PAGE_WIDTH - 40, $footer_y, 0.8, array(0.85, 0.9, 0.96));
        self::draw_text($ops, self::trim_text(self::clean_text($document['footer_note'] ?? ''), 98), 40, $footer_y + 16, 8, array(0.38, 0.45, 0.56), false);
        self::draw_text($ops, self::clean_text('Generated ' . date('F j, Y g:i A')), 430, $footer_y + 16, 8, array(0.5, 0.56, 0.65), false);

        return self::build_pdf_binary($ops);
    }

    private static function draw_section_label(array &$ops, $label, $x, $top, array $color_rgb) {
        self::draw_text($ops, strtoupper(self::clean_text($label)), $x, $top, 8, $color_rgb, true);
    }

    private static function draw_multiline_block(array &$ops, array $lines, $x, $top, $font_size, array $color_rgb, $line_step, $max_lines) {
        $index = 0;
        foreach ($lines as $line) {
            if ($index >= $max_lines) {
                break;
            }
            self::draw_text($ops, self::trim_text(self::clean_text($line), 46), $x, $top + ($index * $line_step), $font_size, $color_rgb, $index === 0);
            $index++;
        }
        return $top + max(1, $index) * $line_step;
    }

    private static function draw_filled_rect(array &$ops, $x, $top, $width, $height, array $fill_rgb) {
        $y_bottom = self::PAGE_HEIGHT - $top - $height;
        $ops[] = self::fmt_color($fill_rgb, 'rg');
        $ops[] = self::fmt_num($x) . ' ' . self::fmt_num($y_bottom) . ' ' . self::fmt_num($width) . ' ' . self::fmt_num($height) . ' re f';
    }

    private static function draw_line(array &$ops, $x1, $top1, $x2, $top2, $width, array $stroke_rgb) {
        $y1 = self::PAGE_HEIGHT - $top1;
        $y2 = self::PAGE_HEIGHT - $top2;
        $ops[] = self::fmt_color($stroke_rgb, 'RG');
        $ops[] = self::fmt_num($width) . ' w';
        $ops[] = self::fmt_num($x1) . ' ' . self::fmt_num($y1) . ' m';
        $ops[] = self::fmt_num($x2) . ' ' . self::fmt_num($y2) . ' l S';
    }

    private static function draw_text(array &$ops, $text, $x, $top, $font_size, array $color_rgb, $bold = false) {
        $y = self::PAGE_HEIGHT - $top;
        $font = $bold ? '/F2' : '/F1';
        $ops[] = 'BT';
        $ops[] = self::fmt_color($color_rgb, 'rg');
        $ops[] = $font . ' ' . self::fmt_num($font_size) . ' Tf';
        $ops[] = self::fmt_num($x) . ' ' . self::fmt_num($y) . ' Td';
        $ops[] = '(' . self::pdf_escape($text) . ') Tj';
        $ops[] = 'ET';
    }

    private static function build_pdf_binary(array $ops) {
        $stream = implode("\n", $ops);

        $objects = array();
        $objects[] = "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
        $objects[] = "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
        $objects[] = "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " . self::PAGE_WIDTH . " " . self::PAGE_HEIGHT . "] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>\nendobj\n";
        $objects[] = "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
        $objects[] = "5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n";
        $objects[] = "6 0 obj\n<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream\nendobj\n";

        $pdf = "%PDF-1.4\n";
        $offsets = array(0);

        foreach ($objects as $object) {
            $offsets[] = strlen($pdf);
            $pdf .= $object;
        }

        $xref_offset = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";

        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\n";
        $pdf .= "startxref\n" . $xref_offset . "\n%%EOF";

        return $pdf;
    }

    private static function compact_lines(array $lines) {
        $out = array();
        foreach ($lines as $line) {
            $line = self::clean_text($line);
            if ($line !== '') {
                $out[] = $line;
            }
        }
        return $out;
    }

    private static function initials($name) {
        $name = trim((string) $name);
        if ($name === '') {
            return 'LOGO';
        }

        $parts = preg_split('/\s+/', $name);
        $letters = '';
        foreach ($parts as $part) {
            if ($part !== '') {
                $letters .= strtoupper(substr($part, 0, 1));
            }
            if (strlen($letters) >= 3) {
                break;
            }
        }

        return $letters !== '' ? $letters : 'LOGO';
    }

    private static function money($value) {
        return '$' . number_format((float) $value, 2);
    }

    private static function normalize_hex($hex, $fallback) {
        $hex = trim((string) $hex);
        if ($hex === '') {
            return $fallback;
        }

        if (!preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $hex)) {
            return $fallback;
        }

        if (strlen($hex) === 4) {
            return '#' . str_repeat($hex[1], 2) . str_repeat($hex[2], 2) . str_repeat($hex[3], 2);
        }

        return strtoupper($hex);
    }

    private static function hex_to_rgb($hex) {
        $hex = self::normalize_hex($hex, '#000000');
        $hex = ltrim($hex, '#');

        return array(
            hexdec(substr($hex, 0, 2)) / 255,
            hexdec(substr($hex, 2, 2)) / 255,
            hexdec(substr($hex, 4, 2)) / 255,
        );
    }

    private static function trim_text($text, $max_len) {
        $text = self::clean_text($text);
        if (strlen($text) <= $max_len) {
            return $text;
        }
        return substr($text, 0, max(0, $max_len - 3)) . '...';
    }

    private static function clean_text($text) {
        $text = sanitize_text_field((string) $text);
        $text = preg_replace('/\s+/', ' ', $text);
        return trim((string) $text);
    }

    private static function pdf_escape($text) {
        $text = str_replace('\\', '\\\\', (string) $text);
        $text = str_replace('(', '\\(', $text);
        $text = str_replace(')', '\\)', $text);
        return preg_replace('/[^\x20-\x7E]/', '', $text);
    }

    private static function fmt_color(array $rgb, $operator) {
        $r = self::fmt_num($rgb[0] ?? 0);
        $g = self::fmt_num($rgb[1] ?? 0);
        $b = self::fmt_num($rgb[2] ?? 0);
        return $r . ' ' . $g . ' ' . $b . ' ' . $operator;
    }

    private static function fmt_num($num) {
        return rtrim(rtrim(number_format((float) $num, 3, '.', ''), '0'), '.');
    }
}
