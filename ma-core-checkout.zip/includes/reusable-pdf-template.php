<?php
/**
 * Reusable branded PDF template for transactional documents.
 *
 * This file is intentionally generic so it can be copied into another plugin
 * and reused by changing the document model values (brand, title, items, totals).
 */

if (!defined('ABSPATH')) {
    exit;
}

class SEC_Reusable_PDF_Template {
    private const PAGE_WIDTH = 612.0;
    private const PAGE_HEIGHT = 792.0;

    /**
     * Build and write a branded payment receipt PDF.
     */
    public static function create_payment_receipt_pdf_file(array $data, $name_hint = '') {
        $document = self::build_receipt_document($data);
        return self::write_document_pdf_file($document, $name_hint ?: 'payment-receipt-' . md5(($data['session_id'] ?? '') . ($data['customer_email'] ?? '')));
    }

    /**
     * Build and write a branded invoice PDF.
     */
    public static function create_invoice_pdf_file(array $data, $name_hint = '') {
        $document = self::build_invoice_document($data);
        return self::write_document_pdf_file($document, $name_hint ?: 'invoice-' . md5(($data['invoice_number'] ?? '') . ($data['customer_email'] ?? '')));
    }

    /**
     * Shared cleanup helper for generated temp files.
     */
    public static function cleanup_temp_files($paths) {
        if (!is_array($paths)) {
            return;
        }

        foreach ($paths as $path) {
            if (!empty($path) && is_string($path) && file_exists($path)) {
                @unlink($path);
            }
        }
    }

    /**
     * Generic write helper for document models.
     */
    public static function write_document_pdf_file(array $document, $name_hint) {
        $upload_dir = wp_upload_dir();
        $dir = trailingslashit($upload_dir['basedir']) . 'sec-pdf-documents/';
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }

        $filename = sanitize_file_name((string) $name_hint) . '.pdf';
        $path = $dir . $filename;
        $pdf = self::render_document_pdf($document);

        if ($pdf === '') {
            return '';
        }

        $written = file_put_contents($path, $pdf);
        if ($written === false) {
            return '';
        }

        return $path;
    }

    /**
     * Reusable document model for receipts.
     */
    private static function build_receipt_document(array $data) {
        $brand_name = self::clean_text($data['brand_name'] ?? get_bloginfo('name'));
        $accent_hex = self::normalize_hex($data['accent_color'] ?? '#635BFF', '#635BFF');
        $secondary_hex = self::normalize_hex($data['secondary_color'] ?? '#0A2540', '#0A2540');

        $service_name = self::clean_text($data['service_name'] ?? 'Website Setup Service');
        $amount_total = (float) ($data['amount_total'] ?? $data['amount'] ?? 0);
        $amount_subtotal = isset($data['amount_subtotal']) ? (float) $data['amount_subtotal'] : $amount_total;

        $totals = array(
            array('label' => 'Subtotal', 'amount' => self::money($amount_subtotal), 'kind' => 'muted'),
        );

        if (!empty($data['amount_discount']) && (float) $data['amount_discount'] > 0) {
            $totals[] = array('label' => 'Discount', 'amount' => '- ' . self::money((float) $data['amount_discount']), 'kind' => 'muted');
        }

        $totals[] = array('label' => 'Total Paid', 'amount' => self::money($amount_total), 'kind' => 'strong');

        $meta_rows = array(
            array('label' => 'Receipt #', 'value' => self::clean_text($data['receipt_number'] ?? substr((string) ($data['session_id'] ?? ''), -12))),
            array('label' => 'Date', 'value' => self::clean_text($data['date'] ?? date('F j, Y g:i A'))),
            array('label' => 'Status', 'value' => self::clean_text($data['status'] ?? 'Paid')),
            array('label' => 'Payment Method', 'value' => self::clean_text($data['payment_method'] ?? 'Card')),
        );

        if (!empty($data['session_id'])) {
            $meta_rows[] = array('label' => 'Session ID', 'value' => self::clean_text((string) $data['session_id']));
        }

        return array(
            'title' => 'PAYMENT RECEIPT',
            'subtitle' => self::clean_text($data['document_subtitle'] ?? 'Transaction confirmation'),
            'header_brand_name' => $brand_name,
            'accent_hex' => $accent_hex,
            'secondary_hex' => $secondary_hex,
            'logo_label' => self::clean_text($data['logo_label'] ?? self::initials($brand_name)),
            'company_block_title' => 'From',
            'company_lines' => self::compact_lines(array(
                $brand_name,
                self::clean_text($data['business_address'] ?? ''),
                self::clean_text($data['business_phone'] ?? ''),
                self::clean_text($data['support_email'] ?? get_option('admin_email')),
            )),
            'customer_block_title' => 'Billed To',
            'customer_lines' => self::compact_lines(array(
                self::clean_text($data['customer_name'] ?? ''),
                self::clean_text($data['customer_email'] ?? ''),
                self::clean_text($data['customer_address'] ?? ''),
            )),
            'metadata_rows' => $meta_rows,
            'table_headers' => array('Description', 'Qty', 'Unit', 'Amount'),
            'table_rows' => array(
                array('description' => $service_name, 'qty' => '1', 'unit' => self::money($amount_total), 'amount' => self::money($amount_total)),
            ),
            'totals' => $totals,
            'footer_note' => self::clean_text($data['footer_note'] ?? ('Questions? Contact ' . self::clean_text($data['support_email'] ?? 'billing@marketingaid.org'))),
            'support_email' => self::clean_text($data['support_email'] ?? 'billing@marketingaid.org'),
            'logo_url' => self::clean_text($data['logo_url'] ?? ''),
        );
    }

    /**
     * Reusable document model for invoices.
     */
    private static function build_invoice_document(array $data) {
        $brand_name = self::clean_text($data['business_name'] ?? get_bloginfo('name'));
        $accent_hex = self::normalize_hex($data['primary_color'] ?? '#635BFF', '#635BFF');
        $secondary_hex = self::normalize_hex($data['secondary_color'] ?? '#0A2540', '#0A2540');

        $items = is_array($data['items'] ?? null) ? $data['items'] : array();
        $table_rows = array();

        foreach ($items as $item) {
            $name = self::clean_text($item['name'] ?? 'Item');
            $qty = (int) ($item['quantity'] ?? 1);
            $price = (float) ($item['price'] ?? 0);
            $line_total = $qty * $price;

            $table_rows[] = array(
                'description' => $name,
                'qty' => (string) max(1, $qty),
                'unit' => self::money($price),
                'amount' => self::money($line_total),
            );
        }

        if (empty($table_rows)) {
            $fallback_total = (float) ($data['amount_total'] ?? 0);
            $table_rows[] = array(
                'description' => 'Service Charge',
                'qty' => '1',
                'unit' => self::money($fallback_total),
                'amount' => self::money($fallback_total),
            );
        }

        $subtotal = isset($data['amount_subtotal']) ? (float) $data['amount_subtotal'] : (float) ($data['amount_total'] ?? 0);
        $tax = (float) ($data['amount_tax'] ?? 0);
        $total = (float) ($data['amount_total'] ?? 0);

        $totals = array(
            array('label' => 'Subtotal', 'amount' => self::money($subtotal), 'kind' => 'muted'),
        );

        if ($tax > 0) {
            $totals[] = array('label' => 'Tax', 'amount' => self::money($tax), 'kind' => 'muted');
        }

        $totals[] = array('label' => 'Total Due', 'amount' => self::money($total), 'kind' => 'strong');

        $created_at = !empty($data['created_at']) ? date('F j, Y', strtotime((string) $data['created_at'])) : date('F j, Y');
        $due_date = !empty($data['expires_at']) ? date('F j, Y', strtotime((string) $data['expires_at'])) : '';

        $meta_rows = array(
            array('label' => 'Invoice #', 'value' => self::clean_text($data['invoice_number'] ?? '')),
            array('label' => 'Issued', 'value' => self::clean_text($created_at)),
            array('label' => 'Status', 'value' => ucfirst(self::clean_text($data['status'] ?? 'Pending'))),
        );

        if ($due_date !== '') {
            $meta_rows[] = array('label' => 'Due', 'value' => self::clean_text($due_date));
        }

        return array(
            'title' => 'INVOICE',
            'subtitle' => self::clean_text($data['document_subtitle'] ?? 'Payment request'),
            'header_brand_name' => $brand_name,
            'accent_hex' => $accent_hex,
            'secondary_hex' => $secondary_hex,
            'logo_label' => self::clean_text($data['logo_label'] ?? self::initials($brand_name)),
            'company_block_title' => 'From',
            'company_lines' => self::compact_lines(array(
                $brand_name,
                self::clean_text($data['business_address'] ?? ''),
                self::clean_text($data['business_phone'] ?? ''),
                self::clean_text($data['support_email'] ?? get_option('admin_email')),
            )),
            'customer_block_title' => 'Bill To',
            'customer_lines' => self::compact_lines(array(
                self::clean_text($data['customer_name'] ?? ''),
                self::clean_text($data['customer_email'] ?? ''),
                self::clean_text($data['customer_address'] ?? ''),
                self::clean_text($data['customer_phone'] ?? ''),
            )),
            'metadata_rows' => $meta_rows,
            'table_headers' => array('Description', 'Qty', 'Unit', 'Amount'),
            'table_rows' => $table_rows,
            'totals' => $totals,
            'footer_note' => self::clean_text($data['footer_note'] ?? ('For support contact ' . self::clean_text($data['support_email'] ?? 'billing@marketingaid.org'))),
            'support_email' => self::clean_text($data['support_email'] ?? 'billing@marketingaid.org'),
            'logo_url' => self::clean_text($data['logo_url'] ?? ''),
        );
    }

    /**
     * Core renderer for a branded document model.
     */
    private static function render_document_pdf(array $document) {
        $ops = array();

        $accent = self::hex_to_rgb($document['accent_hex'] ?? '#635BFF');
        $secondary = self::hex_to_rgb($document['secondary_hex'] ?? '#0A2540');
        $logo_image = self::load_logo_image_object((string) ($document['logo_url'] ?? ''));

        // White page + subtle top brand line (Stripe-like minimal style).
        self::draw_filled_rect($ops, 0, 0, self::PAGE_WIDTH, self::PAGE_HEIGHT, array(1, 1, 1));
        self::draw_filled_rect($ops, 0, 0, self::PAGE_WIDTH, 4, $accent);

        // Header: title left, logo right.
        self::draw_text($ops, ucwords(strtolower((string) ($document['title'] ?? 'Document'))), 40, 52, 21, array(0.11, 0.12, 0.14), true);
        self::draw_text($ops, (string) ($document['subtitle'] ?? ''), 40, 72, 9, array(0.40, 0.43, 0.48), false);

        if (!empty($logo_image)) {
            self::draw_image($ops, 434, 20, 138, 46, $logo_image['width'], $logo_image['height']);
        } else {
            self::draw_text_right($ops, strtoupper((string) ($document['logo_label'] ?? 'LOGO')), 572, 50, 17, array(0.11, 0.12, 0.14), true);
        }

        self::draw_line($ops, 40, 92, self::PAGE_WIDTH - 40, 92, 0.8, array(0.86, 0.88, 0.92));

        // Company + customer blocks.
        $left_x = 40;
        $right_x = 326;
        $top = 114;

        self::draw_section_label($ops, (string) ($document['company_block_title'] ?? 'From'), $left_x, $top, array(0.30, 0.33, 0.37));
        $y_after_company = self::draw_multiline_block($ops, $document['company_lines'] ?? array(), $left_x, $top + 18, 10, array(0.15, 0.2, 0.28), 14, 36);

        self::draw_section_label($ops, (string) ($document['customer_block_title'] ?? 'Bill To'), $right_x, $top, array(0.30, 0.33, 0.37));
        $y_after_customer = self::draw_multiline_block($ops, $document['customer_lines'] ?? array(), $right_x, $top + 18, 10, array(0.15, 0.2, 0.28), 14, 36);

        $meta_top = max($y_after_company, $y_after_customer) + 8;

        // Metadata panel.
        self::draw_filled_rect($ops, 40, $meta_top, self::PAGE_WIDTH - 80, 78, array(1, 1, 1));
        self::draw_line($ops, 40, $meta_top, self::PAGE_WIDTH - 40, $meta_top, 0.7, array(0.86, 0.88, 0.92));
        self::draw_line($ops, 40, $meta_top + 78, self::PAGE_WIDTH - 40, $meta_top + 78, 0.7, array(0.86, 0.88, 0.92));
        $meta_x = 56;
        $meta_y = $meta_top + 18;
        $meta_rows = is_array($document['metadata_rows'] ?? null) ? $document['metadata_rows'] : array();
        $meta_col_width = 128;

        $meta_index = 0;
        foreach ($meta_rows as $meta) {
            $col = $meta_index % 4;
            $row = (int) floor($meta_index / 4);
            $x = $meta_x + ($col * $meta_col_width);
            $y = $meta_y + ($row * 34);
            self::draw_text($ops, strtoupper(self::clean_text($meta['label'] ?? '')), $x, $y, 7, array(0.44, 0.47, 0.52), true);
            self::draw_text($ops, self::trim_text(self::clean_text($meta['value'] ?? ''), 24), $x, $y + 11, 9, array(0.1, 0.16, 0.24), false);
            $meta_index++;
        }

        // Line items table.
        $table_top = $meta_top + 98;
        self::draw_line($ops, 40, $table_top, self::PAGE_WIDTH - 40, $table_top, 0.8, array(0.2, 0.22, 0.26));
        self::draw_filled_rect($ops, 40, $table_top + 1, self::PAGE_WIDTH - 80, 24, array(1, 1, 1));

        $headers = is_array($document['table_headers'] ?? null) ? $document['table_headers'] : array('Description', 'Qty', 'Unit', 'Amount');
        self::draw_text($ops, self::clean_text($headers[0] ?? 'Description'), 52, $table_top + 18, 8, array(0.22, 0.23, 0.27), false);
        self::draw_text($ops, self::clean_text($headers[1] ?? 'Qty'), 360, $table_top + 18, 8, array(0.22, 0.23, 0.27), false);
        self::draw_text($ops, self::clean_text($headers[2] ?? 'Unit'), 422, $table_top + 18, 8, array(0.22, 0.23, 0.27), false);
        self::draw_text_right($ops, self::clean_text($headers[3] ?? 'Amount'), 560, $table_top + 18, 8, array(0.22, 0.23, 0.27), false);

        $rows = is_array($document['table_rows'] ?? null) ? $document['table_rows'] : array();
        $row_top = $table_top + 34;
        $row_height = 24;
        $max_rows = 9;

        for ($i = 0; $i < min(count($rows), $max_rows); $i++) {
            $row = $rows[$i];
            $y = $row_top + ($i * $row_height) + 15;
            self::draw_text($ops, self::trim_text(self::clean_text($row['description'] ?? ''), 54), 52, $y, 9, array(0.13, 0.17, 0.24), false);
            self::draw_text($ops, self::trim_text(self::clean_text($row['qty'] ?? ''), 8), 360, $y, 9, array(0.13, 0.17, 0.24), false);
            self::draw_text($ops, self::trim_text(self::clean_text($row['unit'] ?? ''), 12), 422, $y, 9, array(0.13, 0.17, 0.24), false);
            self::draw_text_right($ops, self::trim_text(self::clean_text($row['amount'] ?? ''), 14), 560, $y, 9, array(0.13, 0.17, 0.24), true);
            self::draw_line($ops, 40, $row_top + (($i + 1) * $row_height), self::PAGE_WIDTH - 40, $row_top + (($i + 1) * $row_height), 0.45, array(0.9, 0.91, 0.93));
        }

        // Totals block.
        $totals_top = $row_top + (max(1, min(count($rows), $max_rows)) * $row_height) + 18;
        self::draw_filled_rect($ops, 344, $totals_top, 228, 84, array(1, 1, 1));
        self::draw_line($ops, 344, $totals_top, 572, $totals_top, 0.7, array(0.86, 0.88, 0.92));
        self::draw_line($ops, 344, $totals_top + 84, 572, $totals_top + 84, 0.7, array(0.86, 0.88, 0.92));

        $totals = is_array($document['totals'] ?? null) ? $document['totals'] : array();
        $ty = $totals_top + 19;
        foreach ($totals as $total) {
            $kind = self::clean_text($total['kind'] ?? 'normal');
            $label_color = $kind === 'muted' ? array(0.39, 0.45, 0.55) : array(0.1, 0.16, 0.24);
            $value_color = $kind === 'strong' ? array(0.11, 0.12, 0.14) : array(0.1, 0.16, 0.24);
            $value_bold = ($kind === 'strong');
            $size = $kind === 'strong' ? 11 : 9;

            self::draw_text($ops, self::trim_text(self::clean_text($total['label'] ?? ''), 24), 356, $ty, $size, $label_color, false);
            self::draw_text_right($ops, self::trim_text(self::clean_text($total['amount'] ?? ''), 16), 560, $ty, $size, $value_color, $value_bold);
            $ty += ($kind === 'strong' ? 18 : 14);
        }

        // Footer with visual divider.
        $footer_y = min(self::PAGE_HEIGHT - 28, $totals_top + 110);
        self::draw_line($ops, 40, $footer_y, self::PAGE_WIDTH - 40, $footer_y, 0.8, array(0.86, 0.88, 0.92));
        self::draw_text($ops, self::trim_text(self::clean_text($document['footer_note'] ?? ''), 98), 40, $footer_y + 16, 8, array(0.38, 0.45, 0.56), false);
        self::draw_text($ops, self::clean_text('Generated ' . date('F j, Y g:i A')), 430, $footer_y + 16, 8, array(0.5, 0.56, 0.65), false);

        return self::build_pdf_binary($ops, $logo_image['object'] ?? '');
    }

    private static function draw_section_label(array &$ops, $label, $x, $top, array $color_rgb) {
        self::draw_text($ops, strtoupper(self::clean_text($label)), $x, $top, 8, $color_rgb, true);
    }

    private static function draw_multiline_block(array &$ops, array $lines, $x, $top, $font_size, array $color_rgb, $line_step, $max_lines) {
        $index = 0;
        foreach ($lines as $line) {
            if ($index >= $max_lines) {
                break;
            }
            self::draw_text($ops, self::trim_text(self::clean_text($line), 46), $x, $top + ($index * $line_step), $font_size, $color_rgb, $index === 0);
            $index++;
        }
        return $top + max(1, $index) * $line_step;
    }

    private static function draw_filled_rect(array &$ops, $x, $top, $width, $height, array $fill_rgb) {
        $y_bottom = self::PAGE_HEIGHT - $top - $height;
        $ops[] = self::fmt_color($fill_rgb, 'rg');
        $ops[] = self::fmt_num($x) . ' ' . self::fmt_num($y_bottom) . ' ' . self::fmt_num($width) . ' ' . self::fmt_num($height) . ' re f';
    }

    private static function draw_line(array &$ops, $x1, $top1, $x2, $top2, $width, array $stroke_rgb) {
        $y1 = self::PAGE_HEIGHT - $top1;
        $y2 = self::PAGE_HEIGHT - $top2;
        $ops[] = self::fmt_color($stroke_rgb, 'RG');
        $ops[] = self::fmt_num($width) . ' w';
        $ops[] = self::fmt_num($x1) . ' ' . self::fmt_num($y1) . ' m';
        $ops[] = self::fmt_num($x2) . ' ' . self::fmt_num($y2) . ' l S';
    }

    private static function draw_text(array &$ops, $text, $x, $top, $font_size, array $color_rgb, $bold = false) {
        $y = self::PAGE_HEIGHT - $top;
        $font = $bold ? '/F2' : '/F1';
        $ops[] = 'BT';
        $ops[] = self::fmt_color($color_rgb, 'rg');
        $ops[] = $font . ' ' . self::fmt_num($font_size) . ' Tf';
        $ops[] = self::fmt_num($x) . ' ' . self::fmt_num($y) . ' Td';
        $ops[] = '(' . self::pdf_escape($text) . ') Tj';
        $ops[] = 'ET';
    }

    private static function draw_text_right(array &$ops, $text, $right_x, $top, $font_size, array $color_rgb, $bold = false) {
        $x = max(0, (float) $right_x - self::text_width_estimate((string) $text, (float) $font_size));
        self::draw_text($ops, $text, $x, $top, $font_size, $color_rgb, $bold);
    }

    private static function draw_image(array &$ops, $x, $top, $max_width, $max_height, $img_width, $img_height) {
        $img_width = max(1, (float) $img_width);
        $img_height = max(1, (float) $img_height);
        $ratio = min($max_width / $img_width, $max_height / $img_height, 1.0);
        $draw_w = $img_width * $ratio;
        $draw_h = $img_height * $ratio;
        $draw_x = $x + (($max_width - $draw_w) / 2);
        $draw_y_bottom = self::PAGE_HEIGHT - $top - $draw_h;

        $ops[] = 'q';
        $ops[] = self::fmt_num($draw_w) . ' 0 0 ' . self::fmt_num($draw_h) . ' ' . self::fmt_num($draw_x) . ' ' . self::fmt_num($draw_y_bottom) . ' cm';
        $ops[] = '/Im1 Do';
        $ops[] = 'Q';
    }

    private static function build_pdf_binary(array $ops, $image_object = '') {
        $stream = implode("\n", $ops);

        $objects = array();
        $objects[] = "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
        $objects[] = "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
        $has_image = !empty($image_object);
        $resource_xobject = $has_image ? " /XObject << /Im1 6 0 R >>" : "";
        $content_ref = $has_image ? "7 0 R" : "6 0 R";
        $objects[] = "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " . self::PAGE_WIDTH . " " . self::PAGE_HEIGHT . "] /Resources << /Font << /F1 4 0 R /F2 5 0 R >>" . $resource_xobject . " >> /Contents " . $content_ref . " >>\nendobj\n";
        $objects[] = "4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
        $objects[] = "5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>\nendobj\n";
        if ($has_image) {
            $objects[] = $image_object;
        }
        $objects[] = ($has_image ? "7" : "6") . " 0 obj\n<< /Length " . strlen($stream) . " >>\nstream\n" . $stream . "\nendstream\nendobj\n";

        $pdf = "%PDF-1.4\n";
        $offsets = array(0);

        foreach ($objects as $object) {
            $offsets[] = strlen($pdf);
            $pdf .= $object;
        }

        $xref_offset = strlen($pdf);
        $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";

        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root 1 0 R >>\n";
        $pdf .= "startxref\n" . $xref_offset . "\n%%EOF";

        return $pdf;
    }

    private static function load_logo_image_object($logo_url) {
        $logo_url = esc_url_raw(trim((string) $logo_url));
        if ($logo_url === '') {
            return array();
        }

        $image_bytes = '';
        if (function_exists('wp_remote_get')) {
            $response = wp_remote_get($logo_url, array('timeout' => 8));
            if (!is_wp_error($response)) {
                $image_bytes = (string) wp_remote_retrieve_body($response);
            }
        } elseif (function_exists('file_get_contents')) {
            $image_bytes = (string) @file_get_contents($logo_url);
        }

        if ($image_bytes === '') {
            return array();
        }

        $meta = @getimagesizefromstring($image_bytes);
        if (!$meta || empty($meta[0]) || empty($meta[1])) {
            return array();
        }

        $width = (int) $meta[0];
        $height = (int) $meta[1];
        $mime = strtolower((string) ($meta['mime'] ?? ''));

        if ($mime === 'image/jpeg' || $mime === 'image/jpg') {
            $object = "6 0 obj\n<< /Type /XObject /Subtype /Image /Width " . $width . " /Height " . $height . " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length " . strlen($image_bytes) . " >>\nstream\n" . $image_bytes . "\nendstream\nendobj\n";
            return array('object' => $object, 'width' => $width, 'height' => $height);
        }

        if ($mime === 'image/svg+xml' && class_exists('Imagick')) {
            try {
                $img = new \Imagick();
                $img->setBackgroundColor(new \ImagickPixel('white'));
                $img->readImageBlob($image_bytes);
                $img->setImageFormat('png');
                $image_bytes = $img->getImageBlob();
                $img->clear();
                $img->destroy();
                $meta = @getimagesizefromstring($image_bytes);
                if ($meta && !empty($meta[0]) && !empty($meta[1])) {
                    $width = (int) $meta[0];
                    $height = (int) $meta[1];
                    $mime = 'image/png';
                }
            } catch (\Exception $e) {
                return array();
            }
        }

        if (function_exists('imagecreatefromstring')) {
            $im = @imagecreatefromstring($image_bytes);
            if (!$im) {
                return array();
            }

            $raw = '';
            for ($y = 0; $y < $height; $y++) {
                for ($x = 0; $x < $width; $x++) {
                    $rgba = imagecolorsforindex($im, imagecolorat($im, $x, $y));
                    $alpha = 1.0 - ((float) $rgba['alpha'] / 127.0);
                    $r = (int) round(($rgba['red'] * $alpha) + (255 * (1.0 - $alpha)));
                    $g = (int) round(($rgba['green'] * $alpha) + (255 * (1.0 - $alpha)));
                    $b = (int) round(($rgba['blue'] * $alpha) + (255 * (1.0 - $alpha)));
                    $raw .= chr($r) . chr($g) . chr($b);
                }
            }
            imagedestroy($im);

            $compressed = gzcompress($raw, 6);
            if ($compressed === false) {
                return array();
            }

            $object = "6 0 obj\n<< /Type /XObject /Subtype /Image /Width " . $width . " /Height " . $height . " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length " . strlen($compressed) . " >>\nstream\n" . $compressed . "\nendstream\nendobj\n";
            return array('object' => $object, 'width' => $width, 'height' => $height);
        }

        return array();
    }

    private static function compact_lines(array $lines) {
        $out = array();
        foreach ($lines as $line) {
            $line = self::clean_text($line);
            if ($line !== '') {
                $out[] = $line;
            }
        }
        return $out;
    }

    private static function initials($name) {
        $name = trim((string) $name);
        if ($name === '') {
            return 'LOGO';
        }

        $parts = preg_split('/\s+/', $name);
        $letters = '';
        foreach ($parts as $part) {
            if ($part !== '') {
                $letters .= strtoupper(substr($part, 0, 1));
            }
            if (strlen($letters) >= 3) {
                break;
            }
        }

        return $letters !== '' ? $letters : 'LOGO';
    }

    private static function money($value) {
        return '$' . number_format((float) $value, 2);
    }

    private static function normalize_hex($hex, $fallback) {
        $hex = trim((string) $hex);
        if ($hex === '') {
            return $fallback;
        }

        if (!preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $hex)) {
            return $fallback;
        }

        if (strlen($hex) === 4) {
            return '#' . str_repeat($hex[1], 2) . str_repeat($hex[2], 2) . str_repeat($hex[3], 2);
        }

        return strtoupper($hex);
    }

    private static function hex_to_rgb($hex) {
        $hex = self::normalize_hex($hex, '#000000');
        $hex = ltrim($hex, '#');

        return array(
            hexdec(substr($hex, 0, 2)) / 255,
            hexdec(substr($hex, 2, 2)) / 255,
            hexdec(substr($hex, 4, 2)) / 255,
        );
    }

    private static function trim_text($text, $max_len) {
        $text = self::clean_text($text);
        if (strlen($text) <= $max_len) {
            return $text;
        }
        return substr($text, 0, max(0, $max_len - 3)) . '...';
    }

    private static function clean_text($text) {
        $text = sanitize_text_field((string) $text);
        $text = preg_replace('/\s+/', ' ', $text);
        return trim((string) $text);
    }

    private static function pdf_escape($text) {
        $text = str_replace('\\', '\\\\', (string) $text);
        $text = str_replace('(', '\\(', $text);
        $text = str_replace(')', '\\)', $text);
        return preg_replace('/[^\x20-\x7E]/', '', $text);
    }

    private static function fmt_color(array $rgb, $operator) {
        $r = self::fmt_num($rgb[0] ?? 0);
        $g = self::fmt_num($rgb[1] ?? 0);
        $b = self::fmt_num($rgb[2] ?? 0);
        return $r . ' ' . $g . ' ' . $b . ' ' . $operator;
    }

    private static function fmt_num($num) {
        return rtrim(rtrim(number_format((float) $num, 3, '.', ''), '0'), '.');
    }

    private static function text_width_estimate($text, $font_size) {
        $chars = strlen((string) $text);
        return $chars * ((float) $font_size * 0.52);
    }
}
