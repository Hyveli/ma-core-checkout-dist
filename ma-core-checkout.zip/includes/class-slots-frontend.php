<?php
/**
 * Activation Slots Frontend Display
 *
 * Provides public-facing slot status and waitlist signup
 */

if (!defined('ABSPATH')) exit;

class SEC_Slots_Frontend {

    /**
     * Initialize frontend
     */
    public static function init() {
        // Register shortcode
        add_shortcode('activation_slots', array(__CLASS__, 'render_shortcode'));

        // Enqueue frontend assets
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_assets'));
    }

    /**
     * Enqueue frontend assets
     */
    public static function enqueue_assets() {
        // Only enqueue if shortcode is present on the page
        global $post;
        if (!is_a($post, 'WP_Post') || !has_shortcode($post->post_content, 'activation_slots')) {
            return;
        }

        wp_enqueue_style(
            'sec-slots-frontend',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/slots-frontend.css',
            array(),
            '1.0.0'
        );

        wp_enqueue_script(
            'sec-slots-frontend',
            plugin_dir_url(dirname(__FILE__)) . 'assets/js/slots-frontend.js',
            array('jquery'),
            '1.0.0',
            true
        );

        wp_localize_script('sec-slots-frontend', 'secSlotsFrontend', array(
            'rest_url' => rest_url('sec/v1/'),
            'nonce' => wp_create_nonce('sec_waitlist_nonce')
        ));
    }

    /**
     * Render shortcode
     */
    public static function render_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => 'Platform Activation Slots',
            'show_timer' => 'yes',
            'checkout_url' => home_url('/#activate')
        ), $atts);

        ob_start();
        ?>
        <div class="sec-slots-widget" id="sec-slots-widget">
            <div class="sec-slots-loading">
                <div class="sec-spinner"></div>
                <p>Loading slot status...</p>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Initialize
SEC_Slots_Frontend::init();
