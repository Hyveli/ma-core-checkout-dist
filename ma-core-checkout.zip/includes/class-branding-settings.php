<?php
/**
 * Branding Settings - Logo and Email Templates Admin Page
 */

if (!defined('ABSPATH')) {
    exit;
}

class SEC_Branding_Settings {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'add_settings_page'], 20);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_scripts']);
        add_action('wp_ajax_sec_upload_logo', [__CLASS__, 'ajax_upload_logo']);
    }

    public static function add_settings_page() {
        add_submenu_page(
            'stripe-embedded-checkout',
            'Branding Settings',
            'Branding',
            'manage_options',
            'sec-branding-settings',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {
        // Logo settings
        register_setting('sec_branding_settings', 'sec_logo_url');

        // Email templates
        register_setting('sec_branding_settings', 'sec_email_from_name', [
            'default' => get_bloginfo('name')
        ]);
        register_setting('sec_branding_settings', 'sec_email_from_email', [
            'default' => get_option('admin_email')
        ]);

        // Payment receipt email
        register_setting('sec_branding_settings', 'sec_receipt_email_subject', [
            'default' => 'Payment Receipt - {{business_name}}'
        ]);
        register_setting('sec_branding_settings', 'sec_receipt_email_body', [
            'default' => self::get_default_receipt_template()
        ]);

        // Survey invitation email
        register_setting('sec_branding_settings', 'sec_survey_email_subject', [
            'default' => 'Complete Your Website Launch Survey'
        ]);
        register_setting('sec_branding_settings', 'sec_survey_email_body', [
            'default' => self::get_default_survey_template()
        ]);

        // Survey completion email
        register_setting('sec_branding_settings', 'sec_completion_email_subject', [
            'default' => 'Website Launch Confirmed - Ready in 48 Hours'
        ]);
        register_setting('sec_branding_settings', 'sec_completion_email_body', [
            'default' => self::get_default_completion_template()
        ]);
    }

    public static function enqueue_admin_scripts($hook) {
        if ($hook !== 'stripe-embedded-checkout_page_sec-branding-settings') {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style('sec-branding-admin', plugins_url('../assets/css/admin-branding.css', __FILE__), [], '1.0.0');
        wp_enqueue_script('sec-branding-admin', plugins_url('../assets/js/admin-branding.js', __FILE__), ['jquery'], '1.0.0', true);

        wp_localize_script('sec-branding-admin', 'secBrandingData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sec_branding_nonce')
        ]);
    }

    public static function render_settings_page() {
        $logo_url = get_option('sec_logo_url', '');
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));

        $receipt_subject = get_option('sec_receipt_email_subject', 'Payment Receipt - {{business_name}}');
        $receipt_body = get_option('sec_receipt_email_body', self::get_default_receipt_template());

        $survey_subject = get_option('sec_survey_email_subject', 'Complete Your Website Launch Survey');
        $survey_body = get_option('sec_survey_email_body', self::get_default_survey_template());

        $completion_subject = get_option('sec_completion_email_subject', 'Website Launch Confirmed - Ready in 48 Hours');
        $completion_body = get_option('sec_completion_email_body', self::get_default_completion_template());
        ?>
        <div class="wrap sec-branding-wrap">
            <h1>🎨 Branding Settings</h1>
            <p class="sec-branding-subtitle">Customize your logo and email templates for a consistent brand experience.</p>

            <form method="post" action="options.php" class="sec-branding-form">
                <?php settings_fields('sec_branding_settings'); ?>

                <!-- Logo Section -->
                <div class="sec-branding-card">
                    <h2>Company Logo</h2>
                    <p class="description">Upload your logo to appear in emails and admin pages.</p>

                    <div class="sec-logo-upload-area">
                        <?php if ($logo_url): ?>
                            <div class="sec-logo-preview">
                                <img src="<?php echo esc_url($logo_url); ?>" alt="Company Logo">
                                <button type="button" class="button sec-remove-logo">Remove Logo</button>
                            </div>
                        <?php else: ?>
                            <div class="sec-logo-placeholder">
                                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                                    <circle cx="8.5" cy="8.5" r="1.5"/>
                                    <polyline points="21 15 16 10 5 21"/>
                                </svg>
                                <p>No logo uploaded</p>
                            </div>
                        <?php endif; ?>
                        <button type="button" class="button button-primary sec-upload-logo">
                            <?php echo $logo_url ? 'Change Logo' : 'Upload Logo'; ?>
                        </button>
                        <input type="hidden" name="sec_logo_url" id="sec_logo_url" value="<?php echo esc_attr($logo_url); ?>">
                    </div>
                </div>

                <!-- Email Sender Settings -->
                <div class="sec-branding-card">
                    <h2>Email Sender Information</h2>
                    <p class="description">This will appear in the "From" field of all emails.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_email_from_name">From Name</label></th>
                            <td>
                                <input type="text" name="sec_email_from_name" id="sec_email_from_name"
                                       value="<?php echo esc_attr($from_name); ?>" class="regular-text">
                                <p class="description">e.g., "MarketingAid Support"</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_email_from_email">From Email</label></th>
                            <td>
                                <input type="email" name="sec_email_from_email" id="sec_email_from_email"
                                       value="<?php echo esc_attr($from_email); ?>" class="regular-text">
                                <p class="description">Must be a verified email address.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Payment Receipt Email -->
                <div class="sec-branding-card">
                    <h2>💳 Payment Receipt Email</h2>
                    <p class="description">Sent immediately after successful payment.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_receipt_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_receipt_email_subject" id="sec_receipt_email_subject"
                                       value="<?php echo esc_attr($receipt_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_receipt_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_receipt_email_body" id="sec_receipt_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($receipt_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{customer_email}}, {{amount}}, {{date}}, {{business_name}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Survey Invitation Email -->
                <div class="sec-branding-card">
                    <h2>📋 Survey Invitation Email</h2>
                    <p class="description">Sent with the tokenized survey link.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_survey_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_survey_email_subject" id="sec_survey_email_subject"
                                       value="<?php echo esc_attr($survey_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_survey_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_survey_email_body" id="sec_survey_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($survey_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{survey_link}}, {{business_name}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Survey Completion Email -->
                <div class="sec-branding-card">
                    <h2>✅ Survey Completion Email</h2>
                    <p class="description">Sent when customer completes the survey.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_completion_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_completion_email_subject" id="sec_completion_email_subject"
                                       value="<?php echo esc_attr($completion_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_completion_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_completion_email_body" id="sec_completion_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($completion_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{business_name}}, {{submitted_at}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button('Save Branding Settings', 'primary large'); ?>
            </form>

            <div class="sec-branding-card sec-preview-card">
                <h2>📧 Email Preview</h2>
                <p class="description">See how your emails will look to customers.</p>
                <button type="button" class="button sec-preview-receipt">Preview Receipt Email</button>
                <button type="button" class="button sec-preview-survey">Preview Survey Email</button>
                <button type="button" class="button sec-preview-completion">Preview Completion Email</button>
            </div>
        </div>
        <?php
    }

    public static function ajax_upload_logo() {
        check_ajax_referer('sec_branding_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized']);
        }

        if (empty($_FILES['logo'])) {
            wp_send_json_error(['message' => 'No file uploaded']);
        }

        $file = $_FILES['logo'];
        $upload = wp_handle_upload($file, ['test_form' => false]);

        if (isset($upload['error'])) {
            wp_send_json_error(['message' => $upload['error']]);
        }

        update_option('sec_logo_url', $upload['url']);
        wp_send_json_success(['url' => $upload['url']]);
    }

    private static function get_default_receipt_template() {
        return 'Hi {{customer_name}},

Thank you for your payment! Your website setup is confirmed.

Payment Details:
• Amount: {{amount}}
• Date: {{date}}
• Business: {{business_name}}

Next Steps:
1. Complete the website launch survey (link sent separately)
2. We\'ll build your website within 48 hours
3. You\'ll receive a preview link to review before going live

Questions? Just reply to this email.

Best regards,
The MarketingAid Team';
    }

    private static function get_default_survey_template() {
        return 'Hi {{customer_name}},

Thank you for your payment! To build your website, we need a few details about your business.

Please complete the survey here:
{{survey_link}}

This should only take 5-10 minutes. Your progress is saved automatically, so you can complete it later if needed.

Once submitted, we\'ll have your website ready within 48 hours!

Best regards,
The MarketingAid Team';
    }

    private static function get_default_completion_template() {
        return 'Hi {{customer_name}},

Perfect! We received your website launch details.

What happens next:
• Our team will build your custom website
• Expect a preview link within 48 hours
• You\'ll be able to review and request changes
• Once approved, we\'ll launch it live!

Submitted: {{submitted_at}}
Business: {{business_name}}

We\'ll be in touch soon!

Best regards,
The MarketingAid Team';
    }
}

SEC_Branding_Settings::init();
