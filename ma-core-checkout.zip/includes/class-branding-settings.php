<?php
/**
 * Branding Settings - Logo and Email Templates Admin Page
 */

if (!defined('ABSPATH')) {
    exit;
}

class SEC_Branding_Settings {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'add_settings_page'], 20);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_scripts']);
        add_action('wp_ajax_sec_upload_logo', [__CLASS__, 'ajax_upload_logo']);
        add_action('wp_ajax_sec_send_test_receipt_email', [__CLASS__, 'ajax_send_test_receipt_email']);
    }

    public static function add_settings_page() {
        add_submenu_page(
            'stripe-embedded-checkout',
            'Branding Settings',
            'Branding',
            'manage_options',
            'sec-branding-settings',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {
        // Logo settings
        register_setting('sec_branding_settings', 'sec_logo_url');

        // Email templates
        register_setting('sec_branding_settings', 'sec_email_from_name', [
            'default' => get_bloginfo('name')
        ]);
        register_setting('sec_branding_settings', 'sec_email_from_email', [
            'default' => get_option('admin_email')
        ]);
        register_setting('sec_branding_settings', 'sec_email_header_gradient_start', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default' => '#3b82f6',
        ]);
        register_setting('sec_branding_settings', 'sec_email_header_gradient_end', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default' => '#0ea5e9',
        ]);

        // Payment receipt email
        register_setting('sec_branding_settings', 'sec_receipt_email_subject', [
            'default' => 'Payment Receipt - {{business_name}}'
        ]);
        register_setting('sec_branding_settings', 'sec_receipt_email_body', [
            'default' => self::get_default_receipt_template()
        ]);

        // Survey invitation email
        register_setting('sec_branding_settings', 'sec_survey_email_subject', [
            'default' => 'Complete Your Website Launch Survey'
        ]);
        register_setting('sec_branding_settings', 'sec_survey_email_body', [
            'default' => self::get_default_survey_template()
        ]);

        // Survey completion email
        register_setting('sec_branding_settings', 'sec_completion_email_subject', [
            'default' => 'Website Launch Confirmed - Ready in 48 Hours'
        ]);
        register_setting('sec_branding_settings', 'sec_completion_email_body', [
            'default' => self::get_default_completion_template()
        ]);

        // Survey reminder email
        register_setting('sec_branding_settings', 'sec_reminder_email_subject', [
            'default' => 'Complete your website setup - we\'re waiting on you!'
        ]);
        register_setting('sec_branding_settings', 'sec_reminder_email_body', [
            'default' => self::get_default_reminder_template()
        ]);
    }

    public static function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'sec-branding-settings') === false) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style('sec-branding-admin', plugins_url('../assets/css/admin-branding.css', __FILE__), [], '1.0.0');
        wp_enqueue_script('sec-branding-admin', plugins_url('../assets/js/admin-branding.js', __FILE__), ['jquery'], '1.0.0', true);

        wp_localize_script('sec-branding-admin', 'secBrandingData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sec_branding_nonce'),
            'default_test_email' => wp_get_current_user()->user_email
        ]);
    }

    public static function render_settings_page() {
        $logo_url = get_option('sec_logo_url', '');
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        $header_gradient_start = sanitize_hex_color(get_option('sec_email_header_gradient_start', '#3b82f6')) ?: '#3b82f6';
        $header_gradient_end = sanitize_hex_color(get_option('sec_email_header_gradient_end', '#0ea5e9')) ?: '#0ea5e9';

        $receipt_subject = get_option('sec_receipt_email_subject', 'Payment Receipt - {{business_name}}');
        $receipt_body = get_option('sec_receipt_email_body', self::get_default_receipt_template());

        $survey_subject = get_option('sec_survey_email_subject', 'Complete Your Website Launch Survey');
        $survey_body = get_option('sec_survey_email_body', self::get_default_survey_template());

        $completion_subject = get_option('sec_completion_email_subject', 'Website Launch Confirmed - Ready in 48 Hours');
        $completion_body = get_option('sec_completion_email_body', self::get_default_completion_template());

        $reminder_subject = get_option('sec_reminder_email_subject', 'Complete your website setup - we\'re waiting on you!');
        $reminder_body = get_option('sec_reminder_email_body', self::get_default_reminder_template());
        ?>
        <div class="wrap sec-branding-wrap">
            <h1>🎨 Branding Settings</h1>
            <p class="sec-branding-subtitle">Customize your logo and email templates for a consistent brand experience.</p>

            <form method="post" action="options.php" class="sec-branding-form">
                <?php settings_fields('sec_branding_settings'); ?>

                <!-- Logo Section -->
                <div class="sec-branding-card">
                    <h2>Company Logo</h2>
                    <p class="description">Upload your logo to appear in emails and admin pages.</p>

                    <div class="sec-logo-upload-area">
                        <?php if ($logo_url): ?>
                            <div class="sec-logo-preview">
                                <img src="<?php echo esc_url($logo_url); ?>" alt="Company Logo">
                                <button type="button" class="button sec-remove-logo">Remove Logo</button>
                            </div>
                        <?php else: ?>
                            <div class="sec-logo-placeholder">
                                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                                    <circle cx="8.5" cy="8.5" r="1.5"/>
                                    <polyline points="21 15 16 10 5 21"/>
                                </svg>
                                <p>No logo uploaded</p>
                            </div>
                        <?php endif; ?>
                        <button type="button" class="button button-primary sec-upload-logo">
                            <?php echo $logo_url ? 'Change Logo' : 'Upload Logo'; ?>
                        </button>
                        <input type="hidden" name="sec_logo_url" id="sec_logo_url" value="<?php echo esc_attr($logo_url); ?>">
                    </div>
                </div>

                <!-- Email Sender Settings -->
                <div class="sec-branding-card">
                    <h2>Email Sender Information</h2>
                    <p class="description">This will appear in the "From" field of all emails.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_email_from_name">From Name</label></th>
                            <td>
                                <input type="text" name="sec_email_from_name" id="sec_email_from_name"
                                       value="<?php echo esc_attr($from_name); ?>" class="regular-text">
                                <p class="description">e.g., "MarketingAid Support"</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_email_from_email">From Email</label></th>
                            <td>
                                <input type="email" name="sec_email_from_email" id="sec_email_from_email"
                                       value="<?php echo esc_attr($from_email); ?>" class="regular-text">
                                <p class="description">Must be a verified email address.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_email_header_gradient_start">Header Gradient</label></th>
                            <td>
                                <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                                    <label for="sec_email_header_gradient_start" style="display:flex; align-items:center; gap:6px;">
                                        Start
                                        <input type="color" id="sec_email_header_gradient_start_picker" value="<?php echo esc_attr($header_gradient_start); ?>">
                                        <input type="text" name="sec_email_header_gradient_start" id="sec_email_header_gradient_start"
                                               value="<?php echo esc_attr($header_gradient_start); ?>" class="small-text" placeholder="#3b82f6">
                                    </label>
                                    <label for="sec_email_header_gradient_end" style="display:flex; align-items:center; gap:6px;">
                                        End
                                        <input type="color" id="sec_email_header_gradient_end_picker" value="<?php echo esc_attr($header_gradient_end); ?>">
                                        <input type="text" name="sec_email_header_gradient_end" id="sec_email_header_gradient_end"
                                               value="<?php echo esc_attr($header_gradient_end); ?>" class="small-text" placeholder="#0ea5e9">
                                    </label>
                                </div>
                                <p class="description">Controls the email header gradient behind your logo.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Payment Receipt Email -->
                <div class="sec-branding-card">
                    <h2>💳 Payment Receipt Email</h2>
                    <p class="description">Sent immediately after successful payment.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_receipt_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_receipt_email_subject" id="sec_receipt_email_subject"
                                       value="<?php echo esc_attr($receipt_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_receipt_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_receipt_email_body" id="sec_receipt_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($receipt_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{customer_email}}, {{amount}}, {{date}}, {{business_name}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Survey Invitation Email -->
                <div class="sec-branding-card">
                    <h2>📋 Survey Invitation Email</h2>
                    <p class="description">Sent with the tokenized survey link.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_survey_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_survey_email_subject" id="sec_survey_email_subject"
                                       value="<?php echo esc_attr($survey_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_survey_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_survey_email_body" id="sec_survey_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($survey_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{survey_link}}, {{business_name}}, {{cta_button:Button Text}}
                                    <br><strong>CTA Button:</strong> Use {{cta_button:Complete Survey →}} to place a styled button anywhere in your email.
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Survey Completion Email -->
                <div class="sec-branding-card">
                    <h2>✅ Survey Completion Email</h2>
                    <p class="description">Sent when customer completes the survey.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_completion_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_completion_email_subject" id="sec_completion_email_subject"
                                       value="<?php echo esc_attr($completion_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_completion_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_completion_email_body" id="sec_completion_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($completion_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{business_name}}, {{submitted_at}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Survey Reminder Email -->
                <div class="sec-branding-card">
                    <h2>⏰ Survey Reminder Email</h2>
                    <p class="description">Sent when customer hasn't completed the survey after payment.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_reminder_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_reminder_email_subject" id="sec_reminder_email_subject"
                                       value="<?php echo esc_attr($reminder_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_reminder_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_reminder_email_body" id="sec_reminder_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($reminder_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{current_step}}, {{total_steps}}, {{progress_percent}}, {{cta_button:Button Text}}
                                    <br><strong>CTA Button:</strong> Use {{cta_button:Continue Survey →}} to place a styled button anywhere in your email.
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button('Save Branding Settings', 'primary large'); ?>
            </form>

            <div class="sec-branding-card sec-preview-card">
                <h2>📧 Email Preview</h2>
                <p class="description">See how your emails will look to customers.</p>
                <button type="button" class="button sec-preview-receipt">Preview Receipt Email</button>
                <button type="button" class="button sec-preview-survey">Preview Survey Email</button>
                <button type="button" class="button sec-preview-completion">Preview Completion Email</button>
                <button type="button" class="button sec-preview-reminder">Preview Reminder Email</button>
                <hr style="margin:16px 0;">
                <h3 style="margin:0 0 8px 0;">Send Test Payment Receipt</h3>
                <p class="description">Sends a real receipt email with PDF attachments, no checkout required.</p>
                <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                    <input type="email" id="sec_test_receipt_email" class="regular-text" placeholder="you@example.com" value="<?php echo esc_attr(wp_get_current_user()->user_email); ?>">
                    <button type="button" class="button button-primary sec-send-test-receipt">Send Test Receipt</button>
                    <span id="sec_test_receipt_status" style="font-weight:600;"></span>
                </div>
            </div>
        </div>
        <script>
            (function() {
                const startPicker = document.getElementById('sec_email_header_gradient_start_picker');
                const endPicker = document.getElementById('sec_email_header_gradient_end_picker');
                const startText = document.getElementById('sec_email_header_gradient_start');
                const endText = document.getElementById('sec_email_header_gradient_end');

                if (!startPicker || !endPicker || !startText || !endText) {
                    return;
                }

                startPicker.addEventListener('input', function() { startText.value = this.value; });
                endPicker.addEventListener('input', function() { endText.value = this.value; });

                startText.addEventListener('input', function() {
                    if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                        startPicker.value = this.value;
                    }
                });
                endText.addEventListener('input', function() {
                    if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                        endPicker.value = this.value;
                    }
                });
            })();
        </script>
        <?php
    }

    public static function ajax_upload_logo() {
        check_ajax_referer('sec_branding_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized']);
        }

        if (empty($_FILES['logo'])) {
            wp_send_json_error(['message' => 'No file uploaded']);
        }

        $file = $_FILES['logo'];
        $upload = wp_handle_upload($file, ['test_form' => false]);

        if (isset($upload['error'])) {
            wp_send_json_error(['message' => $upload['error']]);
        }

        update_option('sec_logo_url', $upload['url']);
        wp_send_json_success(['url' => $upload['url']]);
    }

    public static function ajax_send_test_receipt_email() {
        check_ajax_referer('sec_branding_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized']);
        }

        if (!class_exists('SEC_Survey_Email')) {
            wp_send_json_error(['message' => 'Email handler not available']);
        }

        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        if (empty($email) || !is_email($email)) {
            wp_send_json_error(['message' => 'Enter a valid test email address']);
        }

        $business_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $sent = SEC_Survey_Email::send_payment_receipt([
            'customer_email' => $email,
            'customer_name' => 'Test Customer',
            'amount' => 20150, // cents
            'business_name' => $business_name,
            'session_id' => 'test_' . wp_generate_password(10, false, false),
            'date' => date('F j, Y g:i A'),
        ]);

        if ($sent) {
            wp_send_json_success(['message' => 'Test receipt sent to ' . $email]);
        }

        wp_send_json_error(['message' => 'Unable to send test receipt. Check mail configuration.']);
    }

    private static function get_default_receipt_template() {
        return 'Hi {{customer_name}},

Thank you for your payment! Your website setup is confirmed.

Payment Details:
• Amount: {{amount}}
• Date: {{date}}
• Business: {{business_name}}

Next Steps:
1. Complete the website launch survey (link sent separately)
2. We\'ll build your website within 48 hours
3. You\'ll receive a preview link to review before going live

Questions? Just reply to this email.

Best regards,
The MarketingAid Team';
    }

    private static function get_default_survey_template() {
        return 'Hi {{customer_name}},

Thank you for your payment! To build your website, we need a few details about your business.

{{cta_button:Complete Survey →}}

This should only take 5-10 minutes. Your progress is saved automatically, so you can complete it later if needed.

Once submitted, we\'ll have your website ready within 48 hours!

If the button doesn\'t work, use this link:
{{survey_link}}

Best regards,
The MarketingAid Team';
    }

    private static function get_default_completion_template() {
        return 'Hi {{customer_name}},

Perfect! We received your website launch details.

What happens next:
• Our team will build your custom website
• Expect a preview link within 48 hours
• You\'ll be able to review and request changes
• Once approved, we\'ll launch it live!

Submitted: {{submitted_at}}
Business: {{business_name}}

We\'ll be in touch soon!

Best regards,
The MarketingAid Team';
    }

    private static function get_default_reminder_template() {
        return 'Hi {{customer_name}},

Thanks for starting your website setup! I noticed you left off at Step {{current_step}} of {{total_steps}}.

You\'re {{progress_percent}}% complete — just a few more questions and we can start building your site!

{{cta_button:Continue My Survey →}}

Your progress is automatically saved, so you can pick up right where you left off.

Why does this matter? Without your survey, we cannot build your website. The button above will restore all of your answers.

Best regards,
The MarketingAid Team';
    }
}

SEC_Branding_Settings::init();
