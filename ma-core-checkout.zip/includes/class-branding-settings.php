<?php
/**
 * Branding Settings - Logo and Email Templates Admin Page
 */

if (!defined('ABSPATH')) {
    exit;
}

class SEC_Branding_Settings {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'add_settings_page'], 20);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_scripts']);
        add_action('wp_ajax_sec_upload_logo', [__CLASS__, 'ajax_upload_logo']);
        add_action('wp_ajax_sec_send_test_receipt_email', [__CLASS__, 'ajax_send_test_receipt_email']);
        add_action('wp_ajax_sec_send_test_email', [__CLASS__, 'ajax_send_test_email']);
    }

    public static function add_settings_page() {
        add_submenu_page(
            'stripe-embedded-checkout',
            'Branding Settings',
            'Branding',
            'manage_options',
            'sec-branding-settings',
            [__CLASS__, 'render_settings_page']
        );
    }

    public static function register_settings() {
        // Logo settings
        register_setting('sec_branding_settings', 'sec_logo_url');
        register_setting('sec_branding_settings', 'sec_logo_png_fallback_url', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => '',
        ]);

        // Email templates
        register_setting('sec_branding_settings', 'sec_email_from_name', [
            'default' => get_bloginfo('name')
        ]);
        register_setting('sec_branding_settings', 'sec_email_from_email', [
            'default' => get_option('admin_email')
        ]);
        register_setting('sec_branding_settings', 'sec_billing_support_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => 'billing@marketingaid.org',
        ]);

        // Terms of Service URL
        register_setting('sec_branding_settings', 'sec_terms_of_service_url', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => '',
        ]);

        // Terms of Service acceptance text
        register_setting('sec_branding_settings', 'sec_terms_of_service_text', [
            'type' => 'string',
            'sanitize_callback' => 'wp_kses_post',
            'default' => 'I authorize {{company_name}} to begin development and confirm the {{amount}} setup fee is non-refundable per the <a href="{{tos_url}}" target="_blank" rel="noopener noreferrer">Terms of Service</a> (v1.0).',
        ]);

        // Email-specific From addresses (Google Workspace aliases)
        register_setting('sec_branding_settings', 'sec_invoice_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_survey_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_reminder_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_completion_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_waitlist_confirmation_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_waitlist_notification_from_email', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_email_header_gradient_start', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default' => '#3b82f6',
        ]);
        register_setting('sec_branding_settings', 'sec_email_header_gradient_end', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default' => '#0ea5e9',
        ]);
        register_setting('sec_branding_settings', 'sec_pdf_header_color_start', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default' => '#0EA5E9',
        ]);
        register_setting('sec_branding_settings', 'sec_pdf_header_color_end', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default' => '#0A2540',
        ]);

        // Payment receipt email
        register_setting('sec_branding_settings', 'sec_receipt_email_subject', [
            'default' => 'Payment Receipt - {{business_name}}'
        ]);
        register_setting('sec_branding_settings', 'sec_receipt_email_body', [
            'default' => self::get_default_receipt_template()
        ]);

        // Survey invitation email
        register_setting('sec_branding_settings', 'sec_survey_email_subject', [
            'default' => 'Complete Your Website Launch Survey'
        ]);
        register_setting('sec_branding_settings', 'sec_survey_email_body', [
            'default' => self::get_default_survey_template()
        ]);

        // Survey completion email
        register_setting('sec_branding_settings', 'sec_completion_email_subject', [
            'default' => 'Website Launch Confirmed - Ready in 48 Hours'
        ]);
        register_setting('sec_branding_settings', 'sec_completion_email_body', [
            'default' => self::get_default_completion_template()
        ]);

        // Survey reminder email
        register_setting('sec_branding_settings', 'sec_reminder_email_subject', [
            'default' => 'Complete your website setup - we\'re waiting on you!'
        ]);
        register_setting('sec_branding_settings', 'sec_reminder_email_body', [
            'default' => self::get_default_reminder_template()
        ]);

        // Admin notification email
        register_setting('sec_branding_settings', 'sec_admin_notification_subject', [
            'default' => 'New Website Setup Survey Submission - {{business_name}}'
        ]);
        register_setting('sec_branding_settings', 'sec_admin_notification_title', [
            'default' => 'New Website Setup Survey'
        ]);
        register_setting('sec_branding_settings', 'sec_admin_notification_subtitle', [
            'default' => 'Received {{submitted_at}}'
        ]);

        // Email Footer Settings
        register_setting('sec_branding_settings', 'sec_email_footer_template', [
            'type' => 'string',
            'sanitize_callback' => 'wp_kses_post',
            'default' => '© {{year}} {{company_name}}. All rights reserved. | {{legal_business_name}} | {{physical_address}} | <a href="{{unsubscribe_url}}" style="color: inherit; text-decoration: underline;">Unsubscribe</a>',
        ]);
        register_setting('sec_branding_settings', 'sec_legal_business_name', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_physical_address', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_unsubscribe_url', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => '',
        ]);
        register_setting('sec_branding_settings', 'sec_enable_unsubscribe', [
            'type' => 'boolean',
            'default' => false,
        ]);
    }

    public static function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'sec-branding-settings') === false) {
            return;
        }

        wp_enqueue_media();
        wp_enqueue_style('sec-branding-admin', plugins_url('../assets/css/admin-branding.css', __FILE__), [], '1.0.0');
        wp_enqueue_script('sec-branding-admin', plugins_url('../assets/js/admin-branding.js', __FILE__), ['jquery'], '1.0.0', true);

        wp_localize_script('sec-branding-admin', 'secBrandingData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sec_branding_nonce'),
            'default_test_email' => wp_get_current_user()->user_email
        ]);
    }

    public static function render_settings_page() {
        $logo_url = get_option('sec_logo_url', '');
        $logo_png_fallback_url = get_option('sec_logo_png_fallback_url', '');
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from_email', get_option('admin_email'));
        $billing_support_email = sanitize_email(get_option('sec_billing_support_email', 'billing@marketingaid.org')) ?: 'billing@marketingaid.org';
        $header_gradient_start = sanitize_hex_color(get_option('sec_email_header_gradient_start', '#3b82f6')) ?: '#3b82f6';
        $header_gradient_end = sanitize_hex_color(get_option('sec_email_header_gradient_end', '#0ea5e9')) ?: '#0ea5e9';
        $pdf_header_start = sanitize_hex_color(get_option('sec_pdf_header_color_start', '#0EA5E9')) ?: '#0EA5E9';
        $pdf_header_end = sanitize_hex_color(get_option('sec_pdf_header_color_end', '#0A2540')) ?: '#0A2540';

        $receipt_subject = get_option('sec_receipt_email_subject', 'Payment Receipt - {{business_name}}');
        $receipt_body = get_option('sec_receipt_email_body', self::get_default_receipt_template());

        $survey_subject = get_option('sec_survey_email_subject', 'Complete Your Website Launch Survey');
        $survey_body = get_option('sec_survey_email_body', self::get_default_survey_template());

        $completion_subject = get_option('sec_completion_email_subject', 'Website Launch Confirmed - Ready in 48 Hours');
        $completion_body = get_option('sec_completion_email_body', self::get_default_completion_template());

        $reminder_subject = get_option('sec_reminder_email_subject', 'Complete your website setup - we\'re waiting on you!');
        $reminder_body = get_option('sec_reminder_email_body', self::get_default_reminder_template());
        $admin_notification_subject = get_option('sec_admin_notification_subject', 'New Website Setup Survey Submission - {{business_name}}');
        $admin_notification_title = get_option('sec_admin_notification_title', 'New Website Setup Survey');
        $admin_notification_subtitle = get_option('sec_admin_notification_subtitle', 'Received {{submitted_at}}');
        ?>
        <div class="wrap sec-branding-wrap">
            <h1>🎨 Branding Settings</h1>
            <p class="sec-branding-subtitle">Customize your logo and email templates for a consistent brand experience.</p>

            <form method="post" action="options.php" class="sec-branding-form">
                <?php settings_fields('sec_branding_settings'); ?>

                <!-- Logo Section -->
                <div class="sec-branding-card">
                    <h2>Company Logo</h2>
                    <p class="description">Upload your logo to appear in emails and admin pages.</p>

                    <div class="sec-logo-upload-area">
                        <?php if ($logo_url): ?>
                            <div class="sec-logo-preview">
                                <img src="<?php echo esc_url($logo_url); ?>" alt="Company Logo">
                                <button type="button" class="button sec-remove-logo">Remove Logo</button>
                            </div>
                        <?php else: ?>
                            <div class="sec-logo-placeholder">
                                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                                    <circle cx="8.5" cy="8.5" r="1.5"/>
                                    <polyline points="21 15 16 10 5 21"/>
                                </svg>
                                <p>No logo uploaded</p>
                            </div>
                        <?php endif; ?>
                        <button type="button" class="button button-primary sec-upload-logo">
                            <?php echo $logo_url ? 'Change Logo' : 'Upload Logo'; ?>
                        </button>
                        <input type="hidden" name="sec_logo_url" id="sec_logo_url" value="<?php echo esc_attr($logo_url); ?>">
                    </div>
                    <div style="margin-top:14px;">
                        <label for="sec_logo_png_fallback_url" style="font-weight:600;">PNG Fallback Logo (for Email/PDF)</label>
                        <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin-top:6px;">
                            <input type="url" name="sec_logo_png_fallback_url" id="sec_logo_png_fallback_url"
                                   value="<?php echo esc_attr($logo_png_fallback_url); ?>" class="regular-text"
                                   placeholder="https://.../logo-fallback.png">
                            <button type="button" class="button sec-upload-logo-png-fallback">Upload PNG Fallback</button>
                        </div>
                        <p class="description">Use this when your main logo is SVG. Email clients and PDF rendering are most reliable with PNG.</p>
                    </div>
                </div>

                <!-- Email Sender Settings -->
                <div class="sec-branding-card">
                    <h2>Email Sender Information</h2>
                    <p class="description">This will appear in the "From" field of all emails.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_email_from_name">From Name</label></th>
                            <td>
                                <input type="text" name="sec_email_from_name" id="sec_email_from_name"
                                       value="<?php echo esc_attr($from_name); ?>" class="regular-text">
                                <p class="description">e.g., "MarketingAid Support"</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_email_from_email">From Email</label></th>
                            <td>
                                <input type="email" name="sec_email_from_email" id="sec_email_from_email"
                                       value="<?php echo esc_attr($from_email); ?>" class="regular-text">
                                <p class="description">Must be a verified email address.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_billing_support_email">Support/Billing Email</label></th>
                            <td>
                                <input type="email" name="sec_billing_support_email" id="sec_billing_support_email"
                                       value="<?php echo esc_attr($billing_support_email); ?>" class="regular-text">
                                <p class="description">Used in receipt/invoice PDF support footer text.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_terms_of_service_url">Terms of Service URL</label></th>
                            <td>
                                <input type="url" name="sec_terms_of_service_url" id="sec_terms_of_service_url"
                                       value="<?php echo esc_attr(get_option('sec_terms_of_service_url', '')); ?>" class="regular-text"
                                       placeholder="https://example.com/terms-of-service">
                                <p class="description">Customers must accept your Terms of Service before payment. Leave blank to hide the checkbox.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_terms_of_service_text">Terms of Service Text</label></th>
                            <td>
                                <textarea name="sec_terms_of_service_text" id="sec_terms_of_service_text"
                                          rows="3" class="large-text code" style="font-family: monospace;"><?php
                                    echo esc_textarea(get_option('sec_terms_of_service_text',
                                        'I authorize {{company_name}} to begin development and confirm the {{amount}} setup fee is non-refundable per the <a href="{{tos_url}}" target="_blank" rel="noopener noreferrer">Terms of Service</a> (v1.0).'
                                    ));
                                ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    <code>{{company_name}}</code> - Your company name,
                                    <code>{{amount}}</code> - Setup fee amount (e.g., $199),
                                    <code>{{tos_url}}</code> - TOS URL from above
                                    <br>You can use HTML like <code>&lt;a href="..."&gt;</code> for links or <code>&lt;strong&gt;</code> for bold text.
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Email-Specific From Addresses (Google Workspace Aliases) -->
                <div class="sec-branding-card">
                    <h2>📧 Email-Specific From Addresses (Aliases)</h2>
                    <p class="description">Use different email addresses for different email types. Leave blank to use the default "From Email" above.</p>
                    <p class="description" style="background:#f0f9ff; border-left:3px solid #0ea5e9; padding:10px; margin-top:10px;">
                        <strong>💡 Tip:</strong> If using Google Workspace with WP Mail SMTP, authenticate with your primary account (e.g., hello@yourdomain.com)
                        and use these aliases for sending. Make sure aliases are set up in Google Workspace Admin.
                    </p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_invoice_from_email">Invoice Emails</label></th>
                            <td>
                                <input type="email" name="sec_invoice_from_email" id="sec_invoice_from_email"
                                       value="<?php echo esc_attr(get_option('sec_invoice_from_email', '')); ?>" class="regular-text"
                                       placeholder="billing@yourdomain.com">
                                <p class="description">From address for invoice emails (e.g., billing@yourdomain.com)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_survey_from_email">Survey Invitation Emails</label></th>
                            <td>
                                <input type="email" name="sec_survey_from_email" id="sec_survey_from_email"
                                       value="<?php echo esc_attr(get_option('sec_survey_from_email', '')); ?>" class="regular-text"
                                       placeholder="hello@yourdomain.com">
                                <p class="description">From address for survey invitation emails (e.g., hello@yourdomain.com)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_reminder_from_email">Reminder Emails</label></th>
                            <td>
                                <input type="email" name="sec_reminder_from_email" id="sec_reminder_from_email"
                                       value="<?php echo esc_attr(get_option('sec_reminder_from_email', '')); ?>" class="regular-text"
                                       placeholder="alerts@yourdomain.com">
                                <p class="description">From address for survey reminder emails (e.g., alerts@yourdomain.com)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_completion_from_email">Completion Emails</label></th>
                            <td>
                                <input type="email" name="sec_completion_from_email" id="sec_completion_from_email"
                                       value="<?php echo esc_attr(get_option('sec_completion_from_email', '')); ?>" class="regular-text"
                                       placeholder="hello@yourdomain.com">
                                <p class="description">From address for survey completion confirmation emails (e.g., hello@yourdomain.com)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_waitlist_confirmation_from_email">Waitlist Confirmation</label></th>
                            <td>
                                <input type="email" name="sec_waitlist_confirmation_from_email" id="sec_waitlist_confirmation_from_email"
                                       value="<?php echo esc_attr(get_option('sec_waitlist_confirmation_from_email', '')); ?>" class="regular-text"
                                       placeholder="alerts@yourdomain.com">
                                <p class="description">From address for waitlist confirmation emails (e.g., alerts@yourdomain.com)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_waitlist_notification_from_email">Waitlist Notification</label></th>
                            <td>
                                <input type="email" name="sec_waitlist_notification_from_email" id="sec_waitlist_notification_from_email"
                                       value="<?php echo esc_attr(get_option('sec_waitlist_notification_from_email', '')); ?>" class="regular-text"
                                       placeholder="alerts@yourdomain.com">
                                <p class="description">From address for slot availability notification emails (e.g., alerts@yourdomain.com)</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Email Styling Settings -->
                <div class="sec-branding-card">
                    <h2>Email & PDF Styling</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_email_header_gradient_start">Header Gradient</label></th>
                            <td>
                                <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                                    <label for="sec_email_header_gradient_start" style="display:flex; align-items:center; gap:6px;">
                                        Start
                                        <input type="color" id="sec_email_header_gradient_start_picker" value="<?php echo esc_attr($header_gradient_start); ?>">
                                        <input type="text" name="sec_email_header_gradient_start" id="sec_email_header_gradient_start"
                                               value="<?php echo esc_attr($header_gradient_start); ?>" class="small-text" placeholder="#3b82f6">
                                    </label>
                                    <label for="sec_email_header_gradient_end" style="display:flex; align-items:center; gap:6px;">
                                        End
                                        <input type="color" id="sec_email_header_gradient_end_picker" value="<?php echo esc_attr($header_gradient_end); ?>">
                                        <input type="text" name="sec_email_header_gradient_end" id="sec_email_header_gradient_end"
                                               value="<?php echo esc_attr($header_gradient_end); ?>" class="small-text" placeholder="#0ea5e9">
                                    </label>
                                </div>
                                <p class="description">Controls the email header gradient behind your logo.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_pdf_header_color_start">PDF Header Colors</label></th>
                            <td>
                                <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                                    <label for="sec_pdf_header_color_start" style="display:flex; align-items:center; gap:6px;">
                                        Start
                                        <input type="color" id="sec_pdf_header_color_start_picker" value="<?php echo esc_attr($pdf_header_start); ?>">
                                        <input type="text" name="sec_pdf_header_color_start" id="sec_pdf_header_color_start"
                                               value="<?php echo esc_attr($pdf_header_start); ?>" class="small-text" placeholder="#0EA5E9">
                                    </label>
                                    <label for="sec_pdf_header_color_end" style="display:flex; align-items:center; gap:6px;">
                                        End
                                        <input type="color" id="sec_pdf_header_color_end_picker" value="<?php echo esc_attr($pdf_header_end); ?>">
                                        <input type="text" name="sec_pdf_header_color_end" id="sec_pdf_header_color_end"
                                               value="<?php echo esc_attr($pdf_header_end); ?>" class="small-text" placeholder="#0A2540">
                                    </label>
                                </div>
                                <p class="description">Controls the header color(s) in generated receipt/invoice PDFs.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Payment Receipt Email -->
                <div class="sec-branding-card">
                    <h2>💳 Payment Receipt Email</h2>
                    <p class="description">Sent immediately after successful payment.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_receipt_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_receipt_email_subject" id="sec_receipt_email_subject"
                                       value="<?php echo esc_attr($receipt_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_receipt_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_receipt_email_body" id="sec_receipt_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($receipt_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{customer_email}}, {{original_amount}}, {{processing_fee}}, {{discount_amount}}, {{total_amount}}, {{amount}}, {{date}}, {{business_name}}, {{support_email}}
                                    <br><strong>Layout tokens:</strong> {{transaction_details}} and {{support_callout}} insert styled receipt sections.
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Survey Invitation Email -->
                <div class="sec-branding-card">
                    <h2>📋 Survey Invitation Email</h2>
                    <p class="description">Sent with the tokenized survey link.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_survey_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_survey_email_subject" id="sec_survey_email_subject"
                                       value="<?php echo esc_attr($survey_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_survey_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_survey_email_body" id="sec_survey_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($survey_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{survey_link}}, {{business_name}}, {{cta_button:Button Text}}
                                    <br><strong>CTA Button:</strong> Use {{cta_button:Complete Survey →}} to place a styled button anywhere in your email.
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Survey Completion Email -->
                <div class="sec-branding-card">
                    <h2>✅ Survey Completion Email</h2>
                    <p class="description">Sent when customer completes the survey.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_completion_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_completion_email_subject" id="sec_completion_email_subject"
                                       value="<?php echo esc_attr($completion_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_completion_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_completion_email_body" id="sec_completion_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($completion_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{business_name}}, {{submitted_at}}
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Survey Reminder Email -->
                <div class="sec-branding-card">
                    <h2>⏰ Survey Reminder Email</h2>
                    <p class="description">Sent when customer hasn't completed the survey after payment.</p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_reminder_email_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_reminder_email_subject" id="sec_reminder_email_subject"
                                       value="<?php echo esc_attr($reminder_subject); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_reminder_email_body">Email Body</label></th>
                            <td>
                                <textarea name="sec_reminder_email_body" id="sec_reminder_email_body"
                                          rows="12" class="large-text code"><?php echo esc_textarea($reminder_body); ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong>
                                    {{customer_name}}, {{current_step}}, {{total_steps}}, {{progress_percent}}, {{cta_button:Button Text}}
                                    <br><strong>CTA Button:</strong> Use {{cta_button:Continue Survey →}} to place a styled button anywhere in your email.
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="sec-branding-card">
                    <h2>Admin Notification Email</h2>
                    <p class="description">Controls the internal submission-notification subject and header text.</p>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_admin_notification_subject">Subject Line</label></th>
                            <td>
                                <input type="text" name="sec_admin_notification_subject" id="sec_admin_notification_subject"
                                       value="<?php echo esc_attr($admin_notification_subject); ?>" class="large-text">
                                <p class="description"><strong>Placeholders:</strong> {{business_name}}, {{customer_name}}, {{customer_email}}</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_admin_notification_title">Header Title</label></th>
                            <td>
                                <input type="text" name="sec_admin_notification_title" id="sec_admin_notification_title"
                                       value="<?php echo esc_attr($admin_notification_title); ?>" class="large-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_admin_notification_subtitle">Header Subtitle</label></th>
                            <td>
                                <input type="text" name="sec_admin_notification_subtitle" id="sec_admin_notification_subtitle"
                                       value="<?php echo esc_attr($admin_notification_subtitle); ?>" class="large-text">
                                <p class="description"><strong>Placeholder:</strong> {{submitted_at}}</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Email Footer Settings -->
                <div class="sec-branding-card">
                    <h2>📄 Email Footer Template</h2>
                    <p class="description">Customize the footer that appears at the bottom of all customer emails.</p>
                    <p class="description" style="background:#fff9e6; border-left:3px solid #f59e0b; padding:10px; margin-top:10px;">
                        <strong>⚠️ Important:</strong> The footer is optimized for mobile Gmail rendering. Keep it concise and use placeholders for dynamic content.
                    </p>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="sec_legal_business_name">Legal Business Name</label></th>
                            <td>
                                <input type="text" name="sec_legal_business_name" id="sec_legal_business_name"
                                       value="<?php echo esc_attr(get_option('sec_legal_business_name', '')); ?>" class="regular-text"
                                       placeholder="Marketing Aid LLC">
                                <p class="description">Your legal entity name for compliance (e.g., "Marketing Aid LLC")</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_physical_address">Physical Address</label></th>
                            <td>
                                <input type="text" name="sec_physical_address" id="sec_physical_address"
                                       value="<?php echo esc_attr(get_option('sec_physical_address', '')); ?>" class="large-text"
                                       placeholder="123 Main St, City, State 12345">
                                <p class="description">Your business's physical address (required for CAN-SPAM compliance)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Enable Unsubscribe Feature</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="sec_enable_unsubscribe" id="sec_enable_unsubscribe" value="1"
                                           <?php checked(get_option('sec_enable_unsubscribe', false)); ?>>
                                    Enable automatic unsubscribe links in email footers
                                </label>
                                <p class="description">When enabled, all emails will include a secure tokenized unsubscribe link in the footer. Unsubscribed emails are tracked in the database.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_unsubscribe_url">Unsubscribe URL (Optional)</label></th>
                            <td>
                                <input type="url" name="sec_unsubscribe_url" id="sec_unsubscribe_url"
                                       value="<?php echo esc_attr(get_option('sec_unsubscribe_url', '')); ?>" class="large-text"
                                       placeholder="https://yourdomain.com/unsubscribe">
                                <p class="description">Custom unsubscribe URL (only if not using the built-in feature above). Leave blank to use automatic unsubscribe system.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="sec_email_footer_template">Footer Template</label></th>
                            <td>
                                <textarea name="sec_email_footer_template" id="sec_email_footer_template"
                                          rows="4" class="large-text code" style="font-family: monospace;"><?php
                                    echo esc_textarea(get_option('sec_email_footer_template',
                                        '© {{year}} {{company_name}}. All rights reserved. | {{legal_business_name}} | {{physical_address}} | <a href="{{unsubscribe_url}}" style="color: inherit; text-decoration: underline;">Unsubscribe</a>'
                                    ));
                                ?></textarea>
                                <p class="description">
                                    <strong>Available placeholders:</strong><br>
                                    <code>{{year}}</code> - Current year (e.g., 2026)<br>
                                    <code>{{company_name}}</code> - From Name (set above)<br>
                                    <code>{{legal_business_name}}</code> - Legal entity name<br>
                                    <code>{{physical_address}}</code> - Your business address<br>
                                    <code>{{unsubscribe_url}}</code> - Unsubscribe link URL<br><br>
                                    <strong>Example:</strong> © {{year}} {{company_name}}. All rights reserved. | {{legal_business_name}} | {{physical_address}} | &lt;a href="{{unsubscribe_url}}" style="color: inherit; text-decoration: underline;"&gt;Unsubscribe&lt;/a&gt;
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>

                <?php submit_button('Save Branding Settings', 'primary large'); ?>
            </form>

            <div class="sec-branding-card sec-preview-card">
                <h2>📧 Email Preview</h2>
                <p class="description">See how your emails will look to customers.</p>
                <button type="button" class="button sec-preview-receipt">Preview Receipt Email</button>
                <button type="button" class="button sec-preview-survey">Preview Survey Email</button>
                <button type="button" class="button sec-preview-completion">Preview Completion Email</button>
                <button type="button" class="button sec-preview-reminder">Preview Reminder Email</button>
                <hr style="margin:16px 0;">
                <h3 style="margin:0 0 8px 0;">Send Real Test Emails</h3>
                <p class="description">Send actual test emails for every template without running the full workflow.</p>
                <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; margin-bottom:8px;">
                    <input type="email" id="sec_test_receipt_email" class="regular-text" placeholder="you@example.com" value="<?php echo esc_attr(wp_get_current_user()->user_email); ?>">
                </div>
                <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                    <button type="button" class="button sec-send-test-email" data-type="receipt">Send Receipt</button>
                    <button type="button" class="button sec-send-test-email" data-type="survey">Send Survey Invite</button>
                    <button type="button" class="button sec-send-test-email" data-type="completion">Send Completion</button>
                    <button type="button" class="button sec-send-test-email" data-type="reminder_early">Send Reminder (Early)</button>
                    <button type="button" class="button sec-send-test-email" data-type="reminder_mid">Send Reminder (Mid)</button>
                    <button type="button" class="button sec-send-test-email" data-type="reminder_final">Send Reminder (Final)</button>
                    <button type="button" class="button button-primary sec-send-test-all">Send All Test Emails</button>
                </div>
                <div id="sec_test_receipt_status" style="font-weight:600; margin-top:10px;"></div>
            </div>
        </div>
        <script>
            (function() {
                const startPicker = document.getElementById('sec_email_header_gradient_start_picker');
                const endPicker = document.getElementById('sec_email_header_gradient_end_picker');
                const startText = document.getElementById('sec_email_header_gradient_start');
                const endText = document.getElementById('sec_email_header_gradient_end');
                const pdfStartPicker = document.getElementById('sec_pdf_header_color_start_picker');
                const pdfEndPicker = document.getElementById('sec_pdf_header_color_end_picker');
                const pdfStartText = document.getElementById('sec_pdf_header_color_start');
                const pdfEndText = document.getElementById('sec_pdf_header_color_end');

                if (!startPicker || !endPicker || !startText || !endText) {
                    return;
                }

                startPicker.addEventListener('input', function() { startText.value = this.value; });
                endPicker.addEventListener('input', function() { endText.value = this.value; });

                startText.addEventListener('input', function() {
                    if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                        startPicker.value = this.value;
                    }
                });
                endText.addEventListener('input', function() {
                    if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                        endPicker.value = this.value;
                    }
                });

                if (pdfStartPicker && pdfEndPicker && pdfStartText && pdfEndText) {
                    pdfStartPicker.addEventListener('input', function() { pdfStartText.value = this.value; });
                    pdfEndPicker.addEventListener('input', function() { pdfEndText.value = this.value; });
                    pdfStartText.addEventListener('input', function() {
                        if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                            pdfStartPicker.value = this.value;
                        }
                    });
                    pdfEndText.addEventListener('input', function() {
                        if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
                            pdfEndPicker.value = this.value;
                        }
                    });
                }
            })();
        </script>
        <?php
    }

    public static function ajax_upload_logo() {
        check_ajax_referer('sec_branding_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized']);
        }

        if (empty($_FILES['logo'])) {
            wp_send_json_error(['message' => 'No file uploaded']);
        }

        $file = $_FILES['logo'];
        $upload = wp_handle_upload($file, ['test_form' => false]);

        if (isset($upload['error'])) {
            wp_send_json_error(['message' => $upload['error']]);
        }

        update_option('sec_logo_url', $upload['url']);
        wp_send_json_success(['url' => $upload['url']]);
    }

    public static function ajax_send_test_receipt_email() {
        $_POST['type'] = 'receipt';
        self::ajax_send_test_email();
    }

    public static function ajax_send_test_email() {
        check_ajax_referer('sec_branding_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized']);
        }

        if (!class_exists('SEC_Survey_Email')) {
            wp_send_json_error(['message' => 'Email handler not available']);
        }

        $email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
        if (empty($email) || !is_email($email)) {
            wp_send_json_error(['message' => 'Enter a valid test email address']);
        }

        $type = isset($_POST['type']) ? sanitize_key(wp_unslash($_POST['type'])) : 'receipt';
        $business_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $token = 'test_' . wp_generate_password(14, false, false);
        $site_url = home_url();
        $completion_submission = (object) [
            'customer_email' => $email,
            'customer_name' => 'Test Customer',
            'business_name' => 'Test Business',
            'submitted_at' => current_time('mysql'),
        ];

        $sends = array();
        if ($type === 'all') {
            $sends['receipt'] = SEC_Survey_Email::send_payment_receipt([
                'customer_email' => $email,
                'customer_name' => 'Test Customer',
                'amount' => 20150,
                'business_name' => $business_name,
                'session_id' => 'test_' . wp_generate_password(10, false, false),
                'date' => date('F j, Y g:i A'),
            ]);
            $sends['survey'] = SEC_Survey_Email::send_survey_invitation($email, 'Test Customer', $token, 'Test Business', $site_url);
            $sends['completion'] = SEC_Survey_Email::send_completion_confirmation($completion_submission);
            $sends['reminder_early'] = SEC_Survey_Email::send_survey_reminder($email, 'Test Customer', $token, $site_url, 0);
            $sends['reminder_mid'] = SEC_Survey_Email::send_survey_reminder($email, 'Test Customer', $token, $site_url, 5);
            $sends['reminder_final'] = SEC_Survey_Email::send_survey_reminder($email, 'Test Customer', $token, $site_url, 10);

            $failed = array_keys(array_filter($sends, function($v) { return !$v; }));
            if (!empty($failed)) {
                wp_send_json_error(['message' => 'Some test emails failed: ' . implode(', ', $failed)]);
            }
            wp_send_json_success(['message' => 'All test emails sent to ' . $email]);
        }

        switch ($type) {
            case 'receipt':
                $sent = SEC_Survey_Email::send_payment_receipt([
                    'customer_email' => $email,
                    'customer_name' => 'Test Customer',
                    'amount' => 20150,
                    'business_name' => $business_name,
                    'session_id' => 'test_' . wp_generate_password(10, false, false),
                    'date' => date('F j, Y g:i A'),
                ]);
                $label = 'receipt';
                break;
            case 'survey':
                $sent = SEC_Survey_Email::send_survey_invitation($email, 'Test Customer', $token, 'Test Business', $site_url);
                $label = 'survey invitation';
                break;
            case 'completion':
                $sent = SEC_Survey_Email::send_completion_confirmation($completion_submission);
                $label = 'completion confirmation';
                break;
            case 'reminder_early':
                $sent = SEC_Survey_Email::send_survey_reminder($email, 'Test Customer', $token, $site_url, 0);
                $label = 'reminder (early)';
                break;
            case 'reminder_mid':
                $sent = SEC_Survey_Email::send_survey_reminder($email, 'Test Customer', $token, $site_url, 5);
                $label = 'reminder (mid)';
                break;
            case 'reminder_final':
                $sent = SEC_Survey_Email::send_survey_reminder($email, 'Test Customer', $token, $site_url, 10);
                $label = 'reminder (final)';
                break;
            default:
                wp_send_json_error(['message' => 'Unknown email test type']);
                return;
        }

        if ($sent) {
            wp_send_json_success(['message' => 'Test ' . $label . ' email sent to ' . $email]);
            return;
        }

        wp_send_json_error(['message' => 'Unable to send test ' . $label . ' email. Check mail configuration.']);
    }

    private static function get_default_receipt_template() {
        return 'Hi {{customer_name}},

We have successfully received your payment. This email serves as your official receipt. Please retain it for your records.

{{transaction_details}}

{{support_callout}}

Best regards,
The MarketingAid Team';
    }

    private static function get_default_survey_template() {
        return 'Hi {{customer_name}},

Thank you for your payment! To build your website, we need a few details about your business.

{{cta_button:Complete Survey →}}

This should only take 5-10 minutes. Your progress is saved automatically, so you can complete it later if needed.

Once submitted, we\'ll have your website ready within 48 hours!

If the button doesn\'t work, use this link:
{{survey_link}}

Best regards,
The MarketingAid Team';
    }

    private static function get_default_completion_template() {
        return 'Hi {{customer_name}},

Perfect! We received your website launch details.

What happens next:
• Our team will build your custom website
• Expect a preview link within 48 hours
• You\'ll be able to review and request changes
• Once approved, we\'ll launch it live!

Submitted: {{submitted_at}}
Business: {{business_name}}

We\'ll be in touch soon!

Best regards,
The MarketingAid Team';
    }

    private static function get_default_reminder_template() {
        return 'Hi {{customer_name}},

Thanks for starting your website setup! I noticed you left off at Step {{current_step}} of {{total_steps}}.

You\'re {{progress_percent}}% complete — just a few more questions and we can start building your site!

{{cta_button:Continue My Survey →}}

Your progress is automatically saved, so you can pick up right where you left off.

Why does this matter? Without your survey, we cannot build your website. The button above will restore all of your answers.

Best regards,
The MarketingAid Team';
    }
}

SEC_Branding_Settings::init();

