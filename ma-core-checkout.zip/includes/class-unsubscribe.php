<?php
/**
 * Unsubscribe Management
 *
 * Handles email unsubscribe requests and preferences
 */

if (!defined('ABSPATH')) {
    exit;
}

class SEC_Unsubscribe {

    /**
     * Initialize unsubscribe system
     */
    public static function init() {
        add_action('init', [__CLASS__, 'handle_unsubscribe_request']);
        add_shortcode('sec_unsubscribe_form', [__CLASS__, 'render_unsubscribe_form']);
    }

    /**
     * Create unsubscribe table
     */
    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_unsubscribes';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            email varchar(255) NOT NULL,
            reason text DEFAULT NULL,
            unsubscribed_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY email (email),
            KEY unsubscribed_at (unsubscribed_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Check if email is unsubscribed
     *
     * @param string $email Email address
     * @return bool
     */
    public static function is_unsubscribed($email) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_unsubscribes';

        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE email = %s",
            sanitize_email($email)
        ));

        return (int) $result > 0;
    }

    /**
     * Add email to unsubscribe list
     *
     * @param string $email Email address
     * @param string $reason Optional reason for unsubscribing
     * @return bool
     */
    public static function unsubscribe_email($email, $reason = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_unsubscribes';

        $email = sanitize_email($email);
        if (empty($email)) {
            return false;
        }

        // Check if already unsubscribed
        if (self::is_unsubscribed($email)) {
            return true; // Already unsubscribed
        }

        $result = $wpdb->insert(
            $table_name,
            [
                'email' => $email,
                'reason' => sanitize_textarea_field($reason),
                'unsubscribed_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s']
        );

        return $result !== false;
    }

    /**
     * Resubscribe an email
     *
     * @param string $email Email address
     * @return bool
     */
    public static function resubscribe_email($email) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_unsubscribes';

        $email = sanitize_email($email);
        if (empty($email)) {
            return false;
        }

        $result = $wpdb->delete(
            $table_name,
            ['email' => $email],
            ['%s']
        );

        return $result !== false;
    }

    /**
     * Generate unsubscribe URL
     *
     * @param string $email Email address
     * @return string
     */
    public static function get_unsubscribe_url($email) {
        $base_url = home_url('/');

        // Create secure token
        $token = self::generate_unsubscribe_token($email);

        return add_query_arg([
            'email' => urlencode($email),
            'token' => $token,
            'sec_unsubscribe' => '1'
        ], $base_url);
    }

    /**
     * Generate secure token for unsubscribe link
     *
     * @param string $email Email address
     * @return string
     */
    private static function generate_unsubscribe_token($email) {
        $secret = defined('AUTH_KEY') ? AUTH_KEY : 'sec-unsubscribe-secret';
        return substr(hash_hmac('sha256', $email, $secret), 0, 16);
    }

    /**
     * Verify unsubscribe token
     *
     * @param string $email Email address
     * @param string $token Token to verify
     * @return bool
     */
    private static function verify_unsubscribe_token($email, $token) {
        return hash_equals(self::generate_unsubscribe_token($email), $token);
    }

    /**
     * Handle unsubscribe request
     */
    public static function handle_unsubscribe_request() {
        if (!isset($_GET['sec_unsubscribe']) && !isset($_POST['sec_unsubscribe'])) {
            return;
        }

        $email = isset($_REQUEST['email']) ? sanitize_email($_REQUEST['email']) : '';
        $token = isset($_REQUEST['token']) ? sanitize_text_field($_REQUEST['token']) : '';

        // Verify token
        if (empty($email) || empty($token) || !self::verify_unsubscribe_token($email, $token)) {
            wp_die('Invalid unsubscribe link. Please contact support.', 'Invalid Link', ['response' => 400]);
        }

        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sec_unsubscribe'])) {
            check_admin_referer('sec_unsubscribe_' . $email);

            $reason = isset($_POST['reason']) ? sanitize_textarea_field($_POST['reason']) : '';

            if (self::unsubscribe_email($email, $reason)) {
                // Show success message
                self::show_unsubscribe_success($email);
                exit;
            } else {
                wp_die('Failed to unsubscribe. Please try again or contact support.', 'Unsubscribe Failed', ['response' => 500]);
            }
        }

        // Show unsubscribe form
        self::show_unsubscribe_form($email, $token);
        exit;
    }

    /**
     * Show unsubscribe form
     *
     * @param string $email Email address
     * @param string $token Verification token
     */
    private static function show_unsubscribe_form($email, $token) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Unsubscribe - MarketingAid</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
                    background: linear-gradient(135deg, #f5f7fa 0%, #e8ecf1 100%);
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                }
                .container {
                    background: #ffffff;
                    border-radius: 12px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
                    max-width: 500px;
                    width: 100%;
                    padding: 40px;
                    text-align: center;
                }
                .icon {
                    font-size: 48px;
                    margin-bottom: 20px;
                }
                h1 {
                    font-size: 24px;
                    color: #1a1a2e;
                    margin-bottom: 12px;
                }
                .email {
                    font-size: 16px;
                    color: #2536EB;
                    font-weight: 600;
                    margin-bottom: 20px;
                }
                p {
                    font-size: 15px;
                    color: #5a5a7a;
                    line-height: 1.6;
                    margin-bottom: 24px;
                }
                .form-group {
                    margin-bottom: 24px;
                    text-align: left;
                }
                label {
                    display: block;
                    font-size: 14px;
                    font-weight: 600;
                    color: #1a1a2e;
                    margin-bottom: 8px;
                }
                textarea {
                    width: 100%;
                    min-height: 100px;
                    padding: 12px;
                    border: 1.5px solid #e0e4f0;
                    border-radius: 8px;
                    font-family: inherit;
                    font-size: 14px;
                    resize: vertical;
                    transition: border-color 0.2s;
                }
                textarea:focus {
                    outline: none;
                    border-color: #2536EB;
                }
                .button {
                    display: inline-block;
                    background: #dc2626;
                    color: #ffffff;
                    font-size: 16px;
                    font-weight: 600;
                    padding: 14px 32px;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    transition: background 0.2s;
                    text-decoration: none;
                }
                .button:hover {
                    background: #b91c1c;
                }
                .cancel-link {
                    display: block;
                    margin-top: 16px;
                    font-size: 14px;
                    color: #7878a0;
                    text-decoration: none;
                }
                .cancel-link:hover {
                    color: #2536EB;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="icon">😢</div>
                <h1>We're sorry to see you go</h1>
                <div class="email"><?php echo esc_html($email); ?></div>
                <p>You're about to unsubscribe from all MarketingAid emails. Are you sure?</p>

                <form method="POST" action="">
                    <?php wp_nonce_field('sec_unsubscribe_' . $email); ?>
                    <input type="hidden" name="email" value="<?php echo esc_attr($email); ?>">
                    <input type="hidden" name="token" value="<?php echo esc_attr($token); ?>">
                    <input type="hidden" name="sec_unsubscribe" value="1">

                    <div class="form-group">
                        <label for="reason">Why are you unsubscribing? (Optional)</label>
                        <textarea id="reason" name="reason" placeholder="Your feedback helps us improve..."></textarea>
                    </div>

                    <button type="submit" class="button">Confirm Unsubscribe</button>
                </form>

                <a href="<?php echo esc_url(home_url('/')); ?>" class="cancel-link">Never mind, take me back</a>
            </div>
        </body>
        </html>
        <?php
    }

    /**
     * Show unsubscribe success message
     *
     * @param string $email Email address
     */
    private static function show_unsubscribe_success($email) {
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Unsubscribed - MarketingAid</title>
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif;
                    background: linear-gradient(135deg, #f5f7fa 0%, #e8ecf1 100%);
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                }
                .container {
                    background: #ffffff;
                    border-radius: 12px;
                    box-shadow: 0 4px 20px rgba(0,0,0,0.08);
                    max-width: 500px;
                    width: 100%;
                    padding: 40px;
                    text-align: center;
                }
                .icon {
                    font-size: 64px;
                    margin-bottom: 20px;
                }
                h1 {
                    font-size: 24px;
                    color: #1a1a2e;
                    margin-bottom: 12px;
                }
                .email {
                    font-size: 16px;
                    color: #2536EB;
                    font-weight: 600;
                    margin-bottom: 20px;
                }
                p {
                    font-size: 15px;
                    color: #5a5a7a;
                    line-height: 1.6;
                    margin-bottom: 24px;
                }
                .home-link {
                    display: inline-block;
                    background: #2536EB;
                    color: #ffffff;
                    font-size: 16px;
                    font-weight: 600;
                    padding: 14px 32px;
                    border-radius: 8px;
                    text-decoration: none;
                    transition: background 0.2s;
                }
                .home-link:hover {
                    background: #1a28b8;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="icon">✓</div>
                <h1>You've been unsubscribed</h1>
                <div class="email"><?php echo esc_html($email); ?></div>
                <p>You won't receive any more emails from us. If this was a mistake, you can resubscribe anytime by contacting our support team.</p>
                <a href="<?php echo esc_url(home_url('/')); ?>" class="home-link">Return Home</a>
            </div>
        </body>
        </html>
        <?php
    }

    /**
     * Render unsubscribe form shortcode
     *
     * Usage: [sec_unsubscribe_form]
     */
    public static function render_unsubscribe_form() {
        ob_start();
        ?>
        <div class="sec-unsubscribe-page">
            <p>To unsubscribe from our emails, please use the link provided in any email we've sent you.</p>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Initialize
SEC_Unsubscribe::init();
