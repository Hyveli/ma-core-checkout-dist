<?php
/**
 * Survey Database Handler
 *
 * Handles all database operations for survey submissions
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_DB {
    const DELETED_REF_OPTION = 'sec_deleted_survey_refs';

    /**
     * Build a stable hash for token/session lookup without storing raw values.
     */
    private static function ref_hash($value) {
        $value = sanitize_text_field((string) $value);
        if ($value === '') {
            return '';
        }
        return hash('sha256', $value);
    }

    /**
     * Persist deleted survey references so old links can show a deleted message.
     */
    public static function remember_deleted_reference($survey_token = '', $stripe_session_id = '') {
        $token_hash = self::ref_hash($survey_token);
        $session_hash = self::ref_hash($stripe_session_id);

        if ($token_hash === '' && $session_hash === '') {
            return;
        }

        $refs = get_option(self::DELETED_REF_OPTION, array(
            'tokens' => array(),
            'sessions' => array(),
        ));

        if (!is_array($refs)) {
            $refs = array('tokens' => array(), 'sessions' => array());
        }
        if (!isset($refs['tokens']) || !is_array($refs['tokens'])) {
            $refs['tokens'] = array();
        }
        if (!isset($refs['sessions']) || !is_array($refs['sessions'])) {
            $refs['sessions'] = array();
        }

        if ($token_hash !== '' && !in_array($token_hash, $refs['tokens'], true)) {
            $refs['tokens'][] = $token_hash;
        }
        if ($session_hash !== '' && !in_array($session_hash, $refs['sessions'], true)) {
            $refs['sessions'][] = $session_hash;
        }

        // Keep option bounded.
        if (count($refs['tokens']) > 2000) {
            $refs['tokens'] = array_slice($refs['tokens'], -2000);
        }
        if (count($refs['sessions']) > 2000) {
            $refs['sessions'] = array_slice($refs['sessions'], -2000);
        }

        update_option(self::DELETED_REF_OPTION, $refs, false);
    }

    /**
     * Check whether a survey token was previously deleted.
     */
    public static function is_deleted_survey_token($token) {
        $token_hash = self::ref_hash($token);
        if ($token_hash === '') {
            return false;
        }
        $refs = get_option(self::DELETED_REF_OPTION, array());
        $tokens = is_array($refs) && isset($refs['tokens']) && is_array($refs['tokens']) ? $refs['tokens'] : array();
        return in_array($token_hash, $tokens, true);
    }

    /**
     * Check whether a checkout session was previously deleted.
     */
    public static function is_deleted_checkout_session_id($stripe_session_id) {
        $session_hash = self::ref_hash($stripe_session_id);
        if ($session_hash === '') {
            return false;
        }
        $refs = get_option(self::DELETED_REF_OPTION, array());
        $sessions = is_array($refs) && isset($refs['sessions']) && is_array($refs['sessions']) ? $refs['sessions'] : array();
        return in_array($session_hash, $sessions, true);
    }

    /**
     * Resolve survey upload directories for both legacy and current storage locations.
     */
    public static function get_survey_upload_locations() {
        $upload_dir = wp_upload_dir();
        $plugin_dir = trailingslashit(plugin_dir_path(dirname(__FILE__))) . 'survey-uploads/';
        $plugin_url = trailingslashit(plugin_dir_url(dirname(__FILE__))) . 'survey-uploads/';

        return array(
            'current' => array(
                'dir' => trailingslashit($upload_dir['basedir']) . 'survey-uploads/',
                'url' => trailingslashit($upload_dir['baseurl']) . 'survey-uploads/',
            ),
            'legacy' => array(
                'dir' => trailingslashit($upload_dir['basedir']) . 'survey-images/',
                'url' => trailingslashit($upload_dir['baseurl']) . 'survey-images/',
            ),
            'plugin_legacy' => array(
                'dir' => $plugin_dir,
                'url' => $plugin_url,
            ),
        );
    }

    /**
     * Convert a stored file reference (full URL or filename) to an absolute file path.
     */
    public static function resolve_stored_file_path($stored_value) {
        if (empty($stored_value)) {
            return '';
        }

        $stored_value = trim((string) $stored_value);
        $locations = self::get_survey_upload_locations();

        foreach ($locations as $location) {
            $dir = trailingslashit($location['dir']);
            $url = trailingslashit($location['url']);

            if (strpos($stored_value, $url) === 0) {
                $candidate = $dir . basename(parse_url($stored_value, PHP_URL_PATH));
                if (file_exists($candidate)) {
                    return $candidate;
                }
            }
        }

        $filename = basename(parse_url($stored_value, PHP_URL_PATH));
        foreach ($locations as $location) {
            $candidate = trailingslashit($location['dir']) . $filename;
            if (file_exists($candidate)) {
                return $candidate;
            }
        }

        return '';
    }

    /**
     * Create survey submissions table
     */
    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            stripe_customer_id varchar(255) NOT NULL,
            stripe_session_id varchar(255) NOT NULL,
            customer_name varchar(255) NOT NULL,
            customer_email varchar(255) NOT NULL,
            payment_amount decimal(10,2) NOT NULL DEFAULT 0.00,
            payment_status varchar(50) DEFAULT 'pending',
            payment_date datetime DEFAULT NULL,
            business_name varchar(255) DEFAULT '',
            industry varchar(255) DEFAULT '',
            custom_industry varchar(255) DEFAULT '',
            tagline text DEFAULT NULL,
            services text DEFAULT NULL,
            hours longtext DEFAULT NULL,
            booking text DEFAULT NULL,
            contact_phone varchar(50) DEFAULT '',
            contact_email varchar(255) DEFAULT '',
            contact_address varchar(255) DEFAULT '',
            socials longtext DEFAULT NULL,
            brand text DEFAULT NULL,
            brand_colors varchar(255) DEFAULT '',
            brand_slogan varchar(255) DEFAULT '',
            logo_path varchar(500) DEFAULT '',
            file_paths longtext DEFAULT NULL,
            extra text DEFAULT NULL,
            submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
            status varchar(50) DEFAULT 'new',
            survey_token varchar(64) DEFAULT NULL,
            survey_progress longtext DEFAULT NULL,
            survey_step int(11) DEFAULT 0,
            survey_completed tinyint(1) DEFAULT 0,
            survey_last_saved datetime DEFAULT NULL,
            last_activity datetime DEFAULT NULL,
            reminder_1_sent tinyint(1) DEFAULT 0,
            reminder_1_sent_at datetime DEFAULT NULL,
            reminder_2_sent tinyint(1) DEFAULT 0,
            reminder_2_sent_at datetime DEFAULT NULL,
            reminder_3_sent tinyint(1) DEFAULT 0,
            reminder_3_sent_at datetime DEFAULT NULL,
            reminder_4_sent tinyint(1) DEFAULT 0,
            reminder_4_sent_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_customer_id (stripe_customer_id),
            KEY idx_email (customer_email),
            KEY idx_status (status),
            KEY idx_submitted (submitted_at),
            KEY idx_payment_status (payment_status),
            KEY idx_survey_completed (survey_completed),
            UNIQUE KEY idx_survey_token (survey_token)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Create upload directories (current + legacy fallback)
        $locations = self::get_survey_upload_locations();
        foreach ($locations as $key => $location) {
            if ($key === 'plugin_legacy') {
                continue;
            }
            $survey_dir = trailingslashit($location['dir']);
            if (!file_exists($survey_dir)) {
                wp_mkdir_p($survey_dir);
            }

            if (!file_exists($survey_dir . '.htaccess')) {
                $htaccess_content = "Options -Indexes\n<Files *.php>\ndeny from all\n</Files>";
                file_put_contents($survey_dir . '.htaccess', $htaccess_content);
            }

            if (!file_exists($survey_dir . 'index.php')) {
                file_put_contents($survey_dir . 'index.php', '<?php // Silence is golden');
            }
        }
    }

    /**
     * Insert a new survey submission
     *
     * @param array $data Survey submission data
     * @return int|false Insert ID on success, false on failure
     */
    public static function insert_submission($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        // Prepare data for insertion
        $insert_data = array(
            'stripe_customer_id' => sanitize_text_field($data['stripe_customer_id']),
            'stripe_session_id' => sanitize_text_field($data['stripe_session_id']),
            'customer_name' => sanitize_text_field($data['customer_name']),
            'customer_email' => sanitize_email($data['customer_email']),
            'payment_amount' => floatval($data['payment_amount']),
            'business_name' => sanitize_text_field($data['business_name'] ?? ''),
            'industry' => sanitize_text_field($data['industry'] ?? ''),
            'custom_industry' => sanitize_text_field($data['custom_industry'] ?? ''),
            'tagline' => wp_kses_post($data['tagline'] ?? ''),
            'services' => wp_kses_post($data['services'] ?? ''),
            'hours' => is_array($data['hours'] ?? null) ? json_encode($data['hours']) : '',
            'booking' => is_array($data['booking'] ?? null) ? json_encode($data['booking']) : '',
            'contact_phone' => sanitize_text_field($data['contact_phone'] ?? ''),
            'contact_email' => sanitize_email($data['contact_email'] ?? ''),
            'contact_address' => sanitize_text_field($data['contact_address'] ?? ''),
            'socials' => is_array($data['socials'] ?? null) ? json_encode($data['socials']) : '',
            'brand' => is_array($data['brand'] ?? null) ? json_encode($data['brand']) : '',
            'brand_colors' => sanitize_text_field($data['brand_colors'] ?? ''),
            'brand_slogan' => sanitize_text_field($data['brand_slogan'] ?? ''),
            'logo_path' => sanitize_text_field($data['logo_path'] ?? ''),
            'file_paths' => is_array($data['file_paths'] ?? null) ? json_encode($data['file_paths']) : '',
            'extra' => wp_kses_post($data['extra'] ?? ''),
            'status' => 'new'
        );

        $result = $wpdb->insert($table_name, $insert_data);

        if ($result) {
            return $wpdb->insert_id;
        }

        return false;
    }

    /**
     * Get a submission by ID
     */
    public static function get_submission($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $id
        ));
    }

    /**
     * Get all submissions with optional filtering
     */
    public static function get_submissions($args = array()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        $defaults = array(
            'status' => '',
            'limit' => 20,
            'offset' => 0,
            'orderby' => 'submitted_at',
            'order' => 'DESC'
        );

        $args = wp_parse_args($args, $defaults);

        $where = '1=1';
        if (!empty($args['status'])) {
            $where .= $wpdb->prepare(' AND status = %s', $args['status']);
        }

        $query = "SELECT * FROM $table_name WHERE $where ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";

        return $wpdb->get_results($wpdb->prepare($query, $args['limit'], $args['offset']));
    }

    /**
     * Get submission count
     */
    public static function get_submission_count($status = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        if (!empty($status)) {
            return $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE status = %s",
                $status
            ));
        }

        return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    }

    /**
     * Update submission status
     */
    public static function update_status($id, $status) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return $wpdb->update(
            $table_name,
            array('status' => sanitize_text_field($status)),
            array('id' => intval($id)),
            array('%s'),
            array('%d')
        );
    }

    /**
     * Create or update a survey progress record linked to a Stripe session.
     * Called immediately after successful payment to generate a save token.
     */
    public static function create_or_update_survey_progress($stripe_session_id, $customer_data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, survey_token FROM $table_name WHERE stripe_session_id = %s LIMIT 1",
            $stripe_session_id
        ));

        if ($existing) {
            if (empty($existing->survey_token)) {
                $token = bin2hex(random_bytes(32));
                $wpdb->update($table_name, array('survey_token' => $token), array('id' => $existing->id));
                return $token;
            }
            return $existing->survey_token;
        }

        $token  = bin2hex(random_bytes(32));

        error_log('🔍 [SURVEY DB] create_or_update_survey_progress - INSERTING:');
        error_log('  customer_data[name]: ' . ($customer_data['name'] ?? 'MISSING'));
        error_log('  customer_data[business_name]: ' . ($customer_data['business_name'] ?? 'MISSING'));
        error_log('  customer_data[email]: ' . ($customer_data['email'] ?? 'MISSING'));

        $result = $wpdb->insert($table_name, array(
            'stripe_session_id'  => sanitize_text_field($stripe_session_id),
            'stripe_customer_id' => sanitize_text_field($customer_data['customer_id'] ?? ''),
            'customer_name'      => sanitize_text_field($customer_data['name'] ?? ''),
            'business_name'      => sanitize_text_field($customer_data['business_name'] ?? ''),
            'customer_email'     => sanitize_email($customer_data['email'] ?? ''),
            'payment_amount'     => floatval($customer_data['payment_amount'] ?? 0),
            'payment_status'     => 'paid',
            'payment_date'       => current_time('mysql'),
            'survey_token'       => $token,
            'survey_step'        => 0,
            'survey_completed'   => 0,
            'status'             => 'pending_survey',
        ));

        if ($result) {
            error_log('  ✅ INSERT successful - token: ' . $token);
        } else {
            error_log('  ❌ INSERT FAILED - error: ' . $wpdb->last_error);
        }

        return $result ? $token : false;
    }

    /**
     * Save survey progress per step (auto-save).
     */
    public static function save_survey_progress($token, $step, $answers) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';
        $token = sanitize_text_field($token);
        $step = intval($step);

        $existing = self::get_submission_by_token($token);
        if (!$existing) {
            return false;
        }

        // Never allow autosave races to move a user backward in step index.
        $safe_step = max(intval($existing->survey_step), $step);

        return false !== $wpdb->update(
            $table_name,
            array(
                'survey_step'       => $safe_step,
                'survey_progress'   => wp_json_encode($answers),
                'survey_last_saved' => current_time('mysql'),
                'last_activity'     => current_time('mysql'),
            ),
            array('survey_token' => $token),
            array('%d', '%s', '%s', '%s'),
            array('%s')
        );
    }

    /**
     * Get a submission by its survey token.
     */
    public static function get_submission_by_token($token) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE survey_token = %s LIMIT 1",
            sanitize_text_field($token)
        ));
    }

    /**
     * Get a submission by Stripe Checkout Session ID.
     */
    public static function get_submission_by_stripe_session_id($stripe_session_id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE stripe_session_id = %s LIMIT 1",
            sanitize_text_field($stripe_session_id)
        ));
    }

    /**
     * Mark a survey as completed (called on final submit).
     */
    public static function mark_survey_completed($token) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return false !== $wpdb->update(
            $table_name,
            array('survey_completed' => 1, 'status' => 'new'),
            array('survey_token' => sanitize_text_field($token)),
            array('%d', '%s'),
            array('%s')
        );
    }

    /**
     * Finalize an existing tokenized survey row with full survey submission data.
     * Keeps original Stripe/customer fields when those values are omitted from payload.
     *
     * @param string $token Survey token
     * @param array  $data  Submission payload
     * @return int|false Submission ID on success, false on failure
     */
    public static function finalize_submission_by_token($token, $data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        $token = sanitize_text_field($token);
        if (empty($token)) {
            return false;
        }

        $existing = self::get_submission_by_token($token);
        if (!$existing) {
            return false;
        }

        $update_data = array(
            'stripe_customer_id' => sanitize_text_field($data['stripe_customer_id'] ?? $existing->stripe_customer_id),
            'stripe_session_id' => sanitize_text_field($data['stripe_session_id'] ?? $existing->stripe_session_id),
            'customer_name' => sanitize_text_field($data['customer_name'] ?? $existing->customer_name),
            'customer_email' => sanitize_email($data['customer_email'] ?? $existing->customer_email),
            'payment_amount' => floatval($data['payment_amount'] ?? $existing->payment_amount),
            'business_name' => sanitize_text_field($data['business_name'] ?? ''),
            'industry' => sanitize_text_field($data['industry'] ?? ''),
            'custom_industry' => sanitize_text_field($data['custom_industry'] ?? ''),
            'tagline' => wp_kses_post($data['tagline'] ?? ''),
            'services' => wp_kses_post($data['services'] ?? ''),
            'hours' => is_array($data['hours'] ?? null) ? wp_json_encode($data['hours']) : '',
            'booking' => is_array($data['booking'] ?? null) ? wp_json_encode($data['booking']) : '',
            'contact_phone' => sanitize_text_field($data['contact_phone'] ?? ''),
            'contact_email' => sanitize_email($data['contact_email'] ?? ''),
            'contact_address' => sanitize_text_field($data['contact_address'] ?? ''),
            'socials' => is_array($data['socials'] ?? null) ? wp_json_encode($data['socials']) : '',
            'brand' => is_array($data['brand'] ?? null) ? wp_json_encode($data['brand']) : '',
            'brand_colors' => sanitize_text_field($data['brand_colors'] ?? ''),
            'brand_slogan' => sanitize_text_field($data['brand_slogan'] ?? ''),
            'logo_path' => sanitize_text_field($data['logo_path'] ?? ''),
            'file_paths' => is_array($data['file_paths'] ?? null) ? wp_json_encode($data['file_paths']) : '',
            'extra' => wp_kses_post($data['extra'] ?? ''),
            'submitted_at' => current_time('mysql'),
            'survey_completed' => 1,
            'status' => 'new',
        );

        $result = $wpdb->update(
            $table_name,
            $update_data,
            array('id' => intval($existing->id)),
            null,
            array('%d')
        );

        return $result !== false ? intval($existing->id) : false;
    }

    /**
     * Delete a submission and its associated files
     */
    public static function delete_submission($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        // Get submission to delete associated files
        $submission = self::get_submission($id);

        if ($submission) {
            self::remember_deleted_reference($submission->survey_token ?? '', $submission->stripe_session_id ?? '');

            // Delete logo file
            if (!empty($submission->logo_path)) {
                $logo_file = self::resolve_stored_file_path($submission->logo_path);
                if (!empty($logo_file) && file_exists($logo_file)) {
                    @unlink($logo_file);
                }
            }

            // Delete other files
            if (!empty($submission->file_paths)) {
                $file_paths = json_decode($submission->file_paths, true);
                if (is_array($file_paths)) {
                    foreach ($file_paths as $file_path) {
                        $file = self::resolve_stored_file_path($file_path);
                        if (!empty($file) && file_exists($file)) {
                            @unlink($file);
                        }
                    }
                }
            }
        }

        return $wpdb->delete($table_name, array('id' => intval($id)), array('%d'));
    }

    /**
     * Delete all survey submissions and any uploaded survey files.
     *
     * @return array
     */
    public static function clear_all_submissions_and_files() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'sec_survey_submissions';
        $submissions = $wpdb->get_results("SELECT survey_token, stripe_session_id, logo_path, file_paths FROM $table_name");

        $deleted_files = 0;

        if (is_array($submissions)) {
            foreach ($submissions as $submission) {
                self::remember_deleted_reference($submission->survey_token ?? '', $submission->stripe_session_id ?? '');

                if (!empty($submission->logo_path)) {
                    $logo_file = self::resolve_stored_file_path($submission->logo_path);
                    if (!empty($logo_file) && file_exists($logo_file) && @unlink($logo_file)) {
                        $deleted_files++;
                    }
                }

                if (!empty($submission->file_paths)) {
                    $file_paths = json_decode($submission->file_paths, true);
                    if (is_array($file_paths)) {
                        foreach ($file_paths as $file_path) {
                            $file = self::resolve_stored_file_path($file_path);
                            if (!empty($file) && file_exists($file) && @unlink($file)) {
                                $deleted_files++;
                            }
                        }
                    }
                }
            }
        }

        // Clean up any orphan files in known survey upload directories.
        $locations = self::get_survey_upload_locations();
        foreach ($locations as $location) {
            $dir = trailingslashit($location['dir']);
            if (!is_dir($dir)) {
                continue;
            }

            $entries = @scandir($dir);
            if ($entries === false) {
                continue;
            }

            foreach ($entries as $entry) {
                if ($entry === '.' || $entry === '..' || $entry === '.htaccess' || $entry === 'index.php') {
                    continue;
                }

                $file_path = $dir . $entry;
                if (is_file($file_path) && @unlink($file_path)) {
                    $deleted_files++;
                }
            }
        }

        $deleted_rows = (int) $wpdb->query("DELETE FROM $table_name");

        return array(
            'deleted_rows' => $deleted_rows,
            'deleted_files' => $deleted_files,
        );
    }
}
