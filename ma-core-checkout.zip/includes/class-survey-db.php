<?php
/**
 * Survey Database Handler
 *
 * Handles all database operations for survey submissions
 */

if (!defined('ABSPATH')) exit;

class SEC_Survey_DB {

    /**
     * Create survey submissions table
     */
    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            stripe_customer_id varchar(255) NOT NULL,
            stripe_session_id varchar(255) NOT NULL,
            customer_name varchar(255) NOT NULL,
            customer_email varchar(255) NOT NULL,
            payment_amount decimal(10,2) NOT NULL DEFAULT 0.00,
            business_name varchar(255) DEFAULT '',
            industry varchar(255) DEFAULT '',
            custom_industry varchar(255) DEFAULT '',
            tagline text DEFAULT NULL,
            services text DEFAULT NULL,
            hours longtext DEFAULT NULL,
            booking text DEFAULT NULL,
            contact_phone varchar(50) DEFAULT '',
            contact_email varchar(255) DEFAULT '',
            contact_address varchar(255) DEFAULT '',
            socials longtext DEFAULT NULL,
            brand text DEFAULT NULL,
            brand_colors varchar(255) DEFAULT '',
            brand_slogan varchar(255) DEFAULT '',
            logo_path varchar(500) DEFAULT '',
            file_paths longtext DEFAULT NULL,
            extra text DEFAULT NULL,
            submitted_at datetime DEFAULT CURRENT_TIMESTAMP,
            status varchar(50) DEFAULT 'new',
            survey_token varchar(64) DEFAULT NULL,
            survey_progress longtext DEFAULT NULL,
            survey_step int(11) DEFAULT 0,
            survey_completed tinyint(1) DEFAULT 0,
            survey_last_saved datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_customer_id (stripe_customer_id),
            KEY idx_email (customer_email),
            KEY idx_status (status),
            KEY idx_submitted (submitted_at),
            UNIQUE KEY idx_survey_token (survey_token)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Create upload directory
        $upload_dir = wp_upload_dir();
        $survey_dir = $upload_dir['basedir'] . '/survey-images/';

        if (!file_exists($survey_dir)) {
            wp_mkdir_p($survey_dir);

            // Add .htaccess for security
            $htaccess_content = "Options -Indexes\n<Files *.php>\ndeny from all\n</Files>";
            file_put_contents($survey_dir . '.htaccess', $htaccess_content);

            // Add index.php for security
            file_put_contents($survey_dir . 'index.php', '<?php // Silence is golden');
        }
    }

    /**
     * Insert a new survey submission
     *
     * @param array $data Survey submission data
     * @return int|false Insert ID on success, false on failure
     */
    public static function insert_submission($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        // Prepare data for insertion
        $insert_data = array(
            'stripe_customer_id' => sanitize_text_field($data['stripe_customer_id']),
            'stripe_session_id' => sanitize_text_field($data['stripe_session_id']),
            'customer_name' => sanitize_text_field($data['customer_name']),
            'customer_email' => sanitize_email($data['customer_email']),
            'payment_amount' => floatval($data['payment_amount']),
            'business_name' => sanitize_text_field($data['business_name'] ?? ''),
            'industry' => sanitize_text_field($data['industry'] ?? ''),
            'custom_industry' => sanitize_text_field($data['custom_industry'] ?? ''),
            'tagline' => wp_kses_post($data['tagline'] ?? ''),
            'services' => wp_kses_post($data['services'] ?? ''),
            'hours' => is_array($data['hours'] ?? null) ? json_encode($data['hours']) : '',
            'booking' => is_array($data['booking'] ?? null) ? json_encode($data['booking']) : '',
            'contact_phone' => sanitize_text_field($data['contact_phone'] ?? ''),
            'contact_email' => sanitize_email($data['contact_email'] ?? ''),
            'contact_address' => sanitize_text_field($data['contact_address'] ?? ''),
            'socials' => is_array($data['socials'] ?? null) ? json_encode($data['socials']) : '',
            'brand' => is_array($data['brand'] ?? null) ? json_encode($data['brand']) : '',
            'brand_colors' => sanitize_text_field($data['brand_colors'] ?? ''),
            'brand_slogan' => sanitize_text_field($data['brand_slogan'] ?? ''),
            'logo_path' => sanitize_text_field($data['logo_path'] ?? ''),
            'file_paths' => is_array($data['file_paths'] ?? null) ? json_encode($data['file_paths']) : '',
            'extra' => wp_kses_post($data['extra'] ?? ''),
            'status' => 'new'
        );

        $result = $wpdb->insert($table_name, $insert_data);

        if ($result) {
            return $wpdb->insert_id;
        }

        return false;
    }

    /**
     * Get a submission by ID
     */
    public static function get_submission($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $id
        ));
    }

    /**
     * Get all submissions with optional filtering
     */
    public static function get_submissions($args = array()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        $defaults = array(
            'status' => '',
            'limit' => 20,
            'offset' => 0,
            'orderby' => 'submitted_at',
            'order' => 'DESC'
        );

        $args = wp_parse_args($args, $defaults);

        $where = '1=1';
        if (!empty($args['status'])) {
            $where .= $wpdb->prepare(' AND status = %s', $args['status']);
        }

        $query = "SELECT * FROM $table_name WHERE $where ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d";

        return $wpdb->get_results($wpdb->prepare($query, $args['limit'], $args['offset']));
    }

    /**
     * Get submission count
     */
    public static function get_submission_count($status = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        if (!empty($status)) {
            return $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name WHERE status = %s",
                $status
            ));
        }

        return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    }

    /**
     * Update submission status
     */
    public static function update_status($id, $status) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return $wpdb->update(
            $table_name,
            array('status' => sanitize_text_field($status)),
            array('id' => intval($id)),
            array('%s'),
            array('%d')
        );
    }

    /**
     * Create or update a survey progress record linked to a Stripe session.
     * Called immediately after successful payment to generate a save token.
     */
    public static function create_or_update_survey_progress($stripe_session_id, $customer_data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, survey_token FROM $table_name WHERE stripe_session_id = %s LIMIT 1",
            $stripe_session_id
        ));

        if ($existing) {
            if (empty($existing->survey_token)) {
                $token = bin2hex(random_bytes(32));
                $wpdb->update($table_name, array('survey_token' => $token), array('id' => $existing->id));
                return $token;
            }
            return $existing->survey_token;
        }

        $token  = bin2hex(random_bytes(32));
        $result = $wpdb->insert($table_name, array(
            'stripe_session_id'  => sanitize_text_field($stripe_session_id),
            'stripe_customer_id' => sanitize_text_field($customer_data['customer_id'] ?? ''),
            'customer_name'      => sanitize_text_field($customer_data['name'] ?? ''),
            'customer_email'     => sanitize_email($customer_data['email'] ?? ''),
            'payment_amount'     => floatval($customer_data['payment_amount'] ?? 0),
            'survey_token'       => $token,
            'survey_step'        => 0,
            'survey_completed'   => 0,
            'status'             => 'pending_survey',
        ));

        return $result ? $token : false;
    }

    /**
     * Save survey progress per step (auto-save).
     */
    public static function save_survey_progress($token, $step, $answers) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return false !== $wpdb->update(
            $table_name,
            array(
                'survey_step'       => intval($step),
                'survey_progress'   => wp_json_encode($answers),
                'survey_last_saved' => current_time('mysql'),
            ),
            array('survey_token' => sanitize_text_field($token)),
            array('%d', '%s', '%s'),
            array('%s')
        );
    }

    /**
     * Get a submission by its survey token.
     */
    public static function get_submission_by_token($token) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE survey_token = %s LIMIT 1",
            sanitize_text_field($token)
        ));
    }

    /**
     * Mark a survey as completed (called on final submit).
     */
    public static function mark_survey_completed($token) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        return false !== $wpdb->update(
            $table_name,
            array('survey_completed' => 1, 'status' => 'new'),
            array('survey_token' => sanitize_text_field($token)),
            array('%d', '%s'),
            array('%s')
        );
    }

    /**
     * Delete a submission and its associated files
     */
    public static function delete_submission($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_survey_submissions';

        // Get submission to delete associated files
        $submission = self::get_submission($id);

        if ($submission) {
            // Delete logo file
            if (!empty($submission->logo_path)) {
                $upload_dir = wp_upload_dir();
                $logo_file = $upload_dir['basedir'] . '/survey-images/' . basename($submission->logo_path);
                if (file_exists($logo_file)) {
                    @unlink($logo_file);
                }
            }

            // Delete other files
            if (!empty($submission->file_paths)) {
                $file_paths = json_decode($submission->file_paths, true);
                if (is_array($file_paths)) {
                    foreach ($file_paths as $file_path) {
                        $upload_dir = wp_upload_dir();
                        $file = $upload_dir['basedir'] . '/survey-images/' . basename($file_path);
                        if (file_exists($file)) {
                            @unlink($file);
                        }
                    }
                }
            }
        }

        return $wpdb->delete($table_name, array('id' => intval($id)), array('%d'));
    }
}
