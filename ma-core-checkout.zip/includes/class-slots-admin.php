<?php
/**
 * Activation Slots Admin Page
 *
 * Provides admin interface for managing activation slots and waitlist
 */

if (!defined('ABSPATH')) exit;

class SEC_Slots_Admin {

    /**
     * Initialize admin page
     */
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_admin_assets'));
    }

    /**
     * Add admin menu item
     */
    public static function add_admin_menu() {
        add_menu_page(
            'Activation Slots',
            'Activation Slots',
            'manage_options',
            'sec-activation-slots',
            array(__CLASS__, 'render_admin_page'),
            'dashicons-calendar-alt',
            25
        );
    }

    /**
     * Enqueue admin assets
     */
    public static function enqueue_admin_assets($hook) {
        if ($hook !== 'toplevel_page_sec-activation-slots') {
            return;
        }

        wp_enqueue_style(
            'sec-slots-admin',
            plugin_dir_url(dirname(__FILE__)) . 'assets/css/slots-admin.css',
            array(),
            '1.0.0'
        );

        wp_enqueue_script(
            'sec-slots-admin',
            plugin_dir_url(dirname(__FILE__)) . 'assets/js/slots-admin.js',
            array('jquery'),
            '1.0.0',
            true
        );

        wp_localize_script('sec-slots-admin', 'secSlotsAdmin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => rest_url('sec/v1/'),
            'nonce' => wp_create_nonce('sec_admin_nonce'),
            'waitlist_nonce' => wp_create_nonce('sec_waitlist_nonce')
        ));
    }

    /**
     * Render admin page
     */
    public static function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die('You do not have permission to access this page.');
        }

        // Get current status
        $summary = SEC_Activation_Slots::admin_summary();
        $waitlist = SEC_Activation_Slots::get_waitlist();

        ?>
        <div class="wrap sec-slots-admin">
            <h1>🎯 Activation Slots Manager</h1>

            <!-- Status Cards -->
            <div class="sec-status-cards">
                <div class="sec-card sec-card-total">
                    <div class="sec-card-icon">📊</div>
                    <div class="sec-card-content">
                        <div class="sec-card-label">Total Slots</div>
                        <div class="sec-card-value"><?php echo esc_html($summary['total']); ?></div>
                    </div>
                </div>

                <div class="sec-card sec-card-active">
                    <div class="sec-card-icon">🔴</div>
                    <div class="sec-card-content">
                        <div class="sec-card-label">Active</div>
                        <div class="sec-card-value"><?php echo esc_html($summary['active']); ?></div>
                    </div>
                </div>

                <div class="sec-card sec-card-available">
                    <div class="sec-card-icon">🟢</div>
                    <div class="sec-card-content">
                        <div class="sec-card-label">Available</div>
                        <div class="sec-card-value"><?php echo esc_html($summary['available']); ?></div>
                    </div>
                </div>

                <div class="sec-card sec-card-waitlist">
                    <div class="sec-card-icon">⏳</div>
                    <div class="sec-card-content">
                        <div class="sec-card-label">Waitlist</div>
                        <div class="sec-card-value"><?php echo esc_html($summary['waitlist_count']); ?></div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="sec-section">
                <h2>⚡ Quick Actions</h2>
                <div class="sec-actions-grid">
                    <!-- Free Slots -->
                    <div class="sec-action-card">
                        <h3>Free Slots</h3>
                        <p>Release active slots and notify waitlist members</p>
                        <form id="free-slots-form" class="sec-form">
                            <div class="sec-form-row">
                                <label for="free-count">Number of slots to free:</label>
                                <input type="number" id="free-count" min="1" max="<?php echo esc_attr($summary['active']); ?>" value="1" <?php echo $summary['active'] === 0 ? 'disabled' : ''; ?>>
                            </div>
                            <button type="submit" class="button button-primary" <?php echo $summary['active'] === 0 ? 'disabled' : ''; ?>>
                                🔓 Free Slots
                            </button>
                        </form>
                    </div>

                    <!-- Reserve Slots -->
                    <div class="sec-action-card">
                        <h3>Reserve Slots</h3>
                        <p>Manually reserve slots for 24 hours</p>
                        <form id="reserve-slots-form" class="sec-form">
                            <div class="sec-form-row">
                                <label for="reserve-count">Number of slots to reserve:</label>
                                <input type="number" id="reserve-count" min="1" max="<?php echo esc_attr($summary['available']); ?>" value="1" <?php echo $summary['available'] === 0 ? 'disabled' : ''; ?>>
                            </div>
                            <button type="submit" class="button button-secondary" <?php echo $summary['available'] === 0 ? 'disabled' : ''; ?>>
                                🔒 Reserve Slots
                            </button>
                        </form>
                    </div>

                    <!-- Refresh Status -->
                    <div class="sec-action-card">
                        <h3>Refresh Status</h3>
                        <p>Check for expired slots and update counts</p>
                        <button id="refresh-status" class="button button-secondary">
                            🔄 Refresh Now
                        </button>
                    </div>
                </div>
            </div>

            <!-- Slots Grid -->
            <div class="sec-section">
                <h2>📅 Slot Status</h2>
                <div id="slots-grid" class="sec-slots-grid">
                    <?php foreach ($summary['slots'] as $index => $slot): ?>
                    <div class="sec-slot <?php echo $slot['active'] ? 'sec-slot-active' : 'sec-slot-available'; ?>" data-index="<?php echo esc_attr($index); ?>">
                        <div class="sec-slot-number">Slot #<?php echo esc_html($index + 1); ?></div>
                        <div class="sec-slot-status">
                            <?php if ($slot['active']): ?>
                                <span class="sec-status-badge sec-badge-active">Active</span>
                                <?php
                                $expires_in = ($slot['claimed_at'] + 86400) - time();
                                $hours = floor($expires_in / 3600);
                                $minutes = floor(($expires_in % 3600) / 60);
                                ?>
                                <div class="sec-slot-timer">⏱️ <?php echo esc_html($hours . 'h ' . $minutes . 'm'); ?></div>
                                <div class="sec-slot-email"><?php echo esc_html($slot['email']); ?></div>
                            <?php else: ?>
                                <span class="sec-status-badge sec-badge-available">Available</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Waitlist -->
            <?php if (!empty($waitlist)): ?>
            <div class="sec-section">
                <h2>⏳ Waitlist (<?php echo count($waitlist); ?> people)</h2>
                <div class="sec-waitlist-table">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th style="width: 50px;">#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Added</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($waitlist as $index => $entry): ?>
                            <tr>
                                <td><?php echo esc_html($index + 1); ?></td>
                                <td><?php echo esc_html($entry['name'] ?: 'N/A'); ?></td>
                                <td><?php echo esc_html($entry['email']); ?></td>
                                <td><?php echo esc_html(human_time_diff($entry['added_at'], time()) . ' ago'); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php else: ?>
            <div class="sec-section">
                <h2>⏳ Waitlist</h2>
                <div class="sec-empty-state">
                    <p>✨ No one is waiting. All good!</p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Messages -->
            <div id="sec-message" class="sec-message" style="display: none;"></div>
        </div>
        <?php
    }
}

// Initialize
SEC_Slots_Admin::init();
