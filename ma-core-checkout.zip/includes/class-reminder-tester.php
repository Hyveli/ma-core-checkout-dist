<?php
/**
 * Survey Reminder Testing Tool
 *
 * Provides admin interface to test reminder emails without waiting real time.
 * Features:
 * - Time simulation (fast-forward time for testing)
 * - Dry run mode (preview what would be sent without sending)
 * - Reset reminder flags
 * - Manual trigger
 */

if (!defined('ABSPATH')) exit;

class SEC_Reminder_Tester {

    public static function init() {
        // Add admin menu
        add_action('admin_menu', array(__CLASS__, 'add_admin_menu'));

        // AJAX handlers
        add_action('wp_ajax_sec_test_reminders', array(__CLASS__, 'ajax_test_reminders'));
        add_action('wp_ajax_sec_reset_reminders', array(__CLASS__, 'ajax_reset_reminders'));
        add_action('wp_ajax_sec_preview_reminder', array(__CLASS__, 'ajax_preview_reminder'));
    }

    /**
     * Add testing page to admin menu
     */
    public static function add_admin_menu() {
        add_submenu_page(
            'options-general.php',
            'Survey Reminder Tester',
            '🧪 Reminder Tester',
            'manage_options',
            'sec-reminder-tester',
            array(__CLASS__, 'render_admin_page')
        );
    }

    /**
     * Render admin testing interface
     */
    public static function render_admin_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';

        // Get incomplete surveys
        $incomplete = $wpdb->get_results("
            SELECT
                id,
                customer_name,
                customer_email,
                payment_date,
                survey_step,
                reminder_1_sent,
                reminder_1_sent_at,
                reminder_2_sent,
                reminder_2_sent_at,
                reminder_3_sent,
                reminder_3_sent_at,
                reminder_4_sent,
                reminder_4_sent_at
            FROM {$table}
            WHERE survey_completed = 0
            ORDER BY payment_date DESC
        ");

        ?>
        <div class="wrap">
            <h1>🧪 Survey Reminder Testing Tool</h1>

            <div class="notice notice-info">
                <p><strong>How to use:</strong></p>
                <ul style="margin-left: 20px;">
                    <li>✅ <strong>Dry Run:</strong> Preview what emails would be sent without actually sending them</li>
                    <li>⏰ <strong>Simulate Time:</strong> Fast-forward time to test reminders at 1h, 24h, 72h, 7d intervals</li>
                    <li>🔄 <strong>Reset Flags:</strong> Clear reminder flags to test sending multiple times</li>
                    <li>📧 <strong>Send Test:</strong> Actually send reminder emails to test addresses</li>
                </ul>
            </div>

            <div class="card" style="max-width: 100%; margin-top: 20px;">
                <h2>⚙️ Testing Controls</h2>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-bottom: 20px;">

                    <!-- Dry Run -->
                    <div style="padding: 15px; border: 2px solid #2271b1; border-radius: 8px;">
                        <h3 style="margin-top: 0;">👁️ Dry Run (Preview Only)</h3>
                        <p style="font-size: 13px; color: #666;">See what would be sent without sending emails</p>
                        <button type="button" class="button button-primary" onclick="testReminders(true)">
                            Preview Reminders
                        </button>
                        <div id="preview-output" style="margin-top: 10px;"></div>
                    </div>

                    <!-- Time Simulation -->
                    <div style="padding: 15px; border: 2px solid #d63638; border-radius: 8px;">
                        <h3 style="margin-top: 0;">⏰ Simulate Time</h3>
                        <p style="font-size: 13px; color: #666;">Fast-forward time for testing</p>
                        <select id="time-offset" class="regular-text">
                            <option value="0">Current time (no offset)</option>
                            <option value="3600">+1 hour (Reminder 1)</option>
                            <option value="86400">+24 hours (Reminder 2)</option>
                            <option value="259200">+72 hours (Reminder 3)</option>
                            <option value="604800">+7 days (Reminder 4)</option>
                        </select>
                        <button type="button" class="button" onclick="testReminders(false)" style="margin-top: 10px;">
                            Test with Time Offset
                        </button>
                    </div>

                    <!-- Reset Flags -->
                    <div style="padding: 15px; border: 2px solid #dba617; border-radius: 8px;">
                        <h3 style="margin-top: 0;">🔄 Reset Reminders</h3>
                        <p style="font-size: 13px; color: #666;">Clear all reminder flags to test again</p>
                        <button type="button" class="button button-secondary" onclick="resetReminders()">
                            Reset All Flags
                        </button>
                        <div id="reset-output" style="margin-top: 10px;"></div>
                    </div>

                </div>

                <div id="test-results" style="margin-top: 20px;"></div>
            </div>

            <div class="card" style="max-width: 100%; margin-top: 20px;">
                <h2>📊 Incomplete Surveys (<?php echo count($incomplete); ?>)</h2>

                <?php if (empty($incomplete)): ?>
                    <p style="color: #666;">No incomplete surveys found. Complete a payment and don't finish the survey to test reminders.</p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Customer</th>
                                <th>Email</th>
                                <th>Payment Date</th>
                                <th>Step</th>
                                <th>R1</th>
                                <th>R2</th>
                                <th>R3</th>
                                <th>R4</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($incomplete as $sub): ?>
                                <tr>
                                    <td><?php echo $sub->id; ?></td>
                                    <td><?php echo esc_html($sub->customer_name); ?></td>
                                    <td><?php echo esc_html($sub->customer_email); ?></td>
                                    <td><?php echo esc_html($sub->payment_date); ?></td>
                                    <td><?php echo $sub->survey_step; ?>/11</td>
                                    <td><?php echo $sub->reminder_1_sent ? '✅ ' . $sub->reminder_1_sent_at : '❌'; ?></td>
                                    <td><?php echo $sub->reminder_2_sent ? '✅ ' . $sub->reminder_2_sent_at : '❌'; ?></td>
                                    <td><?php echo $sub->reminder_3_sent ? '✅ ' . $sub->reminder_3_sent_at : '❌'; ?></td>
                                    <td><?php echo $sub->reminder_4_sent ? '✅ ' . $sub->reminder_4_sent_at : '❌'; ?></td>
                                    <td>
                                        <button class="button button-small" onclick="resetSingleReminder(<?php echo $sub->id; ?>)">Reset</button>
                                        <button class="button button-small button-primary" onclick="previewSingleReminder(<?php echo $sub->id; ?>)">Preview</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <script>
        function testReminders(dryRun) {
            const timeOffset = document.getElementById('time-offset').value;
            const output = document.getElementById('test-results');

            output.innerHTML = '<div class="notice notice-info"><p>⏳ Processing...</p></div>';

            jQuery.post(ajaxurl, {
                action: 'sec_test_reminders',
                dry_run: dryRun ? '1' : '0',
                time_offset: timeOffset,
                nonce: '<?php echo wp_create_nonce('sec_reminder_test'); ?>'
            }, function(response) {
                if (response.success) {
                    output.innerHTML = response.data.html;
                } else {
                    output.innerHTML = '<div class="notice notice-error"><p>' + response.data + '</p></div>';
                }
            });
        }

        function resetReminders() {
            if (!confirm('Reset all reminder flags? This will allow reminders to be sent again.')) return;

            const output = document.getElementById('reset-output');
            output.innerHTML = '⏳ Resetting...';

            jQuery.post(ajaxurl, {
                action: 'sec_reset_reminders',
                nonce: '<?php echo wp_create_nonce('sec_reminder_test'); ?>'
            }, function(response) {
                if (response.success) {
                    output.innerHTML = '<span style="color: #46b450;">✅ ' + response.data.message + '</span>';
                    setTimeout(() => location.reload(), 1500);
                } else {
                    output.innerHTML = '<span style="color: #dc3232;">❌ Error</span>';
                }
            });
        }

        function resetSingleReminder(id) {
            if (!confirm('Reset reminders for this submission?')) return;

            jQuery.post(ajaxurl, {
                action: 'sec_reset_reminders',
                submission_id: id,
                nonce: '<?php echo wp_create_nonce('sec_reminder_test'); ?>'
            }, function(response) {
                if (response.success) {
                    location.reload();
                }
            });
        }

        function previewSingleReminder(id) {
            // TODO: Implement preview for single submission
            alert('Preview feature coming soon');
        }
        </script>

        <style>
        .card {
            background: #fff;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            padding: 20px;
            box-shadow: 0 1px 1px rgba(0,0,0,.04);
        }
        .card h2 {
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }
        </style>
        <?php
    }

    /**
     * AJAX: Test reminders with optional time offset
     */
    public static function ajax_test_reminders() {
        check_ajax_referer('sec_reminder_test', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $dry_run = isset($_POST['dry_run']) && $_POST['dry_run'] === '1';
        $time_offset = isset($_POST['time_offset']) ? intval($_POST['time_offset']) : 0;

        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';

        $incomplete = $wpdb->get_results("
            SELECT * FROM {$table}
            WHERE survey_completed = 0
              AND survey_token IS NOT NULL
              AND survey_token != ''
        ");

        $results = array();
        $simulated_time = time() + $time_offset;

        foreach ($incomplete as $submission) {
            if (empty($submission->payment_date) || $submission->payment_date === '0000-00-00 00:00:00') {
                continue;
            }

            $payment_time = strtotime($submission->payment_date);
            $time_since_payment = $simulated_time - $payment_time;

            // Determine which reminder would be sent
            $reminder_to_send = null;

            if (!$submission->reminder_1_sent && $time_since_payment >= 3600) {
                $reminder_to_send = 1;
            } elseif (!$submission->reminder_2_sent && $time_since_payment >= 86400) {
                $reminder_to_send = 2;
            } elseif (!$submission->reminder_3_sent && $time_since_payment >= 259200) {
                $reminder_to_send = 3;
            } elseif (!$submission->reminder_4_sent && $time_since_payment >= 604800) {
                $reminder_to_send = 4;
            }

            if ($reminder_to_send) {
                $results[] = array(
                    'submission_id' => $submission->id,
                    'customer_email' => $submission->customer_email,
                    'customer_name' => $submission->customer_name,
                    'reminder_number' => $reminder_to_send,
                    'time_since_payment' => $time_since_payment,
                    'hours_since_payment' => round($time_since_payment / 3600, 1)
                );

                // Actually send if not dry run
                if (!$dry_run && class_exists('SEC_Survey_Reminders')) {
                    // Temporarily set time offset
                    self::send_test_reminder($submission, $reminder_to_send);
                }
            }
        }

        // Generate HTML output
        $html = self::generate_test_results_html($results, $dry_run, $time_offset);

        wp_send_json_success(array('html' => $html));
    }

    /**
     * Generate HTML for test results
     */
    private static function generate_test_results_html($results, $dry_run, $time_offset) {
        if (empty($results)) {
            return '<div class="notice notice-warning"><p>⚠️ No reminders would be sent with current settings.</p></div>';
        }

        $mode = $dry_run ? '👁️ DRY RUN (Preview Only)' : '📧 LIVE TEST (Emails Sent)';
        $offset_hours = round($time_offset / 3600, 1);

        $html = '<div class="notice notice-' . ($dry_run ? 'info' : 'success') . '">';
        $html .= '<p><strong>' . $mode . '</strong></p>';
        if ($time_offset > 0) {
            $html .= '<p>⏰ Time simulated: +' . $offset_hours . ' hours</p>';
        }
        $html .= '</div>';

        $html .= '<table class="wp-list-table widefat fixed striped">';
        $html .= '<thead><tr>';
        $html .= '<th>Customer</th>';
        $html .= '<th>Email</th>';
        $html .= '<th>Reminder #</th>';
        $html .= '<th>Hours Since Payment</th>';
        $html .= '<th>Subject</th>';
        $html .= '<th>Status</th>';
        $html .= '</tr></thead><tbody>';

        foreach ($results as $result) {
            $subjects = array(
                1 => 'Your website setup is waiting',
                2 => 'Quick reminder: Complete your setup',
                3 => "We're ready to build your site",
                4 => 'Final notice: Your onboarding spot is at risk'
            );

            $html .= '<tr>';
            $html .= '<td>' . esc_html($result['customer_name']) . '</td>';
            $html .= '<td>' . esc_html($result['customer_email']) . '</td>';
            $html .= '<td><strong>Reminder ' . $result['reminder_number'] . '</strong></td>';
            $html .= '<td>' . $result['hours_since_payment'] . 'h</td>';
            $html .= '<td>' . esc_html($subjects[$result['reminder_number']]) . '</td>';
            $html .= '<td>' . ($dry_run ? '👁️ Would send' : '✅ Sent') . '</td>';
            $html .= '</tr>';
        }

        $html .= '</tbody></table>';

        return $html;
    }

    /**
     * Send a test reminder
     */
    private static function send_test_reminder($submission, $reminder_number) {
        // This would trigger the actual email send
        // For now, just mark as sent
        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';
        $field = 'reminder_' . $reminder_number . '_sent';

        $wpdb->update(
            $table,
            array(
                $field => 1,
                'reminder_' . $reminder_number . '_sent_at' => current_time('mysql')
            ),
            array('id' => $submission->id),
            array('%d', '%s'),
            array('%d')
        );
    }

    /**
     * AJAX: Reset reminder flags
     */
    public static function ajax_reset_reminders() {
        check_ajax_referer('sec_reminder_test', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;
        $table = $wpdb->prefix . 'sec_survey_submissions';

        if (isset($_POST['submission_id'])) {
            // Reset single submission
            $id = intval($_POST['submission_id']);
            $wpdb->update(
                $table,
                array(
                    'reminder_1_sent' => 0,
                    'reminder_1_sent_at' => null,
                    'reminder_2_sent' => 0,
                    'reminder_2_sent_at' => null,
                    'reminder_3_sent' => 0,
                    'reminder_3_sent_at' => null,
                    'reminder_4_sent' => 0,
                    'reminder_4_sent_at' => null,
                ),
                array('id' => $id),
                array('%d', '%s', '%d', '%s', '%d', '%s', '%d', '%s'),
                array('%d')
            );
            $message = 'Reminder flags reset for submission #' . $id;
        } else {
            // Reset all incomplete surveys
            $wpdb->query("
                UPDATE {$table}
                SET reminder_1_sent = 0,
                    reminder_1_sent_at = NULL,
                    reminder_2_sent = 0,
                    reminder_2_sent_at = NULL,
                    reminder_3_sent = 0,
                    reminder_3_sent_at = NULL,
                    reminder_4_sent = 0,
                    reminder_4_sent_at = NULL
                WHERE survey_completed = 0
            ");
            $message = 'All reminder flags reset successfully';
        }

        wp_send_json_success(array('message' => $message));
    }
}

// Initialize
SEC_Reminder_Tester::init();
