<?php
/**
 * Plugin Name: Stripe Embedded Checkout
 * Description: Setup fee checkout with contact form, tokenized Stripe payment, and confirmation email
 * Version: 1.0.75
 * Author: Hyveli, LLC
 * Author URI: https://github.com/hyveli
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load the activation slots system
require_once plugin_dir_path(__FILE__) . 'sec-activation-slots.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-slots-admin.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-slots-frontend.php';

// Load survey system
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-db.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-email.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-modal.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-admin.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-page.php';

// Load branding settings
require_once plugin_dir_path(__FILE__) . 'includes/class-branding-settings.php';

// Load time simulator (for testing)
require_once plugin_dir_path(__FILE__) . 'includes/class-time-simulator.php';

// Load survey reminder system
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-reminders.php';

// Load survey migration (data normalization)
require_once plugin_dir_path(__FILE__) . 'includes/class-survey-migration.php';

SEC_Survey_Page::init();

class Stripe_Embedded_Checkout {

    private $stripe_publishable_key;
    private $stripe_secret_key;

    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('admin_menu', array($this, 'add_admin_menu'), 10);
        // Boot the slots system
        add_action('plugins_loaded', ['SEC_Activation_Slots', 'init']);
        // Initialize survey system
        add_action('plugins_loaded', ['SEC_Survey_Modal', 'init']);
        add_action('plugins_loaded', ['SEC_Survey_Admin', 'init']);
        register_activation_hook(__FILE__, array($this, 'activate'));
        // Register activation/deactivation hooks
        register_activation_hook(__FILE__,   ['SEC_Activation_Slots', 'activate']);
        register_deactivation_hook(__FILE__, ['SEC_Activation_Slots', 'deactivate']);
    }

    public function init() {
        // Stripe API keys must be defined in wp-config.php for security
        $this->stripe_publishable_key = defined('STRIPE_PUBLISHABLE_KEY') ? STRIPE_PUBLISHABLE_KEY : '';
        $this->stripe_secret_key = defined('STRIPE_SECRET_KEY') ? STRIPE_SECRET_KEY : '';

        add_shortcode('stripe_checkout_popup', array($this, 'checkout_popup_shortcode'));
        add_shortcode('stripe_embedded_checkout', array($this, 'embedded_checkout_shortcode'));
        add_shortcode('stripe_custom_invoice', array($this, 'custom_invoice_shortcode'));

        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

        add_action('wp_ajax_create_stripe_checkout', array($this, 'ajax_create_stripe_checkout'));
        add_action('wp_ajax_nopriv_create_stripe_checkout', array($this, 'ajax_create_stripe_checkout'));
        add_action('wp_ajax_sec_complete_embedded_checkout', array($this, 'ajax_complete_embedded_checkout'));
        add_action('wp_ajax_nopriv_sec_complete_embedded_checkout', array($this, 'ajax_complete_embedded_checkout'));
        add_action('wp_ajax_sec_refresh_nonce', array($this, 'ajax_refresh_nonce'));
        add_action('wp_ajax_nopriv_sec_refresh_nonce', array($this, 'ajax_refresh_nonce'));
        add_action('wp_ajax_apply_discount_code', array($this, 'ajax_apply_discount_code'));
        add_action('wp_ajax_nopriv_apply_discount_code', array($this, 'ajax_apply_discount_code'));
        add_action('wp_ajax_remove_discount_code', array($this, 'ajax_remove_discount_code'));
        add_action('wp_ajax_nopriv_remove_discount_code', array($this, 'ajax_remove_discount_code'));
        
        add_action('wp_ajax_generate_custom_invoice', array($this, 'ajax_generate_invoice'));
        add_action('wp_ajax_resend_invoice_email', array($this, 'ajax_resend_invoice_email'));
        add_action('wp_ajax_update_invoice_status', array($this, 'ajax_update_invoice_status'));

        add_action('admin_post_sec_delete_customer', array($this, 'handle_delete_customer'));

        add_action('template_redirect', array($this, 'handle_checkout_pages'));
        add_action('init', array($this, 'create_tables'));
    }

    public function activate() {
        $this->create_checkout_pages();
        $this->create_tables();
        flush_rewrite_rules();
    }

    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // Discount codes table
        $table_name = $wpdb->prefix . 'sec_discount_codes';
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            code varchar(50) NOT NULL,
            type enum('percentage','fixed') NOT NULL DEFAULT 'percentage',
            value decimal(10,2) NOT NULL,
            usage_limit int(11) DEFAULT NULL,
            usage_count int(11) DEFAULT 0,
            active tinyint(1) DEFAULT 1,
            expires_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY code (code)
        ) $charset_collate;";
        dbDelta($sql);

        // Customers table
        $customers_table = $wpdb->prefix . 'sec_customers';
        $sql2 = "CREATE TABLE $customers_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            stripe_customer_id varchar(255) NOT NULL,
            full_name varchar(255) NOT NULL,
            business_name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            phone varchar(50) NOT NULL,
            street_address varchar(255) DEFAULT '',
            city varchar(100) DEFAULT '',
            state varchar(100) DEFAULT '',
            zip_code varchar(20) DEFAULT '',
            membership_name varchar(255) DEFAULT '',
            amount_paid decimal(10,2) DEFAULT 0,
            stripe_session_id varchar(255) DEFAULT '',
            subscription_start_date datetime DEFAULT NULL,
            membership_renewal_date datetime DEFAULT NULL,
            hosting_renewal_date datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY stripe_customer_id (stripe_customer_id),
            KEY email (email)
        ) $charset_collate;";
        dbDelta($sql2);

        // Custom invoices table
        $invoices_table = $wpdb->prefix . 'sec_custom_invoices';
        $sql3 = "CREATE TABLE $invoices_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            invoice_number varchar(50) NOT NULL,
            token varchar(64) NOT NULL,
            customer_name varchar(255) NOT NULL,
            customer_email varchar(255) NOT NULL,
            customer_phone varchar(50) DEFAULT '',
            customer_address text DEFAULT NULL,
            items longtext NOT NULL,
            amount_subtotal decimal(10,2) NOT NULL,
            amount_tax decimal(10,2) DEFAULT 0,
            amount_total decimal(10,2) NOT NULL,
            stripe_session_id varchar(255) DEFAULT '',
            stripe_customer_id varchar(255) DEFAULT '',
            stripe_invoice_pdf_url text DEFAULT NULL,
            status enum('pending','paid','expired','voided') NOT NULL DEFAULT 'pending',
            expires_at datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            paid_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY token (token),
            UNIQUE KEY invoice_number (invoice_number),
            KEY status (status),
            KEY customer_email (customer_email)
        ) $charset_collate;";
        dbDelta($sql3);

        // Invoice branding settings table
        $branding_table = $wpdb->prefix . 'sec_invoice_settings';
        $sql4 = "CREATE TABLE $branding_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            setting_key varchar(100) NOT NULL,
            setting_value longtext DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY setting_key (setting_key)
        ) $charset_collate;";
        dbDelta($sql4);

        // Insert default branding settings if not exists
        $default_settings = array(
            'invoice_primary_color' => '#635BFF',
            'invoice_secondary_color' => '#0A2540',
            'invoice_business_name' => get_bloginfo('name'),
            'invoice_business_address' => '',
            'invoice_business_phone' => '',
            'invoice_support_email' => get_option('admin_email'),
            'invoice_logo_url' => '',
            'invoice_default_expiry_days' => '7',
            'invoice_auto_send_email' => '1',
            'invoice_include_pdf' => '1',
            'website_hosting_fee' => '25.00',
            'website_hosting_description' => 'Monthly website hosting and maintenance'
        );

        foreach ($default_settings as $key => $value) {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $branding_table WHERE setting_key = %s",
                $key
            ));
            if (!$exists) {
                $wpdb->insert($branding_table, array(
                    'setting_key' => $key,
                    'setting_value' => $value
                ));
            }
        }

        // Survey submissions table
        SEC_Survey_DB::create_table();
    }

    private function create_checkout_pages() {
        $page_slug = 'checkout';

        // Check if the page exists
        $existing_page = get_page_by_path($page_slug);

        // Also check for old membership-checkout page
        $old_page = get_page_by_path('membership-checkout');

        if (!$existing_page) {
            // If old page exists, update it
            if ($old_page) {
                wp_update_post(array(
                    'ID' => $old_page->ID,
                    'post_name' => $page_slug,
                    'post_title' => 'Checkout'
                ));
                update_post_meta($old_page->ID, '_sec_checkout_page', true);
            } else {
                // Create new page
                wp_insert_post(array(
                    'post_title' => 'Checkout',
                    'post_name' => $page_slug,
                    'post_content' => '[stripe_embedded_checkout]',
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'meta_input' => array(
                        '_sec_checkout_page' => true
                    )
                ));
            }
        } else {
            // Ensure the meta is set on existing page
            update_post_meta($existing_page->ID, '_sec_checkout_page', true);
        }
    }

    public function enqueue_scripts() {
        if (is_page() && (has_shortcode(get_post()->post_content, 'stripe_checkout_popup') ||
                         has_shortcode(get_post()->post_content, 'stripe_embedded_checkout'))) {

            wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, true);
            wp_enqueue_style('sec-popup-style', plugin_dir_url(__FILE__) . 'assets/sec-popup.css', array(), '2.1.6');
            wp_enqueue_script('sec-popup-script', plugin_dir_url(__FILE__) . 'assets/sec-popup.js', array('jquery', 'stripe-js'), '2.1.0', true);

            // Enqueue slot checking styles and scripts
            wp_enqueue_style('sec-slot-overlay', plugin_dir_url(__FILE__) . 'assets/css/slot-overlay.css', array(), '1.0.0');
            wp_enqueue_script('sec-slot-checker', plugin_dir_url(__FILE__) . 'assets/js/slot-checker.js', array('jquery', 'sec-popup-script'), '1.0.0', true);

            $setup_fee_amount = floatval(get_option('sec_setup_fee_amount', 499.00));
            $processing_fee   = floatval(get_option('sec_processing_fee', 2.50));
            $total_display    = '$' . number_format($setup_fee_amount + $processing_fee, 2);
            wp_localize_script('sec-popup-script', 'sec_ajax', array(
                'ajax_url'        => admin_url('admin-ajax.php'),
                'nonce'           => wp_create_nonce('sec_nonce'),
                'stripe_pk'       => $this->stripe_publishable_key,
                'publishable_key' => $this->stripe_publishable_key,
                'home_url'        => home_url(),
                'service_name'    => get_option('sec_setup_fee_name', 'Website Setup Fee'),
                'total_display'   => $total_display,
            ));

            wp_localize_script('sec-slot-checker', 'secSlots', array(
                'restUrl'       => rest_url('sec/v1/'),
                'waitlistNonce' => wp_create_nonce('sec_waitlist_nonce')
            ));
        }
    }

    // --- Token helpers ---

    private function generate_token($data) {
        $token = bin2hex(random_bytes(16));
        set_transient('sec_token_' . $token, json_encode($data), 24 * HOUR_IN_SECONDS);
        return $token;
    }

    private function get_token_data($token) {
        $token = preg_replace('/[^a-f0-9]/', '', $token);
        $data = get_transient('sec_token_' . $token);
        if (!$data) return false;
        return json_decode($data, true);
    }

    private function invalidate_token($token) {
        $token = preg_replace('/[^a-f0-9]/', '', $token);
        delete_transient('sec_token_' . $token);
    }

    public function handle_delete_customer() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized', 'Unauthorized', array('response' => 403));
        }

        // Verify nonce
        check_admin_referer('sec_delete_customer');

        $customer_id = isset($_GET['customer_id']) ? intval($_GET['customer_id']) : 0;
        if (!$customer_id) {
            wp_safe_redirect(admin_url('options-general.php?page=stripe-customers&deleted=0'));
            exit;
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_customers';

        $deleted = $wpdb->delete($table_name, array('id' => $customer_id), array('%d'));

        // Redirect back to the customers page with a status flag
        wp_safe_redirect(admin_url('options-general.php?page=stripe-customers&deleted=' . ($deleted ? '1' : '0')));
        exit;
    }

    // --- Shortcodes ---

    public function checkout_popup_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => 'SETUP FEE APPLICATION',
            'description' => 'Please fill in your information below.'
        ), $atts);

        if (empty($this->stripe_publishable_key)) {
            return '<p><strong>Error:</strong> Stripe not configured. Please contact administrator.</p>';
        }

        $service_name = get_option('sec_setup_fee_name', 'Website Setup Fee');
        $setup_fee_amount = get_option('sec_setup_fee_amount', 499.00);
        $processing_fee = get_option('sec_processing_fee', 2.50);
        $total = $setup_fee_amount + $processing_fee;
        $btn_color = get_option('sec_btn_color', '#667eea');
        $btn_text_color = get_option('sec_btn_text_color', '#ffffff');

        ob_start();
        ?>
        <style>
            .sec-form-container {
                --sec-btn-color: <?php echo esc_attr($btn_color); ?>;
                --sec-btn-text-color: <?php echo esc_attr($btn_text_color); ?>;
            }
            @keyframes sec-spin {
                to { transform: rotate(360deg); }
            }
        </style>
        <!-- Thank you popup (shown after payment) -->
        <div id="sec-thankyou-overlay" class="sec-thankyou-overlay">
            <div class="sec-thankyou-container">
                <div class="sec-thankyou-icon">&#10003;</div>
                <h2>Thank you for being a Member!</h2>
                <p>Please check your email for a payment confirmation.</p>
                <button class="sec-thankyou-btn" onclick="document.getElementById('sec-thankyou-overlay').classList.remove('active');document.body.style.overflow='';">Close</button>
            </div>
        </div>

        <div class="sec-form-container">
                <div class="sec-membership-form-wrapper">
                    <div class="sec-form-header">
                        <h2><?php echo esc_html($atts['title']); ?></h2>
                        <p><?php echo esc_html($atts['description']); ?></p>
                    </div>

                    <form id="sec-contact-form" class="sec-contact-form" onsubmit="return false;">
                        <div class="sec-form-row sec-form-row-2col">
                            <div class="sec-form-group">
                                <label for="sec-full-name">Full Name <span class="sec-required">*</span></label>
                                <input type="text" id="sec-full-name" name="full_name" required placeholder="John Doe" />
                            </div>
                            <div class="sec-form-group">
                                <label for="sec-business-name">Business Name <span class="sec-required">*</span></label>
                                <input type="text" id="sec-business-name" name="business_name" required placeholder="Acme Inc." />
                            </div>
                        </div>

                        <div class="sec-form-row sec-form-row-2col">
                            <div class="sec-form-group">
                                <label for="sec-email">Email Address <span class="sec-required">*</span></label>
                                <input type="email" id="sec-email" name="email" required placeholder="john@example.com" />
                            </div>
                            <div class="sec-form-group">
                                <label for="sec-phone">Phone Number <span class="sec-required">*</span></label>
                                <input type="tel" id="sec-phone" name="phone" required placeholder="(555) 123-4567" />
                            </div>
                        </div>

                        <div class="sec-form-row">
                            <div class="sec-form-group">
                                <label for="sec-address">Street Address <span class="sec-required">*</span></label>
                                <input type="text" id="sec-address" name="street_address" required placeholder="123 Main St" />
                            </div>
                        </div>

                        <div class="sec-form-row sec-form-row-3col">
                            <div class="sec-form-group">
                                <label for="sec-city">City <span class="sec-required">*</span></label>
                                <input type="text" id="sec-city" name="city" required placeholder="New York" />
                            </div>
                            <div class="sec-form-group">
                                <label for="sec-state">State <span class="sec-required">*</span></label>
                                <input type="text" id="sec-state" name="state" required placeholder="NY" />
                            </div>
                            <div class="sec-form-group">
                                <label for="sec-zip">Zip Code <span class="sec-required">*</span></label>
                                <input type="text" id="sec-zip" name="zip_code" required placeholder="10001" />
                            </div>
                        </div>

                        <div id="sec-form-error" class="sec-form-error" style="display:none;"></div>

                        <button type="button" id="sec-submit-btn" class="sec-submit-btn" onclick="secSubmitContactForm()">
                            BECOME A MEMBER
                        </button>
                    </form>
                </div>
        </div>
        <?php
        return ob_get_clean();
    }

    public function embedded_checkout_shortcode($atts) {
        if (empty($this->stripe_publishable_key)) {
            return '<p><strong>Error:</strong> Stripe not configured. Please contact administrator.</p>';
        }

        ob_start();
        ?>
        <div id="stripe-embedded-checkout-container">
            <div class="loading-checkout">
                <div class="loading-spinner"></div>
                <p>Loading secure checkout...</p>
            </div>
        </div>

        <style>
        .loading-checkout { text-align: center; padding: 40px; color: #666; }
        .loading-spinner { display: inline-block; width: 40px; height: 40px; border: 3px solid #f3f3f3; border-top: 3px solid #667eea; border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 20px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        </style>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const clientSecret = urlParams.get('cs');

            if (clientSecret && typeof Stripe !== 'undefined') {
                const stripe = Stripe('<?php echo esc_js($this->stripe_publishable_key); ?>');
                stripe.initEmbeddedCheckout({ clientSecret: clientSecret }).then(function(checkout) {
                    checkout.mount('#stripe-embedded-checkout-container');
                }).catch(function(error) {
                    document.getElementById('stripe-embedded-checkout-container').innerHTML =
                        '<div style="text-align:center;padding:40px;color:#dc3545;"><h3>Error loading checkout</h3><p>Please try again or contact support.</p></div>';
                });
            } else if (!clientSecret) {
                document.getElementById('stripe-embedded-checkout-container').innerHTML =
                    '<div style="text-align:center;padding:40px;color:#dc3545;"><h3>Invalid checkout session</h3><p>Please start the checkout process again.</p><a href="<?php echo esc_url(home_url()); ?>">Return to Homepage</a></div>';
            }
        });
        </script>
        <?php
        return ob_get_clean();
    }

    // --- AJAX handlers ---

    public function ajax_refresh_nonce() {
        wp_send_json_success(array('nonce' => wp_create_nonce('sec_nonce')));
    }

    public function ajax_create_stripe_checkout() {
        if (!wp_verify_nonce($_POST['nonce'], 'sec_nonce')) {
            wp_die('Security check failed');
        }

        // ── Bot Protection Layer ──────────────────────────────────────────────

        // 1. Honeypot: "website_url" must be empty — bots fill it, humans never see it
        $honeypot = isset($_POST['website_url']) ? $_POST['website_url'] : '';
        if (!empty(trim($honeypot))) {
            wp_send_json_success(array('checkout_url' => home_url('/checkout/?token=invalid')));
        }

        // 2. IP rate limiting — resolve real client IP (handles proxies/CDNs)
        $client_ip = '0.0.0.0';
        foreach (array('HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR') as $hdr) {
            if (!empty($_SERVER[$hdr])) {
                $client_ip = trim(explode(',', $_SERVER[$hdr])[0]);
                break;
            }
        }
        $client_ip = sanitize_text_field($client_ip);

        // ── IP Whitelist ─────────────────────────────────────────────────────
        // Add your own IP(s) to bypass rate limiting during development/testing.
        // Set the constant in wp-config.php:
        //   define('SEC_RATE_LIMIT_WHITELIST', '1.2.3.4,5.6.7.8');
        // Or use the filter below to whitelist IPs dynamically.
        $whitelist = array_filter(array_map('trim', explode(',',
            defined('SEC_RATE_LIMIT_WHITELIST') ? SEC_RATE_LIMIT_WHITELIST : ''
        )));
        // Allow plugins/themes to add IPs dynamically
        $whitelist = apply_filters('sec_rate_limit_whitelist', $whitelist);

        $rate_key  = 'sec_rate_' . md5($client_ip);
        $attempts  = (int) get_transient($rate_key);

        if (!in_array($client_ip, $whitelist, true) && $attempts >= 10) {
            wp_send_json_error('Too many requests. Please wait a few minutes and try again.');
        }

        // Only increment the counter for non-whitelisted IPs
        if (!in_array($client_ip, $whitelist, true)) {
            set_transient($rate_key, $attempts + 1, 10 * MINUTE_IN_SECONDS);
        }

        // ─────────────────────────────────────────────────────────────────────

        $full_name = sanitize_text_field($_POST['full_name']);
        $business_name = sanitize_text_field($_POST['business_name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $street_address = sanitize_text_field($_POST['street_address']);
        $city = sanitize_text_field($_POST['city']);
        $state = sanitize_text_field($_POST['state']);
        $zip_code = sanitize_text_field($_POST['zip_code']);

        if (!$full_name || !$business_name || !$email || !$phone || !$street_address || !$city || !$state || !$zip_code) {
            wp_send_json_error('All fields are required.');
        }

        // Email validation
        if (!is_email($email)) {
            wp_send_json_error('Please enter a valid email address.');
        }

        // Phone validation: must have at least 10 digits
        $phone_digits = preg_replace('/\D/', '', $phone);
        if (strlen($phone_digits) < 10 || strlen($phone_digits) > 11) {
            wp_send_json_error('Please enter a valid phone number with 10 digits.');
        }

        // ZIP code validation: 5 digits or 5+4 format
        if (!preg_match('/^\d{5}(-\d{4})?$/', $zip_code)) {
            wp_send_json_error('Please enter a valid ZIP code (e.g., 12345 or 12345-6789).');
        }

        // State validation: 2-letter US state abbreviation
        $valid_states = array('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY');
        if (strlen($state) === 2 && !in_array(strtoupper($state), $valid_states)) {
            wp_send_json_error('Please enter a valid US state abbreviation.');
        }

        try {
            if (!class_exists('Stripe\Stripe')) {
                require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
            }
            \Stripe\Stripe::setApiKey($this->stripe_secret_key);

            $service_name = get_option('sec_setup_fee_name', 'Website Setup Fee');
            $setup_fee_amount = floatval(get_option('sec_setup_fee_amount', 499.00));
            $processing_fee = floatval(get_option('sec_processing_fee', 2.50));
            $total = $setup_fee_amount + $processing_fee;
            $unit_amount_cents = intval(round($total * 100));

            $contact_data = array(
                'full_name' => $full_name,
                'business_name' => $business_name,
                'email' => $email,
                'phone' => $phone,
                'street_address' => $street_address,
                'city' => $city,
                'state' => $state,
                'zip_code' => $zip_code
            );

            // Pre-generate the token (we'll update it with session data after)
            $token = bin2hex(random_bytes(16));

            $session = \Stripe\Checkout\Session::create(array(
                'ui_mode' => 'embedded',
                'payment_method_types' => array('card'),
                'line_items' => array(array(
                    'price_data' => array(
                        'currency' => 'usd',
                        'product_data' => array(
                            'name' => $service_name,
                            'description' => $service_name . ' Fee'
                        ),
                        'unit_amount' => $unit_amount_cents,
                    ),
                    'quantity' => 1,
                )),
                'mode' => 'payment',
                'customer_creation' => 'always',
                'payment_intent_data' => array(
                    'setup_future_usage' => 'off_session'
                ),
                'return_url' => home_url('/survey/?survey_token={CHECKOUT_SESSION_ID}'),
                'metadata' => array(
                    'membership' => $service_name,
                    'business_name' => $business_name,
                    'website_url' => home_url(),
                    'token' => $token
                )
            ));

            // Store token with session data
            $token_data = array_merge($contact_data, array(
                'client_secret' => $session->client_secret,
                'session_id' => $session->id,
                'created' => time()
            ));
            set_transient('sec_token_' . $token, json_encode($token_data), 24 * HOUR_IN_SECONDS);

            // Store token in session for discount code usage
            if (!session_id()) {
                session_start();
            }
            $_SESSION['sec_current_token'] = $token;

            // Store the referring page so we can redirect back after payment
            if (isset($_SERVER['HTTP_REFERER'])) {
                $referer = esc_url_raw($_SERVER['HTTP_REFERER']);
                // Strip any existing payment_complete param
                $referer = remove_query_arg('payment_complete', $referer);
                $_SESSION['sec_form_referrer'] = $referer;
            }

            wp_send_json_success(array(
                'checkout_url' => home_url('/checkout/?token=' . $token),
                'client_secret' => $session->client_secret,
                'session_id' => $session->id
            ));

        } catch (Exception $e) {
            error_log('Stripe Checkout Error: ' . $e->getMessage());
            wp_send_json_error('Failed to create checkout session: ' . $e->getMessage());
        }
    }


    /**
     * Called by JS after Stripe onComplete fires on the same page.
     * Saves customer, sends email, creates survey token — no redirect.
     */
    public function ajax_complete_embedded_checkout() {
        if (!wp_verify_nonce($_POST['nonce'], 'sec_nonce')) {
            wp_die('Security check failed');
        }

        $session_id = sanitize_text_field(isset($_POST['session_id']) ? $_POST['session_id'] : '');
        $token      = sanitize_text_field(isset($_POST['token'])      ? $_POST['token']      : '');

        if (!$session_id || !$token) {
            wp_send_json_error('Missing session_id or token.');
        }

        try {
            if (!class_exists('Stripe\\Stripe')) {
                require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
            }
            \Stripe\Stripe::setApiKey($this->stripe_secret_key);

            $session = \Stripe\Checkout\Session::retrieve($session_id);

            if ($session->payment_status !== 'paid') {
                wp_send_json_error('Payment not yet confirmed.');
            }

            $token_data_raw = get_transient('sec_token_' . $token);
            $token_data     = $token_data_raw ? json_decode($token_data_raw, true) : array();

            $customer_email = isset($token_data['email']) ? $token_data['email']
                            : (isset($session->customer_details->email) ? $session->customer_details->email : '');

            // Claim activation slot
            if (!empty($customer_email) && class_exists('SEC_Activation_Slots')) {
                SEC_Activation_Slots::claim_slot($customer_email);
            }

            // Set default payment method
            if (!empty($session->payment_intent) && !empty($session->customer)) {
                try {
                    $pi = \Stripe\PaymentIntent::retrieve($session->payment_intent);
                    if (!empty($pi->payment_method)) {
                        $pm = \Stripe\PaymentMethod::retrieve($pi->payment_method);
                        if (!$pm->customer) { $pm->attach(array('customer' => $session->customer)); }
                        \Stripe\Customer::update($session->customer, array(
                            'invoice_settings' => array('default_payment_method' => $pi->payment_method)
                        ));
                    }
                } catch (Exception $e) {
                    error_log('SEC: set default PM failed: ' . $e->getMessage());
                }
            }

            // Discount usage
            if (!session_id()) { session_start(); }
            if (!empty($_SESSION['applied_discount']['id'])) {
                global $wpdb;
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}sec_discount_codes SET usage_count = usage_count + 1 WHERE id = %d",
                    intval($_SESSION['applied_discount']['id'])
                ));
                unset($_SESSION['applied_discount']);
            }

            $this->save_customer($session, $token_data);
            $this->send_confirmation_email($session, $token_data);

            // Send payment receipt email
            if (class_exists('SEC_Survey_Email')) {
                $customer_name = isset($token_data['full_name']) ? $token_data['full_name']
                               : (isset($session->customer_details->name) ? $session->customer_details->name : '');
                $business_name = isset($token_data['business_name']) ? $token_data['business_name'] : '';

                SEC_Survey_Email::send_payment_receipt([
                    'customer_email' => $customer_email,
                    'customer_name' => $customer_name,
                    'amount' => $session->amount_total,
                    'business_name' => $business_name,
                    'session_id' => $session->id ?? ''
                ]);
            }

            $survey_token = '';
            if (class_exists('SEC_Survey_Modal')) {
                $survey_token = SEC_Survey_Modal::store_payment_session($session, $token_data);
                if ($survey_token && class_exists('SEC_Survey_Email')) {
                    $customer_name = isset($token_data['full_name']) ? $token_data['full_name']
                                   : (isset($session->customer_details->name) ? $session->customer_details->name : '');
                    $business_name = isset($token_data['business_name']) ? $token_data['business_name'] : '';
                    SEC_Survey_Email::send_survey_invitation($customer_email, $customer_name, $survey_token, $business_name);
                    SEC_Survey_Email::schedule_survey_reminder($customer_email, $customer_name, $survey_token, 3600);
                }
            }

            $this->invalidate_token($token);

            wp_send_json_success(array(
                'customer_name'  => isset($token_data['full_name'])  ? $token_data['full_name']  : '',
                'customer_email' => $customer_email,
                'customer_id'    => isset($session->customer) ? $session->customer : '',
                'session_id'     => $session->id,
                'payment_amount' => $session->amount_total,
                'survey_token'   => $survey_token,
            ));

        } catch (Exception $e) {
            error_log('SEC: ajax_complete_embedded_checkout — ' . $e->getMessage());
            wp_send_json_error('Post-payment processing failed: ' . $e->getMessage());
        }
    }

    public function ajax_apply_discount_code() {
    if (!wp_verify_nonce($_POST['nonce'], 'sec_nonce')) {
        wp_die('Security check failed');
    }

    $code = sanitize_text_field($_POST['code']);
    if (empty($code)) {
        wp_send_json_error('Please enter a discount code');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'sec_discount_codes';

    $discount = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE code = %s AND active = 1",
        strtoupper($code)
    ));

    if (!$discount) {
        wp_send_json_error('Invalid discount code');
    }

    if ($discount->expires_at && strtotime($discount->expires_at) < time()) {
        wp_send_json_error('This discount code has expired');
    }

    if ($discount->usage_limit && $discount->usage_count >= $discount->usage_limit) {
        wp_send_json_error('This discount code has reached its usage limit');
    }

    // Base pricing
    $setup_fee_amount = floatval(get_option('sec_setup_fee_amount', 499.00));
    $processing_fee = floatval(get_option('sec_processing_fee', 2.50));
    $total_before_discount = $setup_fee_amount + $processing_fee;

    // Compute discount on Setup Fee only (processing fee never discounted)
    if ($discount->type === 'percentage') {
        $discount_amount = $setup_fee_amount * ($discount->value / 100);
    } else {
        $discount_amount = floatval($discount->value);
    }

    $discount_amount = min($discount_amount, $setup_fee_amount);
    $new_total = max(0, $total_before_discount - $discount_amount);

    // Need the token that owns this checkout session
    if (!session_id()) {
        session_start();
    }
    $token = isset($_SESSION['sec_current_token']) ? sanitize_text_field($_SESSION['sec_current_token']) : '';
    if (empty($token)) {
        wp_send_json_error('Checkout session not found. Please restart checkout.');
    }

    try {
        if (!class_exists('Stripe\Stripe')) {
            require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
        }
        \Stripe\Stripe::setApiKey($this->stripe_secret_key);

        $service_name = get_option('sec_setup_fee_name', 'Website Setup Fee');
        $discounted_amount_cents = intval(round($new_total * 100));

        // Create a NEW embedded checkout session with the discounted total.
        // We do this first, and only persist the discount server-side if Stripe succeeds,
        // so the discount state and the iframe stay in sync.
        $session = \Stripe\Checkout\Session::create(array(
            'ui_mode' => 'embedded',
            'payment_method_types' => array('card'),
            'line_items' => array(array(
                'price_data' => array(
                    'currency' => 'usd',
                    'product_data' => array(
                        'name' => $service_name,
                        'description' => $service_name . ' Fee (discount: ' . $discount->code . ')'
                    ),
                    'unit_amount' => $discounted_amount_cents,
                ),
                'quantity' => 1,
            )),
            'mode' => 'payment',
            'customer_creation' => 'always',
            'payment_intent_data' => array(
                'setup_future_usage' => 'off_session'
            ),
            'return_url' => home_url('/checkout/?session_id={CHECKOUT_SESSION_ID}&token=' . urlencode($token)),
            'metadata' => array(
                'membership' => $service_name,
                'discount_code' => $discount->code,
                'discount_amount' => $discount_amount,
                'original_total' => $total_before_discount,
                'token' => $token
            )
        ));

        // Persist discount state ONLY after Stripe session creation succeeded
        $_SESSION['applied_discount'] = array(
            'code' => $discount->code,
            'id' => intval($discount->id),
            'amount' => floatval($discount_amount),
            'type' => $discount->type,
            'value' => floatval($discount->value)
        );

        // Update token transient with new session info + discount state (for resilience)
        $token_data = $this->get_token_data($token);
        if ($token_data) {
            $token_data['client_secret'] = $session->client_secret;
            $token_data['session_id'] = $session->id;
            $token_data['applied_discount'] = $_SESSION['applied_discount'];
            set_transient('sec_token_' . $token, json_encode($token_data), 24 * HOUR_IN_SECONDS);
        }

        wp_send_json_success(array(
            'code' => $discount->code,
            'amount' => $discount_amount, // numeric
            'discount_amount' => number_format($discount_amount, 2),
            'new_total' => number_format($new_total, 2),
            'discount_text' => $discount->type === 'percentage' ? $discount->value . '% off' : '$' . $discount->value . ' off',
            'new_client_secret' => $session->client_secret,
            'reload_url' => home_url('/checkout/?token=' . urlencode($token) . '&_sec_reload=' . time())
        ));

    } catch (Exception $e) {
        error_log('SEC: Discount Stripe Session Error: ' . $e->getMessage());
        wp_send_json_error('Could not update checkout amount. Please try again.');
    }
}

public function ajax_remove_discount_code() {
    if (!wp_verify_nonce($_POST['nonce'], 'sec_nonce')) {
        wp_die('Security check failed');
    }

    $setup_fee_amount = floatval(get_option('sec_setup_fee_amount', 499.00));
    $processing_fee = floatval(get_option('sec_processing_fee', 2.50));
    $original_total = $setup_fee_amount + $processing_fee;

    if (!session_id()) {
        session_start();
    }
    $token = isset($_SESSION['sec_current_token']) ? sanitize_text_field($_SESSION['sec_current_token']) : '';
    if (empty($token)) {
        wp_send_json_error('Checkout session not found. Please restart checkout.');
    }

    try {
        if (!class_exists('Stripe\Stripe')) {
            require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
        }
        \Stripe\Stripe::setApiKey($this->stripe_secret_key);

        $service_name = get_option('sec_setup_fee_name', 'Website Setup Fee');
        $original_amount_cents = intval(round($original_total * 100));

        // Create the "no discount" embedded checkout session first; only then clear server-side discount.
        $session = \Stripe\Checkout\Session::create(array(
            'ui_mode' => 'embedded',
            'payment_method_types' => array('card'),
            'line_items' => array(array(
                'price_data' => array(
                    'currency' => 'usd',
                    'product_data' => array(
                        'name' => $service_name,
                        'description' => $service_name . ' Fee'
                    ),
                    'unit_amount' => $original_amount_cents,
                ),
                'quantity' => 1,
            )),
            'mode' => 'payment',
            'customer_creation' => 'always',
            'payment_intent_data' => array(
                'setup_future_usage' => 'off_session'
            ),
            'return_url' => home_url('/checkout/?session_id={CHECKOUT_SESSION_ID}&token=' . urlencode($token)),
            'metadata' => array(
                'membership' => $service_name,
                'token' => $token
            )
        ));

        // Now clear discount state
        if (isset($_SESSION['applied_discount'])) {
            unset($_SESSION['applied_discount']);
        }

        // Update token transient with new session info + cleared discount state
        $token_data = $this->get_token_data($token);
        if ($token_data) {
            $token_data['client_secret'] = $session->client_secret;
            $token_data['session_id'] = $session->id;
            if (isset($token_data['applied_discount'])) {
                unset($token_data['applied_discount']);
            }
            set_transient('sec_token_' . $token, json_encode($token_data), 24 * HOUR_IN_SECONDS);
        }

        wp_send_json_success(array(
            'original_total' => number_format($original_total, 2),
            'new_client_secret' => $session->client_secret,
            'reload_url' => home_url('/checkout/?token=' . urlencode($token) . '&_sec_reload=' . time())
        ));

    } catch (Exception $e) {
        error_log('SEC: Remove Discount Stripe Session Error: ' . $e->getMessage());
        wp_send_json_error('Could not remove discount right now. Please try again.');
    }
}

    // --- Checkout page handling ---

    public function handle_checkout_pages() {
        if (is_page() && get_post_meta(get_the_ID(), '_sec_checkout_page', true)) {

            // Handle custom invoice checkout
            if (isset($_GET['invoice_token'])) {
                if (ob_get_level()) {
                    ob_end_clean();
                }
                $invoice_token = sanitize_text_field($_GET['invoice_token']);
                $this->handle_custom_invoice_checkout($invoice_token);
                exit;
            }

            // Handle custom invoice payment success
            if (isset($_GET['session_id']) && isset($_GET['invoice_token'])) {
                if (ob_get_level()) {
                    ob_end_clean();
                }
                $this->handle_custom_invoice_success(
                    sanitize_text_field($_GET['session_id']),
                    sanitize_text_field($_GET['invoice_token'])
                );
                exit;
            }

            if (isset($_GET['session_id']) && isset($_GET['token'])) {
                if (ob_get_level()) {
                    ob_end_clean();
                }
                $this->handle_checkout_success(
                    sanitize_text_field($_GET['session_id']),
                    sanitize_text_field($_GET['token'])
                );
                exit;
            }

            if (isset($_GET['token'])) {
                $token = sanitize_text_field($_GET['token']);
                $token_data = $this->get_token_data($token);

                if (!$token_data) {
                    // Clear any previous output
                    if (ob_get_level()) {
                        ob_end_clean();
                    }
                    $this->show_expired_checkout();
                    exit;
                }

                // Store token in session for discount operations
                if (!session_id()) {
                    session_start();
                }
                $_SESSION['sec_current_token'] = $token;

                // Clear any previous output before showing checkout
                if (ob_get_level()) {
                    ob_end_clean();
                }
                $this->show_embedded_checkout($token_data['client_secret'], $token_data, $token);
                exit;
            }

            if (isset($_GET['payment_complete'])) {
                // Show the thank-you page — the shortcode on the page handles the popup
                return;
            }

            // No valid parameters - show 404
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            nocache_headers();
            include(get_query_template('404'));
            exit;
        }
    }

    private function show_expired_checkout() {
        $btn_color = get_option('sec_btn_color', '#139204');
        $btn_color_2 = get_option('sec_btn_color_2', '#36b827');
        echo '<!DOCTYPE html><html><head>';
        echo '<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">';
        echo '<title>Checkout Expired</title>';
        echo '<style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;margin:0;padding:0;background:#fafafa;display:flex;align-items:center;justify-content:center;min-height:100vh;}.expired-box{text-align:center;background:white;padding:60px 40px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);max-width:500px;}.expired-box h2{color:#333;margin:0 0 16px;}.expired-box p{color:#666;margin:0 0 24px;}.expired-box a{display:inline-block;background:linear-gradient(135deg,' . esc_attr($btn_color) . ' 0%,' . esc_attr($btn_color_2) . ' 100%);color:white;padding:12px 32px;border-radius:8px;text-decoration:none;font-weight:500;}</style>';
        echo '</head><body>';
        echo '<div class="expired-box">';
        echo '<h2>Checkout Session Expired</h2>';
        echo '<p>This checkout link is no longer valid. It may have expired or already been used.</p>';
        echo '<a href="' . esc_url(home_url()) . '">Return to Homepage</a>';
        echo '</div>';
        echo '</body></html>';
        exit;
    }

    private function show_embedded_checkout($client_secret, $token_data, $token) {
        $service_name = get_option('sec_setup_fee_name', 'Website Setup Fee');
        $setup_fee_amount = floatval(get_option('sec_setup_fee_amount', 499.00));
        $processing_fee = floatval(get_option('sec_processing_fee', 2.50));
        $total = $setup_fee_amount + $processing_fee;
        $logo_image = get_option('sec_logo_image', '');
        $btn_color = get_option('sec_btn_color', '#36b827');
        $btn_color_2 = get_option('sec_btn_color_2', '#139204');


// Load any previously applied discount so the order summary and the embedded checkout stay in sync
if (!session_id()) {
    session_start();
}
$applied_discount = null;
if (isset($_SESSION['applied_discount']) && is_array($_SESSION['applied_discount'])) {
    $applied_discount = $_SESSION['applied_discount'];
} elseif (isset($token_data['applied_discount']) && is_array($token_data['applied_discount'])) {
    $applied_discount = $token_data['applied_discount'];
    // Re-hydrate session for consistent behavior if the PHP session was dropped
    $_SESSION['applied_discount'] = $applied_discount;
}

$final_total = $total;
if ($applied_discount && isset($applied_discount['amount'])) {
    $final_total = max(0, $total - floatval($applied_discount['amount']));
}

        echo '<!DOCTYPE html>';
        echo '<html ' . get_language_attributes() . '>';
        echo '<head>';
        echo '<meta charset="' . get_bloginfo('charset') . '">';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
        echo '<title>' . esc_html($service_name) . ' Checkout</title>';
        echo '<script src="https://js.stripe.com/v3/"></script>';
        echo '<script>
        // Sync theme from localStorage
        (function() {
            const savedTheme = localStorage.getItem("theme") || "light";
            document.documentElement.setAttribute("data-theme", savedTheme);
            // Update body when DOM loads
            if (document.body) {
                document.body.setAttribute("data-theme", savedTheme);
            } else {
                document.addEventListener("DOMContentLoaded", function() {
                    document.body.setAttribute("data-theme", savedTheme);
                });
            }
        })();
        </script>';
        echo '<style>
        :root {
            --bg-primary: #0a0a0a;
            --bg-secondary: #000000;
            --text-primary: #ffffff;
            --text-secondary: #9ca3af;
            --border-color: #1a1a1a;
            --accent-color: #3b82f6;
            --accent-hover: #60a5fa;
        }
        [data-theme="light"] {
            --bg-primary: #ffffff;
            --bg-secondary: #fafafa;
            --text-primary: #1a1a1a;
            --text-secondary: #666666;
            --border-color: #e1e8ed;
            --accent-color: #2563eb;
            --accent-hover: #1d4ed8;
        }
        .header-back-link::before {
            content: "\2039";
            font-size: 16px;
            margin-right: 8px;
            font-weight: bold;
        }
        @media (max-width: 768px) {
            .header-back-link .back-text { display: none; }
            .header-back-link::before { font-size: 20px; margin-right: 0; }
        }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 0; padding: 0; background: var(--bg-primary); color: var(--text-primary); transition: background 0.3s, color 0.3s; }
        .checkout-header { background: var(--bg-secondary); padding: 20px 0; border-bottom: 1px solid var(--border-color); }
        .checkout-header-content { max-width: 1400px; margin: 0 auto; padding: 0 40px; position: relative; }
        .checkout-header h1 { color: var(--text-primary); margin: 0; font-size: 1.5em; font-weight: 500; text-align: center; }
        .checkout-header a { color: var(--text-primary); text-decoration: none; }
        .header-back-link { position: absolute; left: 40px; top: 50%; transform: translateY(-50%); color: var(--accent-color); text-decoration: none; font-size: 14px; transition: color 0.2s; }
        .header-back-link:hover { color: var(--accent-hover); }
        .checkout-main { max-width: 1400px; margin: 0 auto; display: grid; grid-template-columns: 2fr 1.2fr; min-height: calc(100vh - 81px); gap: 0; }
        .checkout-left { background: var(--bg-primary); padding: 20px 60px; border-right: 1px solid var(--border-color); display: flex; flex-direction: column; justify-content: flex-start; }
        .checkout-right { background: var(--bg-secondary); padding: 40px 56px 80px; }
        .checkout-title { text-align: center; margin-bottom: 30px; padding-top: 20px; }
        .checkout-title h2 { margin: 0 0 10px 0; font-size: 1.75em; font-weight: 600; color: var(--text-primary); }
        .checkout-title p { color: var(--text-secondary); margin: 0; font-size: 1.1em; }
        #checkout-element { background: var(--bg-primary); border-radius: 8px; overflow: hidden; width: 100%; max-width: 100%; margin: 0; padding: 0 !important; }
        .loading { text-align: center; padding: 60px 20px; color: var(--text-secondary); }
        .loading-spinner { display: inline-block; width: 32px; height: 32px; border: 3px solid var(--border-color); border-top: 3px solid var(--accent-color); border-radius: 50%; animation: spin 1s linear infinite; margin-bottom: 16px; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .order-summary h3 { margin: 0 0 24px 0; font-size: 18px; font-weight: 500; color: var(--text-primary); }
        .product-item { display: flex; align-items: center; padding: 0 0 24px 0; border-bottom: 1px solid var(--border-color); margin-bottom: 24px; }
        .product-image { width: 64px; height: 64px; background: linear-gradient(135deg, var(--accent-color) 0%, var(--accent-hover) 100%); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.5em; margin-right: 16px; position: relative; border: 1px solid var(--border-color); }
        .quantity-badge { background: var(--accent-color); color: white; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 600; position: absolute; top: -6px; right: -6px; border: 2px solid var(--bg-primary); }
        .product-details { flex-grow: 1; }
        .product-name { font-weight: 500; color: var(--text-primary); margin: 0 0 4px 0; font-size: 14px; }
        .product-description { color: var(--text-secondary); font-size: 12px; margin: 0; }
        .product-price { font-weight: 500; color: var(--text-primary); font-size: 14px; }
        .order-totals { border-top: 1px solid var(--border-color); padding-top: 24px; }
        .total-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; font-size: 14px; color: var(--text-secondary); }
        .total-row:last-child { margin: 16px 0 0 0; padding-top: 16px; border-top: 1px solid var(--border-color); font-weight: 500; font-size: 18px; color: var(--text-primary); }
        .customer-info { margin-top: 24px; padding: 16px; background: var(--bg-secondary); border-radius: 8px; font-size: 13px; color: var(--text-secondary); border: 1px solid var(--border-color); }
        .customer-info h4 { margin: 0 0 8px 0; font-size: 14px; color: var(--text-primary); }
        .customer-info p { margin: 2px 0; }
        @media (max-width: 768px) { .checkout-main { grid-template-columns: 1fr; } .checkout-left { padding: 24px; border-right: none; } .checkout-right { order: -1; padding: 24px; background: var(--bg-primary); } }
        </style>';
        echo '</head>';
        echo '<body>';
        echo '<div class="checkout-header">';
        echo '<div class="checkout-header-content">';
        echo '<a href="/launch" class="header-back-link"><span class="back-text">Back</span></a>';
        if ( function_exists('the_custom_logo') && has_custom_logo() ) {
            echo '<h1 class="site-logo">';
            the_custom_logo();
            echo '</h1>';
        } else {
            echo '<h1 class="site-title">';
            echo '<a href="' . esc_url( home_url('/') ) . '">' . esc_html( get_bloginfo('name') ) . '</a>';
            echo '</h1>';
        }

        echo '</div>';
        echo '</div>';
        echo '<div class="checkout-main">';
        echo '<div class="checkout-left">';
        echo '<div class="checkout-title">';
        echo '<h2>Complete Your Setup Fee Payment</h2>';
        echo '<p>Secure checkout powered by Stripe</p>';
        echo '</div>';
        echo '<div id="checkout-element" class="loading">';
        echo '<div class="loading-spinner"></div>';
        echo '<h3>Loading secure checkout...</h3>';
        echo '<p>Please wait while we prepare your payment form</p>';
        echo '</div>';
        echo '</div>';
        echo '<div class="checkout-right">';
                        // Customer info summary
        echo '<div class="customer-info">';
        echo '<h4>Your Information</h4>';
        echo '<p>' . esc_html($token_data['full_name']) . '</p>';
        echo '<p>' . esc_html($token_data['business_name']) . '</p>';
        echo '<p>' . esc_html($token_data['email']) . '</p>';
        echo '<p>' . esc_html($token_data['phone']) . '</p>';
        echo '<p>' . esc_html($token_data['street_address']) . ', ' . esc_html($token_data['city']) . ', ' . esc_html($token_data['state']) . ' ' . esc_html($token_data['zip_code']) . '</p>';
        echo '</div>';
        $card_image = get_option('sec_card_image', '');
        if ($card_image) {
            echo '<div class="checkout-card-image" style="margin-bottom:24px;border-radius:12px;overflow:hidden;">';
            echo '<img src="' . esc_url($card_image) . '" alt="' . esc_attr($service_name) . '" style="width:100%;height:auto;display:block;" />';
            echo '</div>';
        }
        echo '<div class="order-summary">';
        echo '<h3>Order summary</h3>';
        echo '<div class="product-item">';
        echo '<div class="product-image">';
        echo '<img 
                src="' . esc_url( plugin_dir_url(__FILE__) . 'assets/circle.svg' ) . '" 
                alt="Product"
                class="product-logo"
                style="width:54px;height:54px;max-width:54px;max-height:54px;display:block;"
                />';
        echo '<div class="quantity-badge">1</div>';
        echo '</div>';

        echo '<div class="product-details">';
        echo '<div class="product-name">' . esc_html($service_name) . '</div>';
        echo '<div class="product-description">Setup Fee Amount</div>';
        echo '</div>';
        echo '<div class="product-price">$' . number_format($final_total, 2) . '</div>';
        echo '</div>';
        echo '<div class="order-totals">';

        echo '<div class="total-row">';
        echo '<span class="total-label">' . esc_html($service_name) . '</span>';
        echo '<span class="total-amount">$' . number_format($setup_fee_amount, 2) . '</span>';
        echo '</div>';
        echo '<div class="total-row">';
        echo '<span class="total-label">Processing Fee</span>';
        echo '<span class="total-amount">$' . number_format($processing_fee, 2) . '</span>';
        echo '</div>';

        
// Discount code section
$discount_code_val = $applied_discount && isset($applied_discount['code']) ? $applied_discount['code'] : '';
$discount_amount_val = $applied_discount && isset($applied_discount['amount']) ? floatval($applied_discount['amount']) : 0;
$discount_is_applied = !empty($discount_code_val) && $discount_amount_val > 0;

echo '<div class="discount-code-section" style="margin: 16px 0; padding: 16px 0; border-top: 1px solid #e1e8ed;">';
echo '<div class="discount-input-row" style="display: flex; gap: 8px; margin-bottom: 12px;">';
echo '<input type="text" id="discount-code" placeholder="Discount code" value="' . esc_attr($discount_code_val) . '" style="flex: 1; padding: 12px; border: 1px solid #e1e8ed; border-radius: 4px; font-size: 14px;" ' . ($discount_is_applied ? 'disabled' : '') . ' />';
echo '<button id="apply-discount" onclick="applyDiscountCode()" style="padding: 12px 20px; background: #36b827; color: white; border: none; border-radius: 4px; font-size: 14px; cursor: pointer; font-weight: 500;" ' . ($discount_is_applied ? 'disabled' : '') . '>Apply</button>';
echo '</div>';
echo '<div id="discount-message" style="font-size: 12px; color: #737373; display: none;"></div>';
echo '<div id="discount-applied" style="' . ($discount_is_applied ? 'display:block;' : 'display:none;') . '">';
echo '<div class="total-row" style="color: #28a745;">';
echo '<span class="total-label">Discount (<span id="discount-code-display">' . esc_html($discount_code_val) . '</span>) <button id="remove-discount" onclick="removeDiscountCode()" style="background: none; border: none; color: #dc3545; font-size: 12px; text-decoration: underline; cursor: pointer; margin-left: 8px;">Remove</button></span>';
echo '<span class="total-amount">-$<span id="discount-amount-display">' . number_format($discount_amount_val, 2) . '</span></span>';
echo '</div>';
echo '</div>';
echo '</div>';echo '</div>';

        echo '<div class="total-row">';
        echo '<span class="total-label">Total</span>';
        echo '<span class="total-amount">USD $<span id="final-total">' . number_format($final_total, 2) . '</span></span>';
        echo '</div>';
        echo '</div>';

        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '<script>';
        ?>
        const stripe = Stripe("<?php echo esc_js($this->stripe_publishable_key); ?>");
const originalTotal = <?php echo $total; ?>;
let appliedDiscount = <?php echo $applied_discount ? wp_json_encode($applied_discount) : 'null'; ?>;
let currentCheckout = null;
let secNonce = "<?php echo wp_create_nonce('sec_nonce'); ?>";
const ajaxUrl = "<?php echo admin_url('admin-ajax.php'); ?>";

async function refreshNonce() {
    try {
        const resp = await fetch(ajaxUrl, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "action=sec_refresh_nonce"
        });
        const data = await resp.json();
        if (data.success && data.data.nonce) secNonce = data.data.nonce;
    } catch (e) {}
}

// Prevent overlapping discount operations / iframe reloads (major source of Link hangs)
let isSyncingCheckout = false;
let reloadSeq = 0;

function setDiscountUiLocked(locked) {
    const codeInput = document.getElementById("discount-code");
    const applyBtn = document.getElementById("apply-discount");
    const removeBtn = document.getElementById("remove-discount");

    if (codeInput) codeInput.disabled = locked || (appliedDiscount && appliedDiscount.code);
    if (applyBtn) applyBtn.disabled = locked || (appliedDiscount && appliedDiscount.code);
    if (removeBtn) removeBtn.disabled = locked;
}

function showDiscountMessage(message, type) {
    const el = document.getElementById("discount-message");
    if (!el) return;
    el.textContent = message;
    el.style.color = type === "error" ? "#dc3545" : "#28a745";
    el.style.display = "block";
    setTimeout(() => { el.style.display = "none"; }, 3500);
}

function updateTotal() {
    let t = originalTotal;
    if (appliedDiscount && appliedDiscount.amount) t -= parseFloat(appliedDiscount.amount);
    const totalEl = document.getElementById("final-total");
    if (totalEl) totalEl.textContent = Number(t).toFixed(2);
}

async function applyDiscountCode() {
    const code = document.getElementById("discount-code").value.trim();
    const applyBtn = document.getElementById("apply-discount");

    if (!code) { showDiscountMessage("Please enter a discount code", "error"); return; }
    if (isSyncingCheckout) return;

    isSyncingCheckout = true;
    setDiscountUiLocked(true);
    if (applyBtn) applyBtn.textContent = "Applying...";

    try {
        await refreshNonce();
        const response = await fetch(ajaxUrl, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "action=apply_discount_code&code=" + encodeURIComponent(code) + "&nonce=" + encodeURIComponent(secNonce)
        });
        const result = await response.json();

        if (!result.success) {
            showDiscountMessage(result.data || "Invalid discount code", "error");
            return;
        }

        appliedDiscount = result.data;

        // Update order summary immediately
        document.getElementById("discount-code-display").textContent = appliedDiscount.code;
        document.getElementById("discount-amount-display").textContent = Number(appliedDiscount.amount).toFixed(2);
        document.getElementById("discount-applied").style.display = "block";
        updateTotal();
        showDiscountMessage("Discount applied! Updating checkout…", "success");

        // HARD sync approach (recommended): full page reload to rebuild the embedded checkout iframe cleanly.
        // This avoids the intermittent Link hang caused by destroy() + remount() while Link is initializing.
        if (appliedDiscount.reload_url) {
            window.location.href = appliedDiscount.reload_url;
            return;
        }

        // Fallback: soft reload (kept for compatibility)
        if (appliedDiscount.new_client_secret) {
            await reloadStripeCheckout(appliedDiscount.new_client_secret);
        }
    } catch (error) {
        console.error(error);
        showDiscountMessage("Error applying discount code", "error");
    } finally {
        isSyncingCheckout = false;
        if (applyBtn) applyBtn.textContent = "Apply";
        setDiscountUiLocked(false);
    }
}

async function removeDiscountCode() {
    const btn = document.getElementById("remove-discount");
    if (isSyncingCheckout) return;

    isSyncingCheckout = true;
    setDiscountUiLocked(true);
    if (btn) btn.textContent = "Removing...";

    try {
        await refreshNonce();
        const response = await fetch(ajaxUrl, {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "action=remove_discount_code&nonce=" + encodeURIComponent(secNonce)
        });
        const result = await response.json();

        if (!result.success) {
            showDiscountMessage(result.data || "Error removing discount", "error");
            return;
        }

        // Optimistically update UI
        appliedDiscount = null;
        document.getElementById("discount-applied").style.display = "none";
        document.getElementById("discount-code").value = "";
        document.getElementById("discount-code").disabled = false;
        document.getElementById("apply-discount").disabled = false;
        document.getElementById("final-total").textContent = Number(originalTotal).toFixed(2);
        showDiscountMessage("Discount removed! Updating checkout…", "success");

        if (result.data && result.data.reload_url) {
            window.location.href = result.data.reload_url;
            return;
        }

        if (result.data && result.data.new_client_secret) {
            await reloadStripeCheckout(result.data.new_client_secret);
        }
    } catch (error) {
        console.error(error);
        showDiscountMessage("Error removing discount", "error");
    } finally {
        isSyncingCheckout = false;
        if (btn) btn.textContent = "Remove";
        setDiscountUiLocked(false);
    }
}

function resetCheckoutMount() {
    const container = document.getElementById("checkout-element");
    if (!container) return "#checkout-element";

    // Clear any lingering iframe DOM and mount into a fresh child node.
    container.innerHTML = "";
    const mount = document.createElement("div");
    mount.id = "checkout-mount-" + Date.now();
    container.appendChild(mount);
    return "#" + mount.id;
}

async function reloadStripeCheckout(newClientSecret) {
    const mySeq = ++reloadSeq;
    const container = document.getElementById("checkout-element");
    if (!container) return;

    try {
        container.innerHTML = '<div class="loading"><div class="loading-spinner"></div><h3>Updating checkout...</h3><p>Please wait</p></div>';

        // Give Link/iframe a moment to settle before destroying (reduces hangs)
        await new Promise(r => setTimeout(r, 450));

        if (mySeq !== reloadSeq) return;

        if (currentCheckout) {
            try { currentCheckout.destroy(); } catch (e) {}
            currentCheckout = null;
        }

        await new Promise(r => setTimeout(r, 250));
        if (mySeq !== reloadSeq) return;

        const mountSelector = resetCheckoutMount();
        currentCheckout = await stripe.initEmbeddedCheckout({ clientSecret: newClientSecret });

        if (mySeq !== reloadSeq) return;

        currentCheckout.mount(mountSelector);
    } catch (error) {
        console.error(error);
        container.innerHTML = "<h3>Error updating checkout</h3><p>Please refresh the page.</p>";
    }
}

async function initializeCheckout() {
    try {
        const mountSelector = resetCheckoutMount();
        currentCheckout = await stripe.initEmbeddedCheckout({ clientSecret: "<?php echo esc_js($client_secret); ?>" });
        currentCheckout.mount(mountSelector);

        // If a discount is already applied server-side, make sure totals are correct
        updateTotal();
        setDiscountUiLocked(false);
    } catch (error) {
        console.error(error);
        document.getElementById("checkout-element").innerHTML = "<h3>Error loading checkout</h3><p>Please try again.</p>";
    }
}

initializeCheckout();<?php
        echo '</script>';
        echo '</body>';
        echo '</html>';
        exit;
    }

    private function handle_checkout_success($session_id, $token) {
    try {
        if (!class_exists('Stripe\Stripe')) {
            require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
        }
        \Stripe\Stripe::setApiKey($this->stripe_secret_key);

        $session = \Stripe\Checkout\Session::retrieve($session_id);

        if (!$session || $session->payment_status !== 'paid') {
            wp_redirect(home_url('/?payment_error=1'));
            exit;
        }

        // Get contact info from token before invalidating
        $token_data = $this->get_token_data($token);

        // ═══════════════════════════════════════════════════════════════════
        // CLAIM ACTIVATION SLOT - Do this early, right after payment confirmed
        // ═══════════════════════════════════════════════════════════════════
        $customer_email = $session->customer_details->email ?? '';
        
        if ($customer_email) {
            $slot_claimed = SEC_Activation_Slots::claim_slot($customer_email);
            
            if ($slot_claimed) {
                error_log("✅ Activation slot claimed for: {$customer_email}");
            } else {
                error_log("⚠️ Could not claim activation slot for: {$customer_email} (all slots may be full)");
                // Note: Payment still succeeded. This is an edge case where payment completed
                // but we couldn't claim a slot (e.g., race condition, all slots full).
                // You may want to notify admin or handle this specially.
            }
        } else {
            error_log("⚠️ No customer email found in session for slot claiming");
        }
        // ═══════════════════════════════════════════════════════════════════

        // Set default payment method
        $payment_intent = \Stripe\PaymentIntent::retrieve($session->payment_intent);
        $payment_method_id = $payment_intent->payment_method;

        if ($payment_method_id && $session->customer) {
            try {
                $payment_method = \Stripe\PaymentMethod::retrieve($payment_method_id);
                if (!$payment_method->customer) {
                    $payment_method->attach(['customer' => $session->customer]);
                }
                \Stripe\Customer::update($session->customer, [
                    'invoice_settings' => ['default_payment_method' => $payment_method_id]
                ]);
            } catch (Exception $e) {
                error_log('SEC: Failed to set default payment method: ' . $e->getMessage());
            }
        }

        // Save customer to database
        $this->save_customer($session, $token_data);

        // Update discount code usage
        if (!session_id()) {
            session_start();
        }
        if (isset($_SESSION['applied_discount']) && !empty($_SESSION['applied_discount']['id'])) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'sec_discount_codes';
            $wpdb->query($wpdb->prepare(
                "UPDATE $table_name SET usage_count = usage_count + 1 WHERE id = %d",
                intval($_SESSION['applied_discount']['id'])
            ));
            unset($_SESSION['applied_discount']);
        }

        // Invalidate the token
        $this->invalidate_token($token);

        // Send payment receipt email using branding settings template
        if (class_exists('SEC_Survey_Email')) {
            $customer_name = isset($token_data['full_name']) ? $token_data['full_name'] : ($session->customer_details->name ?? '');
            $customer_email = isset($token_data['email']) ? $token_data['email'] : ($session->customer_details->email ?? '');
            $business_name = isset($token_data['business_name']) ? $token_data['business_name'] : '';

            SEC_Survey_Email::send_payment_receipt([
                'customer_name' => $customer_name,
                'customer_email' => $customer_email,
                'amount' => $session->amount_total, // in cents
                'business_name' => $business_name,
                'session_id' => $session->id ?? '',
            ]);
        }

        // Store payment session data for survey modal and send immediate survey invitation
        if (class_exists('SEC_Survey_Modal')) {
            $survey_token = SEC_Survey_Modal::store_payment_session($session, $token_data);
            if ($survey_token && class_exists('SEC_Survey_Email')) {
                $customer_name = isset($token_data['full_name']) ? $token_data['full_name'] : ($session->customer_details->name ?? '');
                $customer_email = isset($token_data['email']) ? $token_data['email'] : ($session->customer_details->email ?? '');
                $business_name = isset($token_data['business_name']) ? $token_data['business_name'] : '';
                SEC_Survey_Email::send_survey_invitation($customer_email, $customer_name, $survey_token, $business_name);
            }
        }

        // Redirect back to the page with the shortcode (or home) with thank-you trigger
        $redirect_url = home_url('/?payment_complete=1');
        // If we know the referring page, redirect there
        if (isset($_SESSION['sec_form_referrer']) && !empty($_SESSION['sec_form_referrer'])) {
            $ref = $_SESSION['sec_form_referrer'];
            $redirect_url = $ref . (strpos($ref, '?') !== false ? '&' : '?') . 'payment_complete=1';
            unset($_SESSION['sec_form_referrer']);
        }
        wp_redirect($redirect_url);
        exit;

    } catch (Exception $e) {
        error_log('SEC: Checkout success handler error - ' . $e->getMessage());
        wp_redirect(home_url('/?payment_error=1'));
        exit;
    }
}

    private function save_customer($session, $token_data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_customers';
        $service_name = get_option('sec_setup_fee_name', 'Website Setup Fee');

        $wpdb->insert($table_name, array(
            'stripe_customer_id' => $session->customer ? $session->customer : '',
            'full_name' => isset($token_data['full_name']) ? $token_data['full_name'] : ($session->customer_details->name ?? ''),
            'business_name' => isset($token_data['business_name']) ? $token_data['business_name'] : '',
            'email' => isset($token_data['email']) ? $token_data['email'] : ($session->customer_details->email ?? ''),
            'phone' => isset($token_data['phone']) ? $token_data['phone'] : ($session->customer_details->phone ?? ''),
            'street_address' => isset($token_data['street_address']) ? $token_data['street_address'] : '',
            'city' => isset($token_data['city']) ? $token_data['city'] : '',
            'state' => isset($token_data['state']) ? $token_data['state'] : '',
            'zip_code' => isset($token_data['zip_code']) ? $token_data['zip_code'] : '',
            'membership_name' => $service_name,
            'amount_paid' => $session->amount_total / 100,
            'stripe_session_id' => $session->id
        ), array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%s'));
    }

    private function send_confirmation_email($session, $token_data) {
        $service_name = get_option('sec_setup_fee_name', 'Website Setup Fee');
        $setup_fee_amount = floatval(get_option('sec_setup_fee_amount', 499.00));
        $processing_fee = floatval(get_option('sec_processing_fee', 2.50));
        $calendar_url = get_option('sec_calendar_url', '');
        $from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $from_email = get_option('sec_email_from', get_option('admin_email'));
        $logo_image = get_option('sec_logo_image', '');
        $btn_color = get_option('sec_btn_color', 'rgba(255, 0, 0, 1)ff');
        $btn_color_2 = get_option('sec_btn_color_2', '#a03939ff');

        $customer_name = isset($token_data['full_name']) ? $token_data['full_name'] : ($session->customer_details->name ?? 'there');
        $customer_email = isset($token_data['email']) ? $token_data['email'] : ($session->customer_details->email ?? '');
        $customer_business = isset($token_data['business_name']) ? $token_data['business_name'] : '';
        $phone = isset($token_data['phone']) ? $token_data['phone'] : '';

        // Amounts in cents
        $amount_total = (int) $session->amount_total;
        $amount_subtotal = (int) (($setup_fee_amount + $processing_fee) * 100);
        $amount_discount = max(0, $amount_subtotal - $amount_total);

        $paid_at = date('F j, Y');
        $order_id = $session->id;

        // Get payment method details and receipt URL from Stripe
        $pm_brand = '';
        $pm_last4 = '';
        $receipt_url = '';
        try {
            if ($session->payment_intent) {
                $pi = \Stripe\PaymentIntent::retrieve($session->payment_intent);
                if ($pi->latest_charge) {
                    $charge = \Stripe\Charge::retrieve($pi->latest_charge);
                    $receipt_url = $charge->receipt_url ?? '';
                }
                if ($pi->payment_method) {
                    $pm = \Stripe\PaymentMethod::retrieve($pi->payment_method);
                    if (isset($pm->card)) {
                        $pm_brand = ucfirst($pm->card->brand ?? '');
                        $pm_last4 = $pm->card->last4 ?? '';
                    }
                }
            }
        } catch (Exception $e) {
            error_log('SEC: Failed to retrieve payment details for email: ' . $e->getMessage());
        }

        // Format cents to dollar string
        $fmt = function($cents) {
            return '$' . number_format($cents / 100, 2) . ' USD';
        };

        // Build line items (mobile-safe wrapping)
        $items_html = '';

        $items_html .= '<tr>';
        $items_html .= '<td style="
            padding:8px 0;
            color:#111;
            font-family:Arial,Helvetica,sans-serif;
            font-size:14px;
            line-height:20px;
            word-break:break-word;
            overflow-wrap:anywhere;
            hyphens:auto;
        ">';
        $items_html .= 'Setup Fee Amount';
        $items_html .= '</td>';

        $items_html .= '<td align="right" style="
            padding:8px 0;
            color:#111;
            font-family:Arial,Helvetica,sans-serif;
            font-size:14px;
            line-height:20px;
            white-space:nowrap;
            padding-left:12px;
        ">';
        $items_html .= $fmt((int)($setup_fee_amount * 100));
        $items_html .= '</td>';
        $items_html .= '</tr>';

        $items_html .= '<tr>';
        $items_html .= '<td style="
            padding:8px 0;
            color:#111;
            font-family:Arial,Helvetica,sans-serif;
            font-size:14px;
            line-height:20px;
            word-break:break-word;
            overflow-wrap:anywhere;
            hyphens:auto;
        ">Processing Fee</td>';

        $items_html .= '<td align="right" style="
            padding:8px 0;
            color:#111;
            font-family:Arial,Helvetica,sans-serif;
            font-size:14px;
            line-height:20px;
            white-space:nowrap;
            padding-left:12px;
        ">';
        $items_html .= $fmt((int)($processing_fee * 100));
        $items_html .= '</td>';
        $items_html .= '</tr>';


        // Receipt block
        $receipt_block = '
        <div style="margin:18px 0; padding:16px; border:1px solid #e6e6e6; border-radius:10px; background:#fafafa;">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
            <tr>
                <td style="font-weight:700; color:#111; font-size:16px; padding:0 0 8px 0;">'. esc_html($service_name) .'</td>
                <td align="right" style="font-size:12px; color:#666; padding:0 0 8px 0;">' . esc_html($paid_at) . '</td>
            </tr>
            <tr>
                <td style="font-size:12px; color:#666; padding:0 0 12px 0;">Paid to <span style="color:#111; font-weight:600;">' . esc_html($from_name) . '</span></td>
                <td align="right" style="font-size:12px; color:#666; padding:0 0 12px 0;">Order ' . esc_html(substr($order_id, -8)) . '</td>
            </tr>
            </table>

            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
            ' . $items_html . '
            <tr><td colspan="2" style="border-top:1px solid #e6e6e6;"></td></tr>

            <tr>
                <td style="padding:10px 0 6px 0; color:#666; font-size:12px;">Subtotal</td>
                <td align="right" style="padding:10px 0 6px 0; color:#666; font-size:12px;">' . $fmt($amount_subtotal) . '</td>
            </tr>'
            . ($amount_discount > 0 ? '
            <tr>
                <td style="padding:0 0 6px 0; color:#666; font-size:12px;">Discount</td>
                <td align="right" style="padding:0 0 6px 0; color:#666; font-size:12px;">- ' . $fmt($amount_discount) . '</td>
            </tr>' : '') . '

            <tr>
                <td style="padding:10px 0; color:#111; font-size:14px; font-weight:700;">Total</td>
                <td align="right" style="padding:10px 0; color:#111; font-size:14px; font-weight:700; white-space:nowrap;">' . $fmt($amount_total) . '</td>
            </tr>
            </table>

            <div style="border-top:1px solid #e6e6e6; margin:12px 0;"></div>

            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
            <tr>
                <td style="font-size:12px; color:#666; padding:4px 0;">Payment method</td>
            </tr>
            <tr>
                <td style="font-size:14px; color:#111; padding:2px 0;">
                Card' . (($pm_brand || $pm_last4) ? ' <span style="color:#666;">&bull; ' . esc_html(trim($pm_brand . ' &bull;&bull;&bull;&bull; ' . $pm_last4)) . '</span>' : '') . '
                </td>
            </tr>
            </table>'
            . ($receipt_url ? '
            <div style="margin-top:14px;">
                <a href="' . esc_url($receipt_url) . '" target="_blank"
                style="display:inline-block; text-decoration:none; font-weight:600; padding:10px 14px; border-radius:8px; background:#057ffd; color:#fff;">
                View receipt
                </a>
            </div>' : '') . '
        </div>';

        // Calendar booking link
        $calendar_link = '';
        if ($calendar_url) {
            $calendar_params = http_build_query(array(
                'name' => $customer_name,
                'email' => $customer_email,
                'phone' => $phone,
                'business' => $customer_business
            ));
            $calendar_link = $calendar_url . (strpos($calendar_url, '?') !== false ? '&' : '?') . $calendar_params;
        }

        // Logo header (email-safe)
        $logo_html = '';

$logo_url = $logo_image ?: 'https://marketingaid.org/wp-content/uploads/2026/02/MA_Logo.png';

if ( ! empty($logo_url) ) {
    $logo_html =
        '<a href="' . esc_url(home_url('/')) . '" target="_blank" style="display:inline-block;text-decoration:none;">' .
            '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr($from_name) . '" width="120" height="50" border="0" style="display:block;margin:0 auto;width:120px;height:auto;border:0;outline:none;text-decoration:none;">' .
        '</a>';
} else {
    $logo_html =
        '<span style="font-size:20px;font-weight:700;color:#ffffff;font-family:Arial,Helvetica,sans-serif;">' .
            esc_html($from_name) .
        '</span>';
}

        $subject = esc_html($from_name) . ': Payment Receipt';

$body = '<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="x-apple-disable-message-reformatting">
  <style>
    /* Some clients support this; Gmail mobile often ignores media queries,
       but the fluid table structure below still works. */
    @media screen and (max-width: 620px) {
      .container { width: 100% !important; }
      .p-24 { padding: 16px !important; }
      .p-32 { padding: 18px !important; }
    }
  </style>
</head>

<body style="margin:0; padding:0; background:#f9f9f9;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" bgcolor="#f9f9f9" style="background:#f9f9f9;">
    <tr>
      <td align="center" style="padding:16px;">

        <!-- Container (fluid wrapper) -->
        <table role="presentation" class="container" width="600" cellpadding="0" cellspacing="0" border="0" align="center"
          style="width:600px; max-width:600px; background:#ffffff; border:1px solid #dddddd; border-radius:8px; overflow:hidden;">
          
          <!-- Header -->
          <tr>
            <td align="center" class="p-24" style="background:#000000; padding:20px 16px 12px 16px;">
              ' . $logo_html . '
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td class="p-32" style="padding:24px; font-family:Arial,Helvetica,sans-serif; font-size:16px; line-height:1.6; color:#111;">
              <p style="margin:0 0 10px 0; font-size:22px; font-weight:700;">' . esc_html($customer_name) . ',</p>
              <p style="margin:0 0 18px 0; color:#333;">Thank you for choosing MarketingAid!</p>

              ' . $receipt_block . '

              <p style="margin:18px 0 0 0; font-size:13px; color:#666;">
                Questions? Email us at
                <a href="mailto:' . esc_attr($from_email) . '" style="color:' . esc_attr($btn_color) . '; text-decoration:none;">' . esc_html($from_email) . '</a>.
              </p>

              <p style="margin:22px 0 0 0;">Thank you,<br><strong>' . esc_html($from_name) . ' Team</strong></p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td align="center" style="background:#f1f1f1; padding:14px 16px; font-family:Arial,Helvetica,sans-serif; font-size:12px; color:#999;">
              &copy; ' . date('Y') . ' ' . esc_html($from_name) . '. All rights reserved.
            </td>
          </tr>

        </table>
        <!-- /Container -->

      </td>
    </tr>
  </table>
</body>
</html>';

        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );

        wp_mail($customer_email, $subject, $body, $headers);
    }

    // --- Admin ---

    public function add_admin_menu() {
        // Add top-level menu
        add_menu_page(
            'Stripe Checkout',
            'Stripe Checkout',
            'manage_options',
            'stripe-embedded-checkout',
            array($this, 'admin_page'),
            'dashicons-cart',
            30
        );

        // Settings submenu (rename first submenu item)
        add_submenu_page(
            'stripe-embedded-checkout',
            'Settings',
            'Settings',
            'manage_options',
            'stripe-embedded-checkout',
            array($this, 'admin_page')
        );

        // Customers submenu
        add_submenu_page(
            'stripe-embedded-checkout',
            'Customers',
            'Customers',
            'manage_options',
            'stripe-customers',
            array($this, 'customers_page')
        );

        // Slot Management submenu (NEW)
        add_submenu_page(
            'stripe-embedded-checkout',
            'Slot Management',
            'Slot Management',
            'manage_options',
            'stripe-slot-management',
            array($this, 'slot_management_page')
        );

        // Discount Codes submenu
        add_submenu_page(
            'stripe-embedded-checkout',
            'Discount Codes',
            'Discount Codes',
            'manage_options',
            'stripe-discount-codes',
            array($this, 'discount_codes_page')
        );

        // Generate Invoices submenu
        add_submenu_page(
            'stripe-embedded-checkout',
            'Generate Invoice Links',
            'Generate Invoices',
            'manage_options',
            'stripe-generate-invoice',
            array($this, 'invoice_generator_page')
        );

        // View Invoices submenu
        add_submenu_page(
            'stripe-embedded-checkout',
            'View Invoice Links',
            'View Invoices',
            'manage_options',
            'stripe-view-invoices',
            array($this, 'invoice_management_page')
        );

        // Invoice Branding submenu
        add_submenu_page(
            'stripe-embedded-checkout',
            'Invoice Branding',
            'Invoice Branding',
            'manage_options',
            'stripe-invoice-branding',
            array($this, 'invoice_branding_page')
        );
    }

    public function admin_page() {
        wp_enqueue_media();

        if (isset($_POST['submit']) && wp_verify_nonce($_POST['sec_nonce'], 'sec_save_settings')) {
            update_option('sec_setup_fee_name', sanitize_text_field($_POST['membership_name']));
            update_option('sec_setup_fee_amount', floatval($_POST['membership_fee']));
            update_option('sec_processing_fee', floatval($_POST['processing_fee']));
            update_option('sec_calendar_url', esc_url_raw($_POST['calendar_url']));
            update_option('sec_email_from_name', sanitize_text_field($_POST['email_from_name']));
            update_option('sec_email_from', sanitize_email($_POST['email_from']));

            // Landing page settings
            if (isset($_POST['card_image'])) {
                update_option('sec_card_image', esc_url_raw($_POST['card_image']));
            }
            if (isset($_POST['btn_color'])) {
                update_option('sec_btn_color', sanitize_hex_color($_POST['btn_color']));
            }
            if (isset($_POST['btn_text_color'])) {
                update_option('sec_btn_text_color', sanitize_hex_color($_POST['btn_text_color']));
            }

            echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
        }

        $service_name = get_option('sec_setup_fee_name', 'Website Setup Fee');
        $setup_fee_amount = get_option('sec_setup_fee_amount', 499.00);
        $processing_fee = get_option('sec_processing_fee', 2.50);
        $calendar_url = get_option('sec_calendar_url', '');
        $email_from_name = get_option('sec_email_from_name', get_bloginfo('name'));
        $email_from = get_option('sec_email_from', get_option('admin_email'));

        echo '<div class="wrap">';
        echo '<h1>Stripe Embedded Checkout Settings</h1>';
        echo '<form method="post" action="">';
        wp_nonce_field('sec_save_settings', 'sec_nonce');

        echo '<table class="form-table">';
        echo '<tr><th scope="row" colspan="2"><h2 style="margin:0;">Stripe API Keys</h2></th></tr>';
        echo '<tr><td colspan="2"><div class="notice notice-info inline" style="margin:0;padding:10px 15px;">';
        echo '<p><strong>Stripe API keys must be defined in wp-config.php:</strong></p>';
        echo '<pre style="background:#f0f0f0;padding:10px;margin:10px 0;overflow-x:auto;">';
        echo "define('STRIPE_PUBLISHABLE_KEY', 'pk_live_...');\ndefine('STRIPE_SECRET_KEY', 'sk_live_...');";
        echo '</pre>';
        $pk_status = $this->stripe_publishable_key ? '<span style="color:green;">Configured</span>' : '<span style="color:red;">Not configured</span>';
        $sk_status = $this->stripe_secret_key ? '<span style="color:green;">Configured</span>' : '<span style="color:red;">Not configured</span>';
        echo '<p>Publishable Key: ' . $pk_status . ' | Secret Key: ' . $sk_status . '</p>';
        echo '</div></td></tr>';

        echo '<tr><th scope="row" colspan="2"><h2 style="margin:20px 0 0;">Setup Fee &amp; Pricing</h2></th></tr>';
        echo '<tr><th scope="row">Service Name</th><td><input type="text" name="membership_name" value="' . esc_attr($service_name) . '" class="regular-text" /> <span class="description">Displayed on checkout and emails</span></td></tr>';
        echo '<tr><th scope="row">Setup Fee Amount</th><td><input type="number" name="membership_fee" value="' . esc_attr($setup_fee_amount) . '" step="0.01" min="0" class="small-text" /> <span class="description">The main Setup Fee one-time setup fee</span></td></tr>';
        echo '<tr><th scope="row">Processing Fee</th><td><input type="number" name="processing_fee" value="' . esc_attr($processing_fee) . '" step="0.01" min="0" class="small-text" /> <span class="description">Processing fee added to total</span></td></tr>';

        echo '<tr><th scope="row" colspan="2"><h2 style="margin:20px 0 0;">Email &amp; Calendar</h2></th></tr>';
        echo '<tr><th scope="row">Calendar Booking URL</th><td><input type="url" name="calendar_url" value="' . esc_attr($calendar_url) . '" class="regular-text" placeholder="https://calendly.com/your-link" /> <span class="description">Booking link included in confirmation email</span></td></tr>';
        echo '<tr><th scope="row">Email From Name</th><td><input type="text" name="email_from_name" value="' . esc_attr($email_from_name) . '" class="regular-text" /></td></tr>';
        echo '<tr><th scope="row">Email From Address</th><td><input type="email" name="email_from" value="' . esc_attr($email_from) . '" class="regular-text" /></td></tr>';

        // Landing page settings
        $card_image = get_option('sec_card_image', '');
        $btn_color = get_option('sec_btn_color', '#d32424ff');
        $btn_text_color = get_option('sec_btn_text_color', '#ffffff');

        echo '<tr><th scope="row" colspan="2"><h2 style="margin:20px 0 0;">Landing Page</h2></th></tr>';
        echo '<tr><th scope="row">Card Image</th><td>';
        echo '<input type="url" name="card_image" id="sec_card_image" value="' . esc_attr($card_image) . '" class="regular-text" placeholder="https://example.com/image.jpg" />';
        echo ' <button type="button" class="button" id="sec_upload_image_btn">Upload Image</button>';
        if ($card_image) {
            echo '<div style="margin-top:10px;"><img src="' . esc_url($card_image) . '" style="max-width:300px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1);" /></div>';
        }
        echo '<p class="description">Image displayed next to the membership form and above the order summary on checkout. Recommended size: 500x350px.</p>';
        echo '</td></tr>';
        echo '<tr><th scope="row">Button Color</th><td>';
        echo '<input type="color" id="sec_btn_color_picker" value="' . esc_attr($btn_color) . '" /> ';
        echo '<input type="text" name="btn_color" id="sec_btn_color_text" value="' . esc_attr($btn_color) . '" class="small-text" placeholder="#667eea" />';
        echo '<p class="description">Background color for the "Continue to Checkout" button and form header.</p>';
        echo '</td></tr>';
        echo '<tr><th scope="row">Button Text Color</th><td>';
        echo '<input type="color" id="sec_btn_text_color_picker" value="' . esc_attr($btn_text_color) . '" /> ';
        echo '<input type="text" name="btn_text_color" id="sec_btn_text_color_text" value="' . esc_attr($btn_text_color) . '" class="small-text" placeholder="#ffffff" />';
        echo '<p class="description">Text color for the button and form header text.</p>';
        echo '</td></tr>';

        echo '</table>';

        // Media uploader script
        echo '<script>
        jQuery(document).ready(function($) {
            $("#sec_upload_image_btn").on("click", function(e) {
                e.preventDefault();
                var mediaUploader = wp.media({
                    title: "Select Card Image",
                    button: { text: "Use This Image" },
                    multiple: false
                });
                mediaUploader.on("select", function() {
                    var attachment = mediaUploader.state().get("selection").first().toJSON();
                    $("#sec_card_image").val(attachment.url);
                });
                mediaUploader.open();
            });

            // Sync color pickers with text inputs
            $("#sec_btn_color_picker").on("input", function() { $("#sec_btn_color_text").val(this.value); });
            $("#sec_btn_color_text").on("input", function() { $("#sec_btn_color_picker").val(this.value); });
            $("#sec_btn_text_color_picker").on("input", function() { $("#sec_btn_text_color_text").val(this.value); });
            $("#sec_btn_text_color_text").on("input", function() { $("#sec_btn_text_color_picker").val(this.value); });
        });
        </script>';

        // Pricing preview
        $total = $setup_fee_amount + $processing_fee;
        echo '<div style="margin: 20px 0; padding: 15px; background: #f0f8ff; border-left: 4px solid #0073aa;">';
        echo '<h3>Pricing Preview — $' . number_format($total, 2) . '</h3>';
        echo '<ul style="margin:8px 0 0;">';
        echo '<li>' . esc_html($service_name) . ': $' . number_format($setup_fee_amount, 2) . '</li>';
        echo '<li>Processing Fee: $' . number_format($processing_fee, 2) . '</li>';
        echo '</ul>';
        echo '</div>';

        submit_button();
        echo '</form>';

        // Shortcode info
        if ($this->stripe_publishable_key) {
            echo '<div style="margin-top: 30px; padding: 20px; background: #f0f8ff; border-left: 4px solid #0073aa;">';
            echo '<h3>Shortcode Usage</h3>';
            echo '<p>Add this shortcode to any page to display the membership contact form:</p>';
            echo '<code>[stripe_checkout_popup]</code>';
            echo '<h4 style="margin-top: 20px;">Checkout Page</h4>';
            echo '<p>The checkout page is automatically created at: <a href="' . home_url('/checkout/') . '" target="_blank">/checkout/</a></p>';
            echo '</div>';
        }

        echo '</div>';
    }

    public function customers_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_customers';
        $customers = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC LIMIT 100");

        echo '<div class="wrap">';
        echo '<h1>Customers</h1>';

        // Status notice after delete
        if (isset($_GET['deleted'])) {
            if ($_GET['deleted'] === '1') {
                echo '<div class="notice notice-success is-dismissible"><p>Customer deleted.</p></div>';
            } elseif ($_GET['deleted'] === '0') {
                echo '<div class="notice notice-error is-dismissible"><p>Could not delete customer.</p></div>';
            }
        }

        if (empty($customers)) {
            echo '<p>No customers yet.</p>';
        } else {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr>';
            echo '<th>Name</th><th>Business</th><th>Email</th><th>Phone</th><th>Stripe ID</th><th>Amount</th><th>Date</th><th>Actions</th>';
            echo '</tr></thead><tbody>';

            foreach ($customers as $c) {
                $delete_url = wp_nonce_url(
                    admin_url('admin-post.php?action=sec_delete_customer&customer_id=' . intval($c->id)),
                    'sec_delete_customer'
                );

                echo '<tr>';
                echo '<td>' . esc_html($c->full_name) . '</td>';
                echo '<td>' . esc_html($c->business_name) . '</td>';
                echo '<td>' . esc_html($c->email) . '</td>';
                echo '<td>' . esc_html($c->phone) . '</td>';
                echo '<td><code>' . esc_html($c->stripe_customer_id) . '</code></td>';
                echo '<td>$' . number_format((float)$c->amount_paid, 2) . '</td>';
                echo '<td>' . date('M j, Y g:i A', strtotime($c->created_at)) . '</td>';

                echo '<td>
                    <a href="' . esc_url($delete_url) . '" class="button button-small"
                    onclick="return confirm(\'Delete this customer from the local database? This cannot be undone.\');">
                    Delete
                    </a>
                </td>';

                echo '</tr>';
            }

            echo '</tbody></table>';
        }

        echo '</div>';
    }

    // ==========================================
    // CUSTOM INVOICE FUNCTIONALITY
    // ==========================================

    /**
     * Get invoice branding setting
     */
    private function get_invoice_setting($key, $default = '') {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_invoice_settings';
        $value = $wpdb->get_var($wpdb->prepare(
            "SELECT setting_value FROM $table WHERE setting_key = %s",
            $key
        ));
        return $value !== null ? $value : $default;
    }

    /**
     * Update invoice branding setting
     */
    private function update_invoice_setting($key, $value) {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_invoice_settings';
        
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE setting_key = %s",
            $key
        ));

        if ($exists) {
            $wpdb->update(
                $table,
                array('setting_value' => $value),
                array('setting_key' => $key),
                array('%s'),
                array('%s')
            );
        } else {
            $wpdb->insert(
                $table,
                array('setting_key' => $key, 'setting_value' => $value),
                array('%s', '%s')
            );
        }
    }

    /**
     * Generate unique invoice number
     */
    private function generate_invoice_number() {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_custom_invoices';
        $prefix = 'INV-';
        $date_part = date('Ym');
        
        $last_invoice = $wpdb->get_var(
            "SELECT invoice_number FROM $table 
             WHERE invoice_number LIKE '{$prefix}{$date_part}%' 
             ORDER BY id DESC LIMIT 1"
        );

        if ($last_invoice) {
            $number = intval(substr($last_invoice, -4)) + 1;
        } else {
            $number = 1;
        }

        return $prefix . $date_part . '-' . str_pad($number, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Generate custom invoice
     */
    private function generate_custom_invoice($customer_name, $customer_email, $items, $expires_at) {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_custom_invoices';

        try {
            $token = bin2hex(random_bytes(32));
            $invoice_number = $this->generate_invoice_number();

            $amount_subtotal = 0;
            foreach ($items as $item) {
                $amount_subtotal += floatval($item['price']) * intval($item['quantity']);
            }

            $amount_tax = 0; // Can be extended for tax calculation
            $amount_total = $amount_subtotal + $amount_tax;

            $result = $wpdb->insert(
                $table,
                array(
                    'invoice_number' => $invoice_number,
                    'token' => $token,
                    'customer_name' => $customer_name,
                    'customer_email' => $customer_email,
                    'items' => json_encode($items),
                    'amount_subtotal' => $amount_subtotal,
                    'amount_tax' => $amount_tax,
                    'amount_total' => $amount_total,
                    'status' => 'pending',
                    'expires_at' => $expires_at
                ),
                array('%s', '%s', '%s', '%s', '%s', '%f', '%f', '%f', '%s', '%s')
            );

            if ($result === false) {
                error_log('SEC Invoice: Database insert failed - ' . $wpdb->last_error);
                return false;
            }

            return array(
                'invoice_id' => $wpdb->insert_id,
                'invoice_number' => $invoice_number,
                'token' => $token,
                'amount_total' => $amount_total
            );
        } catch (Exception $e) {
            error_log('SEC Invoice: Exception in generate_custom_invoice - ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get invoice by token
     */
    private function get_invoice_by_token($token) {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_custom_invoices';
        
        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE token = %s",
            $token
        ), ARRAY_A);

        if ($invoice && !empty($invoice['items'])) {
            $invoice['items'] = json_decode($invoice['items'], true);
        }

        return $invoice;
    }

    /**
     * Update invoice status
     */
    private function update_invoice_status($invoice_id, $status, $extra_data = array()) {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_custom_invoices';
        
        $update_data = array('status' => $status);
        $update_format = array('%s');

        if ($status === 'paid' && !isset($extra_data['paid_at'])) {
            $update_data['paid_at'] = current_time('mysql');
            $update_format[] = '%s';
        }

        foreach ($extra_data as $key => $value) {
            $update_data[$key] = $value;
            $update_format[] = is_numeric($value) ? '%f' : '%s';
        }

        $wpdb->update(
            $table,
            $update_data,
            array('id' => $invoice_id),
            $update_format,
            array('%d')
        );
    }

    /**
     * Send custom invoice email with Stripe invoice PDF attached
     */
    private function send_custom_invoice_email($invoice_data, $checkout_url) {
        if (!class_exists('\PHPMailer\PHPMailer\PHPMailer')) {
            require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
            require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
            require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
        }

        $email = sanitize_email($invoice_data['customer_email']);
        if (!$email || !is_email($email)) {
            error_log("Invoice Email Error: Invalid email.");
            return false;
        }

        $customer_name = sanitize_text_field($invoice_data['customer_name']);
        $invoice_number = sanitize_text_field($invoice_data['invoice_number']);
        
        $business_name = $this->get_invoice_setting('invoice_business_name', get_bloginfo('name'));
        $support_email = $this->get_invoice_setting('invoice_support_email', get_option('admin_email'));
        $primary_color = $this->get_invoice_setting('invoice_primary_color', '#635BFF');
        $logo_url = $this->get_invoice_setting('invoice_logo_url', '');

        $items = $invoice_data['items'];
        $items_html = '';
        foreach ($items as $item) {
            $item_name = esc_html($item['name']);
            $quantity = intval($item['quantity']);
            $price = floatval($item['price']);
            $line_total = $quantity * $price;
            
            $items_html .= '<tr>';
            $items_html .= '<td style="padding:8px 0; color:#111;">' . $item_name . '</td>';
            $items_html .= '<td align="center" style="padding:8px 0; color:#666;">' . $quantity . '</td>';
            $items_html .= '<td align="right" style="padding:8px 0; color:#111; white-space:nowrap;">$' . number_format($price, 2) . '</td>';
            $items_html .= '<td align="right" style="padding:8px 0; color:#111; white-space:nowrap;">$' . number_format($line_total, 2) . '</td>';
            $items_html .= '</tr>';
        }

        $expires_at = !empty($invoice_data['expires_at']) ? date('F j, Y', strtotime($invoice_data['expires_at'])) : '';
        $expires_warning = $expires_at ? '<p style="margin-top:14px; padding:12px; background:#fff3cd; border:1px solid #ffc107; border-radius:6px; font-size:13px; color:#856404;">⏰ This invoice expires on <strong>' . esc_html($expires_at) . '</strong></p>' : '';

        try {
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);

            $mail->isSMTP();
            $mail->Host       = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.gmail.com';
            $mail->SMTPAuth   = defined('SMTP_AUTH') ? SMTP_AUTH : true;
            $mail->Username   = defined('SMTP_USERNAME') ? SMTP_USERNAME : '';
            $mail->Password   = defined('SMTP_PASSWORD') ? SMTP_PASSWORD : '';
            $mail->SMTPSecure = defined('SMTP_SECURE') ? SMTP_SECURE : 'tls';
            $mail->Port       = defined('SMTP_PORT') ? SMTP_PORT : 587;
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                ]
            ];

            $mail->setFrom(defined('SMTP_USERNAME') ? SMTP_USERNAME : get_option('admin_email'), $business_name);
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Invoice ' . $invoice_number . ' from ' . $business_name;

            // Attach Stripe invoice PDF if available
            if (!empty($invoice_data['stripe_invoice_pdf_url'])) {
                // Download PDF temporarily and attach
                $pdf_content = @file_get_contents($invoice_data['stripe_invoice_pdf_url']);
                if ($pdf_content) {
                    $mail->addStringAttachment($pdf_content, $invoice_number . '.pdf', 'base64', 'application/pdf');
                }
            }

            $mail->Body = <<<HTML
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; color: #333333; background-color: #f9f9f9; }
  </style>
</head>
<body style="margin:0; padding:0; background-color:#f9f9f9;">
  <table width="100%" bgcolor="#f9f9f9" cellpadding="0" cellspacing="0">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0" bgcolor="#ffffff" style="border:1px solid #dddddd; border-radius:8px;">
          <tr>
            <td align="center" style="background-color:{$primary_color}; padding: 30px 20px; border-top-left-radius:8px; border-top-right-radius:8px;">
              <h1 style="margin:0; color:#ffffff; font-size:24px;">Invoice {$invoice_number}</h1>
            </td>
          </tr>

          <tr>
            <td style="padding: 35px; font-size:16px; line-height:1.6;">
              <p>Hi <strong>{$customer_name}</strong>,</p>
              <p>Please find your invoice below. Click the button to view and pay securely.</p>

              {$expires_warning}

              <div style="margin:24px 0; padding:20px; border:1px solid #e6e6e6; border-radius:10px; background:#fafafa;">
                <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;">
                  <thead>
                    <tr style="border-bottom:2px solid #e6e6e6;">
                      <th align="left" style="padding:8px 0; font-size:12px; color:#666;">DESCRIPTION</th>
                      <th align="center" style="padding:8px 0; font-size:12px; color:#666;">QTY</th>
                      <th align="right" style="padding:8px 0; font-size:12px; color:#666;">PRICE</th>
                      <th align="right" style="padding:8px 0; font-size:12px; color:#666;">TOTAL</th>
                    </tr>
                  </thead>
                  <tbody>
                    {$items_html}
                    <tr><td colspan="4" style="border-top:1px solid #e6e6e6; padding-top:12px;"></td></tr>
                    <tr>
                      <td colspan="3" align="right" style="padding:6px 12px 6px 0; font-weight:700; font-size:16px;">Total:</td>
                      <td align="right" style="padding:6px 0; font-weight:700; font-size:16px; white-space:nowrap;">\${$invoice_data['amount_total']}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div style="text-align:center; margin:30px 0;">
                <a href="{$checkout_url}" target="_blank"
                  style="display:inline-block; text-decoration:none; font-weight:600; padding:14px 32px; border-radius:8px; background:{$primary_color}; color:#fff; font-size:16px;">
                  View & Pay Invoice
                </a>
              </div>

              <p style="margin-top:24px; font-size:13px; color:#666;">
                Questions? Reply to this email or contact
                <a href="mailto:{$support_email}" style="color:{$primary_color};">{$support_email}</a>.
              </p>

              <p style="margin-top:26px;">Thank you,<br><strong>{$business_name} Team</strong></p>
            </td>
          </tr>

          <tr>
            <td align="center" style="background-color:#f1f1f1; font-size:12px; color:#999999; padding:20px; border-bottom-left-radius:8px; border-bottom-right-radius:8px;">
              © {$invoice_data['created_at']} {$business_name}. All rights reserved.
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;

            return $mail->send();

        } catch (\Exception $e) {
            error_log("Invoice Mailer Error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * AJAX: Generate custom invoice
     */
    public function ajax_generate_invoice() {
        try {
            // Enable error logging
            error_log('SEC Invoice: Starting invoice generation');
            
            if (!isset($_POST['nonce'])) {
                error_log('SEC Invoice: No nonce provided');
                wp_send_json_error('No security token provided');
                return;
            }
            
            if (!wp_verify_nonce($_POST['nonce'], 'sec_invoice_nonce')) {
                error_log('SEC Invoice: Nonce verification failed');
                wp_send_json_error('Security check failed');
                return;
            }

            if (!current_user_can('manage_options')) {
                error_log('SEC Invoice: User lacks permissions');
                wp_send_json_error('Unauthorized');
                return;
            }

            $customer_name = isset($_POST['customer_name']) ? sanitize_text_field($_POST['customer_name']) : '';
            $customer_email = isset($_POST['customer_email']) ? sanitize_email($_POST['customer_email']) : '';
            $expiry_days = isset($_POST['expiry_days']) ? intval($_POST['expiry_days']) : 7;
            
            if (empty($customer_name) || empty($customer_email)) {
                wp_send_json_error('Customer name and email are required');
                return;
            }
            
            $expires_at = date('Y-m-d H:i:s', strtotime("+{$expiry_days} days"));

            // Build items array
            $items = array();
            $current_month_year = date('F Y');
            
            if (!empty($_POST['include_membership'])) {
                $setup_fee_amount = floatval(get_option('sec_setup_fee_amount', 499.00));
                $items[] = array(
                    'name' => 'Website Setup - ' . $current_month_year,
                    'quantity' => 1,
                    'price' => $setup_fee_amount
                );
            }

            if (!empty($_POST['include_hosting'])) {
                $hosting_fee = floatval($this->get_invoice_setting('website_hosting_fee', 25.00));
                $items[] = array(
                    'name' => 'Website Hosting - ' . $current_month_year,
                    'quantity' => 1,
                    'price' => $hosting_fee
                );
            }

            if (!empty($_POST['include_processing'])) {
                $processing_fee = floatval(get_option('sec_processing_fee', 2.50));
                $items[] = array(
                    'name' => 'Processing Fee',
                    'quantity' => 1,
                    'price' => $processing_fee
                );
            }

            if (empty($items)) {
                wp_send_json_error('Please select at least one item');
                return;
            }

            error_log('SEC Invoice: Generating invoice with ' . count($items) . ' items');
            
            $result = $this->generate_custom_invoice($customer_name, $customer_email, $items, $expires_at);
            
            if (!$result) {
                error_log('SEC Invoice: generate_custom_invoice returned false');
                wp_send_json_error('Failed to generate invoice');
                return;
            }

            $checkout_url = home_url('/checkout/?invoice_token=' . $result['token']);

            // Send email if auto-send is enabled
            $invoice_data = $this->get_invoice_by_token($result['token']);
            if ($this->get_invoice_setting('invoice_auto_send_email', '1') === '1') {
                error_log('SEC Invoice: Sending email to ' . $customer_email);
                $email_sent = $this->send_custom_invoice_email($invoice_data, $checkout_url);
                error_log('SEC Invoice: Email sent status: ' . ($email_sent ? 'success' : 'failed'));
            }

            error_log('SEC Invoice: Invoice generated successfully - ' . $result['invoice_number']);

            wp_send_json_success(array(
                'invoice_number' => $result['invoice_number'],
                'checkout_url' => $checkout_url,
                'token' => $result['token'],
                'amount_total' => $result['amount_total']
            ));
            
        } catch (Exception $e) {
            error_log('SEC Invoice: Exception - ' . $e->getMessage() . ' in ' . $e->getFile() . ' on line ' . $e->getLine());
            wp_send_json_error('Error: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Resend invoice email
     */
    public function ajax_resend_invoice_email() {
        check_ajax_referer('sec_invoice_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $invoice_id = intval($_POST['invoice_id']);
        global $wpdb;
        $table = $wpdb->prefix . 'sec_custom_invoices';
        
        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $invoice_id
        ), ARRAY_A);

        if (!$invoice) {
            wp_send_json_error('Invoice not found');
        }

        $checkout_url = home_url('/checkout/?invoice_token=' . $invoice['token']);
        $sent = $this->send_custom_invoice_email($invoice, $checkout_url);

        if ($sent) {
            wp_send_json_success('Email sent successfully');
        } else {
            wp_send_json_error('Failed to send email');
        }
    }

    /**
     * AJAX: Update invoice status
     */
    public function ajax_update_invoice_status() {
        check_ajax_referer('sec_invoice_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $invoice_id = intval($_POST['invoice_id']);
        $status = sanitize_text_field($_POST['status']);

        $this->update_invoice_status($invoice_id, $status);
        wp_send_json_success('Status updated');
    }

    /**
     * Custom invoice shortcode (displays on checkout page)
     */
    public function custom_invoice_shortcode($atts) {
        if (empty($this->stripe_publishable_key)) {
            return '<p><strong>Error:</strong> Stripe not configured.</p>';
        }

        ob_start();
        echo '<div id="stripe-embedded-checkout-container">';
        echo '<div class="loading-checkout">';
        echo '<div class="loading-spinner"></div>';
        echo '<p>Loading invoice checkout...</p>';
        echo '</div>';
        echo '</div>';
        return ob_get_clean();
    }

    /**
     * Handle custom invoice checkout page
     */
    private function handle_custom_invoice_checkout($invoice_token) {
        $invoice = $this->get_invoice_by_token($invoice_token);

        if (!$invoice) {
            $this->show_expired_checkout();
            exit;
        }

        // Check if expired
        if ($invoice['status'] === 'expired' || 
            ($invoice['expires_at'] && strtotime($invoice['expires_at']) < time())) {
            
            // Update status to expired
            if ($invoice['status'] !== 'expired') {
                $this->update_invoice_status($invoice['id'], 'expired');
            }
            $this->show_expired_checkout();
            exit;
        }

        // Check if already paid
        if ($invoice['status'] === 'paid') {
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Already Paid</title></head><body>';
            echo '<div style="text-align:center; padding:60px 20px; font-family:Arial,sans-serif;">';
            echo '<h2>Invoice Already Paid</h2>';
            echo '<p>This invoice has already been paid.</p>';
            echo '<a href="' . home_url() . '" style="display:inline-block; margin-top:20px; padding:12px 24px; background:#635BFF; color:white; text-decoration:none; border-radius:6px;">Return Home</a>';
            echo '</div></body></html>';
            exit;
        }

        // Check if voided
        if ($invoice['status'] === 'voided') {
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Invoice Voided</title></head><body>';
            echo '<div style="text-align:center; padding:60px 20px; font-family:Arial,sans-serif;">';
            echo '<h2>Invoice Voided</h2>';
            echo '<p>This invoice has been cancelled.</p>';
            echo '<a href="' . home_url() . '" style="display:inline-block; margin-top:20px; padding:12px 24px; background:#635BFF; color:white; text-decoration:none; border-radius:6px;">Return Home</a>';
            echo '</div></body></html>';
            exit;
        }

        // Create Stripe checkout session
        if (!class_exists('Stripe\Stripe')) {
            require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
        }
        \Stripe\Stripe::setApiKey($this->stripe_secret_key);

        try {
            $line_items = array();
            $current_month_year = date('F Y');

            foreach ($invoice['items'] as $item) {
                $line_items[] = array(
                    'price_data' => array(
                        'currency' => 'usd',
                        'product_data' => array(
                            'name' => $item['name']
                        ),
                        'unit_amount' => intval($item['price'] * 100)
                    ),
                    'quantity' => intval($item['quantity'])
                );
            }

            $return_url = home_url('/checkout/?session_id={CHECKOUT_SESSION_ID}&invoice_token=' . urlencode($invoice_token));
            
            $session = \Stripe\Checkout\Session::create(array(
                'payment_method_types' => array('card'),
                'line_items' => $line_items,
                'mode' => 'payment',
                'return_url' => $return_url,
                'customer_email' => $invoice['customer_email'],
                'metadata' => array(
                    'invoice_id' => $invoice['id'],
                    'invoice_number' => $invoice['invoice_number'],
                    'invoice_token' => $invoice_token
                ),
                'ui_mode' => 'embedded'
            ));

            $this->show_custom_invoice_embedded_checkout($session->client_secret, $invoice, $invoice_token);
            exit;

        } catch (Exception $e) {
            error_log('Custom Invoice Checkout Error: ' . $e->getMessage());
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Error</title></head><body>';
            echo '<div style="text-align:center; padding:60px 20px; font-family:Arial,sans-serif;">';
            echo '<h2>Error Loading Checkout</h2>';
            echo '<p>There was an error processing your request. Please try again later.</p>';
            echo '</div></body></html>';
            exit;
        }
    }

    /**
     * Show custom invoice embedded checkout
     */
    private function show_custom_invoice_embedded_checkout($client_secret, $invoice, $token) {
        $business_name = $this->get_invoice_setting('invoice_business_name', get_bloginfo('name'));
        $primary_color = $this->get_invoice_setting('invoice_primary_color', '#635BFF');

        echo '<!DOCTYPE html>';
        echo '<html ' . get_language_attributes() . '>';
        echo '<head>';
        echo '<meta charset="' . get_bloginfo('charset') . '">';
        echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
        echo '<title>Invoice ' . esc_html($invoice['invoice_number']) . ' - Checkout</title>';
        echo '<script src="https://js.stripe.com/v3/"></script>';
        echo '<style>';
        echo file_get_contents(plugin_dir_path(__FILE__) . 'assets/sec-popup.css');
        echo '</style>';
        echo '</head>';
        echo '<body>';
        
        echo '<div class="sec-form-container">';
        echo '<div class="sec-membership-form-wrapper">';
        echo '<div class="sec-form-header">';
        echo '<h2>Invoice ' . esc_html($invoice['invoice_number']) . '</h2>';
        echo '<p>Pay securely with Stripe</p>';
        if ($invoice['expires_at']) {
            echo '<p style="font-size:0.85em; margin-top:10px;">Expires: ' . date('F j, Y', strtotime($invoice['expires_at'])) . '</p>';
        }
        echo '</div>';

        echo '<div style="padding:30px;">';
        echo '<div style="margin-bottom:24px; padding:16px; background:#f8f9fa; border-radius:8px;">';
        echo '<h4 style="margin:0 0 8px 0;">Bill To:</h4>';
        echo '<p style="margin:0; font-size:14px;">' . esc_html($invoice['customer_name']) . '</p>';
        echo '<p style="margin:0; font-size:14px; color:#666;">' . esc_html($invoice['customer_email']) . '</p>';
        echo '</div>';

        echo '<div style="margin-bottom:24px;">';
        echo '<h4 style="margin:0 0 12px 0;">Items:</h4>';
        echo '<table style="width:100%; border-collapse:collapse;">';
        foreach ($invoice['items'] as $item) {
            echo '<tr>';
            echo '<td style="padding:8px 0; border-bottom:1px solid #e6e6e6;">' . esc_html($item['name']) . '</td>';
            echo '<td style="padding:8px 0; border-bottom:1px solid #e6e6e6; text-align:center; width:60px;">' . intval($item['quantity']) . '</td>';
            echo '<td style="padding:8px 0; border-bottom:1px solid #e6e6e6; text-align:right; width:100px;">$' . number_format($item['price'], 2) . '</td>';
            echo '<td style="padding:8px 0; border-bottom:1px solid #e6e6e6; text-align:right; width:100px; font-weight:600;">$' . number_format($item['price'] * $item['quantity'], 2) . '</td>';
            echo '</tr>';
        }
        echo '<tr>';
        echo '<td colspan="3" style="padding:12px 0; text-align:right; font-weight:700; font-size:16px;">Total:</td>';
        echo '<td style="padding:12px 0; text-align:right; font-weight:700; font-size:16px;">$' . number_format($invoice['amount_total'], 2) . '</td>';
        echo '</tr>';
        echo '</table>';
        echo '</div>';

        echo '<div id="checkout-element">';
        echo '<div class="loading-spinner" style="margin:40px auto;"></div>';
        echo '</div>';

        echo '</div>';
        echo '</div>';
        echo '</div>';

        echo '<script>';
        echo 'const stripe = Stripe("' . esc_js($this->stripe_publishable_key) . '");';
        echo 'const checkout = stripe.initEmbeddedCheckout({';
        echo '  clientSecret: "' . esc_js($client_secret) . '"';
        echo '});';
        echo 'checkout.mount("#checkout-element");';
        echo '</script>';
        
        echo '</body>';
        echo '</html>';
    }

    /**
     * Handle custom invoice payment success
     */
    private function handle_custom_invoice_success($session_id, $invoice_token) {
        if (!class_exists('Stripe\Stripe')) {
            require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';
        }
        \Stripe\Stripe::setApiKey($this->stripe_secret_key);

        try {
            $session = \Stripe\Checkout\Session::retrieve($session_id);
            $invoice = $this->get_invoice_by_token($invoice_token);

            if (!$invoice || !$session) {
                wp_redirect(home_url());
                exit;
            }

            // Update invoice status
            $extra_data = array(
                'stripe_session_id' => $session_id,
                'stripe_customer_id' => $session->customer,
                'paid_at' => current_time('mysql')
            );

            // Try to get Stripe invoice PDF URL
            if ($session->invoice) {
                try {
                    $stripe_invoice = \Stripe\Invoice::retrieve($session->invoice);
                    if ($stripe_invoice->invoice_pdf) {
                        $extra_data['stripe_invoice_pdf_url'] = $stripe_invoice->invoice_pdf;
                    }
                } catch (Exception $e) {
                    error_log('Failed to retrieve Stripe invoice PDF: ' . $e->getMessage());
                }
            }

            $this->update_invoice_status($invoice['id'], 'paid', $extra_data);

            // Store customer data with subscription dates
            global $wpdb;
            $customers_table = $wpdb->prefix . 'sec_customers';
            
            $subscription_start = current_time('mysql');
            $membership_renewal = date('Y-m-d H:i:s', strtotime('+1 year'));
            $hosting_renewal = date('Y-m-d H:i:s', strtotime('+1 month'));

            $wpdb->insert(
                $customers_table,
                array(
                    'stripe_customer_id' => $session->customer,
                    'full_name' => $invoice['customer_name'],
                    'business_name' => $invoice['customer_name'],
                    'email' => $invoice['customer_email'],
                    'phone' => isset($invoice['customer_phone']) ? $invoice['customer_phone'] : '',
                    'membership_name' => 'Custom Invoice',
                    'amount_paid' => $invoice['amount_total'],
                    'stripe_session_id' => $session_id,
                    'subscription_start_date' => $subscription_start,
                    'membership_renewal_date' => $membership_renewal,
                    'hosting_renewal_date' => $hosting_renewal
                ),
                array('%s', '%s', '%s', '%s', '%s', '%s', '%f', '%s', '%s', '%s', '%s')
            );

            // Send receipt email with Stripe PDF attached
            $invoice_with_pdf = $this->get_invoice_by_token($invoice_token);
            $checkout_url = home_url('/checkout/?invoice_token=' . $invoice_token);
            $this->send_custom_invoice_email($invoice_with_pdf, $checkout_url);

            // Store payment session data for survey modal
            if (class_exists('SEC_Survey_Modal')) {
                $token_data = array(
                    'full_name' => $invoice['customer_name'] ?? '',
                    'email' => $invoice['customer_email'] ?? '',
                    'phone' => $invoice['customer_phone'] ?? ''
                );
                $survey_token = SEC_Survey_Modal::store_payment_session($session, $token_data);
                if ($survey_token && class_exists('SEC_Survey_Email')) {
                    SEC_Survey_Email::send_survey_invitation(
                        $token_data['email'] ?? '',
                        $token_data['full_name'] ?? '',
                        $survey_token,
                        $token_data['full_name'] ?? ''
                    );
                }
            }

            // Redirect to success page
            wp_redirect(home_url('/checkout/?payment_complete=1'));
            exit;

        } catch (Exception $e) {
            error_log('Custom Invoice Success Error: ' . $e->getMessage());
            wp_redirect(home_url());
            exit;
        }
    }

    public function discount_codes_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sec_discount_codes';

        if (isset($_POST['action']) && wp_verify_nonce($_POST['discount_nonce'], 'discount_codes_action')) {

            if ($_POST['action'] === 'add') {
                $result = $wpdb->insert(
                    $table_name,
                    array(
                        'code' => strtoupper(sanitize_text_field($_POST['code'])),
                        'type' => sanitize_text_field($_POST['type']),
                        'value' => floatval($_POST['value']),
                        'usage_limit' => !empty($_POST['usage_limit']) ? intval($_POST['usage_limit']) : null,
                        'expires_at' => !empty($_POST['expires_at']) ? sanitize_text_field($_POST['expires_at']) : null,
                        'active' => isset($_POST['active']) ? 1 : 0
                    ),
                    array('%s', '%s', '%f', '%d', '%s', '%d')
                );
                echo $result ? '<div class="notice notice-success"><p>Discount code added!</p></div>' : '<div class="notice notice-error"><p>Error adding discount code.</p></div>';
            }

            elseif ($_POST['action'] === 'edit' && !empty($_POST['edit_id'])) {
                $wpdb->update(
                    $table_name,
                    array(
                        'code' => strtoupper(sanitize_text_field($_POST['code'])),
                        'type' => sanitize_text_field($_POST['type']),
                        'value' => floatval($_POST['value']),
                        'usage_limit' => !empty($_POST['usage_limit']) ? intval($_POST['usage_limit']) : null,
                        'expires_at' => !empty($_POST['expires_at']) ? sanitize_text_field($_POST['expires_at']) : null,
                        'active' => isset($_POST['active']) ? 1 : 0
                    ),
                    array('id' => intval($_POST['edit_id'])),
                    array('%s', '%s', '%f', '%d', '%s', '%d'),
                    array('%d')
                );
                echo '<div class="notice notice-success"><p>Discount code updated!</p></div>';
            }

            elseif ($_POST['action'] === 'delete' && !empty($_POST['delete_id'])) {
                $wpdb->delete($table_name, array('id' => intval($_POST['delete_id'])), array('%d'));
                echo '<div class="notice notice-success"><p>Discount code deleted!</p></div>';
            }

            elseif ($_POST['action'] === 'toggle_status' && !empty($_POST['toggle_id'])) {
                $current = $wpdb->get_var($wpdb->prepare("SELECT active FROM $table_name WHERE id = %d", intval($_POST['toggle_id'])));
                $wpdb->update($table_name, array('active' => $current ? 0 : 1), array('id' => intval($_POST['toggle_id'])), array('%d'), array('%d'));
                echo '<div class="notice notice-success"><p>Status updated!</p></div>';
            }
        }

        $edit_code = null;
        if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
            $edit_code = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($_GET['edit'])));
        }

        $discount_codes = $wpdb->get_results("SELECT * FROM $table_name ORDER BY created_at DESC");

        ?>
        <div class="wrap">
            <h1>Discount Codes Management</h1>

            <div class="card" style="max-width: 800px; margin-bottom: 20px;">
                <h2><?php echo $edit_code ? 'Edit Discount Code' : 'Add New Discount Code'; ?></h2>
                <form method="post" action="">
                    <?php wp_nonce_field('discount_codes_action', 'discount_nonce'); ?>
                    <input type="hidden" name="action" value="<?php echo $edit_code ? 'edit' : 'add'; ?>">
                    <?php if ($edit_code): ?>
                        <input type="hidden" name="edit_id" value="<?php echo $edit_code->id; ?>">
                    <?php endif; ?>

                    <table class="form-table">
                        <tr><th>Discount Code</th><td><input type="text" name="code" value="<?php echo $edit_code ? esc_attr($edit_code->code) : ''; ?>" class="regular-text" required maxlength="50" style="text-transform: uppercase;"></td></tr>
                        <tr><th>Discount Type</th><td><select name="type"><option value="percentage" <?php echo ($edit_code && $edit_code->type === 'percentage') ? 'selected' : ''; ?>>Percentage</option><option value="fixed" <?php echo ($edit_code && $edit_code->type === 'fixed') ? 'selected' : ''; ?>>Fixed Amount ($)</option></select></td></tr>
                        <tr><th>Value</th><td><input type="number" name="value" value="<?php echo $edit_code ? esc_attr($edit_code->value) : ''; ?>" class="small-text" required min="0" step="0.01"></td></tr>
                        <tr><th>Usage Limit</th><td><input type="number" name="usage_limit" value="<?php echo $edit_code ? esc_attr($edit_code->usage_limit) : ''; ?>" class="small-text" min="1"> <span class="description">Leave empty for unlimited</span></td></tr>
                        <tr><th>Expiration</th><td><input type="datetime-local" name="expires_at" value="<?php echo $edit_code && $edit_code->expires_at ? date('Y-m-d\TH:i', strtotime($edit_code->expires_at)) : ''; ?>"></td></tr>
                        <tr><th>Status</th><td><label><input type="checkbox" name="active" <?php echo (!$edit_code || $edit_code->active) ? 'checked' : ''; ?>> Active</label></td></tr>
                    </table>

                    <?php submit_button($edit_code ? 'Update' : 'Add Discount Code'); ?>
                    <?php if ($edit_code): ?>
                        <a href="<?php echo admin_url('options-general.php?page=stripe-discount-codes'); ?>" class="button">Cancel</a>
                    <?php endif; ?>
                </form>
            </div>

            <div class="card">
                <h2>Existing Discount Codes</h2>
                <?php if (empty($discount_codes)): ?>
                    <p>No discount codes found.</p>
                <?php else: ?>
                    <table class="wp-list-table widefat fixed striped">
                        <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Usage</th><th>Expires</th><th>Status</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php foreach ($discount_codes as $code): ?>
                                <tr <?php echo !$code->active ? 'style="opacity: 0.6;"' : ''; ?>>
                                    <td><strong><?php echo esc_html($code->code); ?></strong></td>
                                    <td><?php echo ucfirst($code->type); ?></td>
                                    <td><?php echo $code->type === 'percentage' ? esc_html($code->value) . '%' : '$' . number_format($code->value, 2); ?></td>
                                    <td><?php echo intval($code->usage_count); ?><?php echo $code->usage_limit ? ' / ' . intval($code->usage_limit) : ' / &infin;'; ?></td>
                                    <td><?php echo $code->expires_at ? date('M j, Y', strtotime($code->expires_at)) : 'Never'; ?></td>
                                    <td><span style="color:<?php echo $code->active ? '#46b450' : '#d63638'; ?>;font-weight:bold;"><?php echo $code->active ? 'Active' : 'Disabled'; ?></span></td>
                                    <td>
                                        <a href="<?php echo admin_url('options-general.php?page=stripe-discount-codes&edit=' . $code->id); ?>" class="button button-small">Edit</a>
                                        <form method="post" style="display:inline;"><input type="hidden" name="action" value="toggle_status"><input type="hidden" name="toggle_id" value="<?php echo $code->id; ?>"><?php wp_nonce_field('discount_codes_action', 'discount_nonce'); ?><button type="submit" class="button button-small"><?php echo $code->active ? 'Disable' : 'Enable'; ?></button></form>
                                        <form method="post" style="display:inline;" onsubmit="return confirm('Delete this code?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="delete_id" value="<?php echo $code->id; ?>"><?php wp_nonce_field('discount_codes_action', 'discount_nonce'); ?><button type="submit" class="button button-small" style="color:#d63638;">Delete</button></form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <style>.card{background:#fff;border:1px solid #ccd0d4;border-radius:4px;padding:20px;}</style>
        <?php
    }

    // ==========================================
    // INVOICE ADMIN PAGES
    // ==========================================

    /**
     * Invoice Generator Page
     */
    public function invoice_generator_page() {
        // Ensure tables exist
        global $wpdb;
        $table = $wpdb->prefix . 'sec_custom_invoices';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            $this->create_tables();
            echo '<div class="notice notice-info"><p>Invoice tables were just created. Please try again.</p></div>';
        }

        $current_month_year = date('F Y');
        $setup_fee_amount = floatval(get_option('sec_setup_fee_amount', 499.00));
        $hosting_fee = floatval($this->get_invoice_setting('website_hosting_fee', 25.00));
        $processing_fee = floatval(get_option('sec_processing_fee', 2.50));
        $default_expiry = $this->get_invoice_setting('invoice_default_expiry_days', '7');

        ?>
        <div class="wrap">
            <h1>Generate Custom Invoice Link</h1>

            <div class="card" style="max-width: 800px;">
                <h2>Create New Invoice</h2>
                <form id="invoice-generator-form">
                    <?php wp_nonce_field('sec_invoice_nonce', 'invoice_nonce'); ?>
                    
                    <table class="form-table">
                        <tr>
                            <th>Customer Name <span style="color:red;">*</span></th>
                            <td><input type="text" name="customer_name" id="customer_name" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th>Customer Email <span style="color:red;">*</span></th>
                            <td><input type="email" name="customer_email" id="customer_email" class="regular-text" required></td>
                        </tr>
                        <tr>
                            <th>Items to Include</th>
                            <td>
                                <label style="display:block; margin-bottom:8px;">
                                    <input type="checkbox" name="include_membership" checked> 
                                    Website Setup - <?php echo esc_html($current_month_year); ?> 
                                    <strong>($<?php echo number_format($setup_fee_amount, 2); ?>)</strong>
                                </label>
                                <label style="display:block; margin-bottom:8px;">
                                    <input type="checkbox" name="include_hosting" checked> 
                                    Website Hosting - <?php echo esc_html($current_month_year); ?> 
                                    <strong>($<?php echo number_format($hosting_fee, 2); ?>)</strong>
                                </label>
                                <label style="display:block;">
                                    <input type="checkbox" name="include_processing" checked> 
                                    Processing Fee 
                                    <strong>($<?php echo number_format($processing_fee, 2); ?>)</strong>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th>Expires In (Days)</th>
                            <td>
                                <input type="number" name="expiry_days" value="<?php echo esc_attr($default_expiry); ?>" min="1" max="365" class="small-text">
                                <span class="description">Invoice will expire after this many days</span>
                            </td>
                        </tr>
                    </table>

                    <p class="submit">
                        <button type="submit" class="button button-primary button-large" id="generate-invoice-btn">Generate Invoice Link</button>
                    </p>
                </form>

                <div id="invoice-result" style="display:none; margin-top:30px; padding:20px; background:#f0f9ff; border:1px solid #bfdbfe; border-radius:8px;">
                    <h3 style="margin-top:0;">Invoice Generated Successfully!</h3>
                    <p><strong>Invoice Number:</strong> <span id="result-invoice-number"></span></p>
                    <p><strong>Amount:</strong> $<span id="result-amount"></span></p>
                    <p><strong>Checkout Link:</strong></p>
                    <div style="display:flex; gap:10px; margin-bottom:15px;">
                        <input type="text" id="result-url" readonly style="flex:1; padding:10px; border:1px solid #cbd5e1; border-radius:4px; font-family:monospace; font-size:12px;">
                        <button type="button" onclick="copyInvoiceUrl()" class="button">Copy Link</button>
                    </div>
                    <button type="button" onclick="sendInvoiceEmail()" class="button button-secondary" id="send-email-btn">Send Email to Customer</button>
                </div>

                <div id="invoice-error" style="display:none; margin-top:20px; padding:15px; background:#fee; border:1px solid #fcc; border-radius:6px; color:#c00;"></div>
            </div>
        </div>

        <script>
        let currentInvoiceId = null;
        let currentInvoiceToken = null;

        document.getElementById('invoice-generator-form').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const btn = document.getElementById('generate-invoice-btn');
            const resultDiv = document.getElementById('invoice-result');
            const errorDiv = document.getElementById('invoice-error');
            
            btn.disabled = true;
            btn.textContent = 'Generating...';
            resultDiv.style.display = 'none';
            errorDiv.style.display = 'none';

            const formData = new FormData();
            formData.append('action', 'generate_custom_invoice');
            formData.append('nonce', document.getElementById('invoice_nonce').value);
            formData.append('customer_name', document.getElementById('customer_name').value);
            formData.append('customer_email', document.getElementById('customer_email').value);
            formData.append('expiry_days', document.querySelector('[name="expiry_days"]').value);
            
            if (document.querySelector('[name="include_membership"]').checked) {
                formData.append('include_membership', '1');
            }
            if (document.querySelector('[name="include_hosting"]').checked) {
                formData.append('include_hosting', '1');
            }
            if (document.querySelector('[name="include_processing"]').checked) {
                formData.append('include_processing', '1');
            }

            try {
                const response = await fetch(ajaxurl, {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.success) {
                    document.getElementById('result-invoice-number').textContent = result.data.invoice_number;
                    document.getElementById('result-amount').textContent = parseFloat(result.data.amount_total).toFixed(2);
                    document.getElementById('result-url').value = result.data.checkout_url;
                    currentInvoiceToken = result.data.token;
                    resultDiv.style.display = 'block';
                } else {
                    errorDiv.textContent = result.data || 'Failed to generate invoice';
                    errorDiv.style.display = 'block';
                }
            } catch (error) {
                errorDiv.textContent = 'Network error: ' + error.message;
                errorDiv.style.display = 'block';
            } finally {
                btn.disabled = false;
                btn.textContent = 'Generate Invoice Link';
            }
        });

        function copyInvoiceUrl() {
            const input = document.getElementById('result-url');
            input.select();
            document.execCommand('copy');
            
            const btn = event.target;
            const originalText = btn.textContent;
            btn.textContent = 'Copied!';
            setTimeout(() => { btn.textContent = originalText; }, 2000);
        }

        async function sendInvoiceEmail() {
            const btn = document.getElementById('send-email-btn');
            btn.disabled = true;
            btn.textContent = 'Sending...';

            // Email sending logic would go here
            // For now, just show success message
            setTimeout(() => {
                alert('Email sending functionality will use the backend send_custom_invoice_email method');
                btn.disabled = false;
                btn.textContent = 'Send Email to Customer';
            }, 1000);
        }
        </script>

        <style>
        .card { background:#fff; border:1px solid #ccd0d4; border-radius:4px; padding:20px; margin-top:20px; }
        </style>
        <?php
    }

    /**
     * Invoice Management Page
     */
    public function invoice_management_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'sec_custom_invoices';

        // Handle status updates
        if (isset($_POST['action']) && $_POST['action'] === 'update_status' && wp_verify_nonce($_POST['invoice_nonce'], 'sec_invoice_action')) {
            $invoice_id = intval($_POST['invoice_id']);
            $new_status = sanitize_text_field($_POST['new_status']);
            $this->update_invoice_status($invoice_id, $new_status);
            echo '<div class="notice notice-success"><p>Invoice status updated!</p></div>';
        }

        // Handle delete
        if (isset($_POST['action']) && $_POST['action'] === 'delete' && wp_verify_nonce($_POST['invoice_nonce'], 'sec_invoice_action')) {
            $invoice_id = intval($_POST['invoice_id']);
            $wpdb->delete($table, array('id' => $invoice_id), array('%d'));
            echo '<div class="notice notice-success"><p>Invoice deleted!</p></div>';
        }

        $filter_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : 'all';
        
        $where = '';
        if ($filter_status !== 'all') {
            $where = $wpdb->prepare(" WHERE status = %s", $filter_status);
        }

        $invoices = $wpdb->get_results("SELECT * FROM $table {$where} ORDER BY created_at DESC");

        ?>
        <div class="wrap">
            <h1>Invoice Management</h1>

            <div class="tablenav top">
                <div class="alignleft actions">
                    <select onchange="window.location.href='?page=stripe-view-invoices&status=' + this.value">
                        <option value="all" <?php selected($filter_status, 'all'); ?>>All Statuses</option>
                        <option value="pending" <?php selected($filter_status, 'pending'); ?>>Pending</option>
                        <option value="paid" <?php selected($filter_status, 'paid'); ?>>Paid</option>
                        <option value="expired" <?php selected($filter_status, 'expired'); ?>>Expired</option>
                        <option value="voided" <?php selected($filter_status, 'voided'); ?>>Voided</option>
                    </select>
                </div>
            </div>

            <?php if (empty($invoices)): ?>
                <p>No invoices found.</p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Invoice #</th>
                            <th>Customer</th>
                            <th>Email</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Expires</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($invoices as $invoice): ?>
                            <tr>
                                <td><strong><?php echo esc_html($invoice->invoice_number); ?></strong></td>
                                <td><?php echo esc_html($invoice->customer_name); ?></td>
                                <td><?php echo esc_html($invoice->customer_email); ?></td>
                                <td>$<?php echo number_format($invoice->amount_total, 2); ?></td>
                                <td>
                                    <?php
                                    $status_colors = array(
                                        'pending' => '#f59e0b',
                                        'paid' => '#10b981',
                                        'expired' => '#6b7280',
                                        'voided' => '#ef4444'
                                    );
                                    $color = isset($status_colors[$invoice->status]) ? $status_colors[$invoice->status] : '#6b7280';
                                    ?>
                                    <span style="color:<?php echo $color; ?>; font-weight:bold;">
                                        <?php echo ucfirst($invoice->status); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M j, Y g:i A', strtotime($invoice->created_at)); ?></td>
                                <td><?php echo $invoice->expires_at ? date('M j, Y', strtotime($invoice->expires_at)) : 'N/A'; ?></td>
                                <td>
                                    <a href="<?php echo home_url('/checkout/?invoice_token=' . $invoice->token); ?>" target="_blank" class="button button-small">View Link</a>
                                    
                                    <?php if ($invoice->status === 'pending'): ?>
                                        <form method="post" style="display:inline;">
                                            <?php wp_nonce_field('sec_invoice_action', 'invoice_nonce'); ?>
                                            <input type="hidden" name="action" value="update_status">
                                            <input type="hidden" name="invoice_id" value="<?php echo $invoice->id; ?>">
                                            <input type="hidden" name="new_status" value="voided">
                                            <button type="submit" class="button button-small" onclick="return confirm('Void this invoice?');">Void</button>
                                        </form>
                                    <?php endif; ?>

                                    <form method="post" style="display:inline;">
                                        <?php wp_nonce_field('sec_invoice_action', 'invoice_nonce'); ?>
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="invoice_id" value="<?php echo $invoice->id; ?>">
                                        <button type="submit" class="button button-small" style="color:#d63638;" onclick="return confirm('Delete this invoice? This cannot be undone.');">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Invoice Branding Page
     */
    public function invoice_branding_page() {
        if (isset($_POST['submit']) && wp_verify_nonce($_POST['branding_nonce'], 'sec_invoice_branding')) {
            $this->update_invoice_setting('invoice_primary_color', sanitize_hex_color($_POST['primary_color']));
            $this->update_invoice_setting('invoice_secondary_color', sanitize_hex_color($_POST['secondary_color']));
            $this->update_invoice_setting('invoice_business_name', sanitize_text_field($_POST['business_name']));
            $this->update_invoice_setting('invoice_business_address', sanitize_textarea_field($_POST['business_address']));
            $this->update_invoice_setting('invoice_business_phone', sanitize_text_field($_POST['business_phone']));
            $this->update_invoice_setting('invoice_support_email', sanitize_email($_POST['support_email']));
            $this->update_invoice_setting('invoice_logo_url', esc_url_raw($_POST['logo_url']));
            $this->update_invoice_setting('invoice_default_expiry_days', intval($_POST['default_expiry_days']));
            $this->update_invoice_setting('invoice_auto_send_email', isset($_POST['auto_send_email']) ? '1' : '0');
            $this->update_invoice_setting('invoice_include_pdf', isset($_POST['include_pdf']) ? '1' : '0');
            $this->update_invoice_setting('website_hosting_fee', floatval($_POST['hosting_fee']));

            echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
        }

        $primary_color = $this->get_invoice_setting('invoice_primary_color', '#635BFF');
        $secondary_color = $this->get_invoice_setting('invoice_secondary_color', '#0A2540');
        $business_name = $this->get_invoice_setting('invoice_business_name', get_bloginfo('name'));
        $business_address = $this->get_invoice_setting('invoice_business_address', '');
        $business_phone = $this->get_invoice_setting('invoice_business_phone', '');
        $support_email = $this->get_invoice_setting('invoice_support_email', get_option('admin_email'));
        $logo_url = $this->get_invoice_setting('invoice_logo_url', '');
        $default_expiry = $this->get_invoice_setting('invoice_default_expiry_days', '7');
        $auto_send = $this->get_invoice_setting('invoice_auto_send_email', '1');
        $include_pdf = $this->get_invoice_setting('invoice_include_pdf', '1');
        $hosting_fee = $this->get_invoice_setting('website_hosting_fee', '25.00');

        ?>
        <div class="wrap">
            <h1>Invoice Branding Settings</h1>

            <form method="post">
                <?php wp_nonce_field('sec_invoice_branding', 'branding_nonce'); ?>

                <div class="card" style="max-width: 800px;">
                    <h2>Brand Colors</h2>
                    <table class="form-table">
                        <tr>
                            <th>Primary Color</th>
                            <td>
                                <input type="color" name="primary_color" value="<?php echo esc_attr($primary_color); ?>">
                                <span class="description">Used for headers, buttons, and links</span>
                            </td>
                        </tr>
                        <tr>
                            <th>Secondary Color</th>
                            <td>
                                <input type="color" name="secondary_color" value="<?php echo esc_attr($secondary_color); ?>">
                                <span class="description">Used for accents and highlights</span>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="card" style="max-width: 800px; margin-top: 20px;">
                    <h2>Business Information</h2>
                    <table class="form-table">
                        <tr>
                            <th>Business Name</th>
                            <td><input type="text" name="business_name" value="<?php echo esc_attr($business_name); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th>Business Address</th>
                            <td><textarea name="business_address" rows="3" class="large-text"><?php echo esc_textarea($business_address); ?></textarea></td>
                        </tr>
                        <tr>
                            <th>Business Phone</th>
                            <td><input type="text" name="business_phone" value="<?php echo esc_attr($business_phone); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th>Support Email</th>
                            <td><input type="email" name="support_email" value="<?php echo esc_attr($support_email); ?>" class="regular-text"></td>
                        </tr>
                        <tr>
                            <th>Logo URL</th>
                            <td>
                                <input type="url" name="logo_url" id="logo_url" value="<?php echo esc_url($logo_url); ?>" class="regular-text">
                                <button type="button" class="button" onclick="openMediaUploader()">Upload Logo</button>
                                <?php if ($logo_url): ?>
                                    <div style="margin-top:10px;"><img src="<?php echo esc_url($logo_url); ?>" style="max-width:200px; height:auto; border:1px solid #ddd; padding:5px;"></div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="card" style="max-width: 800px; margin-top: 20px;">
                    <h2>Invoice Settings</h2>
                    <table class="form-table">
                        <tr>
                            <th>Website Hosting Fee</th>
                            <td>
                                $<input type="number" name="hosting_fee" value="<?php echo esc_attr($hosting_fee); ?>" step="0.01" min="0" class="small-text">
                                <span class="description">Monthly hosting fee</span>
                            </td>
                        </tr>
                        <tr>
                            <th>Default Expiration (Days)</th>
                            <td>
                                <input type="number" name="default_expiry_days" value="<?php echo esc_attr($default_expiry); ?>" min="1" max="365" class="small-text">
                                <span class="description">Default number of days before invoice expires</span>
                            </td>
                        </tr>
                        <tr>
                            <th>Email Settings</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="auto_send_email" <?php checked($auto_send, '1'); ?>>
                                    Automatically send email when invoice is generated
                                </label>
                                <br>
                                <label style="margin-top:8px; display:block;">
                                    <input type="checkbox" name="include_pdf" <?php checked($include_pdf, '1'); ?>>
                                    Include Stripe invoice PDF in email (when available)
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>

                <p class="submit">
                    <button type="submit" name="submit" class="button button-primary button-large">Save Branding Settings</button>
                </p>
            </form>
        </div>

        <script>
        function openMediaUploader() {
            if (typeof wp !== 'undefined' && wp.media) {
                const frame = wp.media({
                    title: 'Select Logo',
                    button: { text: 'Use this logo' },
                    multiple: false
                });

                frame.on('select', function() {
                    const attachment = frame.state().get('selection').first().toJSON();
                    document.getElementById('logo_url').value = attachment.url;
                });

                frame.open();
            }
        }
        </script>

        <style>
        .card { background:#fff; border:1px solid #ccd0d4; border-radius:4px; padding:20px; }
        </style>
        <?php
    }

    /**
     * Slot Management Page
     */
    public function slot_management_page() {
        // Handle manual slot taking
        if (isset($_POST['take_slot']) && wp_verify_nonce($_POST['slot_nonce'], 'sec_take_slot')) {
            $slots_to_take = intval($_POST['slots_to_take']);
            SEC_Activation_Slots::take_slots_manual($slots_to_take);
            echo '<div class="notice notice-success"><p>Successfully reserved ' . $slots_to_take . ' slot(s) for 24 hours.</p></div>';
        }

        // Handle automatic slot configuration
        if (isset($_POST['update_auto_slots']) && wp_verify_nonce($_POST['auto_slot_nonce'], 'sec_auto_slots')) {
            $enabled = isset($_POST['auto_slot_enabled']) ? 1 : 0;
            $daily_slots = intval($_POST['daily_slots']);
            update_option('sec_auto_slot_enabled', $enabled);
            update_option('sec_auto_daily_slots', $daily_slots);
            echo '<div class="notice notice-success"><p>Automatic slot settings updated.</p></div>';
        }

        // Get current slot status
        $total_slots = SEC_Activation_Slots::get_total_slots();
        $available_slots = SEC_Activation_Slots::get_available_slots();
        $taken_slots = $total_slots - $available_slots;

        // Get auto slot settings
        $auto_enabled = get_option('sec_auto_slot_enabled', 0);
        $daily_slots = get_option('sec_auto_daily_slots', 2);

        ?>
        <div class="wrap">
            <h1>Slot Management</h1>

            <!-- Current Slot Status -->
            <div class="card" style="margin-top:20px;">
                <h2>Current Slot Status</h2>
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:20px; margin-top:20px;">
                    <div style="padding:20px; background:#f0f8ff; border-left:4px solid #0073aa; border-radius:4px;">
                        <div style="font-size:32px; font-weight:bold; color:#0073aa;"><?php echo $total_slots; ?></div>
                        <div style="color:#666; margin-top:4px;">Total Slots</div>
                    </div>
                    <div style="padding:20px; background:#f0fff4; border-left:4px solid #28a745; border-radius:4px;">
                        <div style="font-size:32px; font-weight:bold; color:#28a745;"><?php echo $available_slots; ?></div>
                        <div style="color:#666; margin-top:4px;">Available Slots</div>
                    </div>
                    <div style="padding:20px; background:#fff3cd; border-left:4px solid #ffc107; border-radius:4px;">
                        <div style="font-size:32px; font-weight:bold; color:#856404;"><?php echo $taken_slots; ?></div>
                        <div style="color:#666; margin-top:4px;">Reserved Slots</div>
                    </div>
                </div>
            </div>

            <!-- Manual Slot Reservation -->
            <div class="card" style="margin-top:20px;">
                <h2>Manual Slot Reservation</h2>
                <p>Reserve slots manually for the next 24 hours. These slots will automatically become available again after 24 hours if not purchased.</p>
                <form method="post">
                    <?php wp_nonce_field('sec_take_slot', 'slot_nonce'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Number of Slots to Reserve</th>
                            <td>
                                <input type="number" name="slots_to_take" value="1" min="1" max="<?php echo $available_slots; ?>" style="width:100px;" />
                                <p class="description">Maximum: <?php echo $available_slots; ?> available slots</p>
                            </td>
                        </tr>
                    </table>
                    <p>
                        <button type="submit" name="take_slot" class="button button-primary">Reserve Slots</button>
                    </p>
                </form>
            </div>

            <!-- Automatic Daily Slot Reservation -->
            <div class="card" style="margin-top:20px;">
                <h2>Automatic Daily Slot Reservation</h2>
                <p>Automatically reserve a set number of slots every day. These slots will return if nobody purchases within 24 hours, ensuring you always have available slots for new customers.</p>
                <form method="post">
                    <?php wp_nonce_field('sec_auto_slots', 'auto_slot_nonce'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Enable Automatic Reservation</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="auto_slot_enabled" value="1" <?php checked($auto_enabled, 1); ?> />
                                    Enable daily automatic slot reservation
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Slots to Reserve Daily</th>
                            <td>
                                <input type="number" name="daily_slots" value="<?php echo esc_attr($daily_slots); ?>" min="0" max="<?php echo $total_slots; ?>" style="width:100px;" />
                                <p class="description">Example: Reserve 2 slots every day from your 10 total slots, leaving 8 always available for purchases.</p>
                            </td>
                        </tr>
                    </table>
                    <p class="submit">
                        <button type="submit" name="update_auto_slots" class="button button-primary">Save Settings</button>
                    </p>
                </form>

                <div style="margin-top:20px; padding:15px; background:#f0f8ff; border-left:4px solid #0073aa; border-radius:4px;">
                    <h3 style="margin:0 0 10px 0;">How It Works:</h3>
                    <ul style="margin:0;">
                        <li>Reserved slots are held for 24 hours</li>
                        <li>If nobody purchases, the slots automatically return to the available pool</li>
                        <li>New slots are reserved every day at midnight</li>
                        <li>Manual reservations work independently from automatic reservations</li>
                    </ul>
                </div>
            </div>

            <style>
            .card { background:#fff; border:1px solid #ccd0d4; border-radius:4px; padding:20px; }
            </style>
        </div>
        <?php
    }
}

new Stripe_Embedded_Checkout();

// ============================================================================
// Plugin Update Checker - GitHub Integration
// ============================================================================

// Load update checker
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    // Prevent loading the autoloader multiple times
    if (!class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        require_once __DIR__ . '/vendor/autoload.php';
    }

    if (class_exists('YahnisElsts\PluginUpdateChecker\v5\PucFactory')) {
        $updateChecker = YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
            'https://raw.githubusercontent.com/Hyveli/ma-core-checkout-dist/main/release.json',
            __FILE__,
            'ma-core-checkout'
        );

        // Force update check if URL parameter is present
        if (isset($_GET['force_update_check']) && current_user_can('manage_options')) {
            delete_site_transient('update_plugins');
            $updateChecker->checkForUpdates();
            add_action('admin_notices', function() {
                echo '<div class="notice notice-success is-dismissible"><p>Update check completed.</p></div>';
            });
        }
    }
}

?>
