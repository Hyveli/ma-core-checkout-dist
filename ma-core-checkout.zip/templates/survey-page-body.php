<?php if (!defined('ABSPATH')) exit; ?>

    <div class="survey-theme-floating">
        <div class="theme-toggle">
            <button class="theme-toggle-btn active" id="light-btn" onclick="setTheme('light')" title="Light mode">Light</button>
            <button class="theme-toggle-btn" id="dark-btn" onclick="setTheme('dark')" title="Dark mode">Dark</button>
        </div>
    </div>
<!-- Progress bar -->
    <div class="survey-progress-header" id="progress-header" style="display:none;">
        <div class="survey-progress-inner">
            <div class="survey-progress-track" id="progress-track">
                <div class="survey-progress-fill" id="progress-fill" style="width:0%"></div>
            </div>
            <span class="survey-progress-text" id="progress-text">0%</span>
        </div>
    </div>

    <!-- ============================================================
         MAIN CONTENT
         ============================================================ -->
    <main class="survey-page-body" id="survey-root">
        <!-- Injected by JS -->
    </main>

    <script>
    /* ================================================================
       SURVEY PAGE — Standalone, full-page onboarding experience
       Mirrors the exact data schema of the survey-modal.js implementation
       ================================================================ */

    // ——————————————————————————————————————————————
    // DATA
    // ——————————————————————————————————————————————

    const INDUSTRIES = [
        { id: "beauty", label: "Beauty & Wellness", icon: "💅" },
        { id: "realestate", label: "Real Estate", icon: "🏠" },
        { id: "legal", label: "Legal Services", icon: "⚖️" },
        { id: "health", label: "Health & Medical", icon: "🩺" },
        { id: "finance", label: "Finance & Accounting", icon: "💰" },
        { id: "fitness", label: "Fitness & Training", icon: "💪" },
        { id: "coaching", label: "Coaching & Consulting", icon: "📊" },
        { id: "photography", label: "Photography", icon: "📸" },
        { id: "food", label: "Food & Beverage", icon: "🍽️" },
        { id: "ecommerce", label: "E-Commerce", icon: "🛒" },
        { id: "construction", label: "Construction & Trades", icon: "🔨" },
        { id: "education", label: "Education & Tutoring", icon: "📚" },
        { id: "technology", label: "Technology", icon: "💻" },
        { id: "nonprofit", label: "Non-Profit", icon: "🤝" },
        { id: "other", label: "Other", icon: "⚙️" }
    ];

    const INDUSTRY_SERVICES = {
        "Beauty & Wellness":          "1. Haircut – $45\n2. Color Treatment – $120\n3. Balayage – from $180",
        "Real Estate":                "1. Buyer Representation – Free\n2. Listing & Selling – 2.5% commission\n3. Market Analysis – $150",
        "Legal Services":             "1. Initial Consultation – $200\n2. Contract Review – from $350\n3. Full Representation – contact for pricing",
        "Health & Medical":           "1. New Patient Exam – $150\n2. Follow-Up Visit – $85\n3. Telehealth Appointment – $65",
        "Finance & Accounting":       "1. Financial Consultation – $200\n2. Tax Preparation – from $300\n3. Bookkeeping (monthly) – from $250",
        "Fitness & Personal Training":"1. 1-on-1 Personal Training – $80/session\n2. Group Fitness Class – $25\n3. Monthly Coaching Program – $350",
        "Coaching & Consulting":      "1. Discovery Call – Free\n2. 1-Hour Strategy Session – $175\n3. 3-Month Coaching Package – $1,200",
        "Photography":                "1. Portrait Session – $250\n2. Wedding Photography – from $2,500\n3. Brand & Headshot Session – $400",
        "Food & Beverage":            "1. Catering (per person) – from $35\n2. Private Chef Experience – $500\n3. Meal Prep Package (weekly) – $180",
        "E-Commerce":                 "1. Product A – $XX\n2. Product B – $XX\n3. Bundle / Subscription – $XX/mo",
        "Construction & Trades":      "1. Free Estimate – No charge\n2. Kitchen Remodel – from $8,000\n3. Bathroom Renovation – from $4,500",
        "Education & Tutoring":       "1. 1-on-1 Tutoring (1hr) – $60\n2. Group Study Session – $25\n3. Monthly Learning Plan – $220",
        "Technology":                 "1. IT Support (hourly) – $95\n2. Website Development – from $1,500\n3. Monthly Maintenance – $150/mo",
        "Non-Profit":                 "1. Volunteer Program – Free\n2. Community Workshop – Donation-based\n3. Annual Membership – $50/yr",
        "Other":                      "1. Service Name – Price\n2. Service Name – Price\n3. Service Name – Price"
    };

    const INDUSTRY_TAGLINES = {
        "Beauty & Wellness":          "e.g. We help clients feel confident through personalized beauty treatments.",
        "Real Estate":                "e.g. We help first-time homebuyers find their perfect home.",
        "Legal Services":             "e.g. We protect small businesses with affordable legal counsel.",
        "Health & Medical":           "e.g. We provide compassionate care for families in our community.",
        "Finance & Accounting":       "e.g. We help small business owners master their finances.",
        "Fitness & Personal Training":"e.g. We transform lives through personalized fitness coaching.",
        "Coaching & Consulting":      "e.g. We help professionals achieve their career goals.",
        "Photography":                "e.g. We capture life's special moments with timeless photography.",
        "Food & Beverage":            "e.g. We bring restaurant-quality meals to your table.",
        "E-Commerce":                 "e.g. We deliver quality products right to your door.",
        "Construction & Trades":      "e.g. We build dream homes with expert craftsmanship.",
        "Education & Tutoring":       "e.g. We help students reach their academic potential.",
        "Technology":                 "e.g. We keep businesses running with reliable IT support.",
        "Non-Profit":                 "e.g. We empower communities through education and outreach.",
        "Other":                      "e.g. We help clients solve their problems with expert service."
    };

    const DAYS = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];

    const SOCIAL_PLATFORMS = [
        { label: "Facebook",    icon: '<svg viewBox="0 0 24 24" fill="#1877f2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',  placeholder: "facebook.com/yourbusiness" },
        { label: "Instagram",   icon: '<svg viewBox="0 0 24 24"><defs><linearGradient id="ig" x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" style="stop-color:#f09433"/><stop offset="50%" style="stop-color:#dc2743"/><stop offset="100%" style="stop-color:#bc1888"/></linearGradient></defs><path fill="url(#ig)" d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>', placeholder: "instagram.com/yourbusiness" },
        { label: "LinkedIn",    icon: '<svg viewBox="0 0 24 24" fill="#0a66c2"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>', placeholder: "linkedin.com/in/yourbusiness" },
        { label: "TikTok",      icon: '<svg viewBox="0 0 24 24" fill="#000"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>', placeholder: "tiktok.com/@yourbusiness" },
        { label: "X / Twitter", icon: '<svg viewBox="0 0 24 24" fill="#000"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>', placeholder: "x.com/yourbusiness" },
        { label: "YouTube",     icon: '<svg viewBox="0 0 24 24" fill="#ff0000"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>', placeholder: "youtube.com/@yourbusiness" },
        { label: "Other",       icon: '<svg viewBox="0 0 24 24" fill="#6b7280"><path d="M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z"/></svg>', placeholder: "Paste your link here" },
    ];

    const TIMES = [];
    for (let h = 0; h < 24; h++) {
        const label = h === 0 ? '12:00 AM' : h < 12 ? `${h}:00 AM` : h === 12 ? '12:00 PM' : `${h-12}:00 PM`;
        TIMES.push({ value: `${String(h).padStart(2,'0')}:00`, label });
    }

    const STEPS = [
        { id:1, field:'businessName', label:"What's your business called?",              hint:"Exactly as you'd like it displayed on your website.", type:'text',       required:true  },
        { id:2, field:'industry',     label:"What industry are you in?",                 hint:"Pick the closest match — this helps us tailor your design.",  type:'select',     required:true  },
        { id:3, field:'tagline',      label:"Describe what your business does in one sentence.", hint:"Who do you help and how? Keep it simple and clear.", type:'text',   required:true  },
        { id:4, field:'services',     label:"What are your top 3 services or offerings?",hint:"Include a price if you'd like it shown. Keep each one brief.", type:'textarea',  required:true  },
        { id:5, field:'hours',        label:"What are your business hours?",             hint:"Toggle any day you're not open.",                             type:'hours',      required:false },
        { id:6, field:'booking',      label:"How will clients meet with you?",           hint:"Select all that apply.",                                      type:'multicheck', required:true, options:[{label:"Virtually (video or phone call)",value:"virtual"},{label:"At my location (client comes to me)",value:"our_location"},{label:"At the client's location (I go to them)",value:"client_location"}] },
        { id:7, field:'contact',      label:"How can clients contact you?",              hint:"Only share what you're comfortable displaying publicly.",     type:'contact',    required:true  },
        { id:8, field:'socials',      label:"Add your social media pages.",              hint:"Click a platform to add it. Add as many as you'd like.",      type:'socials',    required:false },
        { id:9, field:'brand',        label:"Do you have a logo or brand colors?",       hint:"No worries if not — we'll take care of it.",                  type:'brandcheck', required:false },
        { id:10, field:'files',       label:"Upload any photos or files for your website.", hint:"Team photos, product shots — anything that represents your brand.", type:'upload', required:false },
        { id:11, field:'extra',       label:"Anything else we should know?",             hint:"Notes, preferences, examples of sites you love — anything helps.", type:'textarea', required:false },
    ];

    // ——————————————————————————————————————————————
    // STATE
    // ——————————————————————————————————————————————
    const state = {
        screen: 'welcome', // 'welcome' | 'step' | 'review' | 'success'
        step: 0,
        direction: 1, // 1 = forward, -1 = back
        animating: false,
        editingFromReview: false, // Track if we're editing from review screen
        answers: {
            businessName: '', industry: '', customIndustry: '', tagline: '',
            services: '', hours: DAYS.map(d => ({ day:d, open:d!=='Sun', from:'09:00', to:'17:00' })),
            booking: [], contact: { phone:'', email:'', address:'' },
            socials: SOCIAL_PLATFORMS.map(p => ({ label:p.label, value:'' })),
            brand: [], brandColors: [], brandSlogan: '', logoFile: null, files: [],
            extra: '',
        },
        // PHP-injected session data (will be populated via wp_localize_script in production)
        session: window.secSurveyData || {
            ajax_url: '/wp-admin/admin-ajax.php',
            nonce: '',
            session: { customer_id:'', customer_name:'', customer_email:'', payment_amount:0, session_id:'' },
            auto_open: true,
            resume_token: '',
        }
    };

    // ——————————————————————————————————————————————
    // THEME
    // ——————————————————————————————————————————————
    function setTheme(t) {
        document.documentElement.setAttribute('data-theme', t);
        document.getElementById('light-btn').classList.toggle('active', t==='light');
        document.getElementById('dark-btn').classList.toggle('active', t==='dark');
        localStorage.setItem('ma-theme', t);
    }
    // Restore saved theme
    const savedTheme = localStorage.getItem('ma-theme') || 'light';
    setTheme(savedTheme);

    // ——————————————————————————————————————————————
    // RENDER
    // ——————————————————————————————————————————————
    const root = document.getElementById('survey-root');
    const progressHeader = document.getElementById('progress-header');
    const progressFill = document.getElementById('progress-fill');
    const progressText = document.getElementById('progress-text');

    function render() {
        root.innerHTML = '';
        if (state.screen === 'welcome') {
            progressHeader.style.display = 'none';
            root.appendChild(buildWelcome());
        } else if (state.screen === 'step') {
            progressHeader.style.display = '';
            const pct = Math.round(((state.step) / STEPS.length) * 100);
            progressFill.style.width = pct + '%';
            progressText.textContent = pct + '%';
            root.appendChild(buildStep(STEPS[state.step]));
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else if (state.screen === 'review') {
            progressHeader.style.display = '';
            progressFill.style.width = '95%';
            progressText.textContent = '95%';
            root.appendChild(buildReview());
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else if (state.screen === 'success') {
            progressHeader.style.display = '';
            progressFill.style.width = '100%';
            progressText.textContent = '100%';
            root.appendChild(buildSuccess());
        }
    }

    // ——————————————————————————————————————————————
    // WELCOME SCREEN
    // ——————————————————————————————————————————————
    function buildWelcome() {
        const div = document.createElement('div');
        div.className = 'survey-welcome';
        div.innerHTML = `
            <div class="survey-welcome-icon">🚀</div>
            <h1>Let's build your <span>website.</span></h1>
            <p>Answer a few quick questions so we can personalize your site. Takes about <strong>5–10 minutes</strong> and saves back automatically.</p>
            <div class="survey-welcome-meta">
                <div class="survey-welcome-meta-item">
                    <div class="survey-welcome-meta-dot"></div>
                    ${STEPS.length} short steps
                </div>
                <div class="survey-welcome-meta-item">
                    <div class="survey-welcome-meta-dot"></div>
                    Auto-saved
                </div>
                <div class="survey-welcome-meta-item">
                    <div class="survey-welcome-meta-dot"></div>
                    Preview in 48 hrs
                </div>
            </div>
            <button class="survey-next-btn" style="max-width:280px;margin:0 auto;" onclick="startSurvey()">
                Let's get started →
            </button>
        `;
        return div;
    }

    function startSurvey() {
        state.screen = 'step';
        state.step = 0;
        render();
    }

    // ——————————————————————————————————————————————
    // STEP SCREEN
    // ——————————————————————————————————————————————
    function buildStep(step) {
        const card = document.createElement('div');
        const animClass = state.direction === 1 ? 'survey-anim-enter-fwd' : 'survey-anim-enter-back';
        card.className = 'survey-step-card ' + animClass;

        // Header
        const header = document.createElement('div');
        header.className = 'survey-step-header';
        const stepNum = String(state.step + 1).padStart(2, '0');
        header.innerHTML = `
            <div class="survey-step-number-label">Step ${stepNum}</div>
            <div class="survey-step-question">${step.label}</div>
            <div class="survey-step-hint">${step.hint}</div>
        `;
        card.appendChild(header);

        // Body
        const body = document.createElement('div');
        body.className = 'survey-step-body';
        body.appendChild(buildStepBody(step));
        card.appendChild(body);

        // Footer
        const footer = document.createElement('div');
        footer.className = 'survey-footer';

        // Back button (hide if on first step and not editing from review)
        const backBtn = document.createElement('button');
        backBtn.className = 'survey-back-btn';
        backBtn.innerHTML = '← Back';
        if (state.step === 0 && !state.editingFromReview) backBtn.hidden = true;
        backBtn.addEventListener('click', () => goStep(-1));
        footer.appendChild(backBtn);

        // "Back to Review" button (show only when editing from review)
        if (state.editingFromReview) {
            const reviewBtn = document.createElement('button');
            reviewBtn.className = 'survey-back-btn survey-back-to-review-btn';
            reviewBtn.innerHTML = '⬅ Back to Review';
            reviewBtn.style.marginLeft = '8px';
            reviewBtn.addEventListener('click', () => {
                state.editingFromReview = false;
                state.screen = 'review';
                state.direction = 1;
                render();
            });
            footer.appendChild(reviewBtn);
        }

        const nextBtn = document.createElement('button');
        nextBtn.className = 'survey-next-btn';
        nextBtn.id = 'survey-next-btn';
        const isLast = state.step === STEPS.length - 1;
        nextBtn.innerHTML = isLast ? 'Submit & Launch 🚀' : 'Continue →';
        nextBtn.addEventListener('click', () => {
            // Clear editingFromReview when continuing forward
            if (state.editingFromReview) state.editingFromReview = false;
            goStep(1);
        });
        footer.appendChild(nextBtn);
        card.appendChild(footer);

        return card;
    }

    function buildStepBody(step) {
        switch (step.type) {
            case 'text':     return buildTextInput(step);
            case 'textarea': return buildTextarea(step);
            case 'select':   return buildIndustrySelect(step);
            case 'hours':    return buildHours();
            case 'multicheck': return buildMulticheck(step);
            case 'contact':  return buildContact();
            case 'socials':  return buildSocials();
            case 'brandcheck': return buildBrandCheck();
            case 'upload':   return buildUpload();
            default: return document.createElement('div');
        }
    }

    // ——————————————————————————————————————————————
    // STEP BUILDERS
    // ——————————————————————————————————————————————
    function buildTextInput(step) {
        const wrap = document.createElement('div');
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'survey-input';
        input.value = state.answers[step.field] || '';
        input.id = 'survey-main-input';

        if (step.field === 'tagline') {
            input.placeholder = INDUSTRY_TAGLINES[state.answers.industry] || 'e.g. We help clients solve their problems with expert service.';
        } else if (step.field === 'businessName') {
            input.placeholder = 'e.g. Acme Design Studio';
        }

        input.addEventListener('input', e => {
            state.answers[step.field] = e.target.value;
            scheduleSave();
        });
        input.addEventListener('keydown', e => { if (e.key === 'Enter') goStep(1); });
        wrap.appendChild(input);
        setTimeout(() => input.focus(), 100);
        return wrap;
    }

    function buildTextarea(step) {
        const wrap = document.createElement('div');
        const ta = document.createElement('textarea');
        ta.className = 'survey-input';
        ta.rows = 5;
        ta.value = state.answers[step.field] || '';

        if (step.field === 'services' && !ta.value && state.answers.industry) {
            ta.value = INDUSTRY_SERVICES[state.answers.industry] || '';
            state.answers.services = ta.value;
        }

        ta.addEventListener('input', e => {
            state.answers[step.field] = e.target.value;
            scheduleSave();
        });
        wrap.appendChild(ta);
        setTimeout(() => ta.focus(), 100);
        return wrap;
    }

    function buildIndustrySelect(step) {
        const wrap = document.createElement('div');
        const grid = document.createElement('div');
        grid.className = 'survey-industry-grid';

        INDUSTRIES.forEach(ind => {
            const tile = document.createElement('button');
            tile.className = 'survey-industry-tile' + (state.answers.industry === ind.label ? ' active' : '');
            tile.innerHTML = `
                <div class="survey-industry-icon">${ind.icon}</div>
                <div class="survey-industry-label">${ind.label}</div>
            `;
            tile.addEventListener('click', () => {
                state.answers.industry = ind.label;
                // Prefill services if empty
                if (!state.answers.services) {
                    state.answers.services = INDUSTRY_SERVICES[ind.label] || '';
                }
                scheduleSave();
                // Auto-advance
                setTimeout(() => goStep(1), 200);
            });
            grid.appendChild(tile);
        });

        wrap.appendChild(grid);

        // Custom industry input if "Other"
        if (state.answers.industry === 'Other') {
            const customInput = document.createElement('input');
            customInput.type = 'text';
            customInput.className = 'survey-input';
            customInput.style.marginTop = '1rem';
            customInput.placeholder = 'Please describe your industry';
            customInput.value = state.answers.customIndustry || '';
            customInput.addEventListener('input', e => {
                state.answers.customIndustry = e.target.value;
            });
            wrap.appendChild(customInput);
        }

        return wrap;
    }

    function buildHours() {
        const wrap = document.createElement('div');
        const grid = document.createElement('div');
        grid.className = 'survey-hours-grid';

        state.answers.hours.forEach((row, i) => {
            const rowEl = document.createElement('div');
            rowEl.className = 'survey-hours-row' + (row.open ? '' : ' inactive');

            // Toggle
            const dayWrap = document.createElement('div');
            dayWrap.className = 'survey-hours-day';
            const toggle = document.createElement('button');
            toggle.className = 'survey-hours-toggle' + (row.open ? ' on' : '');
            toggle.addEventListener('click', () => {
                state.answers.hours[i].open = !state.answers.hours[i].open;
                toggle.classList.toggle('on', state.answers.hours[i].open);
                rowEl.classList.toggle('inactive', !state.answers.hours[i].open);
                scheduleSave();
            });
            const dayLabel = document.createElement('span');
            dayLabel.className = 'survey-hours-day-label';
            dayLabel.textContent = row.day;
            dayWrap.appendChild(toggle);
            dayWrap.appendChild(dayLabel);

            // Times with inline pickers
            const timesWrap = document.createElement('div');
            timesWrap.className = 'survey-hours-times';

            ['from','to'].forEach((field) => {
                const group = document.createElement('div');
                group.className = 'inline-time-picker-group';

                const label = document.createElement('div');
                label.className = 'time-label';
                label.textContent = field === 'from' ? 'Opens' : 'Closes';
                group.appendChild(label);

                const display = document.createElement('div');
                display.className = 'inline-time-display';
                display.innerHTML = `<span id="time-${i}-${field}">${row[field] || '9:00 AM'}</span><span class="time-display-icon">▼</span>`;
                display.addEventListener('click', () => window.toggleInlineTimePicker(i, field));
                group.appendChild(display);

                // Inline time picker
                const picker = document.createElement('div');
                picker.className = 'inline-time-picker-wrapper';
                picker.id = `picker-${i}-${field}`;
                picker.style.display = 'none';

                const wheels = document.createElement('div');
                wheels.className = 'time-picker-wheels';

                // Hour wheel
                const hourWheel = document.createElement('div');
                hourWheel.className = 'time-wheel inline-time-wheel';
                hourWheel.dataset.day = i;
                hourWheel.dataset.type = field;
                hourWheel.dataset.wheel = 'hour';
                wheels.appendChild(hourWheel);

                // Separator
                const sep = document.createElement('div');
                sep.className = 'time-separator';
                sep.textContent = ':';
                wheels.appendChild(sep);

                // Minute wheel
                const minWheel = document.createElement('div');
                minWheel.className = 'time-wheel inline-time-wheel';
                minWheel.dataset.day = i;
                minWheel.dataset.type = field;
                minWheel.dataset.wheel = 'minute';
                wheels.appendChild(minWheel);

                // Period wheel
                const periodWheel = document.createElement('div');
                periodWheel.className = 'time-wheel inline-time-wheel';
                periodWheel.dataset.day = i;
                periodWheel.dataset.type = field;
                periodWheel.dataset.wheel = 'period';
                wheels.appendChild(periodWheel);

                picker.appendChild(wheels);

                const doneBtn = document.createElement('button');
                doneBtn.className = 'inline-time-done';
                doneBtn.textContent = 'Done';
                doneBtn.addEventListener('click', () => window.confirmInlineTime(i, field));
                picker.appendChild(doneBtn);

                group.appendChild(picker);
                timesWrap.appendChild(group);
            });

            rowEl.appendChild(dayWrap);
            rowEl.appendChild(timesWrap);
            grid.appendChild(rowEl);
        });

        wrap.appendChild(grid);

        // Initialize wheels after render
        setTimeout(() => {
            if (window.initializeInlineTimePickers) window.initializeInlineTimePickers();
        }, 50);

        return wrap;
    }

    function buildMulticheck(step) {
        const wrap = document.createElement('div');
        const grid = document.createElement('div');
        grid.className = 'survey-pill-grid cols-1';

        step.options.forEach(opt => {
            const pill = document.createElement('button');
            const isActive = state.answers.booking.includes(opt.value);
            pill.className = 'survey-pill' + (isActive ? ' active' : '');
            pill.innerHTML = `<span class="survey-pill-check">${isActive ? '✓' : ''}</span>${opt.label}`;
            pill.addEventListener('click', () => {
                const idx = state.answers.booking.indexOf(opt.value);
                if (idx > -1) state.answers.booking.splice(idx, 1);
                else state.answers.booking.push(opt.value);
                const active = state.answers.booking.includes(opt.value);
                pill.classList.toggle('active', active);
                pill.querySelector('.survey-pill-check').textContent = active ? '✓' : '';
                scheduleSave();
            });
            grid.appendChild(pill);
        });

        wrap.appendChild(grid);
        return wrap;
    }

    function buildContact() {
        const wrap = document.createElement('div');
        wrap.className = 'survey-contact-grid';

        [
            { key:'phone',   label:'Phone Number',   placeholder:'(555) 123-4567', type:'tel' },
            { key:'email',   label:'Email Address',  placeholder:'hello@yourbusiness.com', type:'email' },
            { key:'address', label:'Business Address', placeholder:'123 Main St, City, State', type:'text' },
        ].forEach(f => {
            const group = document.createElement('div');
            const lbl = document.createElement('label');
            lbl.className = 'survey-field-label';
            lbl.textContent = f.label;
            const input = document.createElement('input');
            input.type = f.type;
            input.className = 'survey-input';
            input.placeholder = f.placeholder;
            input.value = state.answers.contact[f.key] || '';

            input.addEventListener('input', e => {
                state.answers.contact[f.key] = e.target.value;
                clearInputError(input);
                scheduleSave();
            });

            input.addEventListener('blur', e => {
                const value = e.target.value.trim();
                if (!value) return; // Allow empty for optional fields

                if (f.key === 'phone' && !validatePhone(value)) {
                    showInputError(input, 'Please enter a valid phone number');
                } else if (f.key === 'email' && !validateEmail(value)) {
                    showInputError(input, 'Please enter a valid email address');
                } else {
                    clearInputError(input);
                }
            });

            group.appendChild(lbl);
            group.appendChild(input);
            wrap.appendChild(group);
        });

        return wrap;
    }

    function buildSocials() {
        const wrap = document.createElement('div');
        wrap.className = 'survey-socials-wrap';

        // Platform pills
        const pills = document.createElement('div');
        pills.className = 'survey-socials-platforms';

        SOCIAL_PLATFORMS.forEach((p, pi) => {
            const pill = document.createElement('button');
            const isActive = state.answers.socials[pi].value !== '';
            pill.className = 'survey-social-pill' + (isActive ? ' active' : '');
            pill.innerHTML = p.icon + ' ' + p.label;
            pill.addEventListener('click', () => {
                // Toggle input row
                const rowId = 'social-row-' + pi;
                const existingRow = document.getElementById(rowId);
                if (existingRow) {
                    existingRow.remove();
                    pill.classList.remove('active');
                    if (!state.answers.socials[pi].value) return;
                    state.answers.socials[pi].value = '';
                } else {
                    pill.classList.add('active');
                    const inputRow = document.createElement('div');
                    inputRow.className = 'survey-social-input-row';
                    inputRow.id = rowId;
                    const iconWrap = document.createElement('div');
                    iconWrap.className = 'survey-social-icon-wrap';
                    iconWrap.innerHTML = p.icon;
                    const input = document.createElement('input');
                    input.type = 'url';
                    input.className = 'survey-input';
                    input.placeholder = p.placeholder;
                    input.value = state.answers.socials[pi].value;
                    input.addEventListener('input', e => {
                        state.answers.socials[pi].value = e.target.value;
                        clearInputError(input);
                        scheduleSave();
                    });
                    input.addEventListener('blur', e => {
                        const value = e.target.value.trim();
                        if (value && !validateURL(value)) {
                            showInputError(input, 'Please enter a valid URL (e.g., https://example.com)');
                        } else {
                            clearInputError(input);
                        }
                    });
                    inputRow.appendChild(iconWrap);
                    inputRow.appendChild(input);
                    wrap.appendChild(inputRow);
                    setTimeout(() => input.focus(), 50);
                }
            });
            pills.appendChild(pill);
        });

        wrap.insertBefore(pills, wrap.firstChild);

        // Render pre-existing inputs
        state.answers.socials.forEach((s, si) => {
            if (!s.value) return;
            const p = SOCIAL_PLATFORMS[si];
            const inputRow = document.createElement('div');
            inputRow.className = 'survey-social-input-row';
            inputRow.id = 'social-row-' + si;
            const iconWrap = document.createElement('div');
            iconWrap.className = 'survey-social-icon-wrap';
            iconWrap.innerHTML = p.icon;
            const input = document.createElement('input');
            input.type = 'url';
            input.className = 'survey-input';
            input.placeholder = p.placeholder;
            input.value = s.value;
            input.addEventListener('input', e => {
                state.answers.socials[si].value = e.target.value;
                clearInputError(input);
                scheduleSave();
            });
            input.addEventListener('blur', e => {
                const value = e.target.value.trim();
                if (value && !validateURL(value)) {
                    showInputError(input, 'Please enter a valid URL (e.g., https://example.com)');
                } else {
                    clearInputError(input);
                }
            });
            inputRow.appendChild(iconWrap);
            inputRow.appendChild(input);
            wrap.appendChild(inputRow);
        });

        return wrap;
    }

    function buildBrandCheck() {
        const wrap = document.createElement('div');

        const options = [
            { value:'has_logo',   label:'Yes, I have a logo',          sub:'Upload your logo file (PNG or SVG preferred)' },
            { value:'has_colors', label:'Yes, I have brand colors',     sub:"I'll share my hex codes or color swatches" },
            { value:'needs_both', label:'No, please design everything', sub:"We'll create a full brand identity for you" },
        ];

        const optionsWrap = document.createElement('div');
        optionsWrap.className = 'survey-brand-options';

        const brandButtons = [];

        options.forEach(opt => {
            const btn = document.createElement('button');
            const isActive = state.answers.brand.includes(opt.value);
            btn.className = 'survey-brand-option' + (isActive ? ' active' : '');
            btn.dataset.value = opt.value;
            btn.innerHTML = `
                <div class="survey-brand-radio">
                    <div class="survey-brand-radio-dot"></div>
                </div>
                <div class="survey-brand-option-text">
                    <strong>${opt.label}</strong>
                    <span>${opt.sub}</span>
                </div>
            `;
            btn.addEventListener('click', () => {
                const idx = state.answers.brand.indexOf(opt.value);

                // If clicking "needs_both" (None)
                if (opt.value === 'needs_both') {
                    if (idx > -1) {
                        // Deselect "None"
                        state.answers.brand.splice(idx, 1);
                        btn.classList.remove('active');
                    } else {
                        // Select "None" and deselect others
                        state.answers.brand = ['needs_both'];
                        brandButtons.forEach(b => {
                            if (b.dataset.value === 'needs_both') {
                                b.classList.add('active');
                            } else {
                                b.classList.remove('active');
                            }
                        });
                    }
                } else {
                    // Clicking logo or colors
                    const noneIdx = state.answers.brand.indexOf('needs_both');
                    if (noneIdx > -1) {
                        // Deselect "None" if it's selected
                        state.answers.brand.splice(noneIdx, 1);
                        brandButtons.find(b => b.dataset.value === 'needs_both')?.classList.remove('active');
                    }

                    if (idx > -1) {
                        state.answers.brand.splice(idx, 1);
                        btn.classList.remove('active');
                    } else {
                        state.answers.brand.push(opt.value);
                        btn.classList.add('active');
                    }
                }

                // Show extras
                renderBrandExtras();
                scheduleSave();
            });
            optionsWrap.appendChild(btn);
            brandButtons.push(btn);
        });

        wrap.appendChild(optionsWrap);

        const extrasWrap = document.createElement('div');
        extrasWrap.id = 'brand-extras';
        wrap.appendChild(extrasWrap);

        function renderBrandExtras() {
            extrasWrap.innerHTML = '';

            if (state.answers.brand.includes('has_logo')) {
                const uploadZone = document.createElement('div');
                uploadZone.className = 'survey-logo-upload';
                uploadZone.style.marginTop = '1.25rem';
                uploadZone.innerHTML = `
                    <span style="font-size:2rem;">🖼️</span>
                    <p><strong>Click to upload your logo</strong><br>PNG, SVG, or JPG</p>
                `;
                const fileInput = document.createElement('input');
                fileInput.type = 'file';
                fileInput.accept = 'image/*';
                fileInput.style.display = 'none';
                fileInput.addEventListener('change', e => {
                    const file = e.target.files[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = ev => {
                        state.answers.logoFile = { file, url: ev.target.result, name: file.name };
                        uploadZone.innerHTML = `<img src="${ev.target.result}" class="survey-logo-preview" alt="Logo"><p>${file.name}</p>`;
                    };
                    reader.readAsDataURL(file);
                });
                uploadZone.addEventListener('click', () => fileInput.click());
                uploadZone.appendChild(fileInput);
                extrasWrap.appendChild(uploadZone);
            }

            if (state.answers.brand.includes('has_colors')) {
                const colorSection = document.createElement('div');
                colorSection.style.marginTop = '1.25rem';

                const colorLabel = document.createElement('div');
                colorLabel.className = 'survey-field-label';
                colorLabel.textContent = 'Brand Colors';
                colorSection.appendChild(colorLabel);

                const colorGrid = document.createElement('div');
                colorGrid.className = 'survey-brand-colors-grid';
                colorGrid.id = 'brand-colors-grid';

                // Initialize with at least one color
                if (!state.answers.brandColors || state.answers.brandColors.length === 0) {
                    state.answers.brandColors = ['#2536EB'];
                }

                function renderColorSwatches() {
                    colorGrid.innerHTML = '';
                    state.answers.brandColors.forEach((color, index) => {
                        const swatch = document.createElement('div');
                        swatch.className = 'survey-brand-color-swatch';

                        const preview = document.createElement('div');
                        preview.className = 'survey-brand-color-preview';
                        preview.style.background = color;

                        const eyeIcon = document.createElement('div');
                        eyeIcon.className = 'survey-brand-color-icon';
                        eyeIcon.innerHTML = '👁️';
                        preview.appendChild(eyeIcon);

                        const colorInput = document.createElement('input');
                        colorInput.type = 'color';
                        colorInput.value = color;
                        colorInput.style.display = 'none';
                        colorInput.addEventListener('input', e => {
                            preview.style.background = e.target.value;
                            state.answers.brandColors[index] = e.target.value;
                            scheduleSave();
                        });

                        preview.addEventListener('click', () => colorInput.click());
                        swatch.appendChild(preview);
                        swatch.appendChild(colorInput);

                        if (index > 0) {
                            const removeBtn = document.createElement('button');
                            removeBtn.className = 'survey-brand-color-remove';
                            removeBtn.innerHTML = '×';
                            removeBtn.addEventListener('click', e => {
                                e.stopPropagation();
                                state.answers.brandColors.splice(index, 1);
                                renderColorSwatches();
                                scheduleSave();
                            });
                            swatch.appendChild(removeBtn);
                        }

                        colorGrid.appendChild(swatch);
                    });

                    // Add another color button
                    if (state.answers.brandColors.length < 5) {
                        const addBtn = document.createElement('button');
                        addBtn.className = 'survey-brand-color-add';
                        addBtn.innerHTML = '<span class="add-color-plus">+</span> Add Color';
                        addBtn.addEventListener('click', () => {
                            state.answers.brandColors.push('#000000');
                            renderColorSwatches();
                            scheduleSave();
                        });
                        colorGrid.appendChild(addBtn);
                    }
                }

                renderColorSwatches();
                colorSection.appendChild(colorGrid);
                extrasWrap.appendChild(colorSection);
            }
        }

        renderBrandExtras();
        return wrap;
    }

    function buildUpload() {
        const wrap = document.createElement('div');

        const dropzone = document.createElement('div');
        dropzone.className = 'survey-file-dropzone';
        dropzone.innerHTML = `
            <span class="survey-file-dropzone-icon">📁</span>
            <p><span class="dropzone-cta">Click to upload</span> or drag & drop</p>
            <p style="font-size:0.8rem;margin-top:0.25rem;">JPG, PNG, PDF, or any file up to 10MB</p>
        `;

        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.multiple = true;
        fileInput.style.display = 'none';
        fileInput.accept = 'image/*,.pdf,.doc,.docx';

        fileInput.addEventListener('change', e => handleFiles([...e.target.files]));
        dropzone.addEventListener('click', () => fileInput.click());
        dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('drag-over'); });
        dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
        dropzone.addEventListener('drop', e => { e.preventDefault(); dropzone.classList.remove('drag-over'); handleFiles([...e.dataTransfer.files]); });

        wrap.appendChild(fileInput);
        wrap.appendChild(dropzone);

        const thumbGrid = document.createElement('div');
        thumbGrid.className = 'survey-thumb-grid';
        thumbGrid.id = 'upload-thumbs';
        wrap.appendChild(thumbGrid);

        function handleFiles(files) {
            files.forEach(file => {
                const reader = new FileReader();
                reader.onload = ev => {
                    state.answers.files.push({ file, url: ev.target.result, name: file.name, type: file.type });
                    renderThumbs();
                };
                reader.readAsDataURL(file);
            });
        }

        function renderThumbs() {
            thumbGrid.innerHTML = '';
            state.answers.files.forEach((f, idx) => {
                const thumb = document.createElement('div');
                thumb.className = 'survey-thumb';
                if (f.type && f.type.startsWith('image/')) {
                    const img = document.createElement('img');
                    img.src = f.url;
                    img.alt = f.name;
                    thumb.appendChild(img);
                } else {
                    const icon = document.createElement('div');
                    icon.className = 'survey-thumb-icon';
                    icon.textContent = '📄';
                    thumb.appendChild(icon);
                }
                const name = document.createElement('div');
                name.className = 'survey-thumb-name';
                name.textContent = f.name;
                thumb.appendChild(name);
                const rm = document.createElement('button');
                rm.className = 'survey-thumb-remove';
                rm.textContent = '✕';
                rm.addEventListener('click', () => { state.answers.files.splice(idx, 1); renderThumbs(); });
                thumb.appendChild(rm);
                thumbGrid.appendChild(thumb);
            });
        }

        renderThumbs();
        return wrap;
    }

    // ——————————————————————————————————————————————
    // REVIEW SCREEN
    // ——————————————————————————————————————————————
    function buildReview() {
        const card = document.createElement('div');
        const animClass = state.direction === 1 ? 'survey-anim-enter-fwd' : 'survey-anim-enter-back';
        card.className = 'survey-step-card ' + animClass;

        const header = document.createElement('div');
        header.className = 'survey-step-header';
        header.innerHTML = `
            <div class="survey-step-number-label">Step 12</div>
            <div class="survey-step-question">Review your answers</div>
            <div class="survey-step-hint">Double-check everything before we build your website. You can edit any answer.</div>
        `;
        card.appendChild(header);

        const body = document.createElement('div');
        body.className = 'survey-step-body';
        body.style.maxWidth = '900px';

        const reviewGrid = document.createElement('div');
        reviewGrid.className = 'survey-review-grid';

        const a = state.answers;

        // Helper function to add review row
        function addRow(label, value, stepIndex) {
            const row = document.createElement('div');
            row.className = 'survey-review-row';

            const labelDiv = document.createElement('div');
            labelDiv.className = 'survey-review-label';
            labelDiv.textContent = label;

            const valueDiv = document.createElement('div');
            valueDiv.className = 'survey-review-value';
            valueDiv.innerHTML = value;

            const editBtn = document.createElement('button');
            editBtn.className = 'survey-review-edit';
            editBtn.innerHTML = '✏️ Edit';
            editBtn.addEventListener('click', () => {
                state.direction = -1; // Animate back
                state.screen = 'step';
                state.step = stepIndex;
                state.editingFromReview = true; // Mark that we're editing from review
                state.animating = true;
                render();
                setTimeout(() => { state.animating = false; }, 400);
            });

            row.appendChild(labelDiv);
            row.appendChild(valueDiv);
            row.appendChild(editBtn);
            reviewGrid.appendChild(row);
        }

        // Business Name
        addRow('Business Name', a.businessName || '—', 0);

        // Industry
        const industryDisplay = a.industry === 'Other' ? a.customIndustry : a.industry;
        addRow('Industry', industryDisplay || '—', 1);

        // Tagline
        addRow('Tagline', a.tagline || '—', 2);

        // Services
        const servicesDisplay = a.services ? a.services.split('\n').map(s => `<div>${s}</div>`).join('') : '—';
        addRow('Services', servicesDisplay, 3);

        // Hours
        const openDays = a.hours.filter(h => h.open);
        const hoursDisplay = openDays.length === 0 ? '—' : openDays.map(h => `${h.day}: ${h.from} – ${h.to}`).join('<br>');
        addRow('Business Hours', hoursDisplay, 4);

        // Booking
        const bookingDisplay = a.booking.length === 0 ? '—' : a.booking.map(b => {
            if (b === 'virtual') return 'Virtually';
            if (b === 'our_location') return 'At my location';
            if (b === 'client_location') return "At client's location";
            return b;
        }).join(', ');
        addRow('Meeting Options', bookingDisplay, 5);

        // Contact
        const contactParts = [];
        if (a.contact.phone) contactParts.push(`📞 ${a.contact.phone}`);
        if (a.contact.email) contactParts.push(`✉️ ${a.contact.email}`);
        if (a.contact.address) contactParts.push(`📍 ${a.contact.address}`);
        const contactDisplay = contactParts.length === 0 ? '—' : contactParts.join('<br>');
        addRow('Contact Info', contactDisplay, 6);

        // Socials
        const activeSocials = a.socials.filter(s => s.value);
        const socialsDisplay = activeSocials.length === 0 ? '—' : activeSocials.map(s => `${s.label}: ${s.value}`).join('<br>');
        addRow('Social Media', socialsDisplay, 7);

        // Brand
        const brandParts = [];
        if (a.brand.includes('has_logo')) brandParts.push('✓ Logo provided');
        if (a.brand.includes('has_colors')) brandParts.push(`✓ ${a.brandColors.length} brand color(s)`);
        if (a.brand.includes('needs_both')) brandParts.push('Will design everything');
        const brandDisplay = brandParts.length === 0 ? '—' : brandParts.join('<br>');
        addRow('Brand Assets', brandDisplay, 8);

        // Files
        const filesCount = a.files.length + (a.logoFile ? 1 : 0);
        const filesDisplay = filesCount === 0 ? '—' : `${filesCount} file(s) uploaded`;
        addRow('Files', filesDisplay, 9);

        // Extra
        addRow('Additional Notes', a.extra || 'None', 10);

        body.appendChild(reviewGrid);
        card.appendChild(body);

        // Footer
        const footer = document.createElement('div');
        footer.className = 'survey-footer';

        const backBtn = document.createElement('button');
        backBtn.className = 'survey-back-btn';
        backBtn.innerHTML = '← Back';
        backBtn.addEventListener('click', () => {
            state.screen = 'step';
            state.step = STEPS.length - 1;
            render();
        });
        footer.appendChild(backBtn);

        const submitBtn = document.createElement('button');
        submitBtn.className = 'survey-next-btn';
        submitBtn.id = 'survey-next-btn';
        submitBtn.innerHTML = 'Submit & Launch 🚀';
        submitBtn.addEventListener('click', () => submitSurvey());
        footer.appendChild(submitBtn);

        card.appendChild(footer);

        return card;
    }

    // ——————————————————————————————————————————————
    // NAVIGATION
    // ——————————————————————————————————————————————
    function goStep(dir) {
        if (state.animating) return; // Block rapid clicks

        state.direction = dir;

        if (dir === 1) {
            // Validate required fields
            const step = STEPS[state.step];
            if (step.required && !validateStep(step)) return;

            if (state.step === STEPS.length - 1) {
                // Show review screen instead of submitting directly
                state.animating = true;
                state.screen = 'review';
                render();
                setTimeout(() => { state.animating = false; }, 400);
                return;
            }
            state.step++;
        } else {
            if (state.step === 0) {
                state.animating = true;
                state.screen = 'welcome';
                render();
                setTimeout(() => { state.animating = false; }, 400);
                return;
            }
            state.step--;
        }

        state.animating = true;
        render();
        setTimeout(() => { state.animating = false; }, 400);
    }

    function skipStep() {
        if (state.step === STEPS.length - 1) {
            submitSurvey();
            return;
        }
        state.step++;
        render();
    }

    function validateStep(step) {
        const val = state.answers[step.field];
        let valid = true;

        if (step.field === 'businessName' || step.field === 'tagline') {
            valid = val && val.trim().length > 0;
        } else if (step.field === 'industry') {
            valid = val && val.trim().length > 0;
            if (valid && val === 'Other') valid = (state.answers.customIndustry || '').trim().length > 0;
        } else if (step.field === 'services') {
            valid = val && val.trim().length > 0;
        } else if (step.field === 'booking') {
            valid = Array.isArray(val) && val.length > 0;
        } else if (step.field === 'contact') {
            valid = val && (val.phone || val.email);
        } else if (step.field === 'extra') {
            valid = true; // optional even when required flag is there (last step)
        }

        if (!valid) {
            // Shake the continue button
            const btn = document.getElementById('survey-next-btn');
            if (btn) {
                btn.style.animation = 'none';
                btn.offsetHeight; // reflow
                btn.style.animation = 'shake 0.4s ease';
                setTimeout(() => btn.style.animation = '', 400);
            }
            // Add error style to relevant input
            const input = document.querySelector('#survey-root .survey-input, #survey-root .survey-pill.active');
            if (!input) {
                const firstInput = document.querySelector('#survey-root .survey-input');
                if (firstInput) firstInput.classList.add('error');
            }
        }
        return valid;
    }

    // Shake keyframe
    const shakeStyle = document.createElement('style');
    shakeStyle.textContent = '@keyframes shake { 0%,100%{transform:translateX(0)} 20%,60%{transform:translateX(-6px)} 40%,80%{transform:translateX(6px)} }';
    document.head.appendChild(shakeStyle);

    // ——————————————————————————————————————————————
    // AUTO-SAVE
    // ——————————————————————————————————————————————
    let saveTimer;
    function scheduleSave() {
        clearTimeout(saveTimer);
        saveTimer = setTimeout(saveProgressNow, 1500);
    }

    function saveProgressNow() {
        const token = state.session.resume_token;
        if (!token) return;
        const cfg = state.session;
        const payload = new FormData();
        payload.append('action', 'sec_save_survey_progress');
        payload.append('nonce', cfg.nonce || '');
        payload.append('token', token);
        payload.append('step', state.step);
        payload.append('answers', JSON.stringify(serializeAnswers()));
        fetch(cfg.ajax_url || '/wp-admin/admin-ajax.php', {
            method: 'POST', body: payload, credentials: 'same-origin'
        }).catch(() => {});
    }

    function serializeAnswers() {
        const a = state.answers;
        return {
            businessName: a.businessName, industry: a.industry,
            customIndustry: a.customIndustry, tagline: a.tagline,
            services: a.services, hours: a.hours, booking: a.booking,
            contact: a.contact, socials: a.socials, brand: a.brand,
            brandColors: a.brandColors, brandSlogan: a.brandSlogan, extra: a.extra,
        };
    }

    // ——————————————————————————————————————————————
    // SUBMISSION
    // ——————————————————————————————————————————————
    function submitSurvey() {
        const btn = document.getElementById('survey-next-btn');
        if (btn) { btn.disabled = true; btn.innerHTML = 'Submitting… <span class="survey-loading"></span>'; }

        const formData = new FormData();
        const cfg = state.session;
        formData.append('action', 'sec_submit_survey');
        formData.append('nonce', cfg.nonce || '');

        if (cfg.session) {
            formData.append('customer_id', cfg.session.customer_id || '');
            formData.append('customer_name', cfg.session.customer_name || '');
            formData.append('customer_email', cfg.session.customer_email || '');
            formData.append('payment_amount', cfg.session.payment_amount || 0);
            formData.append('session_id', cfg.session.session_id || '');
        }

        const a = state.answers;
        formData.append('business_name', a.businessName);
        formData.append('industry', a.industry);
        formData.append('custom_industry', a.customIndustry);
        formData.append('tagline', a.tagline);
        formData.append('services', a.services);
        formData.append('hours', JSON.stringify(a.hours));
        formData.append('booking', JSON.stringify(a.booking));
        formData.append('contact_phone', a.contact.phone);
        formData.append('contact_email', a.contact.email);
        formData.append('contact_address', a.contact.address);
        formData.append('socials', JSON.stringify(a.socials));
        formData.append('brand', JSON.stringify(a.brand));
        formData.append('brand_colors', a.brandColors.join(','));
        formData.append('brand_slogan', a.brandSlogan);
        formData.append('extra', a.extra);
        if (cfg.resume_token) formData.append('survey_token', cfg.resume_token);
        if (a.logoFile && a.logoFile.file) formData.append('logo', a.logoFile.file);
        a.files.forEach((f, i) => { if (f.file) formData.append(`files[${i}]`, f.file); });

        fetch(cfg.ajax_url || '/wp-admin/admin-ajax.php', {
            method: 'POST', body: formData, credentials: 'same-origin'
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                state.screen = 'success';
                render();
            } else {
                throw new Error(data.data?.message || 'Submission failed');
            }
        })
        .catch(err => {
            console.error(err);
            if (btn) { btn.disabled = false; btn.innerHTML = 'Submit & Launch 🚀'; }
            alert('There was an error submitting. Please try again.');
        });
    }

    // ——————————————————————————————————————————————
    // SUCCESS SCREEN
    // ——————————————————————————————————————————————
    function buildSuccess() {
        const a = state.answers;
        const div = document.createElement('div');
        div.className = 'survey-success';
        div.innerHTML = `
            <div class="survey-success-icon">✓</div>
            <h2>You're all set!</h2>
            <p>We have everything we need to build <strong style="color:var(--brand-blue)">${a.businessName || 'your'}</strong>'s website.<br>Expect your preview within <strong>48 hours</strong>.</p>
            <div class="survey-success-summary">
                <div class="survey-success-row"><strong>Business</strong><span>${a.businessName || '—'}</span></div>
                <div class="survey-success-row"><strong>Industry</strong><span>${a.industry === 'Other' ? a.customIndustry : a.industry || '—'}</span></div>
                <div class="survey-success-row"><strong>Files uploaded</strong><span>${a.files.length + (a.logoFile ? 1 : 0)}</span></div>
                <div class="survey-success-row"><strong>Social pages</strong><span>${a.socials.filter(s=>s.value).length}</span></div>
            </div>
            <p style="font-size:0.875rem;color:var(--text-tertiary);">We'll email you at <strong>${a.contact.email || 'the email you provided'}</strong> when your preview is ready.</p>
        `;
        return div;
    }

    // ——————————————————————————————————————————————
    // INLINE TIME PICKER HELPERS
    // ——————————————————————————————————————————————
    window.toggleInlineTimePicker = function(day, type) {
        // Close all other open pickers
        document.querySelectorAll('.inline-time-picker-wrapper').forEach(wrapper => {
            if (wrapper.id !== `picker-${day}-${type}`) {
                wrapper.style.display = 'none';
                const otherDisplay = wrapper.previousElementSibling;
                const otherIcon = otherDisplay?.querySelector('.time-display-icon');
                if (otherIcon) otherIcon.textContent = '▼';
            }
        });

        const picker = document.getElementById(`picker-${day}-${type}`);
        const display = document.getElementById(`time-${day}-${type}`).parentElement;
        const icon = display.querySelector('.time-display-icon');

        if (picker.style.display === 'none' || !picker.style.display) {
            // Show picker
            picker.style.display = 'block';
            icon.textContent = '▲';

            // Initialize wheels if not done yet
            if (!picker.dataset.initialized) {
                const hourWheel = picker.querySelector('[data-wheel="hour"]');
                const minuteWheel = picker.querySelector('[data-wheel="minute"]');
                const periodWheel = picker.querySelector('[data-wheel="period"]');

                populateWheel(hourWheel, ['1','2','3','4','5','6','7','8','9','10','11','12'], '9');
                populateWheel(minuteWheel, ['00','15','30','45'], '00');
                populateWheel(periodWheel, ['AM','PM'], 'AM');

                picker.dataset.initialized = 'true';
            }
        } else {
            // Hide picker
            picker.style.display = 'none';
            icon.textContent = '▼';
        }
    };

    window.confirmInlineTime = function(day, type) {
        const picker = document.getElementById(`picker-${day}-${type}`);
        const hourWheel = picker.querySelector('[data-wheel="hour"]');
        const minuteWheel = picker.querySelector('[data-wheel="minute"]');
        const periodWheel = picker.querySelector('[data-wheel="period"]');

        const hour = hourWheel.querySelector('.time-option.selected')?.textContent || '9';
        const minute = minuteWheel.querySelector('.time-option.selected')?.textContent || '00';
        const period = periodWheel.querySelector('.time-option.selected')?.textContent || 'AM';

        const timeString = `${hour}:${minute} ${period}`;
        document.getElementById(`time-${day}-${type}`).textContent = timeString;

        // Update state (type is 'from' or 'to')
        state.answers.hours[day][type] = timeString;
        scheduleSave();

        // Hide picker
        picker.style.display = 'none';
        const icon = picker.previousElementSibling.querySelector('.time-display-icon');
        if (icon) icon.textContent = '▼';
    };

    function populateWheel(wheel, options, selectedValue) {
        let html = '<div class="time-option-spacer"></div><div class="time-option-spacer"></div>';
        options.forEach(opt => {
            const isSelected = opt === selectedValue;
            html += `<div class="time-option${isSelected ? ' selected' : ''}">${opt}</div>`;
        });
        html += '<div class="time-option-spacer"></div><div class="time-option-spacer"></div>';
        wheel.innerHTML = html;
    }

    window.initializeInlineTimePickers = function() {
        const wheels = document.querySelectorAll('.inline-time-wheel');

        wheels.forEach(wheel => {
            const options = wheel.querySelectorAll('.time-option:not(.time-option-spacer)');
            let isUserScrolling = false;
            let scrollTimeout;

            function updateSelectedOption() {
                const wheelRect = wheel.getBoundingClientRect();
                const centerY = wheelRect.top + wheelRect.height / 2;

                let closestOption = null;
                let closestDistance = Infinity;

                options.forEach(option => {
                    if (option.classList.contains('time-option-spacer')) return;

                    const optionRect = option.getBoundingClientRect();
                    const optionCenterY = optionRect.top + optionRect.height / 2;
                    const distance = Math.abs(centerY - optionCenterY);

                    if (distance < closestDistance) {
                        closestDistance = distance;
                        closestOption = option;
                    }
                });

                // Update selected class
                options.forEach(opt => opt.classList.remove('selected'));
                if (closestOption) closestOption.classList.add('selected');
            }

            function scrollToSelected() {
                const selected = wheel.querySelector('.time-option.selected');
                if (!selected) return;

                const wheelRect = wheel.getBoundingClientRect();
                const selectedRect = selected.getBoundingClientRect();
                const wheelCenter = wheelRect.height / 2;
                const selectedCenter = selectedRect.height / 2;
                const scrollOffset = (selectedRect.top - wheelRect.top) - wheelCenter + selectedCenter;

                wheel.scrollBy({
                    top: scrollOffset,
                    behavior: 'smooth'
                });
            }

            wheel.addEventListener('scroll', () => {
                clearTimeout(scrollTimeout);
                isUserScrolling = true;

                scrollTimeout = setTimeout(() => {
                    updateSelectedOption();
                    setTimeout(() => {
                        scrollToSelected();
                        isUserScrolling = false;
                    }, 150);
                }, 300);
            });

            // Initialize
            updateSelectedOption();
            setTimeout(() => scrollToSelected(), 100);
        });
    };

    // ——————————————————————————————————————————————
    // VALIDATION HELPERS
    // ——————————————————————————————————————————————
    function validatePhone(phone) {
        // Basic phone validation (10-15 digits, allowing common separators)
        const cleaned = phone.replace(/[\s\-\(\)\.]/g, '');
        return /^\+?[0-9]{10,15}$/.test(cleaned);
    }

    function validateEmail(email) {
        // Standard email regex
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    function validateURL(url) {
        // Basic URL validation
        try {
            const parsed = new URL(url.startsWith('http') ? url : 'https://' + url);
            return parsed.protocol === 'http:' || parsed.protocol === 'https:';
        } catch (e) {
            return false;
        }
    }

    function showInputError(input, message) {
        input.classList.add('error');
        let errorEl = input.nextElementSibling;
        if (!errorEl || !errorEl.classList.contains('survey-input-error')) {
            errorEl = document.createElement('div');
            errorEl.className = 'survey-input-error';
            input.parentNode.insertBefore(errorEl, input.nextSibling);
        }
        errorEl.textContent = message;
        errorEl.style.display = 'block';
    }

    function clearInputError(input) {
        input.classList.remove('error');
        const errorEl = input.nextElementSibling;
        if (errorEl && errorEl.classList.contains('survey-input-error')) {
            errorEl.style.display = 'none';
        }
    }

    // ——————————————————————————————————————————————
    // RESUME FROM TOKEN
    // ——————————————————————————————————————————————
    function maybeResume() {
        const cfg = state.session;
        if (!cfg || !cfg.is_resume) return;
        if (cfg.resume_answers) {
            const saved = cfg.resume_answers;
            const keys = ['businessName','industry','customIndustry','tagline','services',
                          'hours','booking','contact','socials','brand','brandColors','brandSlogan','extra'];
            keys.forEach(k => { if (saved[k] !== undefined) state.answers[k] = saved[k]; });
        }
        const savedStep = Math.min(Math.max(0, parseInt(cfg.resume_step||0,10)), STEPS.length-1);
        state.step = savedStep;
        state.screen = 'step';
    }

    // ——————————————————————————————————————————————
    // BOOT
    // ——————————————————————————————————————————————
    maybeResume();
    render();
    </script>
