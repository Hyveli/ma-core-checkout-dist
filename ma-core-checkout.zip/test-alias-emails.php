<?php
/**
 * Test Email Aliases - WP Mail SMTP Diagnostic
 *
 * Upload this to your WordPress root and visit in browser:
 * https://yoursite.com/test-alias-emails.php
 *
 * DELETE THIS FILE AFTER TESTING FOR SECURITY!
 */

require_once('wp-load.php');

if (!current_user_can('manage_options')) {
    die('Access denied. You must be an administrator.');
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Email Alias Test</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            padding: 20px;
            max-width: 900px;
            margin: 0 auto;
        }
        h1 {
            color: #2536EB;
            border-bottom: 3px solid #2536EB;
            padding-bottom: 10px;
        }
        .test-section {
            background: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .test-section h3 {
            margin-top: 0;
            color: #333;
        }
        .success {
            color: #22c55e;
            font-weight: bold;
        }
        .error {
            color: #ef4444;
            font-weight: bold;
        }
        .warning {
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
        }
        .info {
            background: #e3f2fd;
            border: 1px solid #2196f3;
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
        }
        .code {
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 15px;
            border-radius: 6px;
            font-family: 'Courier New', monospace;
            overflow-x: auto;
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background: #2536EB;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .email-preview {
            border-left: 4px solid #2536EB;
            padding-left: 15px;
            margin: 10px 0;
            color: #666;
        }
        button {
            background: #2536EB;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        button:hover {
            background: #1a28b8;
        }
    </style>
</head>
<body>
    <h1>🧪 Email Alias Test - WP Mail SMTP Diagnostic</h1>

    <div class="warning">
        <strong>⚠️ Security Warning:</strong> DELETE this file after testing! This file exposes email configuration details and should not remain on a production site.
    </div>

    <?php
    // Check if WP Mail SMTP is installed
    $wp_mail_smtp_active = function_exists('wp_mail_smtp') || class_exists('WPMailSMTP\Options');

    if (!$wp_mail_smtp_active) {
        echo '<div class="error"><p><strong>Error:</strong> WP Mail SMTP plugin is not installed or activated.</p></div>';
        exit;
    }

    // Get WP Mail SMTP settings (compatible with v3.x and v4.x)
    $mailer = '';
    $from_email = '';
    $force_from_email = false;
    $oauth_configured = false;

    // Try new API first (WP Mail SMTP 3.0+)
    if (class_exists('WPMailSMTP\Options')) {
        try {
            $options = new WPMailSMTP\Options();
            $mailer = $options->get('mail', 'mailer');
            $from_email = $options->get('mail', 'from_email');
            $force_from_email = $options->get('mail', 'from_email_force');

            // Check OAuth
            $gmail_client_id = $options->get('gmail', 'client_id');
            $gmail_auth_code = $options->get('gmail', 'auth_code');
            $oauth_configured = !empty($gmail_client_id) && !empty($gmail_auth_code);
        } catch (Exception $e) {
            // Fallback to direct option access
            $wp_mail_smtp_options = get_option('wp_mail_smtp', array());
            $mailer = isset($wp_mail_smtp_options['mail']['mailer']) ? $wp_mail_smtp_options['mail']['mailer'] : '';
            $from_email = isset($wp_mail_smtp_options['mail']['from_email']) ? $wp_mail_smtp_options['mail']['from_email'] : '';
            $force_from_email = isset($wp_mail_smtp_options['mail']['from_email_force']) ? $wp_mail_smtp_options['mail']['from_email_force'] : false;
            $oauth_configured = !empty($wp_mail_smtp_options['gmail']['client_id']) && !empty($wp_mail_smtp_options['gmail']['auth_code']);
        }
    } else {
        // Fallback for older versions
        $wp_mail_smtp_options = get_option('wp_mail_smtp', array());
        $mailer = isset($wp_mail_smtp_options['mail']['mailer']) ? $wp_mail_smtp_options['mail']['mailer'] : '';
        $from_email = isset($wp_mail_smtp_options['mail']['from_email']) ? $wp_mail_smtp_options['mail']['from_email'] : '';
        $force_from_email = isset($wp_mail_smtp_options['mail']['from_email_force']) ? $wp_mail_smtp_options['mail']['from_email_force'] : false;
        $oauth_configured = !empty($wp_mail_smtp_options['gmail']['client_id']) && !empty($wp_mail_smtp_options['gmail']['auth_code']);
    }

    echo '<h2>WP Mail SMTP Configuration</h2>';
    echo '<table>';
    echo '<tr><th>Setting</th><th>Value</th><th>Status</th></tr>';

    // Check mailer
    echo '<tr>';
    echo '<td><strong>Mailer</strong></td>';
    echo '<td>' . esc_html($mailer ?: 'Not configured') . '</td>';
    echo '<td>' . ($mailer === 'gmail' ? '<span class="success">✓ Google / Gmail</span>' : '<span class="warning">⚠️ Not using Gmail</span>') . '</td>';
    echo '</tr>';

    // Check From Email
    echo '<tr>';
    echo '<td><strong>From Email</strong></td>';
    echo '<td>' . esc_html($from_email ?: 'Not configured') . '</td>';
    echo '<td>' . ($from_email === 'hello@marketingaid.org' ? '<span class="success">✓ Primary account</span>' : '<span class="warning">⚠️ Should be hello@marketingaid.org</span>') . '</td>';
    echo '</tr>';

    // Check Force From Email setting
    echo '<tr>';
    echo '<td><strong>Force From Email</strong></td>';
    echo '<td>' . ($force_from_email ? 'YES (enabled)' : 'NO (disabled)') . '</td>';
    echo '<td>';
    if ($force_from_email) {
        echo '<span class="error">✗ THIS IS THE PROBLEM! Disable this setting.</span>';
    } else {
        echo '<span class="success">✓ Correctly disabled</span>';
    }
    echo '</td>';
    echo '</tr>';

    // Check OAuth
    echo '<tr>';
    echo '<td><strong>OAuth Status</strong></td>';
    echo '<td>' . ($oauth_configured ? 'Authorized' : 'Not authorized') . '</td>';
    echo '<td>' . ($oauth_configured ? '<span class="success">✓ OAuth configured</span>' : '<span class="error">✗ OAuth not configured</span>') . '</td>';
    echo '</tr>';

    echo '</table>';

    if ($force_from_email) {
        echo '<div class="warning">';
        echo '<h3>🚨 Action Required: Disable "Force From Email"</h3>';
        echo '<p><strong>The problem is:</strong> WP Mail SMTP "Force From Email" is enabled, which means ALL emails will be sent from <code>' . esc_html($from_email) . '</code>, ignoring your plugin\'s custom From headers.</p>';
        echo '<p><strong>How to fix:</strong></p>';
        echo '<ol>';
        echo '<li>Go to <strong>WP Admin</strong> → <strong>WP Mail SMTP</strong> → <strong>Settings</strong></li>';
        echo '<li>Scroll to <strong>"From Email"</strong> section</li>';
        echo '<li><strong>UNCHECK</strong> the box that says <em>"Force From Email"</em></li>';
        echo '<li>Click <strong>Save Settings</strong></li>';
        echo '<li>Refresh this page and run the tests again</li>';
        echo '</ol>';
        echo '<p><a href="' . admin_url('admin.php?page=wp-mail-smtp') . '" style="background:#2536EB;color:white;padding:10px 20px;text-decoration:none;border-radius:6px;display:inline-block;">→ Go to WP Mail SMTP Settings</a></p>';
        echo '</div>';
    }
    ?>

    <h2>Email Alias Configuration</h2>
    <table>
        <tr>
            <th>Email Type</th>
            <th>Configured Alias</th>
            <th>Expected</th>
            <th>Status</th>
        </tr>
        <?php
        $email_configs = [
            'Invoice' => [
                'option' => 'sec_invoice_from_email',
                'expected' => 'billing@marketingaid.org',
            ],
            'Survey Invitation' => [
                'option' => 'sec_survey_from_email',
                'expected' => 'hello@marketingaid.org',
            ],
            'Survey Reminder' => [
                'option' => 'sec_reminder_from_email',
                'expected' => 'alerts@marketingaid.org',
            ],
            'Survey Completion' => [
                'option' => 'sec_completion_from_email',
                'expected' => 'alerts@marketingaid.org',
            ],
        ];

        foreach ($email_configs as $type => $config) {
            $configured = get_option($config['option'], '');
            $matches = ($configured === $config['expected']);

            echo '<tr>';
            echo '<td><strong>' . esc_html($type) . '</strong></td>';
            echo '<td>' . esc_html($configured ?: '(not set)') . '</td>';
            echo '<td>' . esc_html($config['expected']) . '</td>';
            echo '<td>';
            if ($matches) {
                echo '<span class="success">✓ Correct</span>';
            } else {
                echo '<span class="error">✗ Needs update</span>';
            }
            echo '</td>';
            echo '</tr>';
        }
        ?>
    </table>

    <?php if (isset($_POST['send_test_emails'])) : ?>
        <h2>📧 Test Results</h2>

        <?php
        $admin_email = 'karaconcepcion01@gmail.com'; // Changed from get_option('admin_email')
        echo '<p><strong>Sending test emails to:</strong> ' . esc_html($admin_email) . '</p>';

        $tests = [
            'Invoice Email (billing@)' => [
                'from_email' => get_option('sec_invoice_from_email', 'billing@marketingaid.org'),
                'from_name' => 'MarketingAid Billing',
                'subject' => 'Test Invoice Email - ' . date('Y-m-d H:i:s'),
                'expected' => 'billing@marketingaid.org',
            ],
            'Survey Email (hello@)' => [
                'from_email' => get_option('sec_survey_from_email', 'hello@marketingaid.org'),
                'from_name' => 'MarketingAid',
                'subject' => 'Test Survey Email - ' . date('Y-m-d H:i:s'),
                'expected' => 'hello@marketingaid.org',
            ],
            'Reminder Email (alerts@)' => [
                'from_email' => get_option('sec_reminder_from_email', 'alerts@marketingaid.org'),
                'from_name' => 'MarketingAid Alerts',
                'subject' => 'Test Reminder Email - ' . date('Y-m-d H:i:s'),
                'expected' => 'alerts@marketingaid.org',
            ],
        ];

        foreach ($tests as $label => $config) {
            echo '<div class="test-section">';
            echo '<h3>' . esc_html($label) . '</h3>';
            echo '<div class="email-preview">';
            echo '<strong>From:</strong> ' . esc_html($config['from_name']) . ' &lt;' . esc_html($config['from_email']) . '&gt;<br>';
            echo '<strong>To:</strong> ' . esc_html($admin_email) . '<br>';
            echo '<strong>Subject:</strong> ' . esc_html($config['subject']);
            echo '</div>';

            $headers = [
                'Content-Type: text/html; charset=UTF-8',
                'From: ' . $config['from_name'] . ' <' . $config['from_email'] . '>',
            ];

            $body = '<html><body style="font-family:Arial,sans-serif;padding:20px;">';
            $body .= '<h2 style="color:#2536EB;">' . $config['subject'] . '</h2>';
            $body .= '<p>This is a <strong>test email</strong> to verify alias functionality.</p>';
            $body .= '<div style="background:#e3f2fd;border:1px solid #2196f3;padding:15px;border-radius:6px;margin:20px 0;">';
            $body .= '<strong>Check the "From" address in your email client:</strong><br>';
            $body .= 'Expected: <code>' . $config['expected'] . '</code><br>';
            $body .= 'Configured: <code>' . $config['from_email'] . '</code>';
            $body .= '</div>';
            $body .= '<p>If the "From" address is <strong>' . $config['expected'] . '</strong>, the alias is working correctly!</p>';
            $body .= '<p>If it shows <strong>hello@marketingaid.org</strong> instead, then "Force From Email" is likely enabled in WP Mail SMTP.</p>';
            $body .= '<hr>';
            $body .= '<p style="font-size:12px;color:#666;">Sent: ' . date('F j, Y g:i:s A') . '</p>';
            $body .= '</body></html>';

            $sent = wp_mail($admin_email, $config['subject'], $body, $headers);

            if ($sent) {
                echo '<p class="success">✓ Email queued for sending</p>';
                echo '<p><em>Check your inbox at <strong>' . esc_html($admin_email) . '</strong> and verify the From address.</em></p>';
            } else {
                echo '<p class="error">✗ Failed to send email</p>';
                echo '<p>Check WP Mail SMTP Error Log for details.</p>';
            }
            echo '</div>';
        }
        ?>

        <div class="info">
            <h3>✅ What to Check in Your Email Inbox</h3>
            <p><strong>For each test email, verify the "From" address shows:</strong></p>
            <ul>
                <li><strong>Invoice Email:</strong> billing@marketingaid.org</li>
                <li><strong>Survey Email:</strong> hello@marketingaid.org</li>
                <li><strong>Reminder Email:</strong> alerts@marketingaid.org</li>
            </ul>
            <p><strong>If all emails show "hello@marketingaid.org" instead:</strong></p>
            <ul>
                <li>WP Mail SMTP "Force From Email" is enabled (see red warning above)</li>
                <li>Disable it and run the test again</li>
            </ul>
        </div>

        <div class="warning">
            <p><strong>📬 Email Delivery:</strong> It may take a few minutes for emails to arrive. Check your spam folder if you don't see them.</p>
        </div>
    <?php else : ?>
        <h2>📬 Send Test Emails</h2>
        <p>Click the button below to send test emails from each alias to <strong>karaconcepcion01@gmail.com</strong></p>
        <form method="post">
            <button type="submit" name="send_test_emails" value="1">Send Test Emails</button>
        </form>
    <?php endif; ?>

    <h2>📚 Next Steps</h2>
    <div class="info">
        <h3>If "Force From Email" is enabled:</h3>
        <ol>
            <li>Go to <a href="<?php echo admin_url('admin.php?page=wp-mail-smtp'); ?>">WP Mail SMTP Settings</a></li>
            <li>Disable "Force From Email"</li>
            <li>Save settings</li>
            <li>Return to this page and send test emails again</li>
        </ol>

        <h3>If aliases still don't work after disabling "Force From Email":</h3>
        <ol>
            <li>Verify aliases exist in <a href="https://admin.google.com" target="_blank">Google Workspace Admin Console</a></li>
            <li>Re-authorize OAuth in WP Mail SMTP settings</li>
            <li>Wait 5-10 minutes for Google to propagate changes</li>
            <li>Test again</li>
        </ol>

        <h3>If everything works:</h3>
        <ol>
            <li><strong>DELETE THIS FILE!</strong> (test-alias-emails.php)</li>
            <li>Your email aliases are configured correctly</li>
            <li>All emails will now send from the appropriate addresses</li>
        </ol>
    </div>

    <div class="warning">
        <h3>🗑️ Important: Delete This File</h3>
        <p><strong>After testing, DELETE this file from your server for security!</strong></p>
        <div class="code">
            # SSH into your server and run:<br>
            rm /path/to/wordpress/test-alias-emails.php
        </div>
        <p>Or delete it via FTP/File Manager.</p>
    </div>

    <p style="text-align:center;margin-top:40px;color:#999;font-size:12px;">
        MarketingAid Checkout Plugin - Email Alias Diagnostic Tool
    </p>
</body>
</html>
