/**
 * Activation Slots Frontend JavaScript
 */

(function($) {
  'use strict';

  const config = window.secSlotsFrontend || {};
  let refreshInterval;

  /**
   * Fetch and display slot status
   */
  function loadSlotStatus() {
    $.ajax({
      url: config.rest_url + 'slots',
      method: 'GET',
      success: function(response) {
        renderSlotWidget(response);
      },
      error: function() {
        $('#sec-slots-widget').html(
          '<div class="sec-slots-error">Unable to load slot status. Please refresh the page.</div>'
        );
      }
    });
  }

  /**
   * Render the slot widget
   */
  function renderSlotWidget(data) {
    const available = data.available;
    const total = data.total;
    const slotsHtml = generateSlotsHTML(data);

    let widgetHTML = `
      <div class="sec-slots-container">
        <div class="sec-slots-header">
          <h3>🎯 Platform Activation Slots</h3>
          <div class="sec-slots-count">
            <span class="sec-count-available">${available}</span>
            <span class="sec-count-separator">/</span>
            <span class="sec-count-total">${total}</span>
            <span class="sec-count-label">Available</span>
          </div>
        </div>

        <div class="sec-slots-grid">
          ${slotsHtml}
        </div>

        ${available > 0 ? renderAvailableMessage() : renderCheckoutPreview()}
      </div>
    `;

    $('#sec-slots-widget').html(widgetHTML);
    attachEventListeners();
  }

  /**
   * Generate HTML for slot grid
   */
  function generateSlotsHTML(data) {
    return data.slots.map((slot, index) => {
      const status = slot.active ? 'active' : 'available';
      const icon = slot.active ? '🔴' : '🟢';
      let timerHTML = '';

      if (slot.active && slot.expires_in) {
        const hours = Math.floor(slot.expires_in / 3600);
        const minutes = Math.floor((slot.expires_in % 3600) / 60);
        timerHTML = `<div class="sec-slot-timer">${hours}h ${minutes}m</div>`;
      }

      return `
        <div class="sec-slot sec-slot-${status}">
          <div class="sec-slot-icon">${icon}</div>
          <div class="sec-slot-number">#${index + 1}</div>
          ${timerHTML}
        </div>
      `;
    }).join('');
  }

  /**
   * Render message when slots are available
   */
  function renderAvailableMessage() {
    return `
      <div class="sec-slots-available">
        <div class="sec-available-badge">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <circle cx="10" cy="10" r="10" fill="#22c55e"/>
            <path d="M6 10L9 13L14 7" stroke="white" stroke-width="2" stroke-linecap="round"/>
          </svg>
          Slots Available Now!
        </div>
        <p>Activation slots are available on a first-come, first-served basis. Each slot is valid for 24 hours.</p>
        <a href="#activate" class="sec-activate-btn">Activate Your Platform — $29/mo</a>
      </div>
    `;
  }

  /**
   * Render checkout preview with waitlist overlay when slots are full
   */
  function renderCheckoutPreview() {
    return `
      <div class="sec-checkout-preview-wrapper">
        <!-- Blurred checkout form preview -->
        <div class="sec-checkout-preview-blurred">
          <h3 style="margin: 0 0 24px 0; font-size: 20px; color: #1f2937; text-align: center;">SETUP FEE APPLICATION</h3>
          <p style="text-align: center; color: #6b7280; margin-bottom: 24px;">Please fill in your information below.</p>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
            <div>
              <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">Full Name *</label>
              <input type="text" disabled placeholder="John Doe" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb;">
            </div>
            <div>
              <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">Business Name *</label>
              <input type="text" disabled placeholder="Acme Inc." style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb;">
            </div>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;">
            <div>
              <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">Email Address *</label>
              <input type="email" disabled placeholder="john@example.com" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb;">
            </div>
            <div>
              <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">Phone Number *</label>
              <input type="tel" disabled placeholder="(555) 123-4567" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb;">
            </div>
          </div>

          <div style="margin-bottom: 16px;">
            <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">Street Address *</label>
            <input type="text" disabled placeholder="123 Main St" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb;">
          </div>

          <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 16px; margin-bottom: 24px;">
            <div>
              <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">City *</label>
              <input type="text" disabled placeholder="New York" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb;">
            </div>
            <div>
              <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">State *</label>
              <input type="text" disabled placeholder="NY" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb;">
            </div>
            <div>
              <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #374151; font-size: 14px;">Zip Code *</label>
              <input type="text" disabled placeholder="10001" style="width: 100%; padding: 12px; border: 1px solid #d1d5db; border-radius: 6px; background: #f9fafb;">
            </div>
          </div>

          <div style="background: #f0f9ff; border: 2px dashed #3b82f6; border-radius: 8px; padding: 20px; text-align: center; margin-bottom: 20px;">
            <p style="margin: 0; color: #1e40af; font-size: 14px;">🔒 Stripe Checkout • $29 Setup Fee</p>
          </div>

          <button disabled style="width: 100%; padding: 16px; background: #22c55e; color: white; border: none; border-radius: 8px; font-size: 16px; font-weight: 700; cursor: not-allowed; opacity: 0.6;">
            No Slots Available
          </button>
        </div>

        <!-- Waitlist overlay -->
        <div class="sec-waitlist-overlay">
          <div class="sec-waitlist-overlay-card">
            <div class="sec-waitlist-icon">⏳</div>
            <h4>All slots taken — join the waitlist</h4>
            <p>Get notified the moment a slot opens up</p>

            <form id="sec-waitlist-form" class="sec-waitlist-overlay-form">
              <input
                type="email"
                id="waitlist-email"
                placeholder="Enter your email address"
                required
                class="sec-waitlist-overlay-input"
              >
              <button type="submit" class="sec-waitlist-overlay-btn">
                Notify Me
              </button>
            </form>

            <div id="sec-waitlist-message" class="sec-waitlist-message" style="display: none;"></div>
          </div>
        </div>
      </div>
    `;
  }

  /**
   * Attach event listeners
   */
  function attachEventListeners() {
    $('#sec-waitlist-form').on('submit', function(e) {
      e.preventDefault();
      submitWaitlistForm();
    });
  }

  /**
   * Submit waitlist form
   */
  function submitWaitlistForm() {
    const email = $('#waitlist-email').val().trim();
    const $btn = $('#sec-waitlist-form button[type="submit"]');
    const $message = $('#sec-waitlist-message');

    if (!email) {
      showMessage('Please enter your email address.', 'error');
      return;
    }

    $btn.prop('disabled', true).html(
      '<div class="sec-spinner-small"></div> Notifying...'
    );

    $.ajax({
      url: config.rest_url + 'waitlist',
      method: 'POST',
      data: JSON.stringify({
        name: '',
        email: email,
        nonce: config.nonce
      }),
      contentType: 'application/json',
      success: function(response) {
        if (response.reload) {
          showMessage(response.message, 'success');
          setTimeout(loadSlotStatus, 2000);
        } else {
          showMessage('✅ You\'re on the list! We\'ll email you when a slot opens.', 'success');
          $('#waitlist-email').val('');
          $btn.prop('disabled', true).html('✓ Joined Waitlist');
        }
      },
      error: function(xhr) {
        const error = xhr.responseJSON?.message || 'Failed to join waitlist. Please try again.';
        showMessage(error, 'error');
        $btn.prop('disabled', false).html('Notify Me');
      }
    });
  }

  /**
   * Show message
   */
  function showMessage(message, type) {
    const $message = $('#sec-waitlist-message');
    $message
      .removeClass('sec-message-success sec-message-error')
      .addClass('sec-message-' + type)
      .html(message)
      .fadeIn();
  }

  /**
   * Auto-refresh every 60 seconds
   */
  function startAutoRefresh() {
    refreshInterval = setInterval(loadSlotStatus, 60000);
  }

  /**
   * Initialize
   */
  $(document).ready(function() {
    if ($('#sec-slots-widget').length) {
      loadSlotStatus();
      startAutoRefresh();
    }
  });

})(jQuery);
