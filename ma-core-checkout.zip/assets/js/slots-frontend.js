/**
 * Activation Slots Frontend JavaScript
 */

(function($) {
  'use strict';

  const config = window.secSlotsFrontend || {};
  let refreshInterval;

  /**
   * Fetch and display slot status
   */
  function loadSlotStatus() {
    $.ajax({
      url: config.rest_url + 'slots',
      method: 'GET',
      success: function(response) {
        renderSlotWidget(response);
      },
      error: function() {
        $('#sec-slots-widget').html(
          '<div class="sec-slots-error">Unable to load slot status. Please refresh the page.</div>'
        );
      }
    });
  }

  /**
   * Render the slot widget
   */
  function renderSlotWidget(data) {
    const available = data.available;
    const total = data.total;
    const slotsHtml = generateSlotsHTML(data);

    let widgetHTML = `
      <div class="sec-slots-container">
        <div class="sec-slots-header">
          <h3>🎯 Platform Activation Slots</h3>
          <div class="sec-slots-count">
            <span class="sec-count-available">${available}</span>
            <span class="sec-count-separator">/</span>
            <span class="sec-count-total">${total}</span>
            <span class="sec-count-label">Available</span>
          </div>
        </div>

        <div class="sec-slots-grid">
          ${slotsHtml}
        </div>

        ${available > 0 ? renderAvailableMessage() : renderWaitlistForm()}
      </div>
    `;

    $('#sec-slots-widget').html(widgetHTML);
    attachEventListeners();
  }

  /**
   * Generate HTML for slot grid
   */
  function generateSlotsHTML(data) {
    return data.slots.map((slot, index) => {
      const status = slot.active ? 'active' : 'available';
      const icon = slot.active ? '🔴' : '🟢';
      let timerHTML = '';

      if (slot.active && slot.expires_in) {
        const hours = Math.floor(slot.expires_in / 3600);
        const minutes = Math.floor((slot.expires_in % 3600) / 60);
        timerHTML = `<div class="sec-slot-timer">${hours}h ${minutes}m</div>`;
      }

      return `
        <div class="sec-slot sec-slot-${status}">
          <div class="sec-slot-icon">${icon}</div>
          <div class="sec-slot-number">#${index + 1}</div>
          ${timerHTML}
        </div>
      `;
    }).join('');
  }

  /**
   * Render message when slots are available
   */
  function renderAvailableMessage() {
    return `
      <div class="sec-slots-available">
        <div class="sec-available-badge">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <circle cx="10" cy="10" r="10" fill="#22c55e"/>
            <path d="M6 10L9 13L14 7" stroke="white" stroke-width="2" stroke-linecap="round"/>
          </svg>
          Slots Available Now!
        </div>
        <p>Activation slots are available on a first-come, first-served basis. Each slot is valid for 24 hours.</p>
        <a href="#activate" class="sec-activate-btn">Activate Your Platform — $29/mo</a>
      </div>
    `;
  }

  /**
   * Render waitlist signup form
   */
  function renderWaitlistForm() {
    return `
      <div class="sec-slots-waitlist">
        <div class="sec-waitlist-badge">
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <circle cx="10" cy="10" r="10" fill="#f59e0b"/>
            <text x="10" y="14" text-anchor="middle" fill="white" font-size="12" font-weight="bold">!</text>
          </svg>
          All Slots Currently Taken
        </div>
        <p><strong>Join the waitlist</strong> and we'll email you the moment a slot opens up.</p>

        <form id="sec-waitlist-form" class="sec-waitlist-form">
          <div class="sec-form-group">
            <input type="text" id="waitlist-name" placeholder="Your Name (optional)" class="sec-input">
          </div>
          <div class="sec-form-group">
            <input type="email" id="waitlist-email" placeholder="Your Email Address" required class="sec-input">
          </div>
          <button type="submit" class="sec-waitlist-btn">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style="margin-right: 8px;">
              <path d="M8 1L8 15M1 8L15 8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            </svg>
            Join Waitlist
          </button>
        </form>

        <div id="sec-waitlist-message" class="sec-waitlist-message" style="display: none;"></div>
      </div>
    `;
  }

  /**
   * Attach event listeners
   */
  function attachEventListeners() {
    $('#sec-waitlist-form').on('submit', function(e) {
      e.preventDefault();
      submitWaitlistForm();
    });
  }

  /**
   * Submit waitlist form
   */
  function submitWaitlistForm() {
    const name = $('#waitlist-name').val().trim();
    const email = $('#waitlist-email').val().trim();
    const $btn = $('#sec-waitlist-form button[type="submit"]');
    const $message = $('#sec-waitlist-message');

    if (!email) {
      showMessage('Please enter your email address.', 'error');
      return;
    }

    $btn.prop('disabled', true).html(
      '<div class="sec-spinner-small"></div> Joining...'
    );

    $.ajax({
      url: config.rest_url + 'waitlist',
      method: 'POST',
      data: JSON.stringify({
        name: name,
        email: email,
        nonce: config.nonce
      }),
      contentType: 'application/json',
      success: function(response) {
        if (response.reload) {
          showMessage(response.message, 'success');
          setTimeout(loadSlotStatus, 2000);
        } else {
          showMessage(response.message, 'success');
          $('#sec-waitlist-form').hide();
        }
      },
      error: function(xhr) {
        const error = xhr.responseJSON?.message || 'Failed to join waitlist. Please try again.';
        showMessage(error, 'error');
        $btn.prop('disabled', false).html(
          '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" style="margin-right: 8px;"><path d="M8 1L8 15M1 8L15 8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg> Join Waitlist'
        );
      }
    });
  }

  /**
   * Show message
   */
  function showMessage(message, type) {
    const $message = $('#sec-waitlist-message');
    $message
      .removeClass('sec-message-success sec-message-error')
      .addClass('sec-message-' + type)
      .html(message)
      .fadeIn();
  }

  /**
   * Auto-refresh every 60 seconds
   */
  function startAutoRefresh() {
    refreshInterval = setInterval(loadSlotStatus, 60000);
  }

  /**
   * Initialize
   */
  $(document).ready(function() {
    if ($('#sec-slots-widget').length) {
      loadSlotStatus();
      startAutoRefresh();
    }
  });

})(jQuery);
