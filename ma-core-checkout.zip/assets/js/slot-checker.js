/**
 * Slot Availability Checker
 * Checks if activation slots are available and shows waitlist overlay if full
 */

(function($) {
  'use strict';

  const config = window.secSlots || {};

  /**
   * Check slot availability and show overlay if needed
   */
  function checkSlotAvailability() {
    $.ajax({
      url: config.restUrl + 'slots',
      method: 'GET',
      success: function(response) {
        if (response.available === 0) {
          showWaitlistOverlay();
        }
      },
      error: function() {
        // If API fails, let the form work normally
        console.log('Slot check failed, allowing form to work normally');
      }
    });
  }

  /**
   * Show waitlist overlay on top of the form
   */
  function showWaitlistOverlay() {
    const $container = $('.sec-form-container');

    // Add class to blur the form
    $container.addClass('slots-full');

    // Create overlay HTML
    const overlayHTML = `
      <div class="sec-slot-waitlist-overlay">
        <div class="sec-slot-waitlist-icon">⏳</div>
        <h4>All slots taken — join the waitlist</h4>
        <p>Get notified the moment a slot opens up</p>

        <form id="sec-slot-waitlist-form" class="sec-slot-waitlist-form">
          <input
            type="email"
            id="sec-slot-waitlist-email"
            placeholder="Enter your email address"
            required
            class="sec-slot-waitlist-input"
          >
          <button type="submit" class="sec-slot-waitlist-btn">
            Notify Me
          </button>
        </form>

        <div id="sec-slot-waitlist-message" class="sec-slot-waitlist-message" style="display: none;"></div>
      </div>
    `;

    // Append overlay to container
    $container.append(overlayHTML);

    // Attach form submit handler
    $('#sec-slot-waitlist-form').on('submit', function(e) {
      e.preventDefault();
      submitWaitlist();
    });
  }

  /**
   * Submit email to waitlist
   */
  function submitWaitlist() {
    const email = $('#sec-slot-waitlist-email').val().trim();
    const $btn = $('#sec-slot-waitlist-form button[type="submit"]');
    const $message = $('#sec-slot-waitlist-message');

    if (!email) {
      showMessage('Please enter your email address.', 'error');
      return;
    }

    $btn.prop('disabled', true).html(
      '<span class="sec-slot-spinner"></span> Notifying...'
    );

    $.ajax({
      url: config.restUrl + 'waitlist',
      method: 'POST',
      data: JSON.stringify({
        name: '',
        email: email,
        nonce: config.waitlistNonce
      }),
      contentType: 'application/json',
      success: function(response) {
        showMessage('✅ You\'re on the list! We\'ll email you when a slot opens.', 'success');
        $('#sec-slot-waitlist-email').val('');
        $btn.prop('disabled', true).html('✓ Joined Waitlist');
      },
      error: function(xhr) {
        const error = xhr.responseJSON?.message || 'Failed to join waitlist. Please try again.';
        showMessage(error, 'error');
        $btn.prop('disabled', false).html('Notify Me');
      }
    });
  }

  /**
   * Show message to user
   */
  function showMessage(message, type) {
    const $message = $('#sec-slot-waitlist-message');
    $message
      .removeClass('sec-slot-message-success sec-slot-message-error')
      .addClass('sec-slot-message-' + type)
      .html(message)
      .fadeIn();
  }

  /**
   * Initialize on page load
   */
  $(document).ready(function() {
    // Only run if the checkout form exists
    if ($('.sec-form-container').length) {
      checkSlotAvailability();
    }
  });

})(jQuery);
