jQuery(document).ready(function($) {
    'use strict';

    // Upload logo using WordPress media library
    $('.sec-upload-logo').on('click', function(e) {
        e.preventDefault();

        var mediaUploader = wp.media({
            title: 'Upload Company Logo',
            button: {
                text: 'Use this logo'
            },
            multiple: false,
            library: {
                type: 'image'
            }
        });

        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();

            $('#sec_logo_url').val(attachment.url);

            $('.sec-logo-placeholder').remove();
            $('.sec-logo-preview').remove();

            var preview = `
                <div class="sec-logo-preview">
                    <img src="${attachment.url}" alt="Company Logo">
                    <button type="button" class="button sec-remove-logo">Remove Logo</button>
                </div>
            `;

            $('.sec-logo-upload-area').prepend(preview);
            $('.sec-upload-logo').text('Change Logo');
        });

        mediaUploader.open();
    });

    // Remove logo
    $(document).on('click', '.sec-remove-logo', function(e) {
        e.preventDefault();

        if (!confirm('Are you sure you want to remove the logo?')) {
            return;
        }

        $('#sec_logo_url').val('');
        $('.sec-logo-preview').remove();

        var placeholder = `
            <div class="sec-logo-placeholder">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                    <circle cx="8.5" cy="8.5" r="1.5"/>
                    <polyline points="21 15 16 10 5 21"/>
                </svg>
                <p>No logo uploaded</p>
            </div>
        `;

        $('.sec-logo-upload-area').prepend(placeholder);
        $('.sec-upload-logo').text('Upload Logo');
    });

    // Email preview functionality
    $('.sec-preview-receipt, .sec-preview-survey, .sec-preview-completion, .sec-preview-reminder').on('click', function(e) {
        e.preventDefault();

        var type = '';
        var subject = '';
        var body = '';

        if ($(this).hasClass('sec-preview-receipt')) {
            type = 'receipt';
            subject = $('#sec_receipt_email_subject').val();
            body = $('#sec_receipt_email_body').val();
        } else if ($(this).hasClass('sec-preview-survey')) {
            type = 'survey';
            subject = $('#sec_survey_email_subject').val();
            body = $('#sec_survey_email_body').val();
        } else if ($(this).hasClass('sec-preview-reminder')) {
            type = 'reminder';
            subject = $('#sec_reminder_email_subject').val();
            body = $('#sec_reminder_email_body').val();
        } else {
            type = 'completion';
            subject = $('#sec_completion_email_subject').val();
            body = $('#sec_completion_email_body').val();
        }

        // Replace placeholders with example data
        var sampleData = {
            '{{customer_name}}': 'John Doe',
            '{{customer_email}}': 'john@example.com',
            '{{business_name}}': 'Bloom Wellness Studio',
            '{{amount}}': '$199.00',
            '{{date}}': new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
            '{{survey_link}}': 'https://yoursite.com/launch-survey?token=abc123',
            '{{submitted_at}}': new Date().toLocaleString('en-US', { month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }),
            '{{current_step}}': '5',
            '{{total_steps}}': '11',
            '{{progress_percent}}': '45',
            '{{cta_button:Continue Survey →}}': '[STYLED BUTTON: Continue Survey →]',
            '{{cta_button:Complete My Survey →}}': '[STYLED BUTTON: Complete My Survey →]',
            '{{cta_button}}': '[STYLED BUTTON: Continue →]'
        };

        Object.keys(sampleData).forEach(function(placeholder) {
            subject = subject.split(placeholder).join(sampleData[placeholder]);
            body = body.split(placeholder).join(sampleData[placeholder]);
        });

        // Create preview modal
        var modal = `
            <div class="sec-email-preview-modal">
                <div class="sec-email-preview-content">
                    <div class="sec-email-preview-header">
                        <h3>Email Preview</h3>
                        <button class="sec-close-preview">&times;</button>
                    </div>
                    <div class="sec-email-preview-body">
                        <div class="sec-email-field">
                            <strong>Subject:</strong> ${subject}
                        </div>
                        <div class="sec-email-field">
                            <strong>Body:</strong>
                            <pre>${body}</pre>
                        </div>
                    </div>
                </div>
            </div>
        `;

        $('body').append(modal);

        // Inject preview styles if not already present
        if (!$('#sec-preview-styles').length) {
            var styles = `
                <style id="sec-preview-styles">
                .sec-email-preview-modal {
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: rgba(0, 0, 0, 0.7);
                    z-index: 100000;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    padding: 20px;
                }
                .sec-email-preview-content {
                    background: white;
                    border-radius: 8px;
                    max-width: 700px;
                    width: 100%;
                    max-height: 80vh;
                    overflow: hidden;
                    display: flex;
                    flex-direction: column;
                }
                .sec-email-preview-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 1.5rem;
                    border-bottom: 1px solid #ddd;
                }
                .sec-email-preview-header h3 {
                    margin: 0;
                    color: #2536EB;
                }
                .sec-close-preview {
                    background: none;
                    border: none;
                    font-size: 2rem;
                    cursor: pointer;
                    color: #999;
                    padding: 0;
                    width: 32px;
                    height: 32px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    border-radius: 4px;
                }
                .sec-close-preview:hover {
                    background: #f0f0f0;
                    color: #333;
                }
                .sec-email-preview-body {
                    padding: 1.5rem;
                    overflow-y: auto;
                }
                .sec-email-field {
                    margin-bottom: 1.5rem;
                }
                .sec-email-field strong {
                    display: block;
                    margin-bottom: 0.5rem;
                    color: #666;
                }
                .sec-email-field pre {
                    background: #f5f5f5;
                    padding: 1rem;
                    border-radius: 4px;
                    border: 1px solid #ddd;
                    white-space: pre-wrap;
                    word-wrap: break-word;
                    font-family: 'Courier New', Courier, monospace;
                    font-size: 0.9rem;
                    line-height: 1.6;
                }
                </style>
            `;
            $('head').append(styles);
        }
    });

    // Close preview modal
    $(document).on('click', '.sec-close-preview, .sec-email-preview-modal', function(e) {
        if (e.target === this) {
            $('.sec-email-preview-modal').remove();
        }
    });

    function sendTestEmail(type, $btn, done) {
        var $status = $('#sec_test_receipt_status');
        var email = ($('#sec_test_receipt_email').val() || '').trim();
        if (!email) {
            $status.css('color', '#b42318').text('Enter an email address.');
            if (done) done(false);
            return;
        }

        var original = $btn ? $btn.text() : '';
        if ($btn) {
            $btn.prop('disabled', true).text('Sending...');
        }
        $status.css('color', '#475467').text('Sending ' + type.replace('_', ' ') + ' test email...');

        $.post(secBrandingData.ajax_url, {
            action: 'sec_send_test_email',
            nonce: secBrandingData.nonce,
            email: email,
            type: type
        }).done(function(response) {
            if (response && response.success) {
                $status.css('color', '#067647').text(response.data && response.data.message ? response.data.message : 'Sent.');
                if (done) done(true);
            } else {
                var msg = response && response.data && response.data.message ? response.data.message : 'Failed to send.';
                $status.css('color', '#b42318').text(msg);
                if (done) done(false);
            }
        }).fail(function() {
            $status.css('color', '#b42318').text('Request failed. Please try again.');
            if (done) done(false);
        }).always(function() {
            if ($btn) {
                $btn.prop('disabled', false).text(original);
            }
        });
    }

    $('.sec-send-test-email').on('click', function(e) {
        e.preventDefault();
        var type = ($(this).data('type') || '').toString();
        if (!type) return;
        sendTestEmail(type, $(this));
    });

    $('.sec-send-test-all').on('click', function(e) {
        e.preventDefault();
        var $btn = $(this);
        var $status = $('#sec_test_receipt_status');
        var sequence = ['receipt', 'survey', 'completion', 'reminder_early', 'reminder_mid', 'reminder_final'];
        var index = 0;
        var original = $btn.text();

        $btn.prop('disabled', true).text('Sending All...');
        $status.css('color', '#475467').text('Sending all test emails...');

        function next() {
            if (index >= sequence.length) {
                $status.css('color', '#067647').text('All test emails sent.');
                $btn.prop('disabled', false).text(original);
                return;
            }

            var type = sequence[index++];
            sendTestEmail(type, null, function(ok) {
                if (!ok) {
                    $btn.prop('disabled', false).text(original);
                    return;
                }
                setTimeout(next, 150);
            });
        }

        next();
    });
});
