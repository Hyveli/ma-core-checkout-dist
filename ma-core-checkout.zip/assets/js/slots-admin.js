/**
 * Activation Slots Admin JavaScript
 */

(function($) {
  'use strict';

  const config = window.secSlotsAdmin || {};

  /**
   * Show message to user
   */
  function showMessage(message, type = 'success') {
    const $msg = $('#sec-message');
    $msg.removeClass('sec-message-success sec-message-error sec-message-info')
        .addClass('sec-message-' + type)
        .html(message)
        .fadeIn()
        .delay(5000)
        .fadeOut();
  }

  /**
   * Refresh page data
   */
  function refreshPage() {
    window.location.reload();
  }

  /**
   * Free slots
   */
  $('#free-slots-form').on('submit', function(e) {
    e.preventDefault();

    const count = parseInt($('#free-count').val());
    const $btn = $(this).find('button[type="submit"]');

    if (count <= 0) {
      showMessage('Please enter a valid number.', 'error');
      return;
    }

    if (!confirm(`Are you sure you want to free ${count} slot(s)?\n\nThis will notify ${count} people from the waitlist.`)) {
      return;
    }

    $btn.prop('disabled', true).text('🔄 Freeing...');

    $.ajax({
      url: config.rest_url + 'slots/free',
      method: 'POST',
      data: JSON.stringify({
        count: count,
        nonce: config.nonce
      }),
      contentType: 'application/json',
      success: function(response) {
        showMessage(response.message, 'success');
        setTimeout(refreshPage, 1500);
      },
      error: function(xhr) {
        const error = xhr.responseJSON?.message || 'Failed to free slots.';
        showMessage('Error: ' + error, 'error');
        $btn.prop('disabled', false).text('🔓 Free Slots');
      }
    });
  });

  /**
   * Reserve slots
   */
  $('#reserve-slots-form').on('submit', function(e) {
    e.preventDefault();

    const count = parseInt($('#reserve-count').val());
    const $btn = $(this).find('button[type="submit"]');

    if (count <= 0) {
      showMessage('Please enter a valid number.', 'error');
      return;
    }

    if (!confirm(`Reserve ${count} slot(s) for 24 hours?`)) {
      return;
    }

    $btn.prop('disabled', true).text('🔄 Reserving...');

    $.ajax({
      url: config.ajax_url,
      method: 'POST',
      data: {
        action: 'sec_reserve_slots_manual',
        count: count,
        nonce: config.nonce
      },
      success: function(response) {
        if (response.success) {
          showMessage('Successfully reserved ' + count + ' slot(s) for 24 hours.', 'success');
          setTimeout(refreshPage, 1500);
        } else {
          showMessage('Error: ' + (response.data?.message || 'Failed to reserve slots.'), 'error');
          $btn.prop('disabled', false).text('🔒 Reserve Slots');
        }
      },
      error: function() {
        showMessage('Error: Failed to reserve slots.', 'error');
        $btn.prop('disabled', false).text('🔒 Reserve Slots');
      }
    });
  });

  /**
   * Refresh status
   */
  $('#refresh-status').on('click', function() {
    const $btn = $(this);
    $btn.prop('disabled', true).text('🔄 Refreshing...');
    showMessage('Checking for expired slots...', 'info');
    setTimeout(refreshPage, 1000);
  });

  /**
   * Update timers every minute
   */
  function updateTimers() {
    $('.sec-slot-timer').each(function() {
      const $slot = $(this).closest('.sec-slot');
      const index = $slot.data('index');
      // Timer will be updated on page refresh
    });
  }

  // Update timers every 60 seconds
  setInterval(updateTimers, 60000);

})(jQuery);
