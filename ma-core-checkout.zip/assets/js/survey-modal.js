/**
 * Survey Modal - Website Launch Questionnaire
 * Blue Theme - Vanilla JavaScript Implementation
 *
 * Handles 11-step survey with validation, file uploads, and AJAX submission
 */

(function() {
  'use strict';

  // ============================================================================
  // CONSTANTS & CONFIGURATION
  // ============================================================================

  const INDUSTRIES = [
    "Beauty & Wellness",
    "Real Estate",
    "Legal Services",
    "Health & Medical",
    "Finance & Accounting",
    "Fitness & Personal Training",
    "Coaching & Consulting",
    "Photography",
    "Food & Beverage",
    "E-Commerce",
    "Construction & Trades",
    "Education & Tutoring",
    "Technology",
    "Non-Profit",
    "Other"
  ];

  const INDUSTRY_SERVICES = {
    "Beauty & Wellness": "1. Haircut – $45\n2. Color Treatment – $120\n3. Balayage – from $180",
    "Real Estate": "1. Buyer Representation – Free\n2. Listing & Selling – 2.5% commission\n3. Market Analysis – $150",
    "Legal Services": "1. Initial Consultation – $200\n2. Contract Review – from $350\n3. Full Representation – contact for pricing",
    "Health & Medical": "1. New Patient Exam – $150\n2. Follow-Up Visit – $85\n3. Telehealth Appointment – $65",
    "Finance & Accounting": "1. Financial Consultation – $200\n2. Tax Preparation – from $300\n3. Bookkeeping (monthly) – from $250",
    "Fitness & Personal Training": "1. 1-on-1 Personal Training – $80/session\n2. Group Fitness Class – $25\n3. Monthly Coaching Program – $350",
    "Coaching & Consulting": "1. Discovery Call – Free\n2. 1-Hour Strategy Session – $175\n3. 3-Month Coaching Package – $1,200",
    "Photography": "1. Portrait Session – $250\n2. Wedding Photography – from $2,500\n3. Brand & Headshot Session – $400",
    "Food & Beverage": "1. Catering (per person) – from $35\n2. Private Chef Experience – $500\n3. Meal Prep Package (weekly) – $180",
    "E-Commerce": "1. Product A – $XX\n2. Product B – $XX\n3. Bundle / Subscription – $XX/mo",
    "Construction & Trades": "1. Free Estimate – No charge\n2. Kitchen Remodel – from $8,000\n3. Bathroom Renovation – from $4,500",
    "Education & Tutoring": "1. 1-on-1 Tutoring (1hr) – $60\n2. Group Study Session – $25\n3. Monthly Learning Plan – $220",
    "Technology": "1. IT Support (hourly) – $95\n2. Website Development – from $1,500\n3. Monthly Maintenance – $150/mo",
    "Non-Profit": "1. Volunteer Program – Free\n2. Community Workshop – Donation-based\n3. Annual Membership – $50/yr",
    "Other": "1. Service Name – Price\n2. Service Name – Price\n3. Service Name – Price"
  };

  const INDUSTRY_TAGLINES = {
    "Beauty & Wellness": "e.g. We help clients feel confident through personalized beauty treatments.",
    "Real Estate": "e.g. We help first-time homebuyers find their perfect home.",
    "Legal Services": "e.g. We protect small businesses with affordable legal counsel.",
    "Health & Medical": "e.g. We provide compassionate care for families in our community.",
    "Finance & Accounting": "e.g. We help small business owners master their finances.",
    "Fitness & Personal Training": "e.g. We transform lives through personalized fitness coaching.",
    "Coaching & Consulting": "e.g. We help professionals achieve their career goals.",
    "Photography": "e.g. We capture life's special moments with timeless photography.",
    "Food & Beverage": "e.g. We bring restaurant-quality meals to your table.",
    "E-Commerce": "e.g. We deliver quality products right to your door.",
    "Construction & Trades": "e.g. We build dream homes with expert craftsmanship.",
    "Education & Tutoring": "e.g. We help students reach their academic potential.",
    "Technology": "e.g. We keep businesses running with reliable IT support.",
    "Non-Profit": "e.g. We empower communities through education and outreach.",
    "Other": "e.g. We help clients solve their problems with expert service."
  };

  const SOCIAL_PLATFORMS = [
    { label: "Facebook", icon: "📘", placeholder: "facebook.com/yourbusiness" },
    { label: "Instagram", icon: "📸", placeholder: "instagram.com/yourbusiness" },
    { label: "LinkedIn", icon: "💼", placeholder: "linkedin.com/in/yourbusiness" },
    { label: "TikTok", icon: "🎵", placeholder: "tiktok.com/@yourbusiness" },
    { label: "X / Twitter", icon: "🐦", placeholder: "x.com/yourbusiness" },
    { label: "YouTube", icon: "▶️", placeholder: "youtube.com/@yourbusiness" },
    { label: "Pinterest", icon: "📌", placeholder: "pinterest.com/yourbusiness" },
    { label: "Other", icon: "🔗", placeholder: "Paste your link here" }
  ];

  const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  const STEPS = [
    {
      id: 1,
      field: "businessName",
      label: "Thank you for your payment! What's your business called?",
      hint: "Exactly as you'd like it displayed on your website.",
      type: "text",
      required: true
    },
    {
      id: 2,
      field: "industry",
      label: "What industry are you in?",
      hint: "Pick the closest match — this helps us tailor your design.",
      type: "select",
      required: true
    },
    {
      id: 3,
      field: "tagline",
      label: "Describe what your business does in one sentence.",
      hint: "Who do you help and how? Keep it simple and clear.",
      type: "text",
      required: true,
      placeholder: "" // Will be set dynamically based on industry
    },
    {
      id: 4,
      field: "services",
      label: "What are your top 3 services or offerings?",
      hint: "Include a price if you'd like it shown. Keep each one brief.",
      type: "textarea",
      required: true
    },
    {
      id: 5,
      field: "hours",
      label: "What are your business hours?",
      hint: "Toggle any day you're not open.",
      type: "hours",
      required: false
    },
    {
      id: 6,
      field: "booking",
      label: "How will clients meet with you?",
      hint: "Select all that apply — your calendar will be configured to match.",
      type: "multicheck",
      required: true,
      options: [
        { label: "Virtually (video or phone call)", value: "virtual" },
        { label: "At my location (client comes to me)", value: "our_location" },
        { label: "At the client's location (I go to them)", value: "client_location" }
      ]
    },
    {
      id: 7,
      field: "contact",
      label: "How can clients contact you?",
      hint: "Only share what you're comfortable displaying publicly.",
      type: "contact",
      required: true
    },
    {
      id: 8,
      field: "socials",
      label: "Add your social media pages.",
      hint: "Click a platform to add it. Add as many as you'd like.",
      type: "socials",
      required: false
    },
    {
      id: 9,
      field: "brand",
      label: "Do you have a logo or brand colors?",
      hint: "No worries if not — we'll take care of it.",
      type: "brandcheck",
      required: false
    },
    {
      id: 10,
      field: "files",
      label: "Upload any photos or files for your website.",
      hint: "Team photos, product shots — anything that represents your brand.",
      type: "upload",
      required: false
    },
    {
      id: 11,
      field: "extra",
      label: "Anything else you'd like us to know?",
      hint: "Awards, certifications, a must-have page — or leave it blank and hit submit.",
      type: "textarea",
      required: false,
      placeholder: "Optional…"
    }
  ];

  // File upload settings
  const MAX_FILE_SIZE = 35 * 1024 * 1024; // 35MB
  const ALLOWED_MIME_TYPES = [
    'image/jpeg',
    'image/png',
    'image/jpg',
    'image/webp',
    'image/svg+xml',
    'application/pdf'
  ];

  // ============================================================================
  // STATE MANAGEMENT
  // ============================================================================

  const state = {
    currentStep: 0,
    touched: {},
    answers: {
      businessName: '',
      industry: '',
      customIndustry: '',
      tagline: '',
      services: '',
      hours: defaultHours(),
      booking: [],
      contact: { phone: '', email: '', address: '' },
      socials: [],
      brand: [],
      brandColors: '',
      brandSlogan: '',
      logoFile: null,
      files: [],
      extra: ''
    },
    sessionData: window.secSurveyData || {} // Data from PHP
  };

  function defaultHours() {
    const hours = {};
    DAYS.forEach(day => {
      hours[day] = { open: '09:00', close: '17:00', closed: false };
    });
    return hours;
  }

  // ============================================================================
  // VALIDATION
  // ============================================================================

  function validatePhone(value) {
    return /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/.test(value.replace(/\s/g, ''));
  }

  function validateEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function isStepValid() {
    const step = STEPS[state.currentStep];
    const answers = state.answers;

    if (!step.required) return true;

    switch (step.field) {
      case 'businessName':
        return answers.businessName.trim().length > 0;

      case 'industry':
        return answers.industry && (answers.industry !== 'Other' || answers.customIndustry.trim().length > 0);

      case 'tagline':
        return answers.tagline.trim().length > 0;

      case 'services':
        return answers.services.trim().length > 0;

      case 'booking':
        return answers.booking.length > 0;

      case 'contact':
        const phone = answers.contact.phone.trim();
        const email = answers.contact.email.trim();
        const hasAtLeastOne = phone || email;
        const phoneValid = !phone || validatePhone(phone);
        const emailValid = !email || validateEmail(email);
        return hasAtLeastOne && phoneValid && emailValid;

      default:
        return true;
    }
  }

  function validateFile(file) {
    if (file.size > MAX_FILE_SIZE) {
      return { valid: false, error: `File "${file.name}" exceeds 35MB limit` };
    }

    if (!ALLOWED_MIME_TYPES.includes(file.type)) {
      return { valid: false, error: `File type not supported for "${file.name}"` };
    }

    return { valid: true };
  }

  // ============================================================================
  // MODAL MANAGEMENT
  // ============================================================================

  function openModal() {
    const overlay = document.getElementById('sec-survey-modal-overlay');
    if (overlay) {
      overlay.style.display = 'flex';
      document.body.style.overflow = 'hidden';
      render();
    }
  }

  function closeModal() {
    const overlay = document.getElementById('sec-survey-modal-overlay');
    if (overlay) {
      overlay.style.display = 'none';
      document.body.style.overflow = '';
    }
  }

  // ============================================================================
  // NAVIGATION
  // ============================================================================

  function goToStep(direction) {
    if (direction === 1 && state.currentStep === STEPS.length - 1) {
      submitSurvey();
      return;
    }

    state.currentStep += direction;
    state.touched = {};
    render();
  }

  function updateFooter() {
    const step = STEPS[state.currentStep];
    const backBtn = document.getElementById('survey-back-btn');
    const continueBtn = document.getElementById('survey-continue-btn');
    const stepCount = document.getElementById('survey-step-count');
    const progress = document.getElementById('survey-progress-fill');
    const optionalHint = document.getElementById('survey-optional-hint');

    if (backBtn) {
      backBtn.style.display = state.currentStep > 0 ? '' : 'none';
    }

    if (continueBtn) {
      continueBtn.disabled = !isStepValid();
      continueBtn.textContent = state.currentStep === STEPS.length - 1 ? 'Submit & Launch 🚀' : 'Continue →';
    }

    if (stepCount) {
      stepCount.textContent = `${state.currentStep + 1} of ${STEPS.length}`;
    }

    if (progress) {
      progress.style.width = `${((state.currentStep + 1) / STEPS.length) * 100}%`;
    }

    if (optionalHint) {
      optionalHint.textContent = !step.required ? 'This step is optional — feel free to skip' : '';
    }
  }

  // ============================================================================
  // RENDERING
  // ============================================================================

  function render() {
    const step = STEPS[state.currentStep];
    const body = document.getElementById('survey-body');

    if (!body) return;

    // Clear body
    body.innerHTML = `
      <h2 class="survey-question">${step.label}</h2>
      <p class="survey-hint">${step.hint}</p>
    `;

    // Render step content based on type
    switch (step.type) {
      case 'text':
        renderTextInput(body, step);
        break;
      case 'textarea':
        renderTextarea(body, step);
        break;
      case 'select':
        renderIndustrySelect(body);
        break;
      case 'hours':
        renderHours(body);
        break;
      case 'multicheck':
        renderMulticheck(body, step);
        break;
      case 'contact':
        renderContact(body);
        break;
      case 'socials':
        renderSocials(body);
        break;
      case 'brandcheck':
        renderBrandCheck(body);
        break;
      case 'upload':
        renderUpload(body);
        break;
    }

    updateFooter();
  }

  // ============================================================================
  // STEP RENDERERS
  // ============================================================================

  function renderTextInput(container, step) {
    const input = document.createElement('input');
    input.className = 'survey-input';

    // Set dynamic placeholder for tagline based on industry
    if (step.field === 'tagline' && state.answers.industry) {
      const industry = state.answers.industry === 'Other' ? state.answers.customIndustry : state.answers.industry;
      input.placeholder = INDUSTRY_TAGLINES[state.answers.industry] || INDUSTRY_TAGLINES['Other'];
    } else {
      input.placeholder = step.placeholder || '';
    }

    input.value = state.answers[step.field];

    input.addEventListener('input', (e) => {
      state.answers[step.field] = e.target.value;
      updateFooter();
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && isStepValid()) {
        goToStep(1);
      }
    });

    container.appendChild(input);
    setTimeout(() => input.focus(), 50);
  }

  function renderTextarea(container, step) {
    const textarea = document.createElement('textarea');
    textarea.className = 'survey-input';
    textarea.rows = 4;

    if (step.field === 'services') {
      textarea.placeholder = INDUSTRY_SERVICES[state.answers.industry] || INDUSTRY_SERVICES['Other'];
    } else {
      textarea.placeholder = step.placeholder || '';
    }

    textarea.value = state.answers[step.field];

    textarea.addEventListener('input', (e) => {
      state.answers[step.field] = e.target.value;
      updateFooter();
    });

    container.appendChild(textarea);
    setTimeout(() => textarea.focus(), 50);
  }

  function renderIndustrySelect(container) {
    const grid = document.createElement('div');
    grid.className = 'survey-pill-grid';

    INDUSTRIES.forEach(industry => {
      const button = document.createElement('button');
      button.className = 'survey-pill' + (state.answers.industry === industry ? ' active' : '');
      button.textContent = industry;
      button.type = 'button';

      button.addEventListener('click', () => {
        state.answers.industry = industry;
        state.answers.customIndustry = '';

        // Update all pills
        container.querySelectorAll('.survey-pill').forEach(btn => {
          btn.classList.remove('active');
        });
        button.classList.add('active');

        // Handle "Other" custom input
        const customInput = document.getElementById('survey-custom-industry');
        if (industry === 'Other') {
          if (!customInput) {
            const input = document.createElement('input');
            input.id = 'survey-custom-industry';
            input.className = 'survey-input';
            input.style.marginTop = '0.75rem';
            input.placeholder = 'Type your industry…';
            input.addEventListener('input', (e) => {
              state.answers.customIndustry = e.target.value;
              updateFooter();
            });
            grid.after(input);
            setTimeout(() => input.focus(), 50);
          }
        } else {
          if (customInput) {
            customInput.remove();
          }
        }

        updateFooter();
      });

      grid.appendChild(button);
    });

    container.appendChild(grid);

    // Restore custom input if "Other" was selected
    if (state.answers.industry === 'Other') {
      const input = document.createElement('input');
      input.id = 'survey-custom-industry';
      input.className = 'survey-input';
      input.style.marginTop = '0.75rem';
      input.placeholder = 'Type your industry…';
      input.value = state.answers.customIndustry;
      input.addEventListener('input', (e) => {
        state.answers.customIndustry = e.target.value;
        updateFooter();
      });
      container.appendChild(input);
    }
  }

  function renderHours(container) {
    DAYS.forEach(day => {
      const row = document.createElement('div');
      row.className = 'survey-hours-row';

      const label = document.createElement('span');
      label.className = 'survey-day-label';
      label.textContent = day;
      row.appendChild(label);

      const dayHours = state.answers.hours[day];

      if (dayHours.closed) {
        const closedText = document.createElement('span');
        closedText.className = 'survey-closed-text';
        closedText.textContent = 'Closed';
        row.appendChild(closedText);
      } else {
        // Create time display buttons instead of input fields
        ['open', 'close'].forEach(timeType => {
          const timeBtn = document.createElement('button');
          timeBtn.type = 'button';
          timeBtn.className = 'survey-time-btn';
          timeBtn.textContent = formatTime(dayHours[timeType]);

          timeBtn.addEventListener('click', () => {
            showTimePicker(day, timeType, dayHours[timeType], (newTime) => {
              state.answers.hours[day][timeType] = newTime;
              render();
            });
          });

          row.appendChild(timeBtn);
        });
      }

      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'survey-close-day-btn' + (dayHours.closed ? ' closed' : '');
      closeBtn.textContent = dayHours.closed ? 'Closed' : 'Close';
      closeBtn.addEventListener('click', () => {
        state.answers.hours[day].closed = !state.answers.hours[day].closed;
        render();
      });
      row.appendChild(closeBtn);

      container.appendChild(row);
    });
  }

  // Helper function to format time for display
  function formatTime(time24) {
    const [hours, minutes] = time24.split(':');
    const h = parseInt(hours);
    const period = h >= 12 ? 'PM' : 'AM';
    const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
    return `${h12}:${minutes} ${period}`;
  }

  // Show Apple-style time picker
  function showTimePicker(day, timeType, currentTime, onSelect) {
    const [hours, minutes] = currentTime.split(':');
    let selectedHour = parseInt(hours);
    let selectedMinute = parseInt(minutes);

    const modal = document.getElementById('sec-survey-modal');
    const originalContent = modal.innerHTML;

    modal.innerHTML = `
      <div class="survey-card">
        <div class="survey-header" style="background: linear-gradient(135deg, var(--survey-primary), var(--survey-secondary)); padding: 1.5rem;">
          <h3 style="color: white; margin: 0; font-size: 1.125rem;">${day} - ${timeType === 'open' ? 'Opening' : 'Closing'} Time</h3>
        </div>
        <div class="survey-body" style="padding: 2rem;">
          <div class="time-picker-container">
            <div class="time-picker-wheels">
              <div class="time-wheel" id="hour-wheel">
                ${Array.from({length: 24}, (_, i) => `
                  <div class="time-option ${i === selectedHour ? 'selected' : ''}" data-value="${i}">
                    ${i.toString().padStart(2, '0')}
                  </div>
                `).join('')}
              </div>
              <div class="time-separator">:</div>
              <div class="time-wheel" id="minute-wheel">
                ${Array.from({length: 12}, (_, i) => i * 5).map(m => `
                  <div class="time-option ${m === selectedMinute ? 'selected' : ''}" data-value="${m}">
                    ${m.toString().padStart(2, '0')}
                  </div>
                `).join('')}
              </div>
            </div>
            <div class="time-picker-preview">${formatTime(`${selectedHour.toString().padStart(2, '0')}:${selectedMinute.toString().padStart(2, '0')}`)}</div>
          </div>
        </div>
        <div class="survey-footer" style="display: flex; gap: 1rem;">
          <button type="button" class="survey-back" id="cancel-time">Cancel</button>
          <button type="button" class="survey-btn-primary" id="confirm-time">Set Time</button>
        </div>
      </div>
    `;

    // Scroll selected options into view
    setTimeout(() => {
      const hourWheel = document.getElementById('hour-wheel');
      const minuteWheel = document.getElementById('minute-wheel');
      const selectedHourEl = hourWheel.querySelector('.selected');
      const selectedMinuteEl = minuteWheel.querySelector('.selected');

      if (selectedHourEl) selectedHourEl.scrollIntoView({block: 'center'});
      if (selectedMinuteEl) selectedMinuteEl.scrollIntoView({block: 'center'});
    }, 50);

    // Handle hour selection
    document.querySelectorAll('#hour-wheel .time-option').forEach(opt => {
      opt.addEventListener('click', () => {
        document.querySelectorAll('#hour-wheel .time-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        selectedHour = parseInt(opt.dataset.value);
        document.querySelector('.time-picker-preview').textContent =
          formatTime(`${selectedHour.toString().padStart(2, '0')}:${selectedMinute.toString().padStart(2, '0')}`);
      });
    });

    // Handle minute selection
    document.querySelectorAll('#minute-wheel .time-option').forEach(opt => {
      opt.addEventListener('click', () => {
        document.querySelectorAll('#minute-wheel .time-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');
        selectedMinute = parseInt(opt.dataset.value);
        document.querySelector('.time-picker-preview').textContent =
          formatTime(`${selectedHour.toString().padStart(2, '0')}:${selectedMinute.toString().padStart(2, '0')}`);
      });
    });

    // Cancel button
    document.getElementById('cancel-time').addEventListener('click', () => {
      modal.innerHTML = originalContent;
      // Re-attach event listeners
      document.getElementById('survey-back-btn').addEventListener('click', () => goToStep(-1));
      document.getElementById('survey-continue-btn').addEventListener('click', () => goToStep(1));
      render();
    });

    // Confirm button
    document.getElementById('confirm-time').addEventListener('click', () => {
      const newTime = `${selectedHour.toString().padStart(2, '0')}:${selectedMinute.toString().padStart(2, '0')}`;
      onSelect(newTime);
      modal.innerHTML = originalContent;
      // Re-attach event listeners
      document.getElementById('survey-back-btn').addEventListener('click', () => goToStep(-1));
      document.getElementById('survey-continue-btn').addEventListener('click', () => goToStep(1));
    });
  }

  function renderMulticheck(container, step) {
    step.options.forEach(option => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'survey-check-btn' + (state.answers.booking.includes(option.value) ? ' active' : '');
      button.innerHTML = `
        <span class="survey-checkbox">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3">
            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
          </svg>
        </span>
        ${option.label}
      `;

      button.addEventListener('click', () => {
        if (state.answers.booking.includes(option.value)) {
          state.answers.booking = state.answers.booking.filter(v => v !== option.value);
        } else {
          state.answers.booking.push(option.value);
        }
        button.classList.toggle('active');
        updateFooter();
      });

      container.appendChild(button);
    });
  }

  function renderContact(container) {
    const fields = [
      { key: 'phone', icon: '📞', placeholder: 'Phone number', type: 'tel' },
      { key: 'email', icon: '✉️', placeholder: 'Email address', type: 'email' },
      { key: 'address', icon: '📍', placeholder: 'Business address (optional)', type: 'text' }
    ];

    fields.forEach(({ key, icon, placeholder, type }) => {
      const wrapper = document.createElement('div');
      wrapper.className = 'survey-contact-row';
      wrapper.id = `survey-contact-${key}`;

      if (state.touched[key] && state.answers.contact[key]) {
        if ((key === 'phone' && !validatePhone(state.answers.contact[key])) ||
            (key === 'email' && !validateEmail(state.answers.contact[key]))) {
          wrapper.classList.add('error');
        }
      }

      const iconSpan = document.createElement('span');
      iconSpan.className = 'survey-contact-icon';
      iconSpan.textContent = icon;
      wrapper.appendChild(iconSpan);

      const input = document.createElement('input');
      input.className = 'survey-contact-input';
      input.type = type;
      input.placeholder = placeholder;
      input.value = state.answers.contact[key];

      input.addEventListener('input', (e) => {
        state.answers.contact[key] = e.target.value;
        updateFooter();
      });

      input.addEventListener('blur', () => {
        state.touched[key] = true;
        const row = document.getElementById(`survey-contact-${key}`);
        const existingError = document.getElementById(`survey-error-${key}`);

        const isError = (key === 'phone' && state.answers.contact[key] && !validatePhone(state.answers.contact[key])) ||
                        (key === 'email' && state.answers.contact[key] && !validateEmail(state.answers.contact[key]));

        if (row) {
          row.classList.toggle('error', isError);
        }

        const existingBadge = document.getElementById(`survey-badge-${key}`);
        if (existingBadge) existingBadge.remove();

        if (key !== 'address' && state.answers.contact[key]) {
          const badge = document.createElement('span');
          badge.id = `survey-badge-${key}`;
          badge.className = isError ? 'survey-invalid-badge' : 'survey-valid';
          badge.textContent = isError ? 'Invalid' : '✓';
          wrapper.appendChild(badge);
        }

        if (existingError) existingError.remove();

        if (isError) {
          const errorMsg = document.createElement('p');
          errorMsg.id = `survey-error-${key}`;
          errorMsg.className = 'survey-error-msg';
          errorMsg.textContent = key === 'phone'
            ? 'Please enter a valid phone number.'
            : 'Please enter a valid email address.';
          wrapper.after(errorMsg);
        }

        updateFooter();
      });

      wrapper.appendChild(input);
      container.appendChild(wrapper);
    });
  }

  function renderSocials(container) {
    const renderSocialsList = () => {
      // Clear and re-render
      const existingRows = container.querySelectorAll('.survey-social-row, .survey-chips-label, .survey-chips');
      existingRows.forEach(el => el.remove());

      // Render added socials
      state.answers.socials.forEach((social, index) => {
        const row = document.createElement('div');
        row.className = 'survey-social-row';

        const iconSpan = document.createElement('span');
        iconSpan.style.fontSize = '1rem';
        iconSpan.textContent = social.icon;
        row.appendChild(iconSpan);

        const platform = document.createElement('span');
        platform.className = 'survey-social-platform';
        platform.textContent = social.platform;
        row.appendChild(platform);

        const input = document.createElement('input');
        input.className = 'survey-social-input';
        input.placeholder = social.placeholder;
        input.value = social.value;
        input.addEventListener('input', (e) => {
          state.answers.socials[index].value = e.target.value;
        });
        row.appendChild(input);

        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'survey-remove-btn';
        removeBtn.textContent = '✕';
        removeBtn.addEventListener('click', () => {
          state.answers.socials.splice(index, 1);
          renderSocialsList();
        });
        row.appendChild(removeBtn);

        container.appendChild(row);
      });

      // Render platform chips
      const label = document.createElement('p');
      label.className = 'survey-chips-label';
      label.textContent = state.answers.socials.length === 0 ? 'Select a platform to add' : 'Add another';
      container.appendChild(label);

      const chips = document.createElement('div');
      chips.className = 'survey-chips';

      SOCIAL_PLATFORMS
        .filter(platform => !state.answers.socials.find(s => s.platform === platform.label))
        .forEach(platform => {
          const chip = document.createElement('button');
          chip.type = 'button';
          chip.className = 'survey-chip';
          chip.innerHTML = `${platform.icon} ${platform.label}`;
          chip.addEventListener('click', () => {
            state.answers.socials.push({ ...platform, value: '' });
            renderSocialsList();
            setTimeout(() => {
              const inputs = container.querySelectorAll('.survey-social-input');
              if (inputs.length) inputs[inputs.length - 1].focus();
            }, 50);
          });
          chips.appendChild(chip);
        });

      container.appendChild(chips);
    };

    renderSocialsList();
  }

  function renderBrandCheck(container) {
    const renderBrandOptions = () => {
      // Clear and re-render
      const existingElements = container.querySelectorAll('.survey-check-btn, .survey-logo-drop, .survey-logo-preview, .survey-input');
      existingElements.forEach(el => el.remove());

      const options = [
        { label: 'Yes, I have a logo', value: 'logo' },
        { label: 'I have brand colors', value: 'colors' },
        { label: 'I have a slogan or tagline', value: 'slogan' },
        { label: 'None yet — build it for me', value: 'none' }
      ];

      options.forEach(option => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'survey-check-btn' + (state.answers.brand.includes(option.value) ? ' active' : '');
        button.innerHTML = `
          <span class="survey-checkbox">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3">
              <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
            </svg>
          </span>
          ${option.label}
        `;

        button.addEventListener('click', () => {
          if (state.answers.brand.includes(option.value)) {
            state.answers.brand = state.answers.brand.filter(v => v !== option.value);
          } else {
            state.answers.brand.push(option.value);
          }
          renderBrandOptions();
        });

        container.appendChild(button);
      });

      // Logo uploader
      if (state.answers.brand.includes('logo')) {
        const dropZone = document.createElement('div');
        dropZone.className = 'survey-logo-drop';

        if (state.answers.logoFile) {
          dropZone.innerHTML = `
            <span style="font-size:1.25rem">🖼️</span>
            <div class="survey-logo-info">
              <p style="color:var(--survey-primary)">${state.answers.logoFile.name}</p>
            </div>
            <span class="survey-valid">✓</span>
          `;
        } else {
          dropZone.innerHTML = `
            <span style="font-size:1.25rem">🖼️</span>
            <div class="survey-logo-info">
              <p>Upload your logo</p>
              <span>PNG, SVG, PDF or AI file</span>
            </div>
            <span style="font-size:0.75rem;color:var(--survey-primary);font-weight:700">Browse</span>
          `;
        }

        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'image/*,.pdf,.svg';
        fileInput.style.display = 'none';

        fileInput.addEventListener('change', (e) => {
          const file = e.target.files[0];
          if (!file) return;

          const validation = validateFile(file);
          if (!validation.valid) {
            alert(validation.error);
            return;
          }

          const reader = new FileReader();
          reader.onload = (event) => {
            state.answers.logoFile = {
              name: file.name,
              url: event.target.result,
              type: file.type,
              file: file
            };
            renderBrandOptions();
          };
          reader.readAsDataURL(file);
        });

        dropZone.appendChild(fileInput);
        dropZone.addEventListener('click', () => fileInput.click());
        container.appendChild(dropZone);

        // Logo preview
        if (state.answers.logoFile) {
          const preview = document.createElement('div');
          preview.className = 'survey-logo-preview';

          if (state.answers.logoFile.type?.startsWith('image/')) {
            const img = document.createElement('img');
            img.src = state.answers.logoFile.url;
            img.alt = 'Logo';
            preview.appendChild(img);
          }

          const removeBtn = document.createElement('button');
          removeBtn.type = 'button';
          removeBtn.className = 'survey-remove-logo';
          removeBtn.textContent = 'Remove';
          removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            state.answers.logoFile = null;
            renderBrandOptions();
          });
          preview.appendChild(removeBtn);

          container.appendChild(preview);
        }
      }

      // Brand colors input
      if (state.answers.brand.includes('colors')) {
        const input = document.createElement('input');
        input.className = 'survey-input';
        input.style.marginTop = '0.5rem';
        input.placeholder = 'Describe your colors — e.g. Navy #1A2B4C, Gold #D4AF37';
        input.value = state.answers.brandColors;
        input.addEventListener('input', (e) => {
          state.answers.brandColors = e.target.value;
        });
        container.appendChild(input);
      }

      // Brand slogan input
      if (state.answers.brand.includes('slogan')) {
        const input = document.createElement('input');
        input.className = 'survey-input';
        input.style.marginTop = '0.5rem';
        input.placeholder = 'Your slogan or tagline';
        input.value = state.answers.brandSlogan;
        input.addEventListener('input', (e) => {
          state.answers.brandSlogan = e.target.value;
        });
        container.appendChild(input);
      }
    };

    renderBrandOptions();
  }

  function renderUpload(container) {
    const dropZone = document.createElement('div');
    dropZone.className = 'survey-dropzone';
    dropZone.innerHTML = `
      <div class="survey-dropzone-icon">🖼️</div>
      <p>Drag & drop or click to browse</p>
      <span>Images, logos, PDFs — anything that represents your brand</span>
    `;

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.multiple = true;
    fileInput.accept = 'image/*,.pdf,.svg,.png,.jpg,.jpeg,.webp';
    fileInput.style.display = 'none';

    const addFiles = (files) => {
      Array.from(files).forEach(file => {
        const validation = validateFile(file);
        if (!validation.valid) {
          alert(validation.error);
          return;
        }

        const reader = new FileReader();
        reader.onload = (event) => {
          state.answers.files.push({
            name: file.name,
            size: file.size,
            url: event.target.result,
            type: file.type,
            file: file
          });
          renderThumbs();
        };
        reader.readAsDataURL(file);
      });
    };

    fileInput.addEventListener('change', (e) => addFiles(e.target.files));
    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.classList.add('drag-active');
    });

    dropZone.addEventListener('dragleave', () => {
      dropZone.classList.remove('drag-active');
    });

    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.classList.remove('drag-active');
      addFiles(e.dataTransfer.files);
    });

    dropZone.appendChild(fileInput);
    container.appendChild(dropZone);

    const grid = document.createElement('div');
    grid.className = 'survey-thumb-grid';
    grid.id = 'survey-thumb-grid';
    container.appendChild(grid);

    const optionalText = document.createElement('p');
    optionalText.style.cssText = 'font-size:0.75rem;color:var(--survey-gray-400);text-align:center;';
    optionalText.textContent = 'Optional — you can always send files later.';
    container.appendChild(optionalText);

    const renderThumbs = () => {
      grid.innerHTML = '';
      state.answers.files.forEach((file, index) => {
        const thumb = document.createElement('div');
        thumb.className = 'survey-thumb';

        if (file.type?.startsWith('image/')) {
          const img = document.createElement('img');
          img.src = file.url;
          img.alt = file.name;
          thumb.appendChild(img);
        } else {
          const icon = document.createElement('div');
          icon.className = 'survey-thumb-icon';
          icon.textContent = '📄';
          thumb.appendChild(icon);
        }

        const name = document.createElement('div');
        name.className = 'survey-thumb-name';
        name.textContent = file.name;
        thumb.appendChild(name);

        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'survey-thumb-remove';
        removeBtn.textContent = '✕';
        removeBtn.addEventListener('click', () => {
          state.answers.files.splice(index, 1);
          renderThumbs();
        });
        thumb.appendChild(removeBtn);

        grid.appendChild(thumb);
      });
    };

    renderThumbs();
  }

  // ============================================================================
  // SUBMISSION
  // ============================================================================

  function submitSurvey() {
    const continueBtn = document.getElementById('survey-continue-btn');
    if (continueBtn) {
      continueBtn.disabled = true;
      continueBtn.innerHTML = 'Submitting... <span class="survey-loading"></span>';
    }

    const formData = new FormData();

    // Add action and nonce
    formData.append('action', 'sec_submit_survey');
    formData.append('nonce', state.sessionData.nonce || '');

    // Add session data from PHP
    if (state.sessionData.session) {
      formData.append('customer_id', state.sessionData.session.customer_id || '');
      formData.append('customer_name', state.sessionData.session.customer_name || '');
      formData.append('customer_email', state.sessionData.session.customer_email || '');
      formData.append('payment_amount', state.sessionData.session.payment_amount || 0);
      formData.append('session_id', state.sessionData.session.session_id || '');
    }

    // Add answer fields
    formData.append('business_name', state.answers.businessName);
    formData.append('industry', state.answers.industry);
    formData.append('custom_industry', state.answers.customIndustry);
    formData.append('tagline', state.answers.tagline);
    formData.append('services', state.answers.services);
    formData.append('hours', JSON.stringify(state.answers.hours));
    formData.append('booking', JSON.stringify(state.answers.booking));
    formData.append('contact_phone', state.answers.contact.phone);
    formData.append('contact_email', state.answers.contact.email);
    formData.append('contact_address', state.answers.contact.address);
    formData.append('socials', JSON.stringify(state.answers.socials));
    formData.append('brand', JSON.stringify(state.answers.brand));
    formData.append('brand_colors', state.answers.brandColors);
    formData.append('brand_slogan', state.answers.brandSlogan);
    formData.append('extra', state.answers.extra);

    // Add logo file
    if (state.answers.logoFile && state.answers.logoFile.file) {
      formData.append('logo', state.answers.logoFile.file);
    }

    // Add multiple files
    state.answers.files.forEach((fileObj, index) => {
      if (fileObj.file) {
        formData.append(`files[${index}]`, fileObj.file);
      }
    });

    // Submit via AJAX
    fetch(state.sessionData.ajax_url || '/wp-admin/admin-ajax.php', {
      method: 'POST',
      body: formData,
      credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        showSuccess();
      } else {
        throw new Error(data.data?.message || 'Submission failed');
      }
    })
    .catch(error => {
      console.error('Survey submission error:', error);
      alert('There was an error submitting your survey. Please try again.');

      if (continueBtn) {
        continueBtn.disabled = false;
        continueBtn.textContent = 'Submit & Launch 🚀';
      }
    });
  }

  function showSuccess() {
    const answers = state.answers;
    const modal = document.getElementById('sec-survey-modal');

    if (!modal) return;

    modal.innerHTML = `
      <div class="survey-card">
        <div class="survey-body">
          <div class="survey-success">
            <div class="survey-success-icon">✓</div>
            <h2>You're all set!</h2>
            <p>We have everything we need to build <strong style="color:var(--survey-primary)">${answers.businessName}'s</strong> website.<br>Expect your preview within <strong style="color:var(--survey-gray-800)">48 hours</strong>.</p>
            <div class="survey-success-box">
              <p class="survey-success-row"><strong>Business:</strong> ${answers.businessName}</p>
              <p class="survey-success-row"><strong>Industry:</strong> ${answers.industry === 'Other' ? answers.customIndustry : answers.industry}</p>
              <p class="survey-success-row"><strong>Files uploaded:</strong> ${answers.files.length + (answers.logoFile ? 1 : 0)}</p>
              <p class="survey-success-row"><strong>Social pages:</strong> ${answers.socials.filter(s => s.value).length}</p>
            </div>
            <button type="button" id="survey-close-success" style="margin-top: 1.5rem; padding: 0.75rem 2rem; background: var(--survey-primary); color: white; border: none; border-radius: 0.5rem; font-weight: 600; cursor: pointer;">Close & View Launch Page</button>
          </div>
        </div>
      </div>
    `;

    // Add close button handler
    document.getElementById('survey-close-success').addEventListener('click', () => {
      closeModal();
    });
  }

  // ============================================================================
  // INITIALIZATION
  // ============================================================================

  function init() {
    // Check if overlay exists (might be output by PHP)
    let overlay = document.getElementById('sec-survey-modal-overlay');

    if (!overlay) {
      // Create overlay if it doesn't exist
      overlay = document.createElement('div');
      overlay.id = 'sec-survey-modal-overlay';
      overlay.style.display = 'none';
      document.body.appendChild(overlay);
    }

    // Check if modal content exists
    let modalContainer = document.getElementById('sec-survey-modal');

    if (!modalContainer || modalContainer.innerHTML.trim() === '') {
      // Create or populate modal content
      const modalHTML = `
        <div class="survey-card">
          <div class="survey-header">
            <div class="survey-header-top">
              <span class="survey-label">Website Launch</span>
              <span class="survey-step-count" id="survey-step-count">1 of 11</span>
            </div>
            <div class="survey-progress-track">
              <div class="survey-progress-fill" id="survey-progress-fill" style="width:9%"></div>
            </div>
          </div>
          <div class="survey-body" id="survey-body"></div>
          <div class="survey-footer">
            <button type="button" class="survey-back" id="survey-back-btn" style="display:none">← Back</button>
            <button type="button" class="survey-btn-primary" id="survey-continue-btn">Continue →</button>
          </div>
          <div class="survey-optional-hint" id="survey-optional-hint"></div>
        </div>
      `;

      if (!modalContainer) {
        modalContainer = document.createElement('div');
        modalContainer.id = 'sec-survey-modal';
        overlay.appendChild(modalContainer);
      }

      modalContainer.innerHTML = modalHTML;
    }

    // Event listeners
    document.getElementById('survey-back-btn').addEventListener('click', () => goToStep(-1));
    document.getElementById('survey-continue-btn').addEventListener('click', () => goToStep(1));

    // Close on ESC key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && overlay.style.display === 'flex') {
        closeModal();
      }
    });

    // Expose global function to open modal
    window.secOpenSurveyModal = openModal;
    window.secCloseSurveyModal = closeModal;

    // Auto-open if configured
    if (state.sessionData.auto_open) {
      setTimeout(openModal, 1000);
    }
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
