/**
 * Survey Modal - Website Launch Questionnaire
 * Blue Theme - Vanilla JavaScript Implementation
 *
 * Handles 11-step survey with validation, file uploads, and AJAX submission
 */

(function() {
  'use strict';

  // ============================================================================
  // CONSTANTS & CONFIGURATION
  // ============================================================================

  const INDUSTRIES = [
    { id: "beauty", label: "Beauty & Wellness", icon: "💅" },
    { id: "realestate", label: "Real Estate", icon: "🏠" },
    { id: "legal", label: "Legal Services", icon: "⚖️" },
    { id: "health", label: "Health & Medical", icon: "🩺" },
    { id: "finance", label: "Finance & Accounting", icon: "💰" },
    { id: "fitness", label: "Fitness & Training", icon: "💪" },
    { id: "coaching", label: "Coaching & Consulting", icon: "📊" },
    { id: "photography", label: "Photography", icon: "📸" },
    { id: "food", label: "Food & Beverage", icon: "🍽️" },
    { id: "ecommerce", label: "E-Commerce", icon: "🛒" },
    { id: "construction", label: "Construction & Trades", icon: "🔨" },
    { id: "education", label: "Education & Tutoring", icon: "📚" },
    { id: "technology", label: "Technology", icon: "💻" },
    { id: "nonprofit", label: "Non-Profit", icon: "🤝" },
    { id: "other", label: "Other", icon: "⚙️" }
  ];

  const INDUSTRY_LABEL_ALIASES = {
    'fitness & personal training': 'Fitness & Training',
    'fitness and personal training': 'Fitness & Training',
    'fitness training': 'Fitness & Training'
  };

  const INDUSTRY_SERVICES = {
    "Beauty & Wellness": "1. Haircut – $45\n2. Color Treatment – $120\n3. Balayage – from $180",
    "Real Estate": "1. Buyer Representation – Free\n2. Listing & Selling – 2.5% commission\n3. Market Analysis – $150",
    "Legal Services": "1. Initial Consultation – $200\n2. Contract Review – from $350\n3. Full Representation – contact for pricing",
    "Health & Medical": "1. New Patient Exam – $150\n2. Follow-Up Visit – $85\n3. Telehealth Appointment – $65",
    "Finance & Accounting": "1. Financial Consultation – $200\n2. Tax Preparation – from $300\n3. Bookkeeping (monthly) – from $250",
    "Fitness & Training": "1. 1-on-1 Personal Training – $80/session\n2. Group Fitness Class – $25\n3. Monthly Coaching Program – $350",
    "Coaching & Consulting": "1. Discovery Call – Free\n2. 1-Hour Strategy Session – $175\n3. 3-Month Coaching Package – $1,200",
    "Photography": "1. Portrait Session – $250\n2. Wedding Photography – from $2,500\n3. Brand & Headshot Session – $400",
    "Food & Beverage": "1. Catering (per person) – from $35\n2. Private Chef Experience – $500\n3. Meal Prep Package (weekly) – $180",
    "E-Commerce": "1. Product A – $XX\n2. Product B – $XX\n3. Bundle / Subscription – $XX/mo",
    "Construction & Trades": "1. Free Estimate – No charge\n2. Kitchen Remodel – from $8,000\n3. Bathroom Renovation – from $4,500",
    "Education & Tutoring": "1. 1-on-1 Tutoring (1hr) – $60\n2. Group Study Session – $25\n3. Monthly Learning Plan – $220",
    "Technology": "1. IT Support (hourly) – $95\n2. Website Development – from $1,500\n3. Monthly Maintenance – $150/mo",
    "Non-Profit": "1. Volunteer Program – Free\n2. Community Workshop – Donation-based\n3. Annual Membership – $50/yr",
    "Other": "1. Service Name – Price\n2. Service Name – Price\n3. Service Name – Price"
  };

  const INDUSTRY_TAGLINES = {
    "Beauty & Wellness": "e.g. We help clients feel confident through personalized beauty treatments.",
    "Real Estate": "e.g. We help first-time homebuyers find their perfect home.",
    "Legal Services": "e.g. We protect small businesses with affordable legal counsel.",
    "Health & Medical": "e.g. We provide compassionate care for families in our community.",
    "Finance & Accounting": "e.g. We help small business owners master their finances.",
    "Fitness & Training": "e.g. We transform lives through personalized fitness coaching.",
    "Coaching & Consulting": "e.g. We help professionals achieve their career goals.",
    "Photography": "e.g. We capture life's special moments with timeless photography.",
    "Food & Beverage": "e.g. We bring restaurant-quality meals to your table.",
    "E-Commerce": "e.g. We deliver quality products right to your door.",
    "Construction & Trades": "e.g. We build dream homes with expert craftsmanship.",
    "Education & Tutoring": "e.g. We help students reach their academic potential.",
    "Technology": "e.g. We keep businesses running with reliable IT support.",
    "Non-Profit": "e.g. We empower communities through education and outreach.",
    "Other": "e.g. We help clients solve their problems with expert service."
  };

  const SOCIAL_PLATFORMS = [
    {
      label: "Facebook",
      icon: '<svg viewBox="0 0 24 24" fill="#1877f2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
      placeholder: "facebook.com/yourbusiness"
    },
    {
      label: "Instagram",
      icon: '<svg viewBox="0 0 24 24" fill="url(#instagram-gradient)"><defs><linearGradient id="instagram-gradient" x1="0%" y1="100%" x2="100%" y2="0%"><stop offset="0%" style="stop-color:#f09433;stop-opacity:1" /><stop offset="25%" style="stop-color:#e6683c;stop-opacity:1" /><stop offset="50%" style="stop-color:#dc2743;stop-opacity:1" /><stop offset="75%" style="stop-color:#cc2366;stop-opacity:1" /><stop offset="100%" style="stop-color:#bc1888;stop-opacity:1" /></linearGradient></defs><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
      placeholder: "instagram.com/yourbusiness"
    },
    {
      label: "LinkedIn",
      icon: '<svg viewBox="0 0 24 24" fill="#0a66c2"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
      placeholder: "linkedin.com/in/yourbusiness"
    },
    {
      label: "TikTok",
      icon: '<svg viewBox="0 0 24 24" fill="#000000"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/></svg>',
      placeholder: "tiktok.com/@yourbusiness"
    },
    {
      label: "X / Twitter",
      icon: '<svg viewBox="0 0 24 24" fill="#000000"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
      placeholder: "x.com/yourbusiness"
    },
    {
      label: "YouTube",
      icon: '<svg viewBox="0 0 24 24" fill="#ff0000"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
      placeholder: "youtube.com/@yourbusiness"
    },
    {
      label: "Pinterest",
      icon: '<svg viewBox="0 0 24 24" fill="#e60023"><path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z"/></svg>',
      placeholder: "pinterest.com/yourbusiness"
    },
    {
      label: "Other",
      icon: '<svg viewBox="0 0 24 24" fill="#6b7280"><path d="M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z"/></svg>',
      placeholder: "Paste your link here"
    }
  ];

  const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

  const STEPS = [
    {
      id: 1,
      num: "01",
      field: "businessName",
      label: "What's your business called?",
      hint: "Exactly as you'd like it displayed on your website.",
      type: "text",
      required: true
    },
    {
      id: 2,
      num: "02",
      field: "industry",
      label: "What industry are you in?",
      hint: "Pick the closest match — this helps us tailor your design.",
      type: "select",
      required: true
    },
    {
      id: 3,
      num: "03",
      field: "tagline",
      label: "Describe what your business does in one sentence.",
      hint: "Who do you help and how? Keep it simple and clear.",
      type: "text",
      required: true,
      placeholder: "" // Will be set dynamically based on industry
    },
    {
      id: 4,
      num: "04",
      field: "services",
      label: "What are your top 3 services or offerings?",
      hint: "Include a price if you'd like it shown. Keep each one brief.",
      type: "textarea",
      required: true
    },
    {
      id: 5,
      num: "05",
      field: "hours",
      label: "What are your business hours?",
      hint: "Toggle any day you're not open.",
      type: "hours",
      required: false
    },
    {
      id: 6,
      num: "06",
      field: "booking",
      label: "How will clients meet with you?",
      hint: "Select all that apply — your calendar will be configured to match.",
      type: "multicheck",
      required: true,
      options: [
        { label: "Virtually (video or phone call)", value: "virtual" },
        { label: "At my location (client comes to me)", value: "our_location" },
        { label: "At the client's location (I go to them)", value: "client_location" }
      ]
    },
    {
      id: 7,
      num: "07",
      field: "contact",
      label: "How can clients contact you?",
      hint: "Only share what you're comfortable displaying publicly.",
      type: "contact",
      required: true
    },
    {
      id: 8,
      num: "08",
      field: "socials",
      label: "Add your social media pages.",
      hint: "Click a platform to add it. Add as many as you'd like.",
      type: "socials",
      required: false
    },
    {
      id: 9,
      num: "09",
      field: "brand",
      label: "Do you have a logo or brand colors?",
      hint: "No worries if not — we'll take care of it.",
      type: "brandcheck",
      required: false
    },
    {
      id: 10,
      num: "10",
      field: "files",
      label: "Upload any photos or files for your website.",
      hint: "Team photos, product shots — anything that represents your brand.",
      type: "upload",
      required: false
    },
    {
      id: 11,
      num: "11",
      field: "extra",
      label: "Anything else you'd like us to know?",
      hint: "Awards, certifications, a must-have page — or leave it blank and hit submit.",
      type: "textarea",
      required: false,
      placeholder: "Optional…"
    },
    {
      id: 12,
      num: "12",
      field: "review",
      label: "Review your answers",
      hint: "Take a moment to review everything before submitting.",
      type: "review",
      required: false
    }
  ];

  // File upload settings
  const MAX_FILE_SIZE = 35 * 1024 * 1024; // 35MB
  const ALLOWED_MIME_TYPES = [
    'image/jpeg',
    'image/png',
    'image/jpg',
    'image/webp',
    'image/svg+xml',
    'application/pdf'
  ];

  // ============================================================================
  // STATE MANAGEMENT
  // ============================================================================

  const state = {
    currentStep: 0,
    direction: 1,
    animating: false,
    ignoreIndustryClicksUntil: 0,
    touched: {},
    welcomeShown: false,
    autoSaveTimer: null,
    answers: {
      businessName: '',
      industry: '',
      customIndustry: '',
      tagline: '',
      services: '',
      hours: defaultHours(),
      booking: [],
      contact: { phone: '', email: '', address: '' },
      socials: [],
      brand: [],
      brandColors: '',
      brandSlogan: '',
      logoFile: null,
      files: [],
      extra: ''
    },
    sessionData: window.secSurveyData || {} // Data from PHP
  };

  function defaultHours() {
    const hours = {};
    DAYS.forEach(day => {
      hours[day] = { open: '09:00', close: '17:00', closed: false };
    });
    return hours;
  }

  function normalizeIndustryValue(rawValue) {
    const value = String(rawValue || '').trim();
    if (!value) return '';

    const direct = INDUSTRIES.find(ind => ind.label.toLowerCase() === value.toLowerCase());
    if (direct) return direct.label;

    return INDUSTRY_LABEL_ALIASES[value.toLowerCase()] || value;
  }

  function getIndustryServicesTemplate(industryLabel) {
    const normalized = normalizeIndustryValue(industryLabel);
    return INDUSTRY_SERVICES[normalized] || INDUSTRY_SERVICES['Other'] || '';
  }

  function shouldRefreshIndustryServices(currentValue, previousIndustry) {
    const current = String(currentValue || '').trim();
    return !current;
  }

  function syncIndustryDependentAnswers(previousIndustry, nextIndustry) {
    if (shouldRefreshIndustryServices(state.answers.services, previousIndustry)) {
      state.answers.services = getIndustryServicesTemplate(nextIndustry);
    }
  }

  // ============================================================================
  // VALIDATION
  // ============================================================================

  function validatePhone(value) {
    return /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/.test(value.replace(/\s/g, ''));
  }

  function validateEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function validateURL(value) {
    const raw = String(value || '').trim();
    if (!raw) return true;

    let parsed;
    try {
      parsed = new URL(/^https?:\/\//i.test(raw) ? raw : 'https://' + raw);
    } catch (e) {
      return false;
    }

    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false;
    const host = parsed.hostname.toLowerCase().replace(/^www\./, '');
    return isValidPublicDomain(host);
  }

  function isValidPublicDomain(host) {
    if (!host || host.length > 253) return false;
    if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host)) return false;
    if (host.includes(':')) return false;

    const labels = host.split('.');
    if (labels.length < 2) return false;

    const tld = labels[labels.length - 1];
    if (!/^[a-z]{2,63}$/i.test(tld)) return false;

    return labels.every(label => /^[a-z0-9-]{1,63}$/i.test(label) && !label.startsWith('-') && !label.endsWith('-'));
  }

  function normalizeHexColor(value) {
    const raw = String(value || '').trim().toUpperCase();
    if (!raw) return '';

    const withoutHash = raw.startsWith('#') ? raw.slice(1) : raw;
    if (/^[0-9A-F]{3}$/.test(withoutHash)) {
      return '#' + withoutHash.split('').map(ch => ch + ch).join('');
    }
    if (/^[0-9A-F]{6}$/.test(withoutHash)) {
      return '#' + withoutHash;
    }
    return '';
  }

  function parseBrandColors(value) {
    if (Array.isArray(value)) {
      const parsed = value.map(normalizeHexColor).filter(Boolean);
      return parsed.length ? parsed : ['#2536EB'];
    }

    const parsed = String(value || '')
      .split(',')
      .map(part => normalizeHexColor(part))
      .filter(Boolean);
    return parsed.length ? parsed : ['#2536EB'];
  }

  function getSocialPlatformRules() {
    return {
      'Facebook':    { hosts: ['facebook.com'],            handleToPath: handle => '/' + handle.replace(/^@+/, '') },
      'Instagram':   { hosts: ['instagram.com'],           handleToPath: handle => '/' + handle.replace(/^@+/, '') },
      'LinkedIn':    { hosts: ['linkedin.com'] },
      'TikTok':      { hosts: ['tiktok.com'],              handleToPath: handle => '/@' + handle.replace(/^@+/, '') },
      'X / Twitter': { hosts: ['x.com', 'twitter.com'],    handleToPath: handle => '/' + handle.replace(/^@+/, '') },
      'YouTube':     { hosts: ['youtube.com', 'youtu.be'], handleToPath: handle => '/@' + handle.replace(/^@+/, '') },
      'Pinterest':   { hosts: ['pinterest.com'],           handleToPath: handle => '/' + handle.replace(/^@+/, '') },
      'Other':       { hosts: [] }
    };
  }

  function normalizeSocialUrlForPlatform(platform, rawValue) {
    const value = (rawValue || '').trim();
    if (!value) return { ok: true, value: '' };

    const rules = getSocialPlatformRules();
    const rule = rules[platform] || rules['Other'];
    let candidate = value;

    if (rule.handleToPath && /^@[\w._-]+$/.test(candidate)) {
      candidate = 'https://' + rule.hosts[0] + rule.handleToPath(candidate);
    } else if (!/^https?:\/\//i.test(candidate)) {
      candidate = 'https://' + candidate;
    }

    let parsed;
    try {
      parsed = new URL(candidate);
    } catch (e) {
      return { ok: false, error: `Please enter a valid ${platform} URL.` };
    }

    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return { ok: false, error: `Please enter a valid ${platform} URL.` };
    }

    const host = parsed.hostname.toLowerCase().replace(/^www\./, '');
    if (rule.hosts.length > 0) {
      const hostMatches = rule.hosts.some(allowed => host === allowed || host.endsWith(`.${allowed}`));
      if (!hostMatches) {
        return { ok: false, error: `${platform} links must use ${rule.hosts.join(' or ')}.` };
      }
    } else if (!validateURL(candidate)) {
      return { ok: false, error: 'Please enter a valid URL with a real domain (e.g. example.com).' };
    }

    parsed.protocol = 'https:';
    const isRootPath = parsed.pathname === '/' && !parsed.search && !parsed.hash;
    if (platform === 'LinkedIn' && isRootPath) {
      return { ok: true, value: 'https://linkedin.com/' };
    }

    const normalized = parsed.toString();
    const cleaned = isRootPath ? normalized.slice(0, -1) : normalized;
    return { ok: true, value: cleaned };
  }

  function toNormalizedSocialEntry(platformDef, value) {
    return {
      platform: platformDef.label,
      label: platformDef.label,
      icon: platformDef.icon,
      placeholder: platformDef.placeholder,
      value: value || ''
    };
  }

  function getSocialDefaultTemplate(platform) {
    const defaults = {
      'Facebook': 'https://facebook.com/',
      'Instagram': 'https://instagram.com/',
      'LinkedIn': 'https://linkedin.com/',
      'TikTok': 'https://tiktok.com/@',
      'X / Twitter': 'https://x.com/',
      'YouTube': 'https://youtube.com/@',
      'Pinterest': 'https://pinterest.com/',
      'Other': 'https://'
    };
    return defaults[platform] || 'https://';
  }

  function normalizeSocialEntries(entries, strict) {
    const rawEntries = Array.isArray(entries) ? entries : [];
    const normalized = [];
    let firstError = '';

    rawEntries.forEach((social) => {
      if (!social || typeof social !== 'object') return;
      const platform = social.platform || social.label || '';
      const platformDef = SOCIAL_PLATFORMS.find(p => p.label === platform) || { label: platform || 'Other', icon: social.icon || '', placeholder: social.placeholder || '' };
      const result = normalizeSocialUrlForPlatform(platformDef.label, social.value || '');
      if (!result.ok && !firstError) firstError = result.error;
      normalized.push(toNormalizedSocialEntry(platformDef, result.ok ? result.value : ''));
    });

    if (strict && firstError) {
      return { ok: false, error: firstError, entries: normalized };
    }
    return { ok: true, entries: normalized };
  }

  function isStepValid() {
    const step = STEPS[state.currentStep];
    const answers = state.answers;

    if (!step.required) return true;

    switch (step.field) {
      case 'businessName':
        return answers.businessName.trim().length > 0;

      case 'industry':
        return answers.industry && (answers.industry !== 'Other' || answers.customIndustry.trim().length > 0);

      case 'tagline':
        return answers.tagline.trim().length > 0;

      case 'services':
        return answers.services.trim().length > 0;

      case 'booking':
        return answers.booking.length > 0;

      case 'contact':
        const phone = answers.contact.phone.trim();
        const email = answers.contact.email.trim();
        const hasAtLeastOne = phone || email;
        const phoneValid = !phone || validatePhone(phone);
        const emailValid = !email || validateEmail(email);
        return hasAtLeastOne && phoneValid && emailValid;

      default:
        return true;
    }
  }

  function validateFile(file) {
    if (file.size > MAX_FILE_SIZE) {
      return { valid: false, error: `File "${file.name}" exceeds 35MB limit` };
    }

    if (!ALLOWED_MIME_TYPES.includes(file.type)) {
      return { valid: false, error: `File type not supported for "${file.name}"` };
    }

    return { valid: true };
  }

  // ============================================================================
  // MODAL MANAGEMENT
  // ============================================================================

  function openModal() {
    const overlay = document.getElementById('sec-survey-modal-overlay');
    if (overlay) {
      overlay.style.display = 'flex';
      document.body.style.overflow = 'hidden';
      render();
    }
  }

  function closeModal() {
    const overlay = document.getElementById('sec-survey-modal-overlay');
    if (overlay) {
      overlay.style.display = 'none';
      document.body.style.overflow = '';
    }
  }

  // ============================================================================
  // NAVIGATION
  // ============================================================================

  function goToStep(direction) {
    if (state.animating) return;

    // Check if we're on review step OR last step
    const isReviewStep = STEPS[state.currentStep].field === 'review';
    if (direction === 1 && (state.currentStep === STEPS.length - 1 || isReviewStep)) {
      submitSurvey();
      return;
    }

    // Start animation
    state.direction = direction;
    state.animating = true;

    const body = document.getElementById('survey-body');
    if (body) {
      body.classList.remove('survey-step-enter-fwd', 'survey-step-enter-back');
      body.classList.add(direction > 0 ? 'survey-step-exit-fwd' : 'survey-step-exit-back');
    }

    // Wait for exit animation, then update step
    setTimeout(() => {
      state.currentStep += direction;
      state.touched = {};
      if (direction < 0) {
        state.ignoreIndustryClicksUntil = Date.now() + 450;
      }

      // Auto-save progress on any navigation (forward or backward)
      scheduleSave();

      render();

      // Add enter animation
      if (body) {
        body.classList.remove('survey-step-exit-fwd', 'survey-step-exit-back');
        body.classList.add(direction > 0 ? 'survey-step-enter-fwd' : 'survey-step-enter-back');
      }

      state.animating = false;
    }, 250);
  }

  function updateFooter() {
    const step = STEPS[state.currentStep];
    const backBtn = document.getElementById('survey-back-btn');
    const continueBtn = document.getElementById('survey-continue-btn');
    const stepCount = document.getElementById('survey-step-count');
    const progress = document.getElementById('survey-progress-fill');
    const optionalHint = document.getElementById('survey-optional-hint');

    if (backBtn) {
      backBtn.style.display = state.currentStep > 0 ? '' : 'none';
    }

    if (continueBtn) {
      const isReviewStep = STEPS[state.currentStep].field === 'review';
      continueBtn.disabled = !isStepValid();
      continueBtn.textContent = state.currentStep === STEPS.length - 1
        ? 'Submit & Launch 🚀'
        : isReviewStep
          ? 'Submit & Launch 🚀'
          : 'Continue →';
    }

    if (stepCount) {
      stepCount.textContent = `${state.currentStep + 1} of ${STEPS.length}`;
    }

    if (progress) {
      const percentage = Math.round(((state.currentStep + 1) / STEPS.length) * 100);
      progress.style.width = `${percentage}%`;
    }

    if (optionalHint) {
      optionalHint.textContent = !step.required ? 'This step is optional — feel free to skip' : '';
    }
  }

  // ============================================================================
  // RENDERING
  // ============================================================================

  function showWelcomeModal() {
    const modal = document.getElementById('sec-survey-modal');
    if (!modal) return;

    // Create welcome overlay
    const overlay = document.createElement('div');
    overlay.className = 'survey-welcome-overlay';
    overlay.innerHTML = `
      <div class="survey-welcome-card">
        <div class="survey-welcome-icon">✨</div>
        <h2 class="survey-welcome-title">Thank you for your payment!</h2>
        <p class="survey-welcome-text">
          Please complete this survey so we can build your website within <strong>48 hours</strong>.
        </p>
        <p class="survey-welcome-subtext">
          Without this information, we won't be able to complete your site.
        </p>
        <button type="button" class="survey-welcome-btn" id="survey-welcome-close">
          Get Started
        </button>
      </div>
    `;

    modal.appendChild(overlay);

    // Close button handler
    document.getElementById('survey-welcome-close').addEventListener('click', () => {
      overlay.classList.add('fadeOut');
      setTimeout(() => {
        overlay.remove();
      }, 300);
    });

    // Animate in
    setTimeout(() => {
      overlay.classList.add('active');
    }, 100);
  }

  function render() {
    const step = STEPS[state.currentStep];
    const body = document.getElementById('survey-body');

    if (!body) return;

    // Clear body
    body.innerHTML = `
      ${step.num ? `<span class="survey-question-number">Step ${step.num}</span>` : ''}
      <h2 class="survey-question">${step.label}</h2>
      <p class="survey-hint">${step.hint}</p>
    `;

    // Render step content based on type
    switch (step.type) {
      case 'text':
        renderTextInput(body, step);
        break;
      case 'textarea':
        renderTextarea(body, step);
        break;
      case 'select':
        renderIndustrySelect(body);
        break;
      case 'hours':
        renderHours(body);
        break;
      case 'multicheck':
        renderMulticheck(body, step);
        break;
      case 'contact':
        renderContact(body);
        break;
      case 'socials':
        renderSocials(body);
        break;
      case 'brandcheck':
        renderBrandCheck(body);
        break;
      case 'upload':
        renderUpload(body);
        break;
      case 'review':
        renderReview(body);
        break;
    }

    updateFooter();

    // Show welcome modal on first step (only once)
    if (state.currentStep === 0 && !state.welcomeShown) {
      state.welcomeShown = true;
      setTimeout(() => {
        showWelcomeModal();
      }, 500); // Small delay for better UX
    }
  }

  // ============================================================================
  // STEP RENDERERS
  // ============================================================================

  function renderTextInput(container, step) {
    const input = document.createElement('input');
    input.className = 'survey-input';

    // Set dynamic placeholder for tagline based on industry
    if (step.field === 'tagline' && state.answers.industry) {
      const normalizedIndustry = normalizeIndustryValue(state.answers.industry);
      input.placeholder = INDUSTRY_TAGLINES[normalizedIndustry] || INDUSTRY_TAGLINES['Other'];
    } else {
      input.placeholder = step.placeholder || '';
    }

    input.value = state.answers[step.field];

    input.addEventListener('input', (e) => {
      state.answers[step.field] = e.target.value;
      updateFooter();
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && isStepValid()) {
        goToStep(1);
      }
    });

    container.appendChild(input);
    setTimeout(() => input.focus(), 50);
  }

  function renderTextarea(container, step) {
    const textarea = document.createElement('textarea');
    textarea.className = 'survey-input';
    textarea.rows = 4;

    if (step.field === 'services') {
      const normalizedIndustry = normalizeIndustryValue(state.answers.industry);
      textarea.placeholder = INDUSTRY_SERVICES[normalizedIndustry] || INDUSTRY_SERVICES['Other'];
    } else {
      textarea.placeholder = step.placeholder || '';
    }

    textarea.value = state.answers[step.field];

    textarea.addEventListener('input', (e) => {
      state.answers[step.field] = e.target.value;
      updateFooter();
    });

    container.appendChild(textarea);
    setTimeout(() => textarea.focus(), 50);
  }

  function renderIndustrySelect(container) {
    const grid = document.createElement('div');
    grid.className = 'survey-industry-grid';
    const selectedIndustry = normalizeIndustryValue(state.answers.industry);

    INDUSTRIES.forEach(industry => {
      const tile = document.createElement('button');
      tile.className = 'survey-industry-tile' + (selectedIndustry === industry.label ? ' active' : '');
      tile.type = 'button';

      tile.innerHTML = `
        <div class="survey-industry-icon">${industry.icon}</div>
        <div class="survey-industry-label">${industry.label}</div>
      `;

      tile.addEventListener('click', () => {
        if (Date.now() < state.ignoreIndustryClicksUntil) {
          return;
        }
        const previousIndustry = normalizeIndustryValue(state.answers.industry);
        state.answers.industry = industry.label;
        if (industry.label !== 'Other') {
          state.answers.customIndustry = '';
        }
        syncIndustryDependentAnswers(previousIndustry, industry.label);

        // Update all tiles
        container.querySelectorAll('.survey-industry-tile').forEach(btn => {
          btn.classList.remove('active');
        });
        tile.classList.add('active');

        // Handle "Other" custom input
        const customInput = document.getElementById('survey-custom-industry');
        if (industry.label === 'Other') {
          if (!customInput) {
            const input = document.createElement('input');
            input.id = 'survey-custom-industry';
            input.className = 'survey-input';
            input.style.marginTop = '0.75rem';
            input.placeholder = 'Type your industry…';
            input.addEventListener('input', (e) => {
              state.answers.customIndustry = e.target.value;
              scheduleSave();
              updateFooter();
            });
            grid.after(input);
            setTimeout(() => input.focus(), 50);
          }
        } else {
          if (customInput) {
            customInput.remove();
          }
        }

        updateFooter();
      });

      grid.appendChild(tile);
    });

    container.appendChild(grid);

    // Restore custom input if "Other" was selected
    if (state.answers.industry === 'Other') {
      const input = document.createElement('input');
      input.id = 'survey-custom-industry';
      input.className = 'survey-input';
      input.style.marginTop = '0.75rem';
      input.placeholder = 'Type your industry…';
      input.value = state.answers.customIndustry;
      input.addEventListener('input', (e) => {
        state.answers.customIndustry = e.target.value;
        scheduleSave();
        updateFooter();
      });
      container.appendChild(input);
    }
  }

  function renderHours(container) {
    DAYS.forEach(day => {
      const row = document.createElement('div');
      row.className = 'survey-hours-row';

      const label = document.createElement('span');
      label.className = 'survey-day-label';
      label.textContent = day;
      row.appendChild(label);

      const dayHours = state.answers.hours[day];

      if (dayHours.closed) {
        const closedText = document.createElement('span');
        closedText.className = 'survey-closed-text';
        closedText.textContent = 'Closed';
        row.appendChild(closedText);
      } else {
        // Create time display buttons instead of input fields
        ['open', 'close'].forEach(timeType => {
          const timeBtn = document.createElement('button');
          timeBtn.type = 'button';
          timeBtn.className = 'survey-time-btn';
          timeBtn.textContent = formatTime(dayHours[timeType]);

          timeBtn.addEventListener('click', () => {
            showTimePicker(day, timeType, dayHours[timeType], (newTime) => {
              state.answers.hours[day][timeType] = newTime;
              render();
            });
          });

          row.appendChild(timeBtn);
        });
      }

      const closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.className = 'survey-close-day-btn' + (dayHours.closed ? ' closed' : '');
      closeBtn.textContent = dayHours.closed ? 'Closed' : 'Close';
      closeBtn.addEventListener('click', () => {
        state.answers.hours[day].closed = !state.answers.hours[day].closed;
        render();
      });
      row.appendChild(closeBtn);

      container.appendChild(row);
    });
  }

  // Helper function to format time for display
  function formatTime(time24) {
    const [hours, minutes] = time24.split(':');
    const h = parseInt(hours);
    const period = h >= 12 ? 'PM' : 'AM';
    const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
    return `${h12}:${minutes} ${period}`;
  }

  // Show Apple-style inline time picker
  function showTimePicker(day, timeType, currentTime, onSelect) {
    // Close any existing time pickers
    const existingPicker = document.querySelector('.inline-time-picker');
    if (existingPicker) {
      existingPicker.remove();
    }

    const [hours, minutes] = currentTime.split(':');
    let selected24Hour = parseInt(hours);
    let selectedMinute = parseInt(minutes);
    let selectedPeriod = selected24Hour >= 12 ? 'PM' : 'AM';
    let selectedHour12 = selected24Hour === 0 ? 12 : selected24Hour > 12 ? selected24Hour - 12 : selected24Hour;

    // Find the time button that was clicked
    const timeButtons = document.querySelectorAll('.survey-time-btn');
    let targetButton = null;
    timeButtons.forEach(btn => {
      if (btn.textContent === formatTime(currentTime)) {
        targetButton = btn;
      }
    });

    if (!targetButton) return;

    // Create inline picker HTML
    const pickerHTML = `
      <div class="inline-time-picker">
        <div class="inline-time-picker-header">
          <span>${day} - ${timeType === 'open' ? 'Opening' : 'Closing'} Time</span>
        </div>
        <div class="time-picker-wheels">
          <div class="time-wheel" data-type="hour">
            <div class="time-option-spacer"></div>
            <div class="time-option-spacer"></div>
            ${Array.from({length: 12}, (_, i) => i + 1).map(h => `
              <div class="time-option ${h === selectedHour12 ? 'selected' : ''}" data-value="${h}">
                ${h}
              </div>
            `).join('')}
            <div class="time-option-spacer"></div>
            <div class="time-option-spacer"></div>
          </div>
          <div class="time-separator">:</div>
          <div class="time-wheel" data-type="minute">
            <div class="time-option-spacer"></div>
            <div class="time-option-spacer"></div>
            ${Array.from({length: 12}, (_, i) => i * 5).map(m => `
              <div class="time-option ${m === selectedMinute ? 'selected' : ''}" data-value="${m}">
                ${m.toString().padStart(2, '0')}
              </div>
            `).join('')}
            <div class="time-option-spacer"></div>
            <div class="time-option-spacer"></div>
          </div>
          <div class="time-wheel" data-type="period">
            <div class="time-option-spacer"></div>
            <div class="time-option ${selectedPeriod === 'AM' ? 'selected' : ''}" data-value="AM">AM</div>
            <div class="time-option ${selectedPeriod === 'PM' ? 'selected' : ''}" data-value="PM">PM</div>
            <div class="time-option-spacer"></div>
          </div>
        </div>
        <div class="inline-time-picker-actions">
          <button type="button" class="time-picker-cancel">Cancel</button>
          <button type="button" class="time-picker-confirm">Set Time</button>
        </div>
      </div>
    `;

    // Insert picker after the button's parent row
    const row = targetButton.closest('.survey-hours-row');
    row.insertAdjacentHTML('afterend', pickerHTML);

    const picker = row.nextElementSibling;
    const hourWheel = picker.querySelector('[data-type="hour"]');
    const minuteWheel = picker.querySelector('[data-type="minute"]');
    const periodWheel = picker.querySelector('[data-type="period"]');

    // Scroll to center selected options
    setTimeout(() => {
      const selectedHourEl = hourWheel.querySelector('.selected');
      const selectedMinuteEl = minuteWheel.querySelector('.selected');
      const selectedPeriodEl = periodWheel.querySelector('.selected');

      if (selectedHourEl) selectedHourEl.scrollIntoView({block: 'center', behavior: 'instant'});
      if (selectedMinuteEl) selectedMinuteEl.scrollIntoView({block: 'center', behavior: 'instant'});
      if (selectedPeriodEl) selectedPeriodEl.scrollIntoView({block: 'center', behavior: 'instant'});
    }, 10);

    // Function to get centered element in wheel
    function getCenteredElement(wheel) {
      const wheelRect = wheel.getBoundingClientRect();
      const wheelCenter = wheelRect.top + wheelRect.height / 2;

      const options = wheel.querySelectorAll('.time-option');
      let closest = null;
      let closestDistance = Infinity;

      options.forEach(option => {
        const optionRect = option.getBoundingClientRect();
        const optionCenter = optionRect.top + optionRect.height / 2;
        const distance = Math.abs(wheelCenter - optionCenter);

        if (distance < closestDistance) {
          closestDistance = distance;
          closest = option;
        }
      });

      return closest;
    }

    // Function to update selection based on scroll position
    function updateSelectionOnScroll(wheel) {
      const centered = getCenteredElement(wheel);
      if (!centered) return;

      // Remove selection from all options in this wheel
      wheel.querySelectorAll('.time-option').forEach(opt => opt.classList.remove('selected'));
      centered.classList.add('selected');

      // Update values
      const wheelType = wheel.dataset.type;
      if (wheelType === 'hour') {
        selectedHour12 = parseInt(centered.dataset.value);
      } else if (wheelType === 'minute') {
        selectedMinute = parseInt(centered.dataset.value);
      } else if (wheelType === 'period') {
        selectedPeriod = centered.dataset.value;
      }
    }

    // Add scroll listeners with auto-selection
    const scrollTimers = new Map();

    [hourWheel, minuteWheel, periodWheel].forEach(wheel => {
      let isScrolling = false;
      let animationFrame = null;
      let lastWheelAt = 0;

      // Use requestAnimationFrame for smooth, immediate updates
      const handleScroll = () => {
        if (!isScrolling) {
          isScrolling = true;
        }

        if (animationFrame) {
          cancelAnimationFrame(animationFrame);
        }

        animationFrame = requestAnimationFrame(() => {
          updateSelectionOnScroll(wheel);
        });

        // Clear existing timer
        if (scrollTimers.has(wheel)) {
          clearTimeout(scrollTimers.get(wheel));
        }

        // Set new timer to detect scroll end
        const timer = setTimeout(() => {
          isScrolling = false;
          const centered = getCenteredElement(wheel);
          if (centered) {
            centered.scrollIntoView({block: 'center', behavior: 'smooth'});
          }
        }, 150);

        scrollTimers.set(wheel, timer);
      };

      wheel.addEventListener('scroll', handleScroll, {passive: true});

      wheel.addEventListener('wheel', (event) => {
        if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) return;
        if (event.deltaY === 0) return;

        event.preventDefault();

        const now = Date.now();
        if (now - lastWheelAt < 90) return;
        lastWheelAt = now;

        const options = Array.from(wheel.querySelectorAll('.time-option'));
        if (!options.length) return;

        const current = wheel.querySelector('.time-option.selected') || getCenteredElement(wheel) || options[0];
        const currentIndex = Math.max(0, options.indexOf(current));
        const direction = event.deltaY > 0 ? 1 : -1;
        const nextIndex = Math.min(options.length - 1, Math.max(0, currentIndex + direction));
        const next = options[nextIndex];

        wheel.querySelectorAll('.time-option').forEach(opt => opt.classList.remove('selected'));
        next.classList.add('selected');
        next.scrollIntoView({ block: 'center', behavior: 'auto' });
        updateSelectionOnScroll(wheel);
      }, { passive: false });

      // Fallback for browsers that support scrollend
      if ('onscrollend' in wheel) {
        wheel.addEventListener('scrollend', () => {
          const centered = getCenteredElement(wheel);
          if (centered) {
            centered.scrollIntoView({block: 'center', behavior: 'smooth'});
            updateSelectionOnScroll(wheel);
          }
        });
      }
    });

    // Handle click selection (instant feedback)
    picker.querySelectorAll('.time-option').forEach(opt => {
      opt.addEventListener('click', () => {
        const wheel = opt.closest('.time-wheel');
        wheel.querySelectorAll('.time-option').forEach(o => o.classList.remove('selected'));
        opt.classList.add('selected');

        const wheelType = wheel.dataset.type;
        if (wheelType === 'hour') {
          selectedHour12 = parseInt(opt.dataset.value);
        } else if (wheelType === 'minute') {
          selectedMinute = parseInt(opt.dataset.value);
        } else if (wheelType === 'period') {
          selectedPeriod = opt.dataset.value;
        }

        opt.scrollIntoView({block: 'center', behavior: 'smooth'});
      });
    });

    // Cancel button
    picker.querySelector('.time-picker-cancel').addEventListener('click', () => {
      picker.remove();
    });

    // Confirm button
    picker.querySelector('.time-picker-confirm').addEventListener('click', () => {
      // Convert to 24-hour format
      let hour24 = selectedHour12;
      if (selectedPeriod === 'PM' && selectedHour12 !== 12) {
        hour24 = selectedHour12 + 12;
      } else if (selectedPeriod === 'AM' && selectedHour12 === 12) {
        hour24 = 0;
      }
      const newTime = `${hour24.toString().padStart(2, '0')}:${selectedMinute.toString().padStart(2, '0')}`;

      // Call the callback to save the time
      onSelect(newTime);

      // Remove picker
      picker.remove();
    });
  }

  function renderMulticheck(container, step) {
    step.options.forEach(option => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'survey-check-btn' + (state.answers.booking.includes(option.value) ? ' active' : '');
      button.innerHTML = `
        <span class="survey-checkbox">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3">
            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
          </svg>
        </span>
        ${option.label}
      `;

      button.addEventListener('click', () => {
        if (state.answers.booking.includes(option.value)) {
          state.answers.booking = state.answers.booking.filter(v => v !== option.value);
        } else {
          state.answers.booking.push(option.value);
        }
        button.classList.toggle('active');
        updateFooter();
      });

      container.appendChild(button);
    });
  }

  function renderContact(container) {
    const fields = [
      { key: 'phone', icon: '📞', placeholder: 'Phone number', type: 'tel' },
      { key: 'email', icon: '✉️', placeholder: 'Email address', type: 'email' },
      { key: 'address', icon: '📍', placeholder: 'Business address (optional)', type: 'text' }
    ];

    fields.forEach(({ key, icon, placeholder, type }) => {
      const wrapper = document.createElement('div');
      wrapper.className = 'survey-contact-row';
      wrapper.id = `survey-contact-${key}`;

      if (state.touched[key] && state.answers.contact[key]) {
        if ((key === 'phone' && !validatePhone(state.answers.contact[key])) ||
            (key === 'email' && !validateEmail(state.answers.contact[key]))) {
          wrapper.classList.add('error');
        }
      }

      const iconSpan = document.createElement('span');
      iconSpan.className = 'survey-contact-icon';
      iconSpan.textContent = icon;
      wrapper.appendChild(iconSpan);

      const input = document.createElement('input');
      input.className = 'survey-contact-input';
      input.type = type;
      input.placeholder = placeholder;
      input.value = state.answers.contact[key];

      input.addEventListener('input', (e) => {
        state.answers.contact[key] = e.target.value;
        updateFooter();
      });

      input.addEventListener('blur', () => {
        state.touched[key] = true;
        const row = document.getElementById(`survey-contact-${key}`);
        const existingError = document.getElementById(`survey-error-${key}`);

        const isError = (key === 'phone' && state.answers.contact[key] && !validatePhone(state.answers.contact[key])) ||
                        (key === 'email' && state.answers.contact[key] && !validateEmail(state.answers.contact[key]));

        if (row) {
          row.classList.toggle('error', isError);
        }

        const existingBadge = document.getElementById(`survey-badge-${key}`);
        if (existingBadge) existingBadge.remove();

        if (key !== 'address' && state.answers.contact[key]) {
          const badge = document.createElement('span');
          badge.id = `survey-badge-${key}`;
          badge.className = isError ? 'survey-invalid-badge' : 'survey-valid';
          badge.textContent = isError ? 'Invalid' : '✓';
          wrapper.appendChild(badge);
        }

        if (existingError) existingError.remove();

        if (isError) {
          const errorMsg = document.createElement('p');
          errorMsg.id = `survey-error-${key}`;
          errorMsg.className = 'survey-error-msg';
          errorMsg.textContent = key === 'phone'
            ? 'Please enter a valid phone number.'
            : 'Please enter a valid email address.';
          wrapper.after(errorMsg);
        }

        updateFooter();
      });

      wrapper.appendChild(input);
      container.appendChild(wrapper);
    });
  }

  function renderSocials(container) {
    const renderSocialsList = () => {
      // Clear and re-render
      const existingRows = container.querySelectorAll('.survey-social-row, .survey-chips-label, .survey-chips');
      existingRows.forEach(el => el.remove());

      // Render added socials
      state.answers.socials.forEach((social, index) => {
        const platformName = social.platform || social.label || '';
        const row = document.createElement('div');
        row.className = 'survey-social-row';

        const iconSpan = document.createElement('span');
        iconSpan.className = 'survey-social-icon';
        iconSpan.innerHTML = social.icon;
        row.appendChild(iconSpan);

        const platform = document.createElement('span');
        platform.className = 'survey-social-platform';
        platform.textContent = platformName;
        row.appendChild(platform);

        const input = document.createElement('input');
        input.className = 'survey-social-input';
        input.placeholder = social.placeholder;
        input.value = social.value;
        input.addEventListener('input', (e) => {
          const value = e.target.value;
          state.answers.socials[index].value = value;
          const validation = normalizeSocialUrlForPlatform(platformName, value);
          input.title = validation.ok ? '' : validation.error;
          input.classList.toggle('invalid-url', !validation.ok && !!value);
          scheduleSave();
        });

        input.addEventListener('blur', (e) => {
          const value = e.target.value.trim();
          const result = normalizeSocialUrlForPlatform(platformName, value);
          if (!result.ok) {
            input.classList.add('invalid-url');
            input.title = result.error;
          } else {
            state.answers.socials[index] = toNormalizedSocialEntry(
              SOCIAL_PLATFORMS.find(p => p.label === platformName) || { label: platformName, icon: social.icon, placeholder: social.placeholder },
              result.value
            );
            input.value = result.value;
            input.classList.remove('invalid-url');
            input.title = '';
            scheduleSave();
          }
        });

        // Apply initial validation state
        if (social.value && !normalizeSocialUrlForPlatform(platformName, social.value).ok) {
          input.classList.add('invalid-url');
        }

        row.appendChild(input);

        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'survey-remove-btn';
        removeBtn.textContent = '✕';
        removeBtn.addEventListener('click', () => {
          state.answers.socials.splice(index, 1);
          renderSocialsList();
          scheduleSave();
        });
        row.appendChild(removeBtn);

        container.appendChild(row);
      });

      // Render platform chips
      const label = document.createElement('p');
      label.className = 'survey-chips-label';
      label.textContent = state.answers.socials.length === 0 ? 'Select a platform to add' : 'Add another';
      container.appendChild(label);

      const chips = document.createElement('div');
      chips.className = 'survey-chips';

      SOCIAL_PLATFORMS
        .filter(platform => !state.answers.socials.find(s => (s.platform || s.label) === platform.label))
        .forEach(platform => {
          const chip = document.createElement('button');
          chip.type = 'button';
          chip.className = 'survey-chip';
          chip.innerHTML = `${platform.icon} ${platform.label}`;
          chip.addEventListener('click', () => {
            state.answers.socials.push(toNormalizedSocialEntry(platform, getSocialDefaultTemplate(platform.label)));
            renderSocialsList();
            setTimeout(() => {
              const inputs = container.querySelectorAll('.survey-social-input');
              if (inputs.length) inputs[inputs.length - 1].focus();
            }, 50);
            scheduleSave();
          });
          chips.appendChild(chip);
        });

      container.appendChild(chips);
    };

    renderSocialsList();
  }

  function renderBrandCheck(container) {
    const renderBrandOptions = () => {
      // Clear and re-render
      const existingElements = container.querySelectorAll('.survey-check-btn, .survey-logo-drop, .survey-logo-preview, .survey-input, #colors-container, .survey-chip');
      existingElements.forEach(el => el.remove());

      const options = [
        { label: 'Yes, I have a logo', value: 'logo' },
        { label: 'I have brand colors', value: 'colors' },
        { label: 'I have a slogan or tagline', value: 'slogan' },
        { label: 'None yet — build it for me', value: 'none' }
      ];

      options.forEach(option => {
        const button = document.createElement('button');
        button.type = 'button';

        // Check if disabled (when "none" is selected and this is logo/colors/slogan)
        const noneSelected = state.answers.brand.includes('none');
        const isDisabled = noneSelected && option.value !== 'none';

        button.className = 'survey-check-btn' + (state.answers.brand.includes(option.value) ? ' active' : '') + (isDisabled ? ' disabled' : '');
        button.disabled = isDisabled;
        button.innerHTML = `
          <span class="survey-checkbox">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3">
              <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
            </svg>
          </span>
          ${option.label}
        `;

        button.addEventListener('click', () => {
          if (isDisabled) return;

          if (state.answers.brand.includes(option.value)) {
            state.answers.brand = state.answers.brand.filter(v => v !== option.value);
          } else {
            // If selecting "none", clear other selections
            if (option.value === 'none') {
              state.answers.brand = ['none'];
            } else {
              // If selecting anything else, remove "none"
              state.answers.brand = state.answers.brand.filter(v => v !== 'none');
              state.answers.brand.push(option.value);
            }
          }
          renderBrandOptions();
        });

        container.appendChild(button);
      });

      // Logo uploader
      if (state.answers.brand.includes('logo')) {
        const dropZone = document.createElement('div');
        dropZone.className = 'survey-logo-drop';

        if (state.answers.logoFile) {
          dropZone.innerHTML = `
            <span style="font-size:1.25rem">🖼️</span>
            <div class="survey-logo-info">
              <p style="color:var(--survey-primary)">${state.answers.logoFile.name}</p>
            </div>
            <span class="survey-valid">✓</span>
          `;
        } else {
          dropZone.innerHTML = `
            <span style="font-size:1.25rem">🖼️</span>
            <div class="survey-logo-info">
              <p>Upload your logo</p>
              <span>PNG, SVG, PDF or AI file</span>
            </div>
            <span style="font-size:0.75rem;color:var(--survey-primary);font-weight:700">Browse</span>
          `;
        }

        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'image/*,.pdf,.svg';
        fileInput.style.display = 'none';

        fileInput.addEventListener('change', (e) => {
          const file = e.target.files[0];
          if (!file) return;

          const validation = validateFile(file);
          if (!validation.valid) {
            alert(validation.error);
            return;
          }

          const reader = new FileReader();
          reader.onload = (event) => {
            state.answers.logoFile = {
              name: file.name,
              url: event.target.result,
              type: file.type,
              file: file
            };
            renderBrandOptions();
          };
          reader.readAsDataURL(file);
        });

        dropZone.appendChild(fileInput);
        dropZone.addEventListener('click', () => fileInput.click());
        container.appendChild(dropZone);

        // Logo preview
        if (state.answers.logoFile) {
          const preview = document.createElement('div');
          preview.className = 'survey-logo-preview';

          if (state.answers.logoFile.type?.startsWith('image/')) {
            const img = document.createElement('img');
            img.src = state.answers.logoFile.url;
            img.alt = 'Logo';
            preview.appendChild(img);
          }

          const removeBtn = document.createElement('button');
          removeBtn.type = 'button';
          removeBtn.className = 'survey-remove-logo';
          removeBtn.textContent = 'Remove';
          removeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            state.answers.logoFile = null;
            renderBrandOptions();
          });
          preview.appendChild(removeBtn);

          container.appendChild(preview);
        }
      }

      // Brand colors input with color picker - Support multiple colors
      if (state.answers.brand.includes('colors')) {
        // Initialize a normalized hex array from any prior string/array shape.
        if (!Array.isArray(state.answers.brandColorsArray) || state.answers.brandColorsArray.length === 0) {
          state.answers.brandColorsArray = parseBrandColors(state.answers.brandColors);
        } else {
          state.answers.brandColorsArray = parseBrandColors(state.answers.brandColorsArray);
        }
        state.answers.brandColors = state.answers.brandColorsArray.join(',');

        const colorsContainer = document.createElement('div');
        colorsContainer.style.cssText = 'margin-top: 0.5rem;';
        colorsContainer.id = 'colors-container';

        // Title with hint
        const colorTitle = document.createElement('div');
        colorTitle.style.cssText = 'font-size: 0.7rem; font-weight: 700; color: var(--survey-gray-400); text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 0.75rem;';
        colorTitle.textContent = 'Click the color swatches to edit';
        colorsContainer.appendChild(colorTitle);

        // Render each color
        state.answers.brandColorsArray.forEach((color, index) => {
          const colorRow = document.createElement('div');
          colorRow.className = 'survey-color-row';

          // Color picker button with eye dropper icon
          const colorButton = document.createElement('button');
          colorButton.type = 'button';
          colorButton.className = 'survey-color-button';
          colorButton.style.background = normalizeHexColor(color) || '#2536EB';
          colorButton.innerHTML = `
            <svg class="survey-color-dropper" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M15 15l6 6m-6-6v4.8m0-4.8h4.8M19 9l-4-4m0 0l-3.172-3.172a2.828 2.828 0 1 0-4 4L11 9m4-4L9 11m-5 5v4h4l8-8-4-4-8 8z"/>
            </svg>
          `;

          const colorInput = document.createElement('input');
          colorInput.type = 'color';
          colorInput.className = 'survey-color-native';
          colorInput.value = normalizeHexColor(color) || '#2536EB';

          colorButton.addEventListener('click', () => {
            colorInput.click();
          });

          colorInput.addEventListener('change', (e) => {
            const hex = normalizeHexColor(e.target.value) || '#2536EB';
            colorButton.style.background = hex;
            hexInput.value = hex;
            state.answers.brandColorsArray[index] = hex;
            state.answers.brandColors = state.answers.brandColorsArray.join(',');
            scheduleSave();
          });

          const hexInput = document.createElement('input');
          hexInput.className = 'survey-input';
          hexInput.placeholder = '#2536EB';
          hexInput.value = normalizeHexColor(color) || '#2536EB';
          hexInput.style.flex = '1';

          hexInput.addEventListener('input', (e) => {
            const normalized = normalizeHexColor(e.target.value);
            if (normalized) {
              state.answers.brandColorsArray[index] = normalized;
              state.answers.brandColors = state.answers.brandColorsArray.join(',');
              colorInput.value = normalized;
              colorButton.style.background = normalized;
              e.target.value = normalized;
              scheduleSave();
            }
          });
          hexInput.addEventListener('blur', (e) => {
            const normalized = normalizeHexColor(e.target.value) || state.answers.brandColorsArray[index] || '#2536EB';
            e.target.value = normalized;
            colorInput.value = normalized;
            colorButton.style.background = normalized;
            state.answers.brandColorsArray[index] = normalized;
            state.answers.brandColors = state.answers.brandColorsArray.join(',');
            scheduleSave();
          });

          // Remove button (only show if more than 1 color)
          if (state.answers.brandColorsArray.length > 1) {
            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'survey-color-remove';
            removeBtn.innerHTML = '✕';
            removeBtn.addEventListener('click', () => {
              state.answers.brandColorsArray.splice(index, 1);
              state.answers.brandColors = state.answers.brandColorsArray.join(',');
              renderBrandOptions();
              scheduleSave();
            });
            colorRow.appendChild(colorButton);
            colorRow.appendChild(colorInput);
            colorRow.appendChild(hexInput);
            colorRow.appendChild(removeBtn);
          } else {
            colorRow.appendChild(colorButton);
            colorRow.appendChild(colorInput);
            colorRow.appendChild(hexInput);
          }

          colorsContainer.appendChild(colorRow);
        });

        // Add color button with + icon
        const addColorBtn = document.createElement('button');
        addColorBtn.type = 'button';
        addColorBtn.className = 'survey-add-color-btn';
        addColorBtn.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
          </svg>
          Add Another Color
        `;
        addColorBtn.addEventListener('click', () => {
          state.answers.brandColorsArray.push('#2536EB');
          state.answers.brandColors = state.answers.brandColorsArray.join(',');
          renderBrandOptions();
          scheduleSave();
        });

        colorsContainer.appendChild(addColorBtn);
        container.appendChild(colorsContainer);
      }

      // Brand slogan input
      if (state.answers.brand.includes('slogan')) {
        const input = document.createElement('input');
        input.className = 'survey-input';
        input.style.marginTop = '0.5rem';
        input.placeholder = 'Your slogan or tagline';
        input.value = state.answers.brandSlogan;
        input.addEventListener('input', (e) => {
          state.answers.brandSlogan = e.target.value;
        });
        container.appendChild(input);
      }
    };

    renderBrandOptions();
  }

  function renderUpload(container) {
    const dropZone = document.createElement('div');
    dropZone.className = 'survey-dropzone';
    dropZone.innerHTML = `
      <div class="survey-dropzone-icon">🖼️</div>
      <p>Drag & drop or click to browse</p>
      <span>Images, logos, PDFs — anything that represents your brand</span>
    `;

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.multiple = true;
    fileInput.accept = 'image/*,.pdf,.svg,.png,.jpg,.jpeg,.webp';
    fileInput.style.display = 'none';

    const addFiles = (files) => {
      Array.from(files).forEach(file => {
        const validation = validateFile(file);
        if (!validation.valid) {
          alert(validation.error);
          return;
        }

        const reader = new FileReader();
        reader.onload = (event) => {
          state.answers.files.push({
            name: file.name,
            size: file.size,
            url: event.target.result,
            type: file.type,
            file: file
          });
          renderThumbs();
        };
        reader.readAsDataURL(file);
      });
    };

    fileInput.addEventListener('change', (e) => addFiles(e.target.files));
    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.classList.add('drag-active');
    });

    dropZone.addEventListener('dragleave', () => {
      dropZone.classList.remove('drag-active');
    });

    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.classList.remove('drag-active');
      addFiles(e.dataTransfer.files);
    });

    dropZone.appendChild(fileInput);
    container.appendChild(dropZone);

    const grid = document.createElement('div');
    grid.className = 'survey-thumb-grid';
    grid.id = 'survey-thumb-grid';
    container.appendChild(grid);

    const optionalText = document.createElement('p');
    optionalText.style.cssText = 'font-size:0.75rem;color:var(--survey-gray-400);text-align:center;';
    optionalText.textContent = 'Optional — you can always send files later.';
    container.appendChild(optionalText);

    const renderThumbs = () => {
      grid.innerHTML = '';
      state.answers.files.forEach((file, index) => {
        const thumb = document.createElement('div');
        thumb.className = 'survey-thumb';

        if (file.type?.startsWith('image/')) {
          const img = document.createElement('img');
          img.src = file.url;
          img.alt = file.name;
          thumb.appendChild(img);
        } else {
          const icon = document.createElement('div');
          icon.className = 'survey-thumb-icon';
          icon.textContent = '📄';
          thumb.appendChild(icon);
        }

        const name = document.createElement('div');
        name.className = 'survey-thumb-name';
        name.textContent = file.name;
        thumb.appendChild(name);

        const removeBtn = document.createElement('button');
        removeBtn.type = 'button';
        removeBtn.className = 'survey-thumb-remove';
        removeBtn.textContent = '✕';
        removeBtn.addEventListener('click', () => {
          state.answers.files.splice(index, 1);
          renderThumbs();
        });
        thumb.appendChild(removeBtn);

        grid.appendChild(thumb);
      });
    };

    renderThumbs();
  }

  function renderReview(container) {
    const reviewContainer = document.createElement('div');
    reviewContainer.className = 'survey-review-container';

    const reviewData = [
      {
        label: 'Business Name',
        value: state.answers.businessName || '—',
        stepIndex: 0
      },
      {
        label: 'Industry',
        value: state.answers.industry === 'Other'
          ? state.answers.customIndustry || '—'
          : state.answers.industry || '—',
        stepIndex: 1
      },
      {
        label: 'Tagline',
        value: state.answers.tagline || '—',
        stepIndex: 2
      },
      {
        label: 'Services',
        value: state.answers.services || '—',
        stepIndex: 3
      },
      {
        label: 'Business Hours',
        value: formatHoursForReview(),
        stepIndex: 4
      },
      {
        label: 'Booking Options',
        value: state.answers.booking.length > 0
          ? state.answers.booking.map(v => {
              if (v === 'virtual') return 'Virtually';
              if (v === 'our_location') return 'At my location';
              if (v === 'client_location') return "At client's location";
              return v;
            }).join(', ')
          : '—',
        stepIndex: 5
      },
      {
        label: 'Contact Info',
        value: [
          state.answers.contact.phone && `📞 ${state.answers.contact.phone}`,
          state.answers.contact.email && `✉️ ${state.answers.contact.email}`,
          state.answers.contact.address && `📍 ${state.answers.contact.address}`
        ].filter(Boolean).join('\n') || '—',
        stepIndex: 6
      },
      {
        label: 'Social Media',
        value: state.answers.socials.length > 0
          ? state.answers.socials.map(s => `${s.platform || s.label || 'Social Link'}: ${s.value || 'Not set'}`).join('\n')
          : 'None added',
        stepIndex: 7
      },
      {
        label: 'Branding',
        value: state.answers.brand.length > 0
          ? state.answers.brand.map(b => {
              if (b === 'logo') return state.answers.logoFile ? '✓ Logo uploaded' : 'Logo selected';
              if (b === 'colors') return `✓ Brand colors: ${state.answers.brandColors || 'Not set'}`;
              if (b === 'slogan') return `✓ Slogan: ${state.answers.brandSlogan || 'Not set'}`;
              if (b === 'none') return 'Build it for me';
              return b;
            }).join('\n')
          : 'Build it for me',
        stepIndex: 8
      },
      {
        label: 'Files Uploaded',
        value: state.answers.files.length > 0
          ? `${state.answers.files.length} file(s) uploaded`
          : 'No files uploaded',
        stepIndex: 9
      },
      {
        label: 'Additional Notes',
        value: state.answers.extra || 'None',
        stepIndex: 10
      }
    ];

    reviewData.forEach(item => {
      const row = document.createElement('div');
      row.className = 'survey-review-row';

      const label = document.createElement('span');
      label.className = 'survey-review-label';
      label.textContent = item.label;

      const value = document.createElement('span');
      value.className = 'survey-review-value';
      value.style.whiteSpace = 'pre-line';
      value.textContent = item.value;

      const editBtn = document.createElement('button');
      editBtn.className = 'survey-review-edit';
      editBtn.textContent = 'Edit';
      editBtn.type = 'button';
      editBtn.addEventListener('click', async () => {
        // Visual feedback during save
        editBtn.disabled = true;
        const originalText = editBtn.textContent;
        editBtn.textContent = 'Saving...';

        // Wait for save to complete before navigating
        await saveProgressNow();

        // Restore button state before animation
        editBtn.disabled = false;
        editBtn.textContent = originalText;

        state.direction = -1;
        state.animating = true;
        const body = document.getElementById('survey-body');
        if (body) {
          body.classList.remove('survey-step-enter-fwd', 'survey-step-enter-back');
          body.classList.add('survey-step-exit-back');
        }
        setTimeout(() => {
          state.currentStep = item.stepIndex;
          render();
          if (body) {
            body.classList.remove('survey-step-exit-back');
            body.classList.add('survey-step-enter-back');
          }
          state.animating = false;
        }, 250);
      });

      row.appendChild(label);
      row.appendChild(value);
      row.appendChild(editBtn);
      reviewContainer.appendChild(row);
    });

    container.appendChild(reviewContainer);
  }

  function formatHoursForReview() {
    const daysWithHours = DAYS.filter(day => !state.answers.hours[day].closed);
    if (daysWithHours.length === 0) return 'Closed all days';
    if (daysWithHours.length === 7) {
      const first = state.answers.hours[DAYS[0]];
      return `Every day: ${formatTime(first.open)} - ${formatTime(first.close)}`;
    }
    return daysWithHours.map(day => {
      const h = state.answers.hours[day];
      return `${day}: ${formatTime(h.open)}-${formatTime(h.close)}`;
    }).join('\n');
  }

  // ============================================================================
  // AUTO-SAVE & PROGRESS RESUME
  // ============================================================================

  /**
   * Get the survey token from PHP-localized data
   */
  function getSurveyToken() {
    return (state.sessionData && state.sessionData.resume_token) || '';
  }

  /**
   * Serialize answers (exclude file blobs — those live in PHP session).
   */
  function serializeAnswers() {
    const a = state.answers;
    return {
      businessName:   a.businessName,
      industry:       a.industry,
      customIndustry: a.customIndustry,
      tagline:        a.tagline,
      services:       a.services,
      hours:          a.hours,
      booking:        a.booking,
      contact:        a.contact,
      socials:        normalizeSocialEntries(a.socials, false).entries,
      brand:          a.brand,
      brandColors:    a.brandColors,
      brandSlogan:    a.brandSlogan,
      extra:          a.extra,
      // NOTE: file/logo paths stored server-side — skip blobs
    };
  }

  /**
   * Restore serialized answers back into state.
   */
  function restoreAnswers(saved) {
    if (!saved || typeof saved !== 'object') return;
    const keys = ['businessName','industry','customIndustry','tagline','services',
                  'hours','booking','contact','socials','brand','brandColors','brandSlogan','extra'];
    keys.forEach(k => {
      if (saved[k] !== undefined) {
        state.answers[k] = saved[k];
      }
    });
    state.answers.industry = normalizeIndustryValue(state.answers.industry);
    if (Array.isArray(state.answers.socials)) {
      state.answers.socials = normalizeSocialEntries(state.answers.socials, false).entries;
    }
  }

  /**
   * Save progress to the server (debounced — fires 1.5s after the last change).
   */
  function scheduleSave() {
    const token = getSurveyToken();
    if (!token) return; // No token = no server-side saving

    clearTimeout(state.autoSaveTimer);
    state.autoSaveTimer = setTimeout(() => {
      saveProgressNow();
    }, 1500);
  }

  /**
   * Immediately persist current step + answers to the server.
   * Returns a Promise so callers can await completion.
   */
  function saveProgressNow() {
    const token = getSurveyToken();
    if (!token) return Promise.resolve(); // Return resolved promise if no token

    const cfg = state.sessionData;
    const payload = new FormData();
    payload.append('action',  'sec_save_survey_progress');
    payload.append('nonce',   cfg.nonce || '');
    payload.append('token',   token);
    payload.append('step',    state.currentStep);
    payload.append('answers', JSON.stringify(serializeAnswers()));

    // Return promise so callers can await completion
    return fetch(cfg.ajax_url || '/wp-admin/admin-ajax.php', {
      method: 'POST',
      body: payload,
      credentials: 'same-origin',
    }).catch(() => {/* silent — best-effort */});
  }

  /**
   * Check if all required fields are complete (used for resume logic)
   */
  function areAllRequiredStepsComplete() {
    const a = state.answers;

    // Check each required field
    if (!a.businessName || !a.businessName.trim()) return false;
    if (!a.industry || !a.industry.trim()) return false;
    if (a.industry === 'Other' && (!a.customIndustry || !a.customIndustry.trim())) return false;
    if (!a.tagline || !a.tagline.trim()) return false;
    if (!a.services || !a.services.trim()) return false;
    if (!a.booking || !Array.isArray(a.booking) || a.booking.length === 0) return false;
    if (!a.contact || (!a.contact.phone && !a.contact.email)) return false;

    return true;
  }

  /**
   * If the page was opened via a ?survey_token link, restore saved answers
   * and jump to the saved step (or review if all required fields complete).
   */
  function maybeResumeFromToken() {
    const cfg = state.sessionData;
    if (!cfg || !cfg.is_resume) return false;

    // Restore answers from PHP-injected data (populated server-side)
    if (cfg.resume_answers) {
      restoreAnswers(cfg.resume_answers);
    }

    // Check if all required fields are complete
    const allRequiredComplete = areAllRequiredStepsComplete();

    if (allRequiredComplete) {
      // User was on or past review - restore to review step (step 11, 0-indexed)
      state.currentStep = 11; // Review step is the last step (index 11)
    } else {
      // Incomplete survey - restore to last saved step
      const savedStep = Math.min(
        Math.max(0, parseInt(cfg.resume_step || 0, 10)),
        STEPS.length - 1
      );
      state.currentStep = savedStep;
    }

    state.welcomeShown = true; // Skip welcome splash on resume

    return true;
  }

  // ============================================================================
  // SUBMISSION
  // ============================================================================

  function submitSurvey() {
    const continueBtn = document.getElementById('survey-continue-btn');
    if (continueBtn) {
      continueBtn.disabled = true;
      continueBtn.innerHTML = 'Submitting... <span class="survey-loading"></span>';
    }

    const formData = new FormData();

    // Add action and nonce
    formData.append('action', 'sec_submit_survey');
    formData.append('nonce', state.sessionData.nonce || '');

    // Add session data from PHP
    if (state.sessionData.session) {
      formData.append('customer_id', state.sessionData.session.customer_id || '');
      formData.append('customer_name', state.sessionData.session.customer_name || '');
      formData.append('customer_email', state.sessionData.session.customer_email || '');
      formData.append('payment_amount', state.sessionData.session.payment_amount || 0);
      formData.append('session_id', state.sessionData.session.session_id || '');
    }

    // Add answer fields
    formData.append('business_name', state.answers.businessName);
    formData.append('industry', state.answers.industry);
    formData.append('custom_industry', state.answers.customIndustry);
    formData.append('tagline', state.answers.tagline);
    formData.append('services', state.answers.services);
    formData.append('hours', JSON.stringify(state.answers.hours));
    formData.append('booking', JSON.stringify(state.answers.booking));
    formData.append('contact_phone', state.answers.contact.phone);
    formData.append('contact_email', state.answers.contact.email);
    formData.append('contact_address', state.answers.contact.address);
    formData.append('socials', JSON.stringify(state.answers.socials));
    const socialValidation = normalizeSocialEntries(state.answers.socials, true);
    if (!socialValidation.ok) {
      alert(socialValidation.error);
      if (continueBtn) {
        continueBtn.disabled = false;
        continueBtn.innerHTML = 'Submit Survey';
      }
      return;
    }
    state.answers.socials = socialValidation.entries;
    formData.set('socials', JSON.stringify(socialValidation.entries));
    formData.append('brand', JSON.stringify(state.answers.brand));
    const normalizedBrandColors = parseBrandColors(state.answers.brandColorsArray || state.answers.brandColors).join(',');
    state.answers.brandColorsArray = parseBrandColors(normalizedBrandColors);
    state.answers.brandColors = normalizedBrandColors;
    formData.append('brand_colors', normalizedBrandColors);
    formData.append('brand_slogan', state.answers.brandSlogan);
    formData.append('extra', state.answers.extra);

    // Attach survey token so the server can mark it completed
    const surveyToken = getSurveyToken();
    if (surveyToken) {
      formData.append('survey_token', surveyToken);
    }

    // Add logo file
    if (state.answers.logoFile && state.answers.logoFile.file) {
      formData.append('logo', state.answers.logoFile.file);
    }

    // Add multiple files
    state.answers.files.forEach((fileObj, index) => {
      if (fileObj.file) {
        formData.append(`files[${index}]`, fileObj.file);
      }
    });

    // Submit via AJAX
    fetch(state.sessionData.ajax_url || '/wp-admin/admin-ajax.php', {
      method: 'POST',
      body: formData,
      credentials: 'same-origin'
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        showSuccess();
      } else {
        throw new Error(data.data?.message || 'Submission failed');
      }
    })
    .catch(error => {
      console.error('Survey submission error:', error);
      alert('There was an error submitting your survey. Please try again.');

      if (continueBtn) {
        continueBtn.disabled = false;
        continueBtn.textContent = 'Submit & Launch 🚀';
      }
    });
  }

  function showSuccess() {
    const answers = state.answers;
    const modal = document.getElementById('sec-survey-modal');

    if (!modal) return;

    modal.innerHTML = `
      <div class="survey-card">
        <div class="survey-body">
          <div class="survey-success">
            <div class="survey-success-icon">✓</div>
            <h2>You're all set!</h2>
            <p>We have everything we need to build <strong style="color:var(--survey-primary)">${answers.businessName}'s</strong> website.<br>Expect your preview within <strong style="color:var(--survey-gray-800)">48 hours</strong>.</p>
            <div class="survey-success-box">
              <p class="survey-success-row"><strong>Business:</strong> ${answers.businessName}</p>
              <p class="survey-success-row"><strong>Industry:</strong> ${answers.industry === 'Other' ? answers.customIndustry : answers.industry}</p>
              <p class="survey-success-row"><strong>Files uploaded:</strong> ${answers.files.length + (answers.logoFile ? 1 : 0)}</p>
              <p class="survey-success-row"><strong>Social pages:</strong> ${answers.socials.filter(s => s.value).length}</p>
            </div>
            <button type="button" id="survey-close-success" style="margin-top: 1.5rem; padding: 0.75rem 2rem; background: var(--survey-primary); color: white; border: none; border-radius: 0.5rem; font-weight: 600; cursor: pointer;">Close & View Launch Page</button>
          </div>
        </div>
      </div>
    `;

    // Add close button handler
    document.getElementById('survey-close-success').addEventListener('click', () => {
      closeModal();
    });
  }

  // ============================================================================
  // INITIALIZATION
  // ============================================================================

  function init() {
    // Check if overlay exists (might be output by PHP)
    let overlay = document.getElementById('sec-survey-modal-overlay');

    if (!overlay) {
      // Create overlay if it doesn't exist
      overlay = document.createElement('div');
      overlay.id = 'sec-survey-modal-overlay';
      overlay.style.display = 'none';
      document.body.appendChild(overlay);
    }

    // Check if modal content exists
    let modalContainer = document.getElementById('sec-survey-modal');

    if (!modalContainer || modalContainer.innerHTML.trim() === '') {
      // Create or populate modal content
      const modalHTML = `
        <div class="survey-card">
          <div class="survey-header">
            <div class="survey-header-top">
              <span class="survey-label">Website Launch</span>
              <span class="survey-step-count" id="survey-step-count">1 of 11</span>
            </div>
            <div class="survey-progress-track">
              <div class="survey-progress-fill" id="survey-progress-fill" style="width:9%"></div>
            </div>
          </div>
          <div class="survey-body" id="survey-body"></div>
          <div class="survey-footer">
            <button type="button" class="survey-back" id="survey-back-btn" style="display:none">← Back</button>
            <button type="button" class="survey-btn-primary" id="survey-continue-btn">Continue →</button>
          </div>
          <div class="survey-optional-hint" id="survey-optional-hint"></div>
        </div>
      `;

      if (!modalContainer) {
        modalContainer = document.createElement('div');
        modalContainer.id = 'sec-survey-modal';
        overlay.appendChild(modalContainer);
      }

      modalContainer.innerHTML = modalHTML;
    }

    // Event listeners
    document.getElementById('survey-back-btn').addEventListener('click', () => goToStep(-1));
    document.getElementById('survey-continue-btn').addEventListener('click', () => goToStep(1));

    // Close on ESC key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && overlay.style.display === 'flex') {
        closeModal();
      }
    });

    // Expose global function to open modal
    window.secOpenSurveyModal = openModal;
    window.secCloseSurveyModal = closeModal;

    // Restore saved progress if the page was opened via a tokenized link
    const wasResumed = maybeResumeFromToken();

    // Auto-open if configured
    if (state.sessionData.auto_open) {
      setTimeout(() => {
        openModal();
        // Show a "welcome back" banner if resuming
        if (wasResumed) {
          setTimeout(showResumeBanner, 600);
        }
      }, 1000);
    }
  }

  /**
   * Show a small toast-style banner informing the user their progress was restored.
   */
  function showResumeBanner() {
    const existing = document.getElementById('sec-survey-resume-banner');
    if (existing) return;

    const banner = document.createElement('div');
    banner.id = 'sec-survey-resume-banner';
    banner.style.cssText = [
      'position:fixed', 'bottom:24px', 'left:50%', 'transform:translateX(-50%)',
      'background:#2536EB', 'color:#fff', 'padding:12px 24px', 'border-radius:10px',
      'font-family:DM Sans,sans-serif', 'font-size:14px', 'font-weight:600',
      'box-shadow:0 4px 16px rgba(37,54,235,0.4)', 'z-index:9999999',
      'display:flex', 'align-items:center', 'gap:10px',
      'animation:secBannerIn 0.4s ease',
    ].join(';');

    // Inject keyframes once
    if (!document.getElementById('sec-banner-keyframes')) {
      const style = document.createElement('style');
      style.id = 'sec-banner-keyframes';
      style.textContent = '@keyframes secBannerIn{from{opacity:0;transform:translateX(-50%) translateY(20px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}';
      document.head.appendChild(style);
    }

    banner.innerHTML = `<span>✅ Progress restored — you're on step ${state.currentStep + 1} of ${STEPS.length}</span>`;
    document.body.appendChild(banner);

    setTimeout(() => {
      banner.style.transition = 'opacity 0.4s';
      banner.style.opacity = '0';
      setTimeout(() => banner.remove(), 450);
    }, 4000);
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
