/**
 * Stripe Embedded Checkout - Membership Form JavaScript
 */

// ============================================
// BOT PROTECTION — client-side layer
// ============================================

// Records the timestamp when the form first becomes interactive
let SEC_FORM_LOAD_TIME = Date.now();

// Simple in-memory rate limiter: max 3 submission attempts per 60 seconds
const SEC_RATE_LIMIT = { attempts: 0, resetAt: Date.now() + 60000 };

function secCheckRateLimit() {
    const now = Date.now();
    if (now > SEC_RATE_LIMIT.resetAt) {
        SEC_RATE_LIMIT.attempts = 0;
        SEC_RATE_LIMIT.resetAt = now + 60000;
    }
    SEC_RATE_LIMIT.attempts++;
    return SEC_RATE_LIMIT.attempts <= 3;
}

// ============================================
// VALIDATION HELPERS
// ============================================

// Common email providers and their correct domains
const SEC_KNOWN_PROVIDERS = {
    'gmail': 'gmail.com',
    'yahoo': 'yahoo.com',
    'hotmail': 'hotmail.com',
    'outlook': 'outlook.com',
    'icloud': 'icloud.com',
    'aol': 'aol.com',
    'protonmail': 'protonmail.com',
    'mail': 'mail.com',
    'zoho': 'zoho.com',
    'ymail': 'ymail.com',
    'live': 'live.com',
    'msn': 'msn.com'
};

// Common misspellings of provider names (maps typo -> correct name)
const SEC_PROVIDER_TYPOS = {
    // Gmail typos
    'gmial': 'gmail', 'gmal': 'gmail', 'gmai': 'gmail', 'gamil': 'gmail',
    'gnail': 'gmail', 'gmali': 'gmail', 'gmil': 'gmail', 'gimail': 'gmail',
    'gemail': 'gmail', 'gmaill': 'gmail', 'gmaiil': 'gmail', 'ggmail': 'gmail',
    // Yahoo typos
    'yaho': 'yahoo', 'yahooo': 'yahoo', 'yahho': 'yahoo', 'yhaoo': 'yahoo',
    'yaoo': 'yahoo', 'yhoo': 'yahoo', 'yahooi': 'yahoo',
    // Hotmail typos
    'hotmal': 'hotmail', 'hotmai': 'hotmail', 'hotmial': 'hotmail',
    'hotmil': 'hotmail', 'hotmall': 'hotmail', 'hotmaill': 'hotmail',
    'htmail': 'hotmail', 'hotamil': 'hotmail', 'hotmmail': 'hotmail',
    // Outlook typos
    'outlok': 'outlook', 'outloo': 'outlook', 'outlookk': 'outlook',
    'outllok': 'outlook', 'outlok': 'outlook', 'outook': 'outlook',
    'oulook': 'outlook', 'otlook': 'outlook', 'outloook': 'outlook',
    // iCloud typos
    'icoud': 'icloud', 'iclud': 'icloud', 'iclooud': 'icloud',
    'iclod': 'icloud', 'icluod': 'icloud', 'icolud': 'icloud',
    // AOL typos
    'ao': 'aol', 'ail': 'aol', 'aool': 'aol',
    // Live typos
    'liv': 'live', 'livee': 'live', 'liive': 'live'
};

// Common TLD typos (maps typo -> correct TLD)
const SEC_TLD_TYPOS = {
    'con': 'com', 'cim': 'com', 'com': 'com', 'ocm': 'com', 'om': 'com',
    'cpm': 'com', 'vom': 'com', 'xom': 'com', 'coм': 'com', 'comm': 'com',
    'cm': 'com', 'co': 'com', 'comp': 'com', 'coom': 'com', 'comn': 'com',
    'conm': 'com', 'como': 'com', 'clm': 'com', 'ckom': 'com',
    'ner': 'net', 'nett': 'net', 'ney': 'net', 'met': 'net', 'neet': 'net',
    'ogr': 'org', 'rog': 'org', 'orgg': 'org', 'og': 'org', 'ogg': 'org',
    'edi': 'edu', 'ed': 'edu', 'eduu': 'edu',
    'gob': 'gov', 'goov': 'gov',
    'ifo': 'info', 'inf': 'info'
};

// Valid common TLDs (to not flag custom domains incorrectly)
const SEC_VALID_TLDS = [
    'com', 'net', 'org', 'edu', 'gov', 'mil', 'int',
    'co', 'io', 'me', 'us', 'uk', 'ca', 'au', 'de', 'fr', 'es', 'it', 'nl', 'be', 'ch', 'at',
    'jp', 'cn', 'kr', 'in', 'ru', 'br', 'mx', 'ar', 'pl', 'se', 'no', 'dk', 'fi',
    'info', 'biz', 'name', 'pro', 'mobi', 'asia', 'tel', 'jobs', 'travel',
    'app', 'dev', 'tech', 'online', 'store', 'shop', 'site', 'website', 'blog',
    'cloud', 'email', 'live', 'tv', 'cc', 'ws', 'bz', 'club', 'xyz', 'top'
];

/**
 * Validate email address with smart typo detection
 * Catches typos in common providers while allowing custom domains
 */
function secValidateEmail(email) {
    email = email.toLowerCase().trim();

    // Basic format check (require at least 2 chars for TLD)
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
        return { valid: false, error: 'Please enter a valid email address.' };
    }

    const domain = email.split('@')[1];
    const domainParts = domain.split('.');
    const tld = domainParts.pop();
    const domainName = domainParts.join('.'); // Handle subdomains like mail.google.com

    // Check for provider name typos
    let suggestedProvider = null;
    let suggestedTld = null;

    // Is the domain name a known typo of a common provider?
    if (SEC_PROVIDER_TYPOS[domainName]) {
        suggestedProvider = SEC_PROVIDER_TYPOS[domainName];
    }

    // Is the TLD a known typo?
    if (SEC_TLD_TYPOS[tld] && tld !== SEC_TLD_TYPOS[tld]) {
        suggestedTld = SEC_TLD_TYPOS[tld];
    }

    // If we found a provider typo, suggest the correct domain (non-blocking — user can still proceed)
    if (suggestedProvider) {
        const correctDomain = SEC_KNOWN_PROVIDERS[suggestedProvider];
        const suggestion = email.replace(domain, correctDomain);
        return {
            valid: true,   // don't block submission — just nudge
            suggestion: suggestion
        };
    }

    // If the domain name matches a known provider exactly but TLD is wrong
    if (SEC_KNOWN_PROVIDERS[domainName] && suggestedTld) {
        const correctDomain = SEC_KNOWN_PROVIDERS[domainName];
        const suggestion = email.replace(domain, correctDomain);
        return {
            valid: true,   // non-blocking nudge
            suggestion: suggestion
        };
    }

    // For non-provider domains, just check if TLD is obviously invalid
    if (suggestedTld && !SEC_VALID_TLDS.includes(tld)) {
        return {
            valid: false,
            error: '".' + tld + '" doesn\'t look right. Did you mean .' + suggestedTld + '?',
            suggestion: email.split('@')[0] + '@' + domainName + '.' + suggestedTld
        };
    }

    // TLD length check (valid TLDs are 2-6 chars typically)
    if (tld.length < 2 || tld.length > 10) {
        return { valid: false, error: 'Please check your email domain.' };
    }

    return { valid: true };
}

/**
 * Validate phone number (US/Canada format)
 */
function secValidatePhone(phone) {
    // Strip all non-digits
    const digits = phone.replace(/\D/g, '');

    // US/Canada: 10 digits, or 11 with country code 1
    if (digits.length === 10) {
        return {
            valid: true,
            formatted: '(' + digits.slice(0,3) + ') ' + digits.slice(3,6) + '-' + digits.slice(6)
        };
    }
    if (digits.length === 11 && digits[0] === '1') {
        return {
            valid: true,
            formatted: '(' + digits.slice(1,4) + ') ' + digits.slice(4,7) + '-' + digits.slice(7)
        };
    }

    if (digits.length < 10) {
        return { valid: false, error: 'Phone number must have at least 10 digits.' };
    }
    if (digits.length > 11) {
        return { valid: false, error: 'Phone number has too many digits.' };
    }

    return { valid: false, error: 'Please enter a valid phone number.' };
}

/**
 * Format phone input as user types
 */
function secFormatPhoneInput(input) {
    let digits = input.value.replace(/\D/g, '');

    // Limit to 10 digits (or 11 if starts with 1)
    if (digits.length > 0 && digits[0] === '1') {
        digits = digits.slice(0, 11);
    } else {
        digits = digits.slice(0, 10);
    }

    // Format as (XXX) XXX-XXXX
    let formatted = '';
    if (digits.length > 0) {
        // Handle country code
        let start = 0;
        if (digits.length === 11 && digits[0] === '1') {
            start = 1;
        }

        const areaCode = digits.slice(start, start + 3);
        const prefix = digits.slice(start + 3, start + 6);
        const line = digits.slice(start + 6, start + 10);

        if (digits.length <= start + 3) {
            formatted = digits.slice(start);
        } else if (digits.length <= start + 6) {
            formatted = '(' + areaCode + ') ' + prefix;
        } else {
            formatted = '(' + areaCode + ') ' + prefix + '-' + line;
        }
    }

    input.value = formatted;
}

// US States for validation
const SEC_US_STATES = [
    'AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN',
    'IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH',
    'NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT',
    'VT','VA','WA','WV','WI','WY'
];

/**
 * Validate address fields (plausibility checks)
 */
function secValidateAddress(street, city, state, zip) {
    const errors = [];

    // Street address should contain at least one number
    if (!/\d/.test(street)) {
        errors.push('Street address should include a street number.');
    }

    // Street should have some letters too (not just numbers)
    if (!/[a-zA-Z]/.test(street)) {
        errors.push('Street address should include a street name.');
    }

    // City should be letters, spaces, hyphens, apostrophes only
    if (!/^[a-zA-Z\s\-'.]+$/.test(city) || city.trim().length < 2) {
        errors.push('Please enter a valid city name.');
    }

    // State validation - accept 2-letter abbreviation
    const stateUpper = state.toUpperCase().trim();
    if (stateUpper.length === 2 && !SEC_US_STATES.includes(stateUpper)) {
        errors.push('Please enter a valid US state abbreviation (e.g., NY, CA).');
    } else if (stateUpper.length < 2) {
        errors.push('Please enter a state abbreviation.');
    }

    // ZIP code format (5 digits or 5+4 format)
    const zipTrimmed = zip.trim();
    if (!/^\d{5}(-\d{4})?$/.test(zipTrimmed)) {
        errors.push('Please enter a valid ZIP code (e.g., 12345 or 12345-6789).');
    }

    return { valid: errors.length === 0, errors: errors };
}

// ============================================
// CORE FUNCTIONALITY
// ============================================

// Refresh nonce to handle cached pages
async function secRefreshNonce() {
    try {
        const response = await fetch(sec_ajax.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'action=sec_refresh_nonce',
            credentials: 'same-origin'
        });
        const data = await response.json();
        if (data.success && data.data.nonce) {
            sec_ajax.nonce = data.data.nonce;
            return true;
        }
    } catch (e) {
        console.error('Nonce refresh failed:', e);
    }
    return false;
}

// Submit contact form and create checkout session
async function secSubmitContactForm() {
    const btn = document.getElementById('sec-submit-btn');
    const errorEl = document.getElementById('sec-form-error');

    // Clear previous errors
    errorEl.style.display = 'none';
    document.querySelectorAll('.sec-input-error').forEach(el => el.classList.remove('sec-input-error'));

    // Gather fields
    const fields = {
        full_name: document.getElementById('sec-full-name'),
        business_name: document.getElementById('sec-business-name'),
        email: document.getElementById('sec-email'),
        phone: document.getElementById('sec-phone'),
        street_address: document.getElementById('sec-address'),
        city: document.getElementById('sec-city'),
        state: document.getElementById('sec-state'),
        zip_code: document.getElementById('sec-zip')
    };

    // Validate required fields
    let hasError = false;
    const errors = [];

    for (const input of Object.values(fields)) {
        if (!input.value.trim()) {
            input.classList.add('sec-input-error');
            hasError = true;
        }
    }

    if (hasError) {
        errors.push('Please fill in all required fields.');
    }

    // --- Bot protection checks ---
    // 1. Honeypot: hidden field must remain empty; bots fill it, humans don't
    const honeypot = document.getElementById('sec-hp-field');
    if (honeypot && honeypot.value.trim() !== '') {
        // Silent fail — do not reveal why to the bot
        btn.disabled = true;
        btn.textContent = 'Processing...';
        setTimeout(() => { btn.disabled = false; btn.textContent = 'Continue to Checkout'; }, 3500);
        return;
    }

    // 2. Timing: human users take at least 3 seconds to fill a form
    const elapsed = Date.now() - SEC_FORM_LOAD_TIME;
    if (elapsed < 3000) {
        errors.push('Please review your details before submitting.');
        hasError = true;
    }

    // 3. Client-side rate limiting — max 3 attempts per minute
    if (!secCheckRateLimit()) {
        errors.push('Too many attempts. Please wait a moment before trying again.');
        hasError = true;
    }

    // Email validation with TLD and typo checking
    if (fields.email.value.trim()) {
        const emailResult = secValidateEmail(fields.email.value.trim());
        if (!emailResult.valid) {
            fields.email.classList.add('sec-input-error');
            errors.push(emailResult.error);
            hasError = true;
        }
        // Non-blocking suggestion chip is handled live (see secInitEmailSuggestion)
    }

    // Phone validation
    if (fields.phone.value.trim()) {
        const phoneResult = secValidatePhone(fields.phone.value.trim());
        if (!phoneResult.valid) {
            fields.phone.classList.add('sec-input-error');
            errors.push(phoneResult.error);
            hasError = true;
        }
    }

    // Address validation
    if (fields.street_address.value.trim() && fields.city.value.trim() &&
        fields.state.value.trim() && fields.zip_code.value.trim()) {
        const addressResult = secValidateAddress(
            fields.street_address.value.trim(),
            fields.city.value.trim(),
            fields.state.value.trim(),
            fields.zip_code.value.trim()
        );
        if (!addressResult.valid) {
            hasError = true;
            addressResult.errors.forEach(err => errors.push(err));
            // Highlight specific fields based on error messages
            if (addressResult.errors.some(e => e.includes('street') || e.includes('Street'))) {
                fields.street_address.classList.add('sec-input-error');
            }
            if (addressResult.errors.some(e => e.includes('city') || e.includes('City'))) {
                fields.city.classList.add('sec-input-error');
            }
            if (addressResult.errors.some(e => e.includes('state') || e.includes('State'))) {
                fields.state.classList.add('sec-input-error');
            }
            if (addressResult.errors.some(e => e.includes('ZIP'))) {
                fields.zip_code.classList.add('sec-input-error');
            }
        }
    }

    if (hasError) {
        errorEl.textContent = errors.join(' ');
        errorEl.style.display = 'block';
        return;
    }

    // Check AJAX config
    if (!sec_ajax || !sec_ajax.ajax_url || !sec_ajax.nonce) {
        errorEl.textContent = 'Configuration error. Please refresh the page.';
        errorEl.style.display = 'block';
        return;
    }

    // Disable button and show loading
    btn.disabled = true;
    btn.textContent = 'Processing...';

    // Refresh nonce to handle cached pages
    await secRefreshNonce();

    const formData = new FormData();
    formData.append('action', 'create_stripe_checkout');
    formData.append('nonce', sec_ajax.nonce);
    // Honeypot — always empty for real users; server rejects if populated
    formData.append('website_url', '');
    for (const [key, input] of Object.entries(fields)) {
        formData.append(key, input.value.trim());
    }

    fetch(sec_ajax.ajax_url, {
        method: 'POST',
        body: formData,
        credentials: 'same-origin'
    })
    .then(response => {
        if (!response.ok) throw new Error('Network response was not ok');
        return response.json();
    })
    .then(data => {
        if (data.success && data.data.client_secret) {
            secTrackEvent('checkout_started', 'membership');
            // Mount Stripe Embedded Checkout inline — no redirect
            secMountEmbeddedCheckout(
                data.data.client_secret,
                data.data.session_id,
                data.data.token
            );
        } else {
            btn.disabled = false;
            btn.textContent = 'Continue to Checkout';
            errorEl.textContent = (data.data && typeof data.data === 'string') ? data.data : 'Error creating checkout session. Please try again.';
            errorEl.style.display = 'block';
        }
    })
    .catch(error => {
        console.error('Checkout error:', error);
        btn.disabled = false;
        btn.textContent = 'Continue to Checkout';
        errorEl.textContent = 'Network error. Please check your connection and try again.';
        errorEl.style.display = 'block';
    });
}

// ============================================
// INLINE STRIPE EMBEDDED CHECKOUT
// Mounts Stripe's UI on the same page,
// no redirect to /checkout/
// ============================================

let secStripeCheckoutInstance = null;

async function secMountEmbeddedCheckout(clientSecret, sessionId, token) {
    const formContainer = document.querySelector('.sec-form-container');

    // ── 1. Build the shell invisibly (opacity:0, no display change yet) ──
    // The shell takes the same space as the form so the page height
    // doesn't change and there's no layout jump.
    let shell = document.getElementById('sec-embedded-checkout-shell');
    if (!shell) {
        shell = document.createElement('div');
        shell.id = 'sec-embedded-checkout-shell';
        shell.style.cssText = 'opacity:0;transition:opacity 0.4s ease;';
        shell.innerHTML = `
            <div id="sec-embedded-checkout-inner" style="
                max-width: 640px;
                margin: 0 auto;
                padding: 0 16px;
                font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
            ">
                <div id="sec-embedded-checkout-header" style="
                    background: linear-gradient(135deg, #2536EB, #3d4ef0);
                    border-radius: 16px 16px 0 0;
                    padding: 28px 28px 24px;
                    color: white;
                    text-align: center;
                ">
                    <div style="font-size:13px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;opacity:.85;margin-bottom:6px;">
                        Secure Payment
                    </div>
                    <div style="font-size:28px;font-weight:800;" id="sec-checkout-amount-display"></div>
                    <div style="font-size:14px;opacity:.9;margin-top:4px;" id="sec-checkout-name-display"></div>
                </div>
                <div id="sec-stripe-mount-point" style="
                    background: #fff;
                    border-radius: 0 0 16px 16px;
                    box-shadow: 0 10px 40px rgba(37,54,235,0.12);
                    padding: 28px;
                    border: 1px solid #e5e7eb;
                    border-top: none;
                    min-height: 420px;
                "></div>
            </div>`;
        // Insert in the same position as the form — page height stays identical
        if (formContainer && formContainer.parentNode) {
            formContainer.parentNode.insertBefore(shell, formContainer.nextSibling);
        } else {
            document.body.appendChild(shell);
        }
    }

    // Populate header
    const amountEl = document.getElementById('sec-checkout-amount-display');
    const nameEl   = document.getElementById('sec-checkout-name-display');
    if (amountEl && sec_ajax.total_display)  amountEl.textContent = sec_ajax.total_display;
    if (nameEl   && sec_ajax.service_name)   nameEl.textContent   = sec_ajax.service_name;

    // ── 2. Init Stripe in the background while the form is still visible ──
    if (!window.Stripe) {
        console.error('SEC: Stripe.js not loaded');
        return;
    }

    let checkoutInstance;
    try {
        const stripe = Stripe(sec_ajax.publishable_key);
        checkoutInstance = await stripe.initEmbeddedCheckout({
            clientSecret: clientSecret,
            onComplete: () => secHandlePaymentComplete(sessionId, token)
        });
    } catch (e) {
        console.error('SEC: Stripe init failed', e);
        document.getElementById('sec-stripe-mount-point').innerHTML =
            '<p style="color:#ef4444;padding:20px;text-align:center;">Payment form failed to load. Please refresh and try again.</p>';
        return;
    }

    // ── 3. Mount Stripe (still invisible) so its iframe is ready ──
    checkoutInstance.mount('#sec-stripe-mount-point');
    secStripeCheckoutInstance = checkoutInstance;

    // ── 4. Cross-fade: fade form out, fade shell in simultaneously ──
    // This keeps total page height constant — zero layout shift.
    if (formContainer) {
        formContainer.style.transition = 'opacity 0.35s ease';
        formContainer.style.opacity   = '0';
    }
    // Short delay so Stripe iframe has a frame to render before we reveal
    await new Promise(r => setTimeout(r, 120));

    if (formContainer) formContainer.style.display = 'none';
    shell.style.opacity = '1';

    // ── 5. Scroll only after the swap is visible — smooth and purposeful ──
    shell.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ============================================
// POST-PAYMENT HANDLER (no redirect)
// ============================================

async function secHandlePaymentComplete(sessionId, token) {
    // 1. Unmount Stripe widget and show a brief loading state
    if (secStripeCheckoutInstance) {
        secStripeCheckoutInstance.destroy();
        secStripeCheckoutInstance = null;
    }

    const shell = document.getElementById('sec-embedded-checkout-shell');
    if (shell) {
        shell.innerHTML = `
            <div style="text-align:center;padding:60px 20px;font-family:'DM Sans',sans-serif;">
                <div style="width:48px;height:48px;border:4px solid #e5e7eb;border-top-color:#2536EB;
                            border-radius:50%;animation:sec-spin 0.8s linear infinite;margin:0 auto 20px;"></div>
                <p style="color:#6b7280;font-size:15px;">Confirming your payment…</p>
            </div>`;
    }

    // 2. Notify PHP to process the completed session (save customer, send email, create survey token)
    try {
        const fd = new FormData();
        fd.append('action',     'sec_complete_embedded_checkout');
        fd.append('nonce',      sec_ajax.nonce);
        fd.append('session_id', sessionId);
        fd.append('token',      token);

        const res  = await fetch(sec_ajax.ajax_url, { method: 'POST', body: fd, credentials: 'same-origin' });
        const data = await res.json();

        if (data.success) {
            secTrackEvent('purchase', 'membership');
            secShowInlineThankYou(data.data);
        } else {
            // Payment went through but post-processing failed — still show thank-you
            secShowInlineThankYou({ survey_token: '' });
            console.warn('SEC post-payment processing issue:', data.data);
        }
    } catch (e) {
        console.error('SEC: post-payment handler error', e);
        secShowInlineThankYou({ survey_token: '' });
    }
}

// ============================================
// INLINE THANK-YOU + SURVEY TRIGGER
// ============================================

function secShowInlineThankYou(responseData) {
    const shell = document.getElementById('sec-embedded-checkout-shell');
    if (shell) {
        shell.innerHTML = `
            <div style="max-width:520px;margin:40px auto;padding:0 16px;font-family:'DM Sans',sans-serif;text-align:center;">
                <div style="background:#fff;border-radius:20px;padding:48px 36px;box-shadow:0 10px 40px rgba(37,54,235,0.12);border:1px solid #e5e7eb;">
                    <div style="width:80px;height:80px;background:linear-gradient(135deg,#22c55e,#10b981);border-radius:50%;
                                display:flex;align-items:center;justify-content:center;margin:0 auto 24px;font-size:36px;color:white;">✓</div>
                    <h2 style="margin:0 0 12px;font-size:1.75rem;font-weight:800;color:#1f2937;">Payment Successful!</h2>
                    <p style="margin:0 0 28px;color:#6b7280;font-size:1rem;line-height:1.6;">
                        Thank you! We're setting up your account now.<br>
                        Next, let's get your website details sorted.
                    </p>
                    <button id="sec-start-survey-btn"
                        style="display:inline-block;background:#2536EB;color:#fff;border:none;border-radius:10px;
                               padding:15px 36px;font-family:'DM Sans',sans-serif;font-size:1rem;font-weight:700;
                               cursor:pointer;transition:all .3s ease;box-shadow:0 4px 14px rgba(37,54,235,0.35);">
                        Continue to Website Survey →
                    </button>
                    <p style="margin:16px 0 0;font-size:13px;color:#9ca3af;">
                        Takes about 5 minutes • Your progress is saved automatically
                    </p>
                </div>
            </div>`;
    }

    // Wire up the survey button
    const surveyBtn = document.getElementById('sec-start-survey-btn');
    if (surveyBtn) {
        surveyBtn.addEventListener('mouseenter', () => {
            surveyBtn.style.background = '#1a28b8';
            surveyBtn.style.transform  = 'translateY(-2px)';
        });
        surveyBtn.addEventListener('mouseleave', () => {
            surveyBtn.style.background = '#2536EB';
            surveyBtn.style.transform  = 'translateY(0)';
        });
        surveyBtn.addEventListener('click', () => {
            // Update the global secSurveyData with the returned session info
            if (responseData && window.secSurveyData) {
                if (responseData.customer_name)  secSurveyData.session.customer_name  = responseData.customer_name;
                if (responseData.business_name)  secSurveyData.session.business_name  = responseData.business_name;
                if (responseData.customer_email) secSurveyData.session.customer_email = responseData.customer_email;
                if (responseData.customer_id)    secSurveyData.session.customer_id    = responseData.customer_id;
                if (responseData.payment_amount) secSurveyData.session.payment_amount = responseData.payment_amount;
                if (responseData.session_id)     secSurveyData.session.session_id     = responseData.session_id;
                if (responseData.survey_token)   secSurveyData.resume_token           = responseData.survey_token;
            }

            // Open the survey modal
            if (typeof window.secOpenSurveyModal === 'function') {
                window.secOpenSurveyModal();
            } else {
                // Fallback: survey JS not yet loaded — inject it
                const overlay = document.getElementById('sec-survey-modal-overlay');
                if (overlay) {
                    overlay.style.display = 'flex';
                    document.body.style.overflow = 'hidden';
                }
            }
        });
    }

    // Scroll to thank-you card
    if (shell) shell.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

// Show thank-you popup if payment_complete param is present
function secCheckPaymentComplete() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('payment_complete') === '1') {
        const overlay = document.getElementById('sec-thankyou-overlay');
        if (overlay) {
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';

            // Close on click outside
            overlay.addEventListener('click', function(e) {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });

            // Close on Escape
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    overlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
        }

        // Clean URL
        if (window.history && window.history.replaceState) {
            const cleanUrl = window.location.pathname;
            window.history.replaceState({}, document.title, cleanUrl);
        }
    }
}

// Analytics tracking
function secTrackEvent(eventName, label) {
    try {
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, {
                'event_category': 'Stripe Checkout',
                'event_label': label
            });
        }
        if (typeof fbq !== 'undefined') {
            fbq('track', eventName, { content_type: 'product', content_category: label });
        }
    } catch (e) {
        // Silent fail for analytics
    }
}

// ============================================
// LIVE "DID YOU MEAN?" EMAIL SUGGESTION CHIP
// ============================================

/**
 * Injects an inline suggestion chip beneath the email field.
 * The chip appears automatically while the user types and disappears
 * once they accept or clear it. Clicking the chip auto-fills the field.
 */
function secInitEmailSuggestion() {
    const emailInput = document.getElementById('sec-email');
    if (!emailInput) return;

    // Create suggestion element
    const chip = document.createElement('div');
    chip.id = 'sec-email-suggestion';
    chip.style.cssText = [
        'display:none',
        'margin-top:6px',
        'padding:7px 12px',
        'background:#fffbeb',
        'border:1px solid #fde68a',
        'border-radius:7px',
        'font-size:13px',
        'color:#92400e',
        'cursor:pointer',
        'transition:background 0.15s ease',
        'user-select:none',
        'line-height:1.4',
    ].join(';');
    chip.setAttribute('role', 'button');
    chip.setAttribute('tabindex', '0');
    chip.setAttribute('aria-label', 'Accept email suggestion');

    emailInput.parentNode.appendChild(chip);

    let currentSuggestion = '';

    function showChip(suggestion) {
        currentSuggestion = suggestion;
        chip.innerHTML = '✉️ Did you mean <strong>' + suggestion + '</strong>? <span style="color:#b45309;text-decoration:underline;margin-left:4px;">Click to use</span>';
        chip.style.display = 'block';
    }

    function hideChip() {
        currentSuggestion = '';
        chip.style.display = 'none';
    }

    function applyChip() {
        if (!currentSuggestion) return;
        emailInput.value = currentSuggestion;
        hideChip();
        emailInput.classList.remove('sec-input-error');
        // Remove any form-level error that mentioned the email
        const errorEl = document.getElementById('sec-form-error');
        if (errorEl && errorEl.textContent.toLowerCase().includes('email')) {
            errorEl.style.display = 'none';
        }
        emailInput.focus();
    }

    // Hover effect
    chip.addEventListener('mouseenter', () => { chip.style.background = '#fef3c7'; });
    chip.addEventListener('mouseleave', () => { chip.style.background = '#fffbeb'; });

    // Click or keyboard-activate
    chip.addEventListener('click', applyChip);
    chip.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); applyChip(); }
    });

    // Debounced live check as user types
    let debounceTimer = null;
    emailInput.addEventListener('input', function() {
        clearTimeout(debounceTimer);
        const val = this.value.trim();
        if (!val) { hideChip(); return; }
        debounceTimer = setTimeout(function() {
            // Only run if there's an @ and at least one dot after it
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val)) { hideChip(); return; }
            const result = secValidateEmail(val);
            if (result.suggestion && result.suggestion !== val.toLowerCase()) {
                showChip(result.suggestion);
            } else {
                hideChip();
            }
        }, 500); // 500 ms debounce — don't flash while still typing
    });

    // Hide chip if the user manually types the suggestion themselves
    emailInput.addEventListener('blur', function() {
        if (this.value.trim().toLowerCase() === currentSuggestion) hideChip();
    });
}

// ============================================
// HONEYPOT FIELD INJECTION
// ============================================

/**
 * Injects a visually-hidden honeypot field into the form.
 * Real users never see or fill it. Bots that blindly populate all
 * inputs will fill it, letting us silently reject their submission.
 */
function secInjectHoneypot() {
    const form = document.getElementById('sec-contact-form');
    if (!form || document.getElementById('sec-hp-field')) return;

    const wrapper = document.createElement('div');
    // Hidden from humans via CSS — NOT display:none (some bots skip those)
    wrapper.setAttribute('aria-hidden', 'true');
    wrapper.style.cssText = 'position:absolute;left:-9999px;top:-9999px;width:1px;height:1px;overflow:hidden;opacity:0;pointer-events:none;tab-index:-1;';

    const label = document.createElement('label');
    label.setAttribute('for', 'sec-hp-field');
    label.textContent = 'Leave this blank';

    const input = document.createElement('input');
    input.type = 'text';
    input.id = 'sec-hp-field';
    input.name = 'website_url'; // looks like a legit field name to bots
    input.autocomplete = 'off';
    input.tabIndex = -1;
    input.value = '';

    wrapper.appendChild(label);
    wrapper.appendChild(input);
    form.appendChild(wrapper);
}

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', function() {
    window.secSubmitContactForm = secSubmitContactForm;

    // Reset the form-load clock now that the DOM is ready
    SEC_FORM_LOAD_TIME = Date.now();

    secCheckPaymentComplete();
    secInjectHoneypot();
    secInitEmailSuggestion();

    // Add enter-key submit support for form
    const form = document.getElementById('sec-contact-form');
    if (form) {
        form.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                secSubmitContactForm();
            }
        });
    }

    // Clear error styling on input focus
    document.querySelectorAll('.sec-contact-form input').forEach(function(input) {
        input.addEventListener('focus', function() {
            this.classList.remove('sec-input-error');
        });
    });

    // Phone number formatting as user types
    const phoneInput = document.getElementById('sec-phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function() {
            secFormatPhoneInput(this);
        });
        // Prevent non-numeric input (except formatting chars)
        phoneInput.addEventListener('keypress', function(e) {
            if (!/[0-9]/.test(e.key) && !['Backspace', 'Delete', 'Tab', 'Escape', 'Enter', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
                e.preventDefault();
            }
        });
    }

    // State field: auto-uppercase and limit to 2 chars for abbreviation
    const stateInput = document.getElementById('sec-state');
    if (stateInput) {
        stateInput.addEventListener('input', function() {
            this.value = this.value.toUpperCase().slice(0, 2);
        });
    }

    // ZIP code formatting
    const zipInput = document.getElementById('sec-zip');
    if (zipInput) {
        zipInput.addEventListener('input', function() {
            this.value = this.value.replace(/[^\d-]/g, '').slice(0, 10);
        });
    }
});

/* ============================================================
   SEC – Activation Slots Counter & Waitlist Popup
   Add to or merge with your existing sec-popup.js
   ============================================================ */

(function () {
  'use strict';

  /* ---------- Config ---------- */
  const REST_URL       = (window.secSlots && secSlots.restUrl)       || '/wp-json/sec/v1/';
  const WAITLIST_NONCE = (window.secSlots && secSlots.waitlistNonce) || '';
  const POLL_INTERVAL  = 30000; // re-check availability every 30 seconds

  /* ---------- State ---------- */
  let slotsData = { available: 10, total: 10, slots: [] };
  let pollTimer  = null;

  /* ==========================================================
     SLOTS COUNTER BAR
     Injected just above the submit button inside .sec-contact-form
     ========================================================== */

  function injectSlotBar() {
    if (document.getElementById('sec-slot-bar')) return;

    const form = document.querySelector('.sec-contact-form');
    if (!form) return;

    const submitBtn = form.querySelector('.sec-submit-btn');
    if (!submitBtn) return;

    const bar = document.createElement('div');
    bar.id = 'sec-slot-bar';
    bar.innerHTML = `
      <div class="sec-slot-bar-inner">
        <div class="sec-slot-pips" id="sec-slot-pips"></div>
        <div class="sec-slot-label" id="sec-slot-label">
          Checking availability…
        </div>
      </div>
    `;

    form.insertBefore(bar, submitBtn);
  }

  function renderSlotBar(data) {
    const pips  = document.getElementById('sec-slot-pips');
    const label = document.getElementById('sec-slot-label');
    if (!pips || !label) return;

    const { available, total } = data;
    const taken = total - available;

    // Render pip dots
    pips.innerHTML = '';
    for (let i = 0; i < total; i++) {
      const pip = document.createElement('span');
      pip.className = 'sec-slot-pip ' + (i < taken ? 'sec-slot-pip--taken' : 'sec-slot-pip--free');
      pips.appendChild(pip);
    }

    // Label text + urgency class
    const bar = document.getElementById('sec-slot-bar');
    bar.classList.remove('sec-slot-bar--ok', 'sec-slot-bar--low', 'sec-slot-bar--full');

    if (available === 0) {
      label.innerHTML = '<strong>All slots taken</strong> — join the waitlist below';
      bar.classList.add('sec-slot-bar--full');
      lockSubmitForSlots(true);
    } else if (available <= 3) {
      label.innerHTML = `<strong>${available} of ${total}</strong> activation slots remaining — act fast`;
      bar.classList.add('sec-slot-bar--low');
      lockSubmitForSlots(false);
    } else {
      label.innerHTML = `<strong>${available} of ${total}</strong> activation slots available today`;
      bar.classList.add('sec-slot-bar--ok');
      lockSubmitForSlots(false);
    }
  }

  function lockSubmitForSlots(lock) {
    const btn = document.querySelector('.sec-submit-btn');
    if (!btn) return;

    if (lock) {
      btn.disabled = true;
      btn.dataset.secOriginalText = btn.dataset.secOriginalText || btn.textContent;
      btn.textContent = 'No Slots Available';
    } else {
      btn.disabled = false;
      if (btn.dataset.secOriginalText) {
        btn.textContent = btn.dataset.secOriginalText;
        delete btn.dataset.secOriginalText;
      }
    }
  }

  /* ==========================================================
     FETCH SLOTS FROM REST
     ========================================================== */

  async function fetchSlots() {
    try {
      const res  = await fetch(REST_URL + 'slots', { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      slotsData  = data;
      renderSlotBar(data);
      return data;
    } catch (e) {
      console.warn('[SEC Slots] Could not fetch slot data:', e);
      return slotsData; // return last known state
    }
  }

  function startPolling() {
    if (pollTimer) return;
    pollTimer = setInterval(fetchSlots, POLL_INTERVAL);
  }

  /* ==========================================================
     WAITLIST POPUP
     ========================================================== */

  function injectWaitlistPopup() {
    if (document.getElementById('sec-waitlist-overlay')) return;

    const overlay = document.createElement('div');
    overlay.id        = 'sec-waitlist-overlay';
    overlay.className = 'sec-waitlist-overlay';
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-label', 'Join the waitlist');

    overlay.innerHTML = `
      <div class="sec-waitlist-container" id="sec-waitlist-container">

        <!-- Close -->
        <button class="sec-waitlist-close" id="sec-waitlist-close"
                aria-label="Close">&times;</button>

        <!-- Icon -->
        <div class="sec-waitlist-icon">⏳</div>

        <!-- Headline -->
        <h2 class="sec-waitlist-title">All Activation Slots Are Taken</h2>
        <p class="sec-waitlist-sub">
          Every slot refills every 24 hours.<br>
          Drop your email and we'll notify you the <strong>moment one opens up</strong>.
        </p>

        <!-- Form state -->
        <div id="sec-waitlist-form-wrap">
          <div class="sec-wl-row">
            <input type="text"  id="sec-wl-name"  placeholder="Your name (optional)"
                   class="sec-wl-input" autocomplete="name">
          </div>
          <div class="sec-wl-row">
            <input type="email" id="sec-wl-email" placeholder="Your email address"
                   class="sec-wl-input" required autocomplete="email">
          </div>
          <div id="sec-wl-error" class="sec-wl-error" style="display:none;"></div>
          <button id="sec-wl-submit" class="sec-wl-btn">
            Notify Me When a Slot Opens
          </button>
        </div>

        <!-- Success state (hidden initially) -->
        <div id="sec-waitlist-success" style="display:none;">
          <div class="sec-waitlist-icon sec-waitlist-icon--success">✓</div>
          <p class="sec-waitlist-success-msg" id="sec-wl-success-msg"></p>
        </div>

        <p class="sec-waitlist-fine">
          No spam. One email only — when a slot opens.
        </p>
      </div>
    `;

    document.body.appendChild(overlay);

    // Close handlers
    document.getElementById('sec-waitlist-close').addEventListener('click', closeWaitlist);
    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) closeWaitlist();
    });
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') closeWaitlist();
    });

    // Submit handler
    document.getElementById('sec-wl-submit').addEventListener('click', submitWaitlist);
    document.getElementById('sec-wl-email').addEventListener('keydown', function(e) {
      if (e.key === 'Enter') submitWaitlist();
    });
  }

  function openWaitlist() {
    injectWaitlistPopup();
    const overlay = document.getElementById('sec-waitlist-overlay');
    if (overlay) {
      overlay.classList.add('active');
      setTimeout(() => {
        const input = document.getElementById('sec-wl-email');
        if (input) input.focus();
      }, 200);
    }
  }

  function closeWaitlist() {
    const overlay = document.getElementById('sec-waitlist-overlay');
    if (overlay) overlay.classList.remove('active');
  }

  async function submitWaitlist() {
    const emailEl  = document.getElementById('sec-wl-email');
    const nameEl   = document.getElementById('sec-wl-name');
    const errorEl  = document.getElementById('sec-wl-error');
    const submitEl = document.getElementById('sec-wl-submit');

    const email = (emailEl && emailEl.value.trim()) || '';
    const name  = (nameEl  && nameEl.value.trim())  || '';

    // Basic client validation
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      showWlError('Please enter a valid email address.');
      if (emailEl) emailEl.focus();
      return;
    }

    hideWlError();
    submitEl.disabled    = true;
    submitEl.textContent = 'Adding you…';

    try {
      const res = await fetch(REST_URL + 'waitlist', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ email, name, nonce: WAITLIST_NONCE }),
      });

      const data = await res.json();

      if (data.reload) {
        // A slot just freed — refresh and let them proceed
        showWlSuccess(data.message || 'A slot just opened! Refreshing…');
        setTimeout(() => window.location.reload(), 2000);
        return;
      }

      if (data.success || data.already) {
        showWlSuccess(data.message || "You're on the list!");
      } else {
        showWlError((data.message) || 'Something went wrong. Please try again.');
        submitEl.disabled    = false;
        submitEl.textContent = 'Notify Me When a Slot Opens';
      }
    } catch (e) {
      console.error('[SEC Waitlist]', e);
      showWlError('Network error. Please check your connection and try again.');
      submitEl.disabled    = false;
      submitEl.textContent = 'Notify Me When a Slot Opens';
    }
  }

  function showWlError(msg) {
    const el = document.getElementById('sec-wl-error');
    if (!el) return;
    el.textContent = msg;
    el.style.display = 'block';
  }

  function hideWlError() {
    const el = document.getElementById('sec-wl-error');
    if (el) el.style.display = 'none';
  }

  function showWlSuccess(msg) {
    const formWrap  = document.getElementById('sec-waitlist-form-wrap');
    const successEl = document.getElementById('sec-waitlist-success');
    const msgEl     = document.getElementById('sec-wl-success-msg');

    if (formWrap)  formWrap.style.display  = 'none';
    if (successEl) successEl.style.display = 'block';
    if (msgEl)     msgEl.textContent       = msg;
  }

  /* ==========================================================
     INTERCEPT SUBMIT — block if no slots
     ========================================================== */

  function watchSubmitButton() {
    document.addEventListener('click', function(e) {
      const btn = e.target.closest('.sec-submit-btn');
      if (!btn) return;

      // Re-check from latest known state
      if (slotsData.available <= 0) {
        e.preventDefault();
        e.stopImmediatePropagation();
        openWaitlist();
      }
    }, true); // capture phase so we intercept before Stripe handler
  }

  /* ==========================================================
     INIT
     ========================================================== */

  function init() {
    injectSlotBar();
    fetchSlots().then(() => startPolling());
    watchSubmitButton();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();