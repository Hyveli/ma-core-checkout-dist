# PowerShell script to update Membership → Setup Fee terminology

Write-Host "Updating Membership to Setup Fee terminology..." -ForegroundColor Yellow

$file = "stripe-embedded-checkout.php"
$content = Get-Content $file -Raw

# Plugin description
$content = $content -replace 'Membership checkout with contact form', 'Setup fee checkout with contact form'

# Database option names
$content = $content -replace 'sec_membership_name', 'sec_setup_fee_name'
$content = $content -replace 'sec_membership_fee', 'sec_setup_fee_amount'

# Variable names
$content = $content -replace '\$membership_name', '$service_name'
$content = $content -replace '\$membership_fee', '$setup_fee_amount'

# User-facing text
$content = $content -replace "'Annual Membership'", "'Website Setup Fee'"
$content = $content -replace '"Annual Membership"', '"Website Setup Fee"'
$content = $content -replace 'Annual Membership Fee', 'Setup Fee Amount'
$content = $content -replace 'Annual Preferred Membership', 'Website Setup'
$content = $content -replace 'Membership Fee', 'Setup Fee'
$content = $content -replace 'Membership Checkout', 'Checkout'
$content = $content -replace 'Membership Customers', 'Customers'
$content = $content -replace 'Membership Application', 'SETUP FEE APPLICATION'
$content = $content -replace 'MEMBERSHIP APPLICATION', 'SETUP FEE APPLICATION'
$content = $content -replace 'Membership &amp; Pricing', 'Setup Fee &amp; Pricing'
$content = $content -replace 'Membership Name', 'Service Name'
$content = $content -replace 'membership details', 'information'
$content = $content -replace 'Membership Purchase', 'Setup Fee Payment'

# Save
Set-Content -Path $file -Value $content

Write-Host "Done! Updated stripe-embedded-checkout.php" -ForegroundColor Green
