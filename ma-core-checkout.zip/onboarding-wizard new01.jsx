import { useState, useRef } from "react";

// ─── INDUSTRY TEMPLATES ───────────────────────────────────────────────────────
const INDUSTRIES = [
  { id:"wellness",      label:"Wellness & Spa",     icon:"🌿", color:"#2D6A4F", services:["Massage","Facial","Consultation","Manicure"],                       hours:{open:"09:00",close:"19:00"}, buffer:10, durations:{Massage:[30,60,90],Facial:[45,60,75],Consultation:[30],Manicure:[30,45,60]} },
  { id:"beauty",        label:"Hair & Beauty",       icon:"✂️", color:"#6B3FA0", services:["Haircut","Color","Blowout","Treatment"],                             hours:{open:"09:00",close:"18:00"}, buffer:15, durations:{Haircut:[30,45,60],Color:[90,120,150],Blowout:[30,45],Treatment:[45,60]} },
  { id:"fitness",       label:"Fitness & Training",  icon:"💪", color:"#C0392B", services:["Personal Training","Group Class","Assessment","Nutrition Consult"],  hours:{open:"06:00",close:"21:00"}, buffer:10, durations:{"Personal Training":[30,45,60],"Group Class":[45,60,75],Assessment:[60],"Nutrition Consult":[30,45]} },
  { id:"home_services", label:"Home Services",       icon:"🏠", color:"#1A5276", services:["Inspection","Repair Visit","Estimate","Installation"],              hours:{open:"07:00",close:"17:00"}, buffer:30, durations:{Inspection:[60,90],"Repair Visit":[90,120],Estimate:[30,45],Installation:[120,180]} },
  { id:"upholstery",    label:"Upholstery",          icon:"🪑", color:"#7D6608", services:["Repair","Estimate","Drop-off","Pickup"],                            hours:{open:"08:00",close:"17:00"}, buffer:15, durations:{Repair:[60,90,120],Estimate:[20,30],"Drop-off":[10],Pickup:[20,30]} },
  { id:"medical",       label:"Medical & Therapy",   icon:"🩺", color:"#1A5276", services:["New Patient","Follow-up","Consultation","Procedure"],               hours:{open:"08:00",close:"17:00"}, buffer:15, durations:{"New Patient":[45,60],"Follow-up":[15,20,30],Consultation:[30,45],Procedure:[30,60,90]} },
  { id:"legal",         label:"Legal & Consulting",  icon:"⚖️", color:"#2E4057", services:["Initial Consult","Case Review","Follow-up","Document Review"],     hours:{open:"09:00",close:"17:00"}, buffer:10, durations:{"Initial Consult":[30,45,60],"Case Review":[60,90],"Follow-up":[20,30],"Document Review":[45,60]} },
  { id:"other",         label:"Other",               icon:"⚙️", color:"#444",   services:["Appointment","Consultation","Follow-up"],                           hours:{open:"09:00",close:"17:00"}, buffer:10, durations:{} },
];

const BRAND_COLORS = [
  {hex:"#1A1A1A",name:"Obsidian"},{hex:"#1A5276",name:"Navy"},
  {hex:"#2D6A4F",name:"Forest"}, {hex:"#6B3FA0",name:"Violet"},
  {hex:"#C0392B",name:"Crimson"},{hex:"#B7770D",name:"Amber"},
  {hex:"#2E4057",name:"Slate"},  {hex:"#A04040",name:"Burgundy"},
];

const HOURS_OPEN  = ["06:00","07:00","08:00","09:00","10:00","11:00","12:00"];
const HOURS_CLOSE = ["14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00"];
const BUFFER_OPTS = [0,5,10,15,20,30,45,60];
function fmtHour(h){const[hr]=h.split(":").map(Number);return hr===12?"12 PM":hr>12?`${hr-12} PM`:`${hr} AM`;}

const QUESTIONS = [
  {id:"bizName",  num:"01",type:"text",    label:"What's your business called?",                  sub:"This will appear on your booking page.",                         placeholder:"e.g. Bloom Wellness Studio",required:true },
  {id:"industry", num:"02",type:"industry",label:"What kind of business is this?",                sub:"We'll pre-load everything — you just confirm it."},
  {id:"services", num:"03",type:"services",label:"Which services do you offer?",                  sub:"Pre-selected for your industry. Untick anything you don't offer. Tap Edit to adjust session length."},
  {id:"buffer",   num:"04",type:"buffer",  label:"Do you want buffer time between appointments?", sub:"A hidden gap before and/or after each booking so you're never rushed. Clients never see it."},
  {id:"hours",    num:"05",type:"hours",   label:"When are you open?",                            sub:"Pre-filled for your industry — adjust if needed."},
  {id:"logo",     num:"06",type:"logo",    label:"Do you have a logo?",                           sub:"Used on your booking page header."},
  {id:"color",    num:"07",type:"color",   label:"Pick your brand color.",                        sub:"Sets the accent across your entire booking site."},
  {id:"phone",    num:"08",type:"tel",     label:"What's your business phone number?",            sub:"Shown on your website for clients to reach you.",                 placeholder:"+1 (555) 000-0000",required:false},
  {id:"location", num:"09",type:"location",label:"Where are you based?",                          sub:"City and state — shown in your site footer.",                    placeholder:"e.g. Miami, FL",required:true},
  {id:"staff",    num:"10",type:"staff",   label:"Is it just you, or do you have a team?",        sub:"Clients can request a specific person if you have multiple staff."},
  {id:"note",     num:"11",type:"note",    label:"Anything clients should know before booking?",  sub:"Parking, what to bring, arrival tips. Totally optional.",         placeholder:"e.g. Please arrive 10 minutes early. Free parking on site.",required:false},
  {id:"review",   num:"12",type:"review",  label:"You're ready to launch.",                       sub:"Review everything below, then go live."},
];

const CSS = `
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
  ::selection{background:#1A1A1A;color:#fff;}
  .q-ef{animation:enterFwd .22s cubic-bezier(.4,0,.2,1) forwards;}
  .q-xf{animation:exitFwd  .18s cubic-bezier(.4,0,.2,1) forwards;}
  .q-eb{animation:enterBack .22s cubic-bezier(.4,0,.2,1) forwards;}
  .q-xb{animation:exitBack  .18s cubic-bezier(.4,0,.2,1) forwards;}
  @keyframes enterFwd {from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}
  @keyframes exitFwd  {from{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(-16px)}}
  @keyframes enterBack{from{opacity:0;transform:translateY(-20px)}to{opacity:1;transform:translateY(0)}}
  @keyframes exitBack {from{opacity:1;transform:translateY(0)}to{opacity:0;transform:translateY(16px)}}
  .ind-tile{background:#fff;border:2px solid #E5E4DF;border-radius:12px;padding:18px 16px;cursor:pointer;transition:border-color .15s,background .15s,transform .12s;text-align:left;font-family:inherit;width:100%;}
  .ind-tile:hover{border-color:#999;background:#FAFAF8;transform:translateY(-1px);}
  .ind-tile.sel{border-color:#1A1A1A;background:#FAFAF8;}
  .svc-card{border:2px solid #E5E4DF;border-radius:12px;background:#fff;overflow:hidden;transition:border-color .15s,background .15s;}
  .svc-card.on{border-color:#1A1A1A;background:#FAFAF8;}
  .dur-pill{padding:9px 16px;border-radius:9px;border:2px solid #E5E4DF;background:#fff;color:#888;font-size:13px;font-weight:500;cursor:pointer;font-family:system-ui,sans-serif;transition:all .12s;}
  .dur-pill:hover{border-color:#999;color:#1A1A1A;}
  .dur-pill.sel{border-color:#1A1A1A;background:#1A1A1A;color:#fff;}
  .buf-pill{padding:9px 13px;border-radius:9px;border:2px solid #E5E4DF;background:#fff;color:#888;font-size:12px;font-weight:500;cursor:pointer;font-family:system-ui,sans-serif;transition:all .12s;}
  .buf-pill:hover{border-color:#999;color:#1A1A1A;}
  .buf-pill.sel{border-color:#1A1A1A;background:#1A1A1A;color:#fff;}
  .yn-btn{background:#fff;border:2px solid #E5E4DF;border-radius:12px;padding:18px 28px;cursor:pointer;transition:all .15s;font-family:inherit;font-size:16px;font-weight:600;color:#888;flex:1;text-align:center;}
  .yn-btn:hover{border-color:#999;color:#1A1A1A;}
  .yn-btn.sel{border-color:#1A1A1A;background:#1A1A1A;color:#fff;}
  .hour-sel{background:#fff;border:2px solid #E5E4DF;border-radius:10px;padding:12px 14px;font-size:15px;font-family:inherit;color:#1A1A1A;outline:none;cursor:pointer;transition:border-color .15s;width:100%;appearance:none;text-align:center;}
  .hour-sel:focus{border-color:#1A1A1A;}
  .color-swatch{width:42px;height:42px;border-radius:50%;cursor:pointer;transition:transform .12s,box-shadow .12s;border:3px solid transparent;flex-shrink:0;}
  .color-swatch:hover{transform:scale(1.1);}
  .color-swatch.sel{box-shadow:0 0 0 3px #1A1A1A;transform:scale(1.08);}
  .main-input{width:100%;background:transparent;border:none;border-bottom:2px solid #D0CFC8;padding:12px 0;font-size:clamp(18px,3vw,26px);font-family:'Georgia',serif;color:#1A1A1A;outline:none;transition:border-color .15s;caret-color:#1A1A1A;}
  .main-input:focus{border-bottom-color:#1A1A1A;}
  .main-input::placeholder{color:#C8C7C0;}
  .main-textarea{width:100%;background:#fff;border:2px solid #E5E4DF;border-radius:12px;padding:14px 16px;font-size:15px;font-family:'Georgia',serif;color:#1A1A1A;outline:none;transition:border-color .15s;resize:none;caret-color:#1A1A1A;min-height:110px;}
  .main-textarea:focus{border-color:#999;}
  .main-textarea::placeholder{color:#C8C7C0;}
  .staff-input{background:#fff;border:2px solid #E5E4DF;border-radius:10px;padding:12px 14px;font-size:15px;font-family:'Georgia',serif;color:#1A1A1A;outline:none;transition:border-color .15s;width:100%;}
  .staff-input:focus{border-color:#999;}
  .staff-input::placeholder{color:#C8C7C0;}
  .pbtn{background:#1A1A1A;color:#fff;border:none;border-radius:10px;padding:14px 32px;font-size:15px;font-weight:700;cursor:pointer;font-family:'Georgia',serif;transition:opacity .15s;letter-spacing:.01em;}
  .pbtn:disabled{opacity:.25;cursor:default;}
  .pbtn:not(:disabled):hover{opacity:.82;}
  .back-btn{background:none;border:none;color:#999;font-size:13px;cursor:pointer;font-family:inherit;padding:0;transition:color .12s;display:flex;align-items:center;gap:6px;}
  .back-btn:hover{color:#1A1A1A;}
  .review-row{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:13px 0;border-bottom:1px solid #F0EFE9;font-size:14px;}
  .review-edit{background:none;border:none;color:#bbb;font-size:12px;cursor:pointer;font-family:inherit;padding:0;transition:color .12s;flex-shrink:0;}
  .review-edit:hover{color:#1A1A1A;}
  .logo-drop{border:2px dashed #D0CFC8;border-radius:14px;padding:36px;text-align:center;cursor:pointer;transition:border-color .15s,background .15s;}
  .logo-drop:hover{border-color:#999;background:#F9F8F5;}
  ::-webkit-scrollbar{width:4px;}
  ::-webkit-scrollbar-thumb{background:#D0CFC8;border-radius:2px;}
`;

export default function App() {
  const [current, setCurrent]    = useState(0);
  const [answers, setAnswers]    = useState({
    bizName:"", industry:null, services:[], serviceConfigs:{},
    globalBuffer:{before:10,after:10},
    hours:{open:"09:00",close:"18:00"},
    logo:null, logoPreview:null, color:"#1A1A1A",
    phone:"", location:"", staff:"solo", staffNames:[""], note:"",
  });
  const [expandedSvc, setExpandedSvc] = useState(null);
  const [direction, setDir]  = useState(1);
  const [animating, setAnim] = useState(false);
  const [launched, setLaunched] = useState(false);
  const logoRef = useRef();

  const q    = QUESTIONS[current];
  const tmpl = answers.industry ? INDUSTRIES.find(i=>i.id===answers.industry) : null;
  const progress = Math.round((current/(QUESTIONS.length-1))*100);

  const canAdvance = () => {
    if (q.required===false) return true;
    if ((q.type==="text"||q.type==="location")&&q.required) return (answers[q.id]||"").trim().length>0;
    if (q.type==="industry") return !!answers.industry;
    if (q.type==="services") return answers.services.length>0;
    return true;
  };

  function go(dir) {
    if (animating) return;
    if (dir===1&&!canAdvance()) return;
    setDir(dir); setAnim(true);
    setTimeout(()=>{setCurrent(c=>Math.max(0,Math.min(QUESTIONS.length-1,c+dir)));setAnim(false);},180);
  }

  function set(k,v){setAnswers(a=>({...a,[k]:v}));}

  function selectIndustry(id) {
    const t = INDUSTRIES.find(i=>i.id===id);
    const cfgs={};
    t.services.forEach(name=>{
      const durs=t.durations[name]||[60];
      cfgs[name]={duration:durs[Math.floor((durs.length-1)/2)]};
    });
    setAnswers(a=>({...a,industry:id,services:[...t.services],serviceConfigs:cfgs,
      globalBuffer:{before:t.buffer,after:t.buffer},
      hours:{open:t.hours.open,close:t.hours.close},color:t.color}));
    setTimeout(()=>go(1),260);
  }

  function toggleSvc(name) {
    setAnswers(a=>{
      const has=a.services.includes(name);
      const cfgs={...a.serviceConfigs};
      if(!has&&!cfgs[name]){
        const t=INDUSTRIES.find(i=>i.id===a.industry);
        const durs=t?.durations?.[name]||[60];
        cfgs[name]={duration:durs[Math.floor((durs.length-1)/2)]};
      }
      return{...a,services:has?a.services.filter(x=>x!==name):[...a.services,name],serviceConfigs:cfgs};
    });
  }

  function setSvcDuration(name,val){
    setAnswers(a=>({...a,serviceConfigs:{...a.serviceConfigs,[name]:{...(a.serviceConfigs[name]||{}),duration:val}}}));
  }

  function handleLogo(e){
    const file=e.target.files?.[0];if(!file)return;
    const r=new FileReader();
    r.onload=ev=>setAnswers(a=>({...a,logo:file,logoPreview:ev.target.result}));
    r.readAsDataURL(file);
  }

  if(launched) return <LaunchScreen answers={answers} tmpl={tmpl} onEdit={()=>setLaunched(false)} />;

  const animClass = animating?(direction>0?"q-xf":"q-xb"):(direction>0?"q-ef":"q-eb");

  return (
    <div style={{minHeight:"100vh",background:"#F5F4F1",color:"#1A1A1A",fontFamily:"'Georgia','Times New Roman',serif",display:"flex",flexDirection:"column"}}>
      <style>{CSS}</style>

      <div style={{position:"fixed",top:0,left:0,right:0,height:3,background:"#E5E4DF",zIndex:100}}>
        <div style={{height:"100%",background:"#1A1A1A",width:`${progress}%`,transition:"width .5s cubic-bezier(.4,0,.2,1)"}}/>
      </div>

      <div style={{position:"fixed",top:0,left:0,right:0,height:52,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 28px",zIndex:50,background:"#F5F4F1"}}>
        <span style={{fontSize:15,fontWeight:700,letterSpacing:"-0.2px",fontFamily:"system-ui,sans-serif"}}>Setup</span>
        <span style={{fontSize:12,color:"#aaa",letterSpacing:"0.05em",fontFamily:"system-ui,sans-serif"}}>{current+1} / {QUESTIONS.length}</span>
      </div>

      <div style={{flex:1,display:"flex",flexDirection:"column",justifyContent:"center",padding:"80px 28px 120px",maxWidth:700,margin:"0 auto",width:"100%"}}>
        <div className={animClass} key={current}>

          <div style={{marginBottom:32}}>
            <span style={{fontSize:11,color:"#bbb",letterSpacing:"0.12em",textTransform:"uppercase",fontFamily:"system-ui,sans-serif"}}>{q.num}</span>
            <h2 style={{fontSize:"clamp(22px,4vw,34px)",fontWeight:400,lineHeight:1.25,margin:"8px 0 10px",letterSpacing:"-0.02em"}}>{q.label}</h2>
            <p style={{fontSize:14,color:"#888",fontFamily:"system-ui,sans-serif",lineHeight:1.6}}>{q.sub}</p>
          </div>

          {/* TEXT / LOCATION */}
          {(q.type==="text"||q.type==="location")&&(
            <input className="main-input" placeholder={q.placeholder} value={answers[q.id]||""} autoFocus
              onChange={e=>set(q.id,e.target.value)} onKeyDown={e=>e.key==="Enter"&&canAdvance()&&go(1)}/>
          )}

          {/* TEL */}
          {q.type==="tel"&&(
            <input className="main-input" type="tel" placeholder={q.placeholder} value={answers.phone} autoFocus
              onChange={e=>set("phone",e.target.value)} onKeyDown={e=>e.key==="Enter"&&go(1)}/>
          )}

          {/* INDUSTRY */}
          {q.type==="industry"&&(
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(148px,1fr))",gap:10}}>
              {INDUSTRIES.map(ind=>(
                <button key={ind.id} className={`ind-tile ${answers.industry===ind.id?"sel":""}`} onClick={()=>selectIndustry(ind.id)}>
                  <div style={{fontSize:22,marginBottom:8}}>{ind.icon}</div>
                  <div style={{fontSize:13,fontWeight:600,fontFamily:"system-ui,sans-serif",lineHeight:1.3}}>{ind.label}</div>
                </button>
              ))}
            </div>
          )}

          {/* SERVICES */}
          {q.type==="services"&&tmpl&&(
            <div>
              <div style={{display:"grid",gap:9,marginBottom:14}}>
                {tmpl.services.map(name=>{
                  const isOn  = answers.services.includes(name);
                  const isExp = expandedSvc===name;
                  const cfg   = answers.serviceConfigs[name]||{duration:60};
                  const durs  = tmpl.durations[name]||[30,45,60,90];
                  return (
                    <div key={name} className={`svc-card ${isOn?"on":""}`}>
                      <div style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px"}}>
                        <div onClick={()=>{toggleSvc(name);if(!isOn)setExpandedSvc(name);else if(isExp)setExpandedSvc(null);}}
                          style={{width:20,height:20,borderRadius:5,border:`2px solid ${isOn?"#1A1A1A":"#D0CFC8"}`,background:isOn?"#1A1A1A":"#fff",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"all .12s",cursor:"pointer"}}>
                          {isOn&&<span style={{color:"#fff",fontSize:11,lineHeight:1}}>✓</span>}
                        </div>
                        <div style={{flex:1,cursor:"pointer"}} onClick={()=>{toggleSvc(name);if(!isOn)setExpandedSvc(name);else if(isExp)setExpandedSvc(null);}}>
                          <span style={{fontWeight:600,fontSize:14,fontFamily:"system-ui,sans-serif"}}>{name}</span>
                          {isOn&&<span style={{fontSize:12,color:"#aaa",marginLeft:8,fontFamily:"system-ui,sans-serif"}}>{cfg.duration} min</span>}
                        </div>
                        {isOn&&(
                          <button onClick={e=>{e.stopPropagation();setExpandedSvc(isExp?null:name);}}
                            style={{background:"none",border:"none",cursor:"pointer",color:isExp?"#1A1A1A":"#bbb",fontSize:12,fontFamily:"system-ui,sans-serif",display:"flex",alignItems:"center",gap:4,padding:"4px 8px",borderRadius:6,transition:"color .12s"}}>
                            {isExp?"Done ":"Edit "}
                            <span style={{display:"inline-block",transition:"transform .15s",transform:isExp?"rotate(180deg)":"rotate(0deg)",fontSize:10}}>▾</span>
                          </button>
                        )}
                      </div>

                      {isOn&&isExp&&(
                        <div style={{borderTop:"1px solid #F0EFE9",padding:"18px 18px 20px",background:"#fff"}}>
                          <div style={{fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",color:"#aaa",fontFamily:"system-ui,sans-serif",marginBottom:12}}>Session duration</div>
                          <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:12}}>
                            {durs.map(d=>(
                              <button key={d} className={`dur-pill ${cfg.duration===d?"sel":""}`} onClick={()=>setSvcDuration(name,d)}>{d} min</button>
                            ))}
                          </div>
                          <div style={{display:"flex",alignItems:"center",gap:10}}>
                            <span style={{fontSize:12,color:"#bbb",fontFamily:"system-ui,sans-serif",whiteSpace:"nowrap"}}>Custom:</span>
                            <div style={{display:"flex",alignItems:"center",border:"2px solid #E5E4DF",borderRadius:9,overflow:"hidden",background:"#fff"}}>
                              <input type="number" min={5} max={480} step={5} placeholder="—"
                                value={durs.includes(cfg.duration)?"":cfg.duration}
                                onChange={e=>{const v=parseInt(e.target.value);if(v>=5)setSvcDuration(name,v);}}
                                style={{width:54,border:"none",outline:"none",fontSize:14,fontFamily:"system-ui,sans-serif",color:"#1A1A1A",padding:"9px 10px",background:"transparent",textAlign:"center"}}/>
                              <span style={{fontSize:12,color:"#bbb",fontFamily:"system-ui,sans-serif",paddingRight:10}}>min</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <button onClick={()=>{
                const name=prompt("What's the service called?");
                if(!name?.trim())return;
                const n=name.trim();
                if(!tmpl.durations[n])tmpl.durations[n]=[30,45,60];
                if(!tmpl.services.includes(n))tmpl.services.push(n);
                setAnswers(a=>({...a,services:[...a.services,n],serviceConfigs:{...a.serviceConfigs,[n]:{duration:60}}}));
                setExpandedSvc(n);
              }} style={{background:"none",border:"2px dashed #E5E4DF",borderRadius:10,padding:"12px 18px",color:"#aaa",fontSize:13,cursor:"pointer",fontFamily:"system-ui,sans-serif",width:"100%",textAlign:"left",transition:"border-color .12s,color .12s"}}
                onMouseEnter={e=>{e.currentTarget.style.borderColor="#999";e.currentTarget.style.color="#1A1A1A";}}
                onMouseLeave={e=>{e.currentTarget.style.borderColor="#E5E4DF";e.currentTarget.style.color="#aaa";}}>
                + Add a custom service
              </button>
            </div>
          )}

          {/* BUFFER */}
          {q.type==="buffer"&&(()=>{
            const gb=answers.globalBuffer;
            return (
              <div>
                {/* Visual timeline */}
                <div style={{background:"#fff",border:"1px solid #E5E4DF",borderRadius:12,padding:"14px 18px",marginBottom:28,display:"flex",alignItems:"center",flexWrap:"wrap",gap:6}}>
                  <div style={{background:"#E8F5E9",border:"1px solid #A5D6A7",borderRadius:6,padding:"5px 12px",fontSize:11,fontWeight:600,color:"#2E7D32",fontFamily:"system-ui,sans-serif",whiteSpace:"nowrap"}}>Appointment ends</div>
                  {gb.after>0&&<div style={{background:"#FFF8E1",border:"1px solid #FFD54F",borderRadius:6,padding:"5px 12px",fontSize:11,fontWeight:600,color:"#F57F17",fontFamily:"system-ui,sans-serif",whiteSpace:"nowrap"}}>↔ {gb.after}m buffer</div>}
                  {gb.before>0&&<div style={{background:"#FFF8E1",border:"1px solid #FFD54F",borderRadius:6,padding:"5px 12px",fontSize:11,fontWeight:600,color:"#F57F17",fontFamily:"system-ui,sans-serif",whiteSpace:"nowrap"}}>{gb.before}m buffer ↔</div>}
                  <div style={{background:"#E8F5E9",border:"1px solid #A5D6A7",borderRadius:6,padding:"5px 12px",fontSize:11,fontWeight:600,color:"#2E7D32",fontFamily:"system-ui,sans-serif",whiteSpace:"nowrap"}}>Next appointment</div>
                  <span style={{fontSize:11,color:"#bbb",fontFamily:"system-ui,sans-serif"}}>Clients never see this.</span>
                </div>

                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:24}}>
                  {[
                    ["before","Before each appointment","Prep time, setup, travel"],
                    ["after","After each appointment","Clean up, notes, reset"],
                  ].map(([key,label,hint])=>(
                    <div key={key}>
                      <div style={{fontSize:14,fontWeight:700,fontFamily:"system-ui,sans-serif",marginBottom:3}}>{label}</div>
                      <div style={{fontSize:12,color:"#bbb",fontFamily:"system-ui,sans-serif",marginBottom:12,lineHeight:1.5}}>{hint}</div>
                      <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                        {BUFFER_OPTS.map(b=>(
                          <button key={b} className={`buf-pill ${gb[key]===b?"sel":""}`}
                            onClick={()=>set("globalBuffer",{...gb,[key]:b})}>
                            {b===0?"None":`${b}m`}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                <div style={{marginTop:24,borderRadius:11,padding:"13px 17px",fontSize:13,fontFamily:"system-ui,sans-serif",
                  background:gb.before===0&&gb.after===0?"#FFFBF0":"#F9F8F5",
                  border:`1px solid ${gb.before===0&&gb.after===0?"#FFE082":"#E5E4DF"}`,
                  color:gb.before===0&&gb.after===0?"#7A6000":"#555"}}>
                  {gb.before===0&&gb.after===0
                    ?"No buffer — appointments will be scheduled back-to-back."
                    :<>Applied to all services: <strong>{[gb.before>0&&`${gb.before} min before`,gb.after>0&&`${gb.after} min after`].filter(Boolean).join(" · ")}</strong></>
                  }
                </div>
              </div>
            );
          })()}

          {/* HOURS */}
          {q.type==="hours"&&(
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
              {[["open","Opens at",HOURS_OPEN],["close","Closes at",HOURS_CLOSE]].map(([key,label,opts])=>(
                <div key={key}>
                  <div style={{fontSize:11,color:"#aaa",textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:10,fontFamily:"system-ui,sans-serif"}}>{label}</div>
                  <select className="hour-sel" value={answers.hours[key]} onChange={e=>set("hours",{...answers.hours,[key]:e.target.value})}>
                    {opts.map(h=><option key={h} value={h}>{fmtHour(h)}</option>)}
                  </select>
                </div>
              ))}
            </div>
          )}

          {/* LOGO */}
          {q.type==="logo"&&(
            <div>
              <div style={{display:"flex",gap:12,marginBottom:20}}>
                <button className={`yn-btn ${answers.logoPreview?"sel":""}`} onClick={()=>logoRef.current?.click()}>Yes — upload it</button>
                <button className={`yn-btn ${answers.logo==="no"?"sel":""}`}
                  onClick={()=>{set("logo","no");set("logoPreview",null);setTimeout(()=>go(1),260);}}>Not yet</button>
              </div>
              <input ref={logoRef} type="file" accept="image/*" style={{display:"none"}} onChange={handleLogo}/>
              {!answers.logoPreview&&answers.logo!=="no"&&(
                <div className="logo-drop" onClick={()=>logoRef.current?.click()}>
                  <div style={{fontSize:28,marginBottom:10,color:"#ccc"}}>↑</div>
                  <div style={{fontSize:14,color:"#aaa",fontFamily:"system-ui,sans-serif"}}>Click to select an image</div>
                  <div style={{fontSize:12,color:"#ccc",marginTop:4,fontFamily:"system-ui,sans-serif"}}>PNG, JPG or SVG · Max 5MB</div>
                </div>
              )}
              {answers.logoPreview&&(
                <div style={{position:"relative",display:"inline-block"}}>
                  <img src={answers.logoPreview} alt="logo" style={{maxHeight:100,maxWidth:280,borderRadius:10,border:"1px solid #E5E4DF",objectFit:"contain",background:"#F9F8F5",padding:8}}/>
                  <button onClick={()=>{set("logo",null);set("logoPreview",null);}}
                    style={{position:"absolute",top:-8,right:-8,width:22,height:22,borderRadius:"50%",background:"#1A1A1A",border:"none",color:"#fff",fontSize:11,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
                </div>
              )}
            </div>
          )}

          {/* COLOR */}
          {q.type==="color"&&(
            <div>
              <div style={{display:"flex",flexWrap:"wrap",gap:14,marginBottom:20}}>
                {BRAND_COLORS.map(c=>(
                  <div key={c.hex} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:6,cursor:"pointer"}} onClick={()=>set("color",c.hex)}>
                    <div className={`color-swatch ${answers.color===c.hex?"sel":""}`} style={{background:c.hex}}/>
                    <span style={{fontSize:10,color:"#aaa",fontFamily:"system-ui,sans-serif",letterSpacing:"0.05em"}}>{c.name}</span>
                  </div>
                ))}
                <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:6}}>
                  <div style={{position:"relative",width:42,height:42}}>
                    <div className={`color-swatch ${!BRAND_COLORS.find(c=>c.hex===answers.color)?"sel":""}`} style={{background:answers.color,width:"100%",height:"100%",position:"absolute"}}/>
                    <input type="color" value={answers.color} onChange={e=>set("color",e.target.value)}
                      style={{position:"absolute",inset:0,opacity:0,cursor:"pointer",width:"100%",height:"100%",border:"none"}}/>
                  </div>
                  <span style={{fontSize:10,color:"#aaa",fontFamily:"system-ui,sans-serif",letterSpacing:"0.05em"}}>Custom</span>
                </div>
              </div>
              <div style={{display:"inline-flex",alignItems:"center",gap:10,background:"#fff",border:"1px solid #E5E4DF",borderRadius:10,padding:"10px 16px"}}>
                <div style={{width:18,height:18,borderRadius:4,background:answers.color}}/>
                <span style={{fontSize:13,color:"#888",fontFamily:"system-ui,sans-serif"}}>{answers.color.toUpperCase()}</span>
              </div>
            </div>
          )}

          {/* STAFF */}
          {q.type==="staff"&&(
            <div>
              <div style={{display:"flex",gap:12,marginBottom:answers.staff==="team"?24:0}}>
                <button className={`yn-btn ${answers.staff==="solo"?"sel":""}`} onClick={()=>{set("staff","solo");setTimeout(()=>go(1),260);}}>Just me</button>
                <button className={`yn-btn ${answers.staff==="team"?"sel":""}`} onClick={()=>set("staff","team")}>We have a team</button>
              </div>
              {answers.staff==="team"&&(
                <div>
                  <div style={{fontSize:11,color:"#aaa",fontFamily:"system-ui,sans-serif",textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:12}}>Team member names</div>
                  <div style={{display:"grid",gap:10}}>
                    {answers.staffNames.map((name,i)=>(
                      <div key={i} style={{display:"flex",gap:10}}>
                        <input className="staff-input" placeholder={`Staff member ${i+1}`} value={name}
                          onChange={e=>{const ns=[...answers.staffNames];ns[i]=e.target.value;set("staffNames",ns);}}/>
                        {i>0&&<button onClick={()=>set("staffNames",answers.staffNames.filter((_,j)=>j!==i))}
                          style={{background:"none",border:"2px solid #E5E4DF",borderRadius:8,color:"#aaa",fontSize:14,cursor:"pointer",padding:"0 12px",fontFamily:"inherit"}}>✕</button>}
                      </div>
                    ))}
                    <button onClick={()=>set("staffNames",[...answers.staffNames,""])}
                      style={{background:"none",border:"none",color:"#aaa",fontSize:13,cursor:"pointer",fontFamily:"system-ui,sans-serif",textAlign:"left",padding:0}}>
                      + Add another
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* NOTE */}
          {q.type==="note"&&(
            <textarea className="main-textarea" placeholder={q.placeholder} value={answers.note} onChange={e=>set("note",e.target.value)}/>
          )}

          {/* REVIEW */}
          {q.type==="review"&&(
            <ReviewScreen answers={answers} tmpl={tmpl}
              onEdit={i=>{setDir(-1);setAnim(true);setTimeout(()=>{setCurrent(i);setAnim(false);},180);}}/>
          )}
        </div>
      </div>

      {/* Bottom nav */}
      <div style={{position:"fixed",bottom:0,left:0,right:0,padding:"18px 28px 24px",background:"linear-gradient(to top,#F5F4F1 65%,transparent)",display:"flex",alignItems:"center",justifyContent:"space-between",zIndex:50}}>
        {current>0?<button className="back-btn" onClick={()=>go(-1)}>← Back</button>:<div/>}
        <div style={{display:"flex",alignItems:"center",gap:14}}>
          {q.required===false&&q.type!=="review"&&(
            <button onClick={()=>go(1)} style={{background:"none",border:"none",color:"#bbb",fontSize:13,cursor:"pointer",fontFamily:"system-ui,sans-serif"}}>Skip</button>
          )}
          {!["industry"].includes(q.type)&&q.type!=="review"&&(
            <>
              {q.type==="staff"&&answers.staff==="team"&&<button className="pbtn" onClick={()=>go(1)}>Continue →</button>}
              {q.type!=="staff"&&q.type!=="logo"&&<button className="pbtn" disabled={!canAdvance()} onClick={()=>go(1)}>{current===QUESTIONS.length-2?"Review →":"Continue →"}</button>}
              {q.type==="logo"&&(answers.logoPreview||answers.logo==="no")&&<button className="pbtn" onClick={()=>go(1)}>Continue →</button>}
            </>
          )}
          {q.type==="review"&&<button className="pbtn" onClick={()=>setLaunched(true)} style={{padding:"14px 40px",fontSize:16}}>Launch my site →</button>}
        </div>
      </div>
    </div>
  );
}

// ─── REVIEW ───────────────────────────────────────────────────────────────────
function ReviewScreen({answers,tmpl,onEdit}){
  const gb=answers.globalBuffer;
  const bufStr=gb.before===0&&gb.after===0?"None":[gb.before>0&&`${gb.before}m before`,gb.after>0&&`${gb.after}m after`].filter(Boolean).join(" · ");
  const rows=[
    {label:"Business", value:answers.bizName||"—",q:0},
    {label:"Industry", value:tmpl?.label||"—",q:1},
    {label:"Services", value:answers.services.length?answers.services.map(s=>`${s} (${(answers.serviceConfigs[s]||{}).duration||60}m)`).join(", "):"—",q:2},
    {label:"Buffer",   value:bufStr,q:3},
    {label:"Hours",    value:`${fmtHour(answers.hours.open)} – ${fmtHour(answers.hours.close)}`,q:4},
    {label:"Logo",     value:answers.logoPreview?"Uploaded ✓":answers.logo==="no"?"Not yet":"—",q:5},
    {label:"Color",    value:answers.color?.toUpperCase(),swatch:true,q:6},
    {label:"Phone",    value:answers.phone||"—",q:7},
    {label:"Location", value:answers.location||"—",q:8},
    {label:"Team",     value:answers.staff==="solo"?"Solo":answers.staffNames.filter(Boolean).join(", ")||"Team",q:9},
    {label:"Note",     value:answers.note?answers.note.slice(0,55)+(answers.note.length>55?"…":""):"None",q:10},
  ];
  return(
    <div style={{background:"#fff",border:"1px solid #E5E4DF",borderRadius:16,padding:24}}>
      {rows.map(row=>(
        <div key={row.label} className="review-row">
          <span style={{color:"#aaa",fontFamily:"system-ui,sans-serif",fontSize:13,minWidth:72,flexShrink:0}}>{row.label}</span>
          <div style={{flex:1,display:"flex",alignItems:"center",gap:8,justifyContent:"flex-end",overflow:"hidden",minWidth:0}}>
            {row.swatch&&<div style={{width:13,height:13,borderRadius:3,background:answers.color,flexShrink:0}}/>}
            <span style={{fontWeight:500,color:"#1A1A1A",textAlign:"right",fontSize:13,fontFamily:"system-ui,sans-serif",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{row.value}</span>
          </div>
          <button className="review-edit" onClick={()=>onEdit(row.q)}>Edit</button>
        </div>
      ))}
    </div>
  );
}

// ─── LAUNCH SCREEN ────────────────────────────────────────────────────────────
function LaunchScreen({answers,tmpl,onEdit}){
  const accent=answers.color||"#1A1A1A";
  const services=answers.services.map((s,i)=>({
    id:s.toLowerCase().replace(/\s+/g,"_"),label:s,
    description:["Professional service","Expert care","Tailored to you","Specialized treatment"][i%4],
    duration:(answers.serviceConfigs[s]||{}).duration||60,
    nextSlot:i===0?"Today, 2:15 PM":i===1?"Tomorrow, 10:00 AM":null,
  }));
  return(
    <div style={{minHeight:"100vh",background:"#F5F4F1",fontFamily:"system-ui,-apple-system,sans-serif"}}>
      <style>{`
        .ls *{box-sizing:border-box;}
        .ls-tile{background:#fff;border:2px solid #E5E4DF;border-radius:12px;padding:18px 20px;cursor:pointer;transition:border-color .15s;text-align:left;width:100%;font-family:inherit;}
        .ls-tile:hover{border-color:${accent};}
        @keyframes lsFade{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        .lf{animation:lsFade .35s ease forwards;}
        .lf2{animation:lsFade .35s .08s ease both;}
        .lf3{animation:lsFade .35s .16s ease both;}
      `}</style>
      <div className="ls">
        <header style={{background:"#fff",borderBottom:"1px solid #E5E4DF",padding:"0 28px",height:56,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            {answers.logoPreview?<img src={answers.logoPreview} alt="logo" style={{height:32,objectFit:"contain"}}/>
              :<div style={{width:32,height:32,borderRadius:8,background:accent,display:"flex",alignItems:"center",justifyContent:"center",fontSize:15}}>{tmpl?.icon||"⚙️"}</div>}
            <span style={{fontWeight:700,fontSize:16,letterSpacing:"-0.2px"}}>{answers.bizName||"Your Business"}</span>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:20}}>
            {answers.phone&&<span style={{fontSize:13,color:"#888"}}>{answers.phone}</span>}
            <button style={{background:accent,color:"#fff",border:"none",borderRadius:8,padding:"8px 18px",fontSize:13,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>Book now</button>
          </div>
        </header>

        <div style={{background:accent,padding:"52px 28px 44px",textAlign:"center"}} className="lf">
          <div style={{display:"inline-flex",alignItems:"center",gap:6,background:"rgba(255,255,255,0.18)",borderRadius:100,padding:"4px 12px",fontSize:11,fontWeight:600,color:"#fff",marginBottom:16}}>
            <span style={{width:5,height:5,borderRadius:"50%",background:"#fff",display:"inline-block"}}/>
            Online booking · Instant confirmation
          </div>
          <h1 style={{fontSize:"clamp(26px,5vw,46px)",fontWeight:700,letterSpacing:"-0.03em",color:"#fff",lineHeight:1.15,marginBottom:12}}>
            Book an appointment —<br/><span style={{opacity:0.6,fontWeight:400}}>in under 60 seconds.</span>
          </h1>
          <p style={{fontSize:15,color:"rgba(255,255,255,0.7)",maxWidth:460,margin:"0 auto 28px"}}>
            {answers.bizName||"Your Business"} · {tmpl?.label||"Professional Services"}{answers.location?` · ${answers.location}`:""}
          </p>
          <button style={{background:"#fff",color:accent,border:"none",borderRadius:10,padding:"14px 36px",fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"inherit"}}>Book now →</button>
        </div>

        <div style={{maxWidth:680,margin:"0 auto",padding:"36px 24px 60px"}}>
          <div style={{background:"#fff",borderRadius:16,border:"1px solid #E5E4DF",overflow:"hidden"}} className="lf2">
            <div style={{padding:"13px 22px",borderBottom:"1px solid #F0EFE9",display:"flex",alignItems:"center",gap:6}}>
              {[1,2,3,4,5].map(s=>(
                <div key={s} style={{display:"flex",alignItems:"center",gap:6}}>
                  <div style={{width:24,height:24,borderRadius:"50%",border:`2px solid ${s===1?accent:"#E5E4DF"}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,color:s===1?accent:"#ccc"}}>{s}</div>
                  {s<5&&<div style={{width:16,height:2,background:"#E5E4DF"}}/>}
                </div>
              ))}
            </div>
            <div style={{padding:"22px 24px 28px"}}>
              <div style={{marginBottom:22}}>
                <div style={{display:"inline-flex",alignItems:"center",gap:5,background:"#F0FAF4",border:"1px solid #B8E8CE",borderRadius:100,padding:"3px 10px",fontSize:11,fontWeight:600,color:"#2D9E6B",marginBottom:12}}>
                  <span style={{width:5,height:5,borderRadius:"50%",background:"#2D9E6B",display:"inline-block"}}/>
                  Online booking · Instant confirmation
                </div>
                <h2 style={{fontSize:22,fontWeight:700,letterSpacing:"-0.3px",margin:"0 0 4px"}}>
                  Book an appointment —<br/><span style={{color:"#aaa",fontWeight:500}}>in under 60 seconds.</span>
                </h2>
                <p style={{fontSize:12,color:"#aaa"}}>{tmpl?.label||"Services"} · Select a service below.</p>
              </div>
              <div style={{display:"grid",gap:9}}>
                {services.map(svc=>(
                  <button key={svc.id} className="ls-tile" style={{borderLeft:`3px solid ${accent}`}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                      <div>
                        <div style={{display:"flex",alignItems:"baseline",gap:8,marginBottom:3}}>
                          <span style={{fontWeight:700,fontSize:14}}>{svc.label}</span>
                          <span style={{fontSize:11,color:"#bbb"}}>{svc.duration} min</span>
                        </div>
                        <div style={{fontSize:12,color:"#999"}}>{svc.description}</div>
                        {svc.nextSlot&&(
                          <div style={{display:"flex",alignItems:"center",gap:4,marginTop:7,fontSize:11,color:"#2D9E6B",fontWeight:500}}>
                            <span style={{width:5,height:5,borderRadius:"50%",background:"#2D9E6B",display:"inline-block"}}/>
                            Next: {svc.nextSlot}
                          </div>
                        )}
                      </div>
                      <span style={{color:accent,fontSize:16,opacity:0.5}}>→</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {answers.note&&(
            <div style={{marginTop:14,background:"#fff",borderRadius:12,border:"1px solid #E5E4DF",padding:"16px 20px"}} className="lf3">
              <div style={{fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.5px",color:"#aaa",marginBottom:6}}>Before you book</div>
              <p style={{fontSize:14,color:"#555",lineHeight:1.6}}>{answers.note}</p>
            </div>
          )}

          <div style={{marginTop:36,paddingTop:24,borderTop:"1px solid #E5E4DF",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
            <div>
              <div style={{fontWeight:700,fontSize:14}}>{answers.bizName||"Your Business"}</div>
              {answers.location&&<div style={{fontSize:13,color:"#aaa",marginTop:2}}>{answers.location}</div>}
              {answers.phone&&<div style={{fontSize:13,color:"#aaa"}}>{answers.phone}</div>}
            </div>
            <button onClick={onEdit} style={{background:"none",border:"1px solid #E5E4DF",borderRadius:8,padding:"8px 16px",fontSize:12,color:"#aaa",cursor:"pointer",fontFamily:"inherit"}}>← Edit answers</button>
          </div>
        </div>
      </div>
    </div>
  );
}
